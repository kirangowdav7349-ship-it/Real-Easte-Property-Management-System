<?php
$pageTitle = 'Home Design & Construction Guide';
require_once 'includes/header.php';
?>
<link href="<?= SITE_URL ?>/assets/css/home-design.css" rel="stylesheet">

<div class="hd-banner">
  <div class="container">
    <div class="ai-badge"><i class="fas fa-microchip"></i> AI-Powered Design</div>
    <h1>🏠 Home Design & Construction Guide</h1>
    <p>Front elevation designs, material suggestions & step-by-step construction planner</p>
  </div>
</div>

<!-- ══════ HOUSE TYPE SELECTOR ══════ -->
<section class="py-4" style="background:var(--body-bg)">
  <div class="container">
    <h4 class="fw-bold text-center mb-4"><i class="fas fa-home me-2 text-accent"></i>Choose Your House Style</h4>
    <div class="house-type-grid" id="houseTypeGrid">
      <?php
      $types = [
        ['simple','Simple House','Budget-friendly single-story home','₹800-1200/sqft','🏡','#4CAF50'],
        ['modern','Modern House','Contemporary design with clean lines','₹1500-2500/sqft','🏢','#2196F3'],
        ['premium','Premium House','High-end finishes & smart features','₹2500-4000/sqft','🏰','#9C27B0'],
        ['luxury','Luxury Villa','Ultra-premium lifestyle villa','₹4000-8000/sqft','👑','#FF6B35'],
        ['duplex','Duplex House','Two-floor independent home','₹1800-3500/sqft','🏘️','#00BCD4'],
      ];
      foreach($types as $i=>$t): ?>
      <div class="house-type-card <?=$i===1?'active':''?>" data-type="<?=$t[0]?>" onclick="selectHouseType(this,'<?=$t[0]?>')">
        <div class="ht-icon" style="color:<?=$t[5]?>"><?=$t[4]?></div>
        <div class="ht-name"><?=$t[1]?></div>
        <div class="ht-desc"><?=$t[2]?></div>
        <div class="ht-cost" style="color:<?=$t[5]?>"><?=$t[3]?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════ PLANS VIEWER ══════ -->
<section class="py-5 bg-white">
  <div class="container">
    <!-- Plan Type Tabs -->
    <div class="plan-tabs-bar mb-3" id="planTabsBar">
      <button class="plan-tab active" data-plan="front" onclick="switchPlan(this,'front')"><i class="fas fa-home me-1"></i>Front View</button>
      <button class="plan-tab" data-plan="floor" onclick="switchPlan(this,'floor')"><i class="fas fa-th-large me-1"></i>Floor Plan</button>
      <button class="plan-tab" data-plan="elevation" onclick="switchPlan(this,'elevation')"><i class="fas fa-building me-1"></i>Elevation</button>
      <button class="plan-tab" data-plan="section" onclick="switchPlan(this,'section')"><i class="fas fa-layer-group me-1"></i>Section</button>
      <button class="plan-tab" data-plan="site" onclick="switchPlan(this,'site')"><i class="fas fa-map me-1"></i>Site Plan</button>
      <button class="plan-tab" data-plan="electrical" onclick="switchPlan(this,'electrical')"><i class="fas fa-bolt me-1"></i>Electrical</button>
      <button class="plan-tab" data-plan="plumbing" onclick="switchPlan(this,'plumbing')"><i class="fas fa-faucet me-1"></i>Plumbing</button>
    </div>
    <div class="row g-4">
      <div class="col-lg-7">
        <div class="elevation-card">
          <div class="elev-toolbar">
            <span class="fw-bold"><i class="fas fa-building me-2"></i><span id="planLabel">Front View</span> — <span id="elevType">Modern House</span></span>
            <div class="d-flex gap-2">
              <button class="elev-btn" onclick="downloadElevation()"><i class="fas fa-download me-1"></i>Save</button>
            </div>
          </div>
          <div style="position:relative;overflow:hidden;background:#f0f0f0">
            <img id="elevationImage" src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80" 
                 alt="Modern House Front View" 
                 style="width:100%;height:420px;object-fit:cover;transition:opacity .5s,transform .5s;display:block">
            <div id="elevOverlay" style="position:absolute;bottom:0;left:0;right:0;padding:18px 22px;background:linear-gradient(transparent,rgba(0,0,0,.7));color:white">
              <div style="font-size:.72rem;font-weight:600;text-transform:uppercase;letter-spacing:1px;opacity:.8;margin-bottom:4px" id="planSubLabel">Front Elevation Design</div>
              <div style="font-size:1.15rem;font-weight:800" id="elevTitle">Modern House</div>
              <div style="font-size:.78rem;opacity:.75;margin-top:2px" id="elevDesc">Contemporary flat-roof design with glass panels & minimalist facade</div>
            </div>
          </div>
          <!-- Feature Strip -->
          <div style="display:flex;background:#f8f9fb;border-top:1px solid #e5e7eb;overflow-x:auto" id="elevFeatures">
            <div class="elev-feat"><i class="fas fa-ruler-combined text-accent"></i><span>Flat Roof</span></div>
            <div class="elev-feat"><i class="fas fa-window-maximize text-info"></i><span>Large Windows</span></div>
            <div class="elev-feat"><i class="fas fa-paint-roller text-success"></i><span>Minimal Finish</span></div>
            <div class="elev-feat"><i class="fas fa-car text-warning"></i><span>Parking</span></div>
          </div>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="admin-card h-100">
          <h5 class="fw-bold mb-3"><i class="fas fa-calculator me-2 text-accent"></i>Budget Estimator</h5>
          <div class="mb-3">
            <label class="form-label small fw-bold">Plot Area (sq ft)</label>
            <input type="range" class="form-range" id="plotArea" min="500" max="5000" value="1500" oninput="updateBudget()">
            <div class="d-flex justify-content-between"><small class="text-muted">500</small><strong id="plotAreaVal" class="text-accent">1500 sqft</strong><small class="text-muted">5000</small></div>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-bold">Number of Floors</label>
            <select class="form-select form-select-sm" id="numFloorsBudget" onchange="updateBudget()">
              <option value="1">Ground Floor</option><option value="1.5">G + Half</option>
              <option value="2" selected>G + 1 Floor</option><option value="3">G + 2 Floors</option>
            </select>
          </div>
          <hr>
          <div class="budget-result" id="budgetResult">
            <div class="budget-row"><span>Built-up Area</span><strong id="builtArea">3000 sqft</strong></div>
            <div class="budget-row"><span>Structure Cost</span><strong id="structCost">—</strong></div>
            <div class="budget-row"><span>Finishing Cost</span><strong id="finishCost">—</strong></div>
            <div class="budget-row"><span>Misc (10%)</span><strong id="miscCost">—</strong></div>
            <div class="budget-row total"><span>Total Estimate</span><strong id="totalCost" class="text-accent">—</strong></div>
          </div>
          <button class="btn btn-accent w-100 mt-3 fw-bold" onclick="updateBudget()"><i class="fas fa-sync me-1"></i>Calculate</button>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ══════ MATERIAL SUGGESTIONS ══════ -->
<section class="py-5" style="background:var(--body-bg)">
  <div class="container">
    <h4 class="fw-bold text-center mb-1"><i class="fas fa-cubes me-2 text-accent"></i>Material Suggestions</h4>
    <p class="text-center text-muted mb-4" style="font-size:.88rem">Recommended materials for <strong id="matTypeName">Modern House</strong></p>
    <div class="row g-3" id="materialGrid"><!-- JS --></div>
  </div>
</section>

<!-- ══════ STEP-BY-STEP CONSTRUCTION ══════ -->
<section class="py-5 bg-white">
  <div class="container">
    <h4 class="fw-bold text-center mb-1"><i class="fas fa-hard-hat me-2 text-accent"></i>Step-by-Step Construction Guide</h4>
    <p class="text-center text-muted mb-4" style="font-size:.88rem">Complete construction timeline from start to finish</p>
    <div class="construction-timeline" id="timeline"><!-- JS --></div>
  </div>
</section>

<!-- ══════ PROPERTY VERIFICATION BADGE ══════ -->
<section class="py-5" style="background:linear-gradient(135deg,#0e1621,#1a3c5e)">
  <div class="container">
    <div class="row align-items-center g-4">
      <div class="col-lg-6 text-white">
        <h3 class="fw-bold mb-3">🛡️ Property Verification Badge</h3>
        <p class="opacity-75 mb-4">Our multi-level verification ensures trust. Properties go through rigorous checks before earning badges.</p>
        <div class="badge-levels">
          <?php
          $badges = [
            ['Basic Verified','Document check completed','fa-check-circle','#4CAF50','basic'],
            ['RERA Verified','RERA registration confirmed','fa-shield-alt','#2196F3','rera'],
            ['Legal Verified','Legal due diligence done','fa-gavel','#FF9800','legal'],
            ['Premium Verified','Physical inspection + all checks','fa-award','#9C27B0','premium'],
            ['PropNexus Certified','Highest trust — fully vetted','fa-certificate','#FF6B35','certified'],
          ];
          foreach($badges as $b): ?>
          <div class="badge-level-row">
            <div class="badge-icon-wrap" style="background:<?=$b[3]?>20;border-color:<?=$b[3]?>">
              <i class="fas <?=$b[2]?>" style="color:<?=$b[3]?>"></i>
            </div>
            <div>
              <div class="badge-name" style="color:<?=$b[3]?>"><?=$b[0]?></div>
              <div class="badge-desc"><?=$b[1]?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="verify-card">
          <h5 class="fw-bold mb-3"><i class="fas fa-search me-2 text-accent"></i>Verify a Property</h5>
          <form onsubmit="verifyProperty(event)">
            <div class="mb-3">
              <label class="form-label small fw-bold">Property ID or RERA Number</label>
              <input type="text" class="form-control" id="verifyInput" placeholder="Enter Property ID / RERA No." required>
            </div>
            <button type="submit" class="btn btn-accent w-100 fw-bold"><i class="fas fa-shield-alt me-1"></i>Check Verification Status</button>
          </form>
          <div id="verifyResult" class="mt-3" style="display:none"></div>
        </div>
      </div>
    </div>
  </div>
</section>

<script src="<?= SITE_URL ?>/assets/js/home-design.js"></script>
<?php require_once 'includes/footer.php'; ?>
