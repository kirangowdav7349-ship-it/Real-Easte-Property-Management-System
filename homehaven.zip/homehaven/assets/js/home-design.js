// ══════ HOME DESIGN JS ══════
var currentHouseType = 'modern';
var currentPlan = 'front';

// ── HOUSE TYPE SELECTION ──
function selectHouseType(el, type) {
  document.querySelectorAll('.house-type-card').forEach(function(c){c.classList.remove('active')});
  el.classList.add('active');
  currentHouseType = type;
  var names = {simple:'Simple House',modern:'Modern House',premium:'Premium House',luxury:'Luxury Villa',duplex:'Duplex House'};
  document.getElementById('elevType').textContent = names[type]||type;
  document.getElementById('matTypeName').textContent = names[type]||type;
  drawElevation();
  renderMaterials();
  updateBudget();
}

// ── PLAN TAB SWITCH ──
function switchPlan(el, plan) {
  document.querySelectorAll('.plan-tab').forEach(function(t){t.classList.remove('active')});
  el.classList.add('active');
  currentPlan = plan;
  var labels = {front:'Front View',floor:'Floor Plan',elevation:'Elevation Drawing',section:'Section Drawing',site:'Site Plan',electrical:'Electrical Plan',plumbing:'Plumbing Plan'};
  document.getElementById('planLabel').textContent = labels[plan]||plan;
  drawElevation();
}

// ══════════════════════════════════════════════════════════
// PLAN IMAGES — 7 plan types × 5 house types
// ══════════════════════════════════════════════════════════
var PLAN_DATA = {
  front: {
    simple: {img:'https://images.unsplash.com/photo-1518780664697-55e3ad937233?w=800&q=80',title:'Simple House — Front View',desc:'Budget-friendly facade with sloped roof, painted walls and basic landscaping',feats:[{i:'fa-home',c:'text-success',l:'Single Story'},{i:'fa-layer-group',c:'text-danger',l:'Sloped Roof'},{i:'fa-th-large',c:'text-warning',l:'Clay Tiles'},{i:'fa-leaf',c:'text-success',l:'Garden'}]},
    modern: {img:'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80',title:'Modern House — Front View',desc:'Contemporary flat-roof design with glass panels & minimalist facade',feats:[{i:'fa-ruler-combined',c:'text-accent',l:'Flat Roof'},{i:'fa-window-maximize',c:'text-info',l:'Large Windows'},{i:'fa-paint-roller',c:'text-success',l:'Minimal Finish'},{i:'fa-car',c:'text-warning',l:'Parking'}]},
    premium: {img:'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80',title:'Premium House — Front View',desc:'Grand bungalow with stone cladding, pillars and premium finishes',feats:[{i:'fa-columns',c:'text-primary',l:'Grand Pillars'},{i:'fa-gem',c:'text-danger',l:'Stone Cladding'},{i:'fa-wifi',c:'text-info',l:'Smart Home'},{i:'fa-hot-tub',c:'text-warning',l:'Luxury Bath'}]},
    luxury: {img:'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&q=80',title:'Luxury Villa — Front View',desc:'Ultra-premium villa with marble facade, landscaped gardens & pool',feats:[{i:'fa-crown',c:'text-warning',l:'Premium Marble'},{i:'fa-swimming-pool',c:'text-info',l:'Pool Area'},{i:'fa-shield-alt',c:'text-danger',l:'Security'},{i:'fa-tree',c:'text-success',l:'Landscape'}]},
    duplex: {img:'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=800&q=80',title:'Duplex House — Front View',desc:'Two-floor home with modern balcony, staircase & separate entrances',feats:[{i:'fa-building',c:'text-primary',l:'Two Floors'},{i:'fa-stairs',c:'text-accent',l:'Staircase'},{i:'fa-door-open',c:'text-success',l:'Balcony'},{i:'fa-expand-arrows-alt',c:'text-info',l:'Spacious'}]}
  },
  floor: {
    simple: {img:'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&q=80',title:'Simple House — Floor Plan',desc:'Open layout with 2BHK arrangement: living room, kitchen, bedrooms & bathroom',feats:[{i:'fa-bed',c:'text-primary',l:'2 Bedrooms'},{i:'fa-utensils',c:'text-danger',l:'Kitchen'},{i:'fa-couch',c:'text-info',l:'Living Room'},{i:'fa-bath',c:'text-warning',l:'1 Bathroom'}]},
    modern: {img:'https://images.unsplash.com/photo-1574362848149-11496d93a7c7?w=800&q=80',title:'Modern House — Floor Plan',desc:'Open-concept layout with island kitchen, master suite & utility room',feats:[{i:'fa-bed',c:'text-primary',l:'3 Bedrooms'},{i:'fa-utensils',c:'text-danger',l:'Modular Kitchen'},{i:'fa-couch',c:'text-info',l:'Open Living'},{i:'fa-car',c:'text-warning',l:'Garage'}]},
    premium: {img:'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&q=80',title:'Premium House — Floor Plan',desc:'Spacious layout with home office, walk-in closets & dedicated pooja room',feats:[{i:'fa-bed',c:'text-primary',l:'4 Bedrooms'},{i:'fa-laptop-house',c:'text-success',l:'Home Office'},{i:'fa-praying-hands',c:'text-warning',l:'Pooja Room'},{i:'fa-bath',c:'text-info',l:'3 Bathrooms'}]},
    luxury: {img:'https://images.unsplash.com/photo-1574362848149-11496d93a7c7?w=800&q=80',title:'Luxury Villa — Floor Plan',desc:'Expansive layout with home theater, gym, guest suite & servant quarters',feats:[{i:'fa-bed',c:'text-primary',l:'5+ Bedrooms'},{i:'fa-film',c:'text-danger',l:'Home Theater'},{i:'fa-dumbbell',c:'text-info',l:'Gym'},{i:'fa-swimming-pool',c:'text-warning',l:'Pool'}]},
    duplex: {img:'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&q=80',title:'Duplex — Floor Plan (Both Floors)',desc:'Ground: living, kitchen, guest room. First floor: master suite, bedrooms, study',feats:[{i:'fa-bed',c:'text-primary',l:'3 Bedrooms'},{i:'fa-utensils',c:'text-danger',l:'Kitchen'},{i:'fa-book',c:'text-info',l:'Study Room'},{i:'fa-bath',c:'text-warning',l:'2 Bathrooms'}]}
  },
  elevation: {
    simple: {img:'https://images.unsplash.com/photo-1449844908441-8829872d2607?w=800&q=80',title:'Simple House — Elevation Drawing',desc:'Side elevation showing roof pitch, window placement & floor height details',feats:[{i:'fa-arrows-alt-v',c:'text-primary',l:'10ft Height'},{i:'fa-window-maximize',c:'text-info',l:'Standard Windows'},{i:'fa-ruler-vertical',c:'text-danger',l:'Plinth Level'},{i:'fa-cloud-rain',c:'text-success',l:'Rain Gutters'}]},
    modern: {img:'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',title:'Modern House — Elevation Drawing',desc:'All-side elevation with material annotations, height dimensions & cladding details',feats:[{i:'fa-arrows-alt-v',c:'text-primary',l:'12ft Height'},{i:'fa-window-maximize',c:'text-info',l:'Floor-to-Ceiling'},{i:'fa-th',c:'text-warning',l:'ACP Cladding'},{i:'fa-lightbulb',c:'text-success',l:'Facade Lighting'}]},
    premium: {img:'https://images.unsplash.com/photo-1600607687644-aac4c3eac7f4?w=800&q=80',title:'Premium House — Elevation Drawing',desc:'Detailed elevation with stone texture, pillar sections & ornamental details',feats:[{i:'fa-arrows-alt-v',c:'text-primary',l:'14ft Height'},{i:'fa-columns',c:'text-warning',l:'Columns'},{i:'fa-gem',c:'text-danger',l:'Stone Work'},{i:'fa-border-style',c:'text-info',l:'Cornices'}]},
    luxury: {img:'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',title:'Luxury Villa — Elevation Drawing',desc:'Grand elevation showing double-height spaces, terrace gardens & canopy details',feats:[{i:'fa-arrows-alt-v',c:'text-primary',l:'18ft Double'},{i:'fa-tree',c:'text-success',l:'Terrace Garden'},{i:'fa-glass-martini',c:'text-danger',l:'Entertainment'},{i:'fa-sun',c:'text-warning',l:'Pergola'}]},
    duplex: {img:'https://images.unsplash.com/photo-1600607687644-aac4c3eac7f4?w=800&q=80',title:'Duplex — Elevation Drawing',desc:'Two-floor elevation with staircase profile, balcony railing & parapet details',feats:[{i:'fa-arrows-alt-v',c:'text-primary',l:'22ft Total'},{i:'fa-stairs',c:'text-accent',l:'Staircase'},{i:'fa-border-all',c:'text-info',l:'Railings'},{i:'fa-grip-horizontal',c:'text-warning',l:'Parapet'}]}
  },
  section: {
    simple: {img:'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800&q=80',title:'Simple House — Section Drawing',desc:'Cross-section showing foundation depth, wall thickness, roof structure & room heights',feats:[{i:'fa-expand-arrows-alt',c:'text-primary',l:'Wall 9" Thick'},{i:'fa-level-down-alt',c:'text-danger',l:'3ft Foundation'},{i:'fa-angle-double-up',c:'text-info',l:'Truss Roof'},{i:'fa-ruler-vertical',c:'text-success',l:'10ft Clearance'}]},
    modern: {img:'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&q=80',title:'Modern House — Section Drawing',desc:'Section through living room showing slab levels, beam depths & sunken areas',feats:[{i:'fa-expand-arrows-alt',c:'text-primary',l:'RCC 6" Slab'},{i:'fa-level-down-alt',c:'text-danger',l:'Sunken Floor'},{i:'fa-grip-lines',c:'text-info',l:'False Ceiling'},{i:'fa-lightbulb',c:'text-warning',l:'Cove Lights'}]},
    premium: {img:'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800&q=80',title:'Premium House — Section Drawing',desc:'Detailed section with insulation layers, waterproofing membranes & HVAC ducts',feats:[{i:'fa-shield-alt',c:'text-primary',l:'Insulation'},{i:'fa-water',c:'text-info',l:'Waterproofing'},{i:'fa-wind',c:'text-success',l:'HVAC Ducts'},{i:'fa-download',c:'text-warning',l:'Drainage'}]},
    luxury: {img:'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&q=80',title:'Luxury Villa — Section Drawing',desc:'Complex section with basement, double-height foyer, pool pit & terrace garden layers',feats:[{i:'fa-level-down-alt',c:'text-danger',l:'Basement'},{i:'fa-arrows-alt-v',c:'text-primary',l:'Double Height'},{i:'fa-swimming-pool',c:'text-info',l:'Pool Pit'},{i:'fa-leaf',c:'text-success',l:'Green Roof'}]},
    duplex: {img:'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800&q=80',title:'Duplex — Section Drawing',desc:'Section showing staircase construction, inter-floor slab & utility shaft details',feats:[{i:'fa-stairs',c:'text-accent',l:'Staircase RCC'},{i:'fa-grip-lines',c:'text-primary',l:'Inter Slab'},{i:'fa-columns',c:'text-warning',l:'Utility Shaft'},{i:'fa-border-all',c:'text-info',l:'Parapet Wall'}]}
  },
  site: {
    simple: {img:'https://images.unsplash.com/photo-1494526585095-c41746248156?w=800&q=80',title:'Simple House — Site Plan',desc:'Plot layout showing setbacks, driveway, garden area & boundary walls',feats:[{i:'fa-border-all',c:'text-primary',l:'Boundary Wall'},{i:'fa-road',c:'text-warning',l:'Driveway'},{i:'fa-seedling',c:'text-success',l:'Garden'},{i:'fa-arrows-alt',c:'text-info',l:'Setbacks'}]},
    modern: {img:'https://images.unsplash.com/photo-1448630360428-65456885c650?w=800&q=80',title:'Modern House — Site Plan',desc:'Comprehensive site plan with parking, landscape zones & utility connections',feats:[{i:'fa-car',c:'text-warning',l:'2-Car Parking'},{i:'fa-tree',c:'text-success',l:'Landscape'},{i:'fa-tint',c:'text-info',l:'Water Tank'},{i:'fa-plug',c:'text-danger',l:'Utilities'}]},
    premium: {img:'https://images.unsplash.com/photo-1494526585095-c41746248156?w=800&q=80',title:'Premium House — Site Plan',desc:'Detailed site plan with swimming pool placement, generator room & security cabin',feats:[{i:'fa-swimming-pool',c:'text-info',l:'Pool Area'},{i:'fa-bolt',c:'text-warning',l:'Generator'},{i:'fa-shield-alt',c:'text-danger',l:'Guard Room'},{i:'fa-tree',c:'text-success',l:'Lawn'}]},
    luxury: {img:'https://images.unsplash.com/photo-1448630360428-65456885c650?w=800&q=80',title:'Luxury Villa — Site Plan',desc:'Grand estate plan with guest house, pool, tennis court & multi-car parking',feats:[{i:'fa-home',c:'text-primary',l:'Guest House'},{i:'fa-table-tennis',c:'text-accent',l:'Tennis Court'},{i:'fa-parking',c:'text-warning',l:'Multi Parking'},{i:'fa-water',c:'text-info',l:'Water Feature'}]},
    duplex: {img:'https://images.unsplash.com/photo-1494526585095-c41746248156?w=800&q=80',title:'Duplex — Site Plan',desc:'Twin-unit site plan with separate entrances, shared driveway & garden partition',feats:[{i:'fa-door-open',c:'text-success',l:'2 Entrances'},{i:'fa-road',c:'text-warning',l:'Shared Drive'},{i:'fa-grip-vertical',c:'text-primary',l:'Partition'},{i:'fa-seedling',c:'text-info',l:'Gardens'}]}
  },
  electrical: {
    simple: {img:'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=800&q=80',title:'Simple House — Electrical Plan',desc:'Basic wiring layout with switch points, socket locations, DB board & earthing',feats:[{i:'fa-plug',c:'text-warning',l:'15A Sockets'},{i:'fa-toggle-on',c:'text-info',l:'Switch Points'},{i:'fa-server',c:'text-primary',l:'DB Board'},{i:'fa-bolt',c:'text-danger',l:'Earthing'}]},
    modern: {img:'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=800&q=80',title:'Modern House — Electrical Plan',desc:'Smart wiring with RCBO protection, USB outlets, cove lighting circuits & sensor wiring',feats:[{i:'fa-microchip',c:'text-info',l:'Smart Switches'},{i:'fa-lightbulb',c:'text-warning',l:'Cove Lights'},{i:'fa-usb',c:'text-primary',l:'USB Outlets'},{i:'fa-shield-alt',c:'text-danger',l:'RCBO'}]},
    premium: {img:'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=800&q=80',title:'Premium House — Electrical Plan',desc:'Advanced electrical with home automation wiring, UPS circuit & solar panel interface',feats:[{i:'fa-robot',c:'text-info',l:'Automation'},{i:'fa-battery-full',c:'text-success',l:'UPS Circuit'},{i:'fa-solar-panel',c:'text-warning',l:'Solar Ready'},{i:'fa-wifi',c:'text-primary',l:'Data Points'}]},
    luxury: {img:'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=800&q=80',title:'Luxury Villa — Electrical Plan',desc:'Full KNX automation, landscape lighting, pool electrical, elevator power & AV wiring',feats:[{i:'fa-microchip',c:'text-primary',l:'KNX System'},{i:'fa-film',c:'text-danger',l:'AV Wiring'},{i:'fa-elevator',c:'text-warning',l:'Elevator'},{i:'fa-swimming-pool',c:'text-info',l:'Pool Electric'}]},
    duplex: {img:'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=800&q=80',title:'Duplex — Electrical Plan',desc:'Dual-floor wiring with separate meters, staircase lighting & inter-floor distribution',feats:[{i:'fa-tachometer-alt',c:'text-warning',l:'2 Meters'},{i:'fa-lightbulb',c:'text-info',l:'Stair Lights'},{i:'fa-code-branch',c:'text-primary',l:'Distribution'},{i:'fa-bell',c:'text-danger',l:'Intercom'}]}
  },
  plumbing: {
    simple: {img:'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=800&q=80',title:'Simple House — Plumbing Plan',desc:'Basic cold & hot water supply lines, drainage layout & septic tank connection',feats:[{i:'fa-tint',c:'text-info',l:'Water Supply'},{i:'fa-arrow-down',c:'text-danger',l:'Drainage'},{i:'fa-toilet',c:'text-primary',l:'Fixtures'},{i:'fa-warehouse',c:'text-warning',l:'Septic Tank'}]},
    modern: {img:'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=800&q=80',title:'Modern House — Plumbing Plan',desc:'CPVC hot & cold lines, concealed drainage, rain water harvesting & STP connection',feats:[{i:'fa-tint',c:'text-info',l:'CPVC Lines'},{i:'fa-cloud-rain',c:'text-primary',l:'Rain Harvest'},{i:'fa-recycle',c:'text-success',l:'STP Ready'},{i:'fa-fire',c:'text-danger',l:'Hot Water'}]},
    premium: {img:'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=800&q=80',title:'Premium House — Plumbing Plan',desc:'Multi-point geyser lines, floor drain system, water softener & pressure pump layout',feats:[{i:'fa-fire',c:'text-danger',l:'Multi Geyser'},{i:'fa-tachometer-alt',c:'text-warning',l:'Pressure Pump'},{i:'fa-filter',c:'text-info',l:'Water Softener'},{i:'fa-arrow-down',c:'text-primary',l:'Floor Drains'}]},
    luxury: {img:'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=800&q=80',title:'Luxury Villa — Plumbing Plan',desc:'Central heating system, pool plumbing, fountain supply, grey water recycling & spa lines',feats:[{i:'fa-swimming-pool',c:'text-info',l:'Pool Plumbing'},{i:'fa-spa',c:'text-danger',l:'Spa Lines'},{i:'fa-recycle',c:'text-success',l:'Grey Water'},{i:'fa-fountain',c:'text-primary',l:'Fountain'}]},
    duplex: {img:'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=800&q=80',title:'Duplex — Plumbing Plan',desc:'Vertical stack system, overhead tank for both floors, separate bathroom risers',feats:[{i:'fa-arrows-alt-v',c:'text-primary',l:'Vertical Stack'},{i:'fa-database',c:'text-info',l:'OH Tank'},{i:'fa-code-branch',c:'text-warning',l:'Risers'},{i:'fa-toilet',c:'text-danger',l:'Dual Bath'}]}
  }
};

function drawElevation() {
  var planSet = PLAN_DATA[currentPlan] || PLAN_DATA.front;
  var data = planSet[currentHouseType] || planSet.modern;
  var img = document.getElementById('elevationImage');
  
  // Animate out
  img.style.opacity = '0';
  img.style.transform = 'scale(1.03)';
  
  setTimeout(function() {
    img.src = data.img;
    img.alt = data.title;
    document.getElementById('elevTitle').textContent = data.title;
    document.getElementById('elevDesc').textContent = data.desc;
    var subLabels = {front:'Front Elevation Design',floor:'Floor Plan Layout',elevation:'Elevation Drawing',section:'Section Drawing Detail',site:'Site Plan Layout',electrical:'Electrical Wiring Layout',plumbing:'Plumbing & Drainage Plan'};
    document.getElementById('planSubLabel').textContent = subLabels[currentPlan]||'Design';
    
    // Update features strip
    var featHtml = '';
    data.feats.forEach(function(f) {
      featHtml += '<div class="elev-feat"><i class="fas ' + f.i + ' ' + f.c + '"></i><span>' + f.l + '</span></div>';
    });
    document.getElementById('elevFeatures').innerHTML = featHtml;
    
    // Animate in
    img.style.opacity = '1';
    img.style.transform = 'scale(1)';
  }, 300);
}

function downloadElevation() {
  var img = document.getElementById('elevationImage');
  var a = document.createElement('a');
  a.href = img.src;
  a.download = 'PropNexus_' + currentPlan + '_' + currentHouseType + '.jpg';
  a.target = '_blank';
  a.click();
}

// ══════ MATERIALS ══════
var MATERIALS = {
  simple: [
    {icon:'🧱',name:'Bricks',detail:'Standard clay red bricks for walls',brand:'Local kiln bricks',price:'₹5-8/brick',color:'#E53935'},
    {icon:'🪨',name:'Cement',detail:'OPC 43 grade cement for foundations',brand:'UltraTech / ACC / Ambuja',price:'₹350-400/bag',color:'#607D8B'},
    {icon:'🏗️',name:'TMT Steel',detail:'Fe500 grade TMT bars for RCC',brand:'TATA Tiscon / JSW',price:'₹55-65/kg',color:'#37474F'},
    {icon:'🪵',name:'Wood',detail:'Sal wood for doors and windows',brand:'Local timber',price:'₹1500-2500/cft',color:'#795548'},
    {icon:'🔲',name:'Tiles',detail:'Ceramic floor tiles 2x2',brand:'Johnson / Kajaria',price:'₹25-40/sqft',color:'#FF9800'},
    {icon:'🎨',name:'Paint',detail:'Interior emulsion & exterior primer',brand:'Asian Paints / Berger',price:'₹150-250/ltr',color:'#9C27B0'},
  ],
  modern: [
    {icon:'🧱',name:'AAC Blocks',detail:'Lightweight autoclaved aerated concrete',brand:'Ultratech / Magicrete',price:'₹45-60/block',color:'#78909C'},
    {icon:'🪨',name:'Cement',detail:'PPC grade cement, eco-friendly',brand:'UltraTech / Birla',price:'₹380-420/bag',color:'#607D8B'},
    {icon:'🪟',name:'UPVC Windows',detail:'Double-glazed UPVC frames',brand:'Fenesta / Prominance',price:'₹450-700/sqft',color:'#2196F3'},
    {icon:'🏗️',name:'TMT Steel',detail:'Fe550 high-strength bars',brand:'TATA / Jindal',price:'₹65-75/kg',color:'#37474F'},
    {icon:'🔲',name:'Vitrified Tiles',detail:'Anti-skid 600x600 vitrified',brand:'Somany / Orient Bell',price:'₹45-80/sqft',color:'#FF9800'},
    {icon:'🎨',name:'Premium Paint',detail:'Weatherproof exterior & satin interior',brand:'Asian Royale / Dulux',price:'₹350-550/ltr',color:'#9C27B0'},
  ],
  premium: [
    {icon:'🧱',name:'Fly Ash Bricks',detail:'High-strength precision blocks',brand:'Premium manufacturers',price:'₹8-12/brick',color:'#78909C'},
    {icon:'🪟',name:'Aluminium Windows',detail:'Powder-coated aluminium with glass',brand:'Hindalco / Schuco',price:'₹600-1000/sqft',color:'#2196F3'},
    {icon:'🚿',name:'Premium Bath',detail:'Wall-hung WC, rain shower, glass partition',brand:'Kohler / Duravit',price:'₹50K-1.5L/set',color:'#00BCD4'},
    {icon:'🏗️',name:'Steel Fe600',detail:'Earthquake-resistant high-grade TMT',brand:'TATA Tiscon Super',price:'₹70-85/kg',color:'#37474F'},
    {icon:'🔲',name:'Italian Marble',detail:'Imported Statuario / Carrara marble',brand:'Italian imports',price:'₹200-800/sqft',color:'#FF9800'},
    {icon:'🏠',name:'Smart Home Kit',detail:'Automated lights, AC, security',brand:'Schneider / Legrand',price:'₹1-3L/home',color:'#4CAF50'},
  ],
  luxury: [
    {icon:'🪨',name:'Imported Marble',detail:'Calacatta Gold, Emperador Dark',brand:'Italy / Spain import',price:'₹500-2000/sqft',color:'#FF9800'},
    {icon:'🪟',name:'Designer Glass',detail:'Low-E tempered double glazing',brand:'Saint-Gobain',price:'₹800-1500/sqft',color:'#2196F3'},
    {icon:'🏠',name:'Home Automation',detail:'Full KNX/Crestron smart home',brand:'Crestron / Control4',price:'₹5-15L',color:'#4CAF50'},
    {icon:'🚿',name:'Luxury Fixtures',detail:'Designer faucets & bathtubs',brand:'Grohe / Hansgrohe',price:'₹2-8L/bath',color:'#00BCD4'},
    {icon:'🔐',name:'Security System',detail:'Biometric, CCTV, access control',brand:'Honeywell / Bosch',price:'₹2-5L',color:'#F44336'},
    {icon:'🌿',name:'Landscaping',detail:'Designer garden, water features',brand:'Professional landscape',price:'₹3-10L',color:'#2E7D32'},
  ],
  duplex: [
    {icon:'🧱',name:'AAC Blocks',detail:'Lightweight blocks for upper floor',brand:'Magicrete / Ultratech',price:'₹45-60/block',color:'#78909C'},
    {icon:'🏗️',name:'Staircase Steel',detail:'MS railing with glass panels',brand:'Custom fabrication',price:'₹800-1500/rft',color:'#37474F'},
    {icon:'🪟',name:'Sliding Windows',detail:'Aluminium sliding with mesh',brand:'Fenesta / Encraft',price:'₹500-800/sqft',color:'#2196F3'},
    {icon:'🔲',name:'Wooden Flooring',detail:'Engineered oak/teak planks - upper floor',brand:'Pergo / Greenply',price:'₹150-350/sqft',color:'#795548'},
    {icon:'🎨',name:'Texture Paint',detail:'Exterior texture + interior premium',brand:'Asian Paints Apex',price:'₹400-600/ltr',color:'#9C27B0'},
    {icon:'💡',name:'LED Lighting',detail:'Recessed, cove & pendant lighting',brand:'Philips / Havells',price:'₹50K-1.5L',color:'#FFC107'},
  ]
};

function renderMaterials() {
  var mats = MATERIALS[currentHouseType] || MATERIALS.modern;
  var html = '';
  mats.forEach(function(m){
    html += '<div class="col-lg-4 col-md-6"><div class="mat-card">' +
      '<div class="mat-icon" style="background:'+m.color+'15;color:'+m.color+'">'+m.icon+'</div>' +
      '<div class="mat-name">'+m.name+'</div><div class="mat-detail">'+m.detail+'</div>' +
      '<div class="mat-brand"><i class="fas fa-tag me-1"></i>'+m.brand+'</div>' +
      '<div class="mat-price"><i class="fas fa-rupee-sign me-1"></i>'+m.price+'</div>' +
    '</div></div>';
  });
  document.getElementById('materialGrid').innerHTML = html;
}

// ══════ BUDGET ══════
function updateBudget() {
  var area = parseInt(document.getElementById('plotArea').value)||1500;
  var floors = parseFloat(document.getElementById('numFloorsBudget').value)||2;
  document.getElementById('plotAreaVal').textContent = area+' sqft';
  var builtUp = Math.round(area*floors);
  var rates = {simple:1000,modern:2000,premium:3200,luxury:6000,duplex:2600};
  var rate = rates[currentHouseType]||2000;
  var struct = Math.round(builtUp*rate*0.6);
  var finish = Math.round(builtUp*rate*0.3);
  var misc = Math.round((struct+finish)*0.1);
  var total = struct+finish+misc;
  document.getElementById('builtArea').textContent = builtUp+' sqft';
  document.getElementById('structCost').textContent = fmt(struct);
  document.getElementById('finishCost').textContent = fmt(finish);
  document.getElementById('miscCost').textContent = fmt(misc);
  document.getElementById('totalCost').textContent = fmt(total);
}
function fmt(v){if(v>=10000000)return '\u20B9'+(v/10000000).toFixed(1)+' Cr';if(v>=100000)return '\u20B9'+(v/100000).toFixed(1)+' L';return '\u20B9'+v.toLocaleString('en-IN');}

// ══════ CONSTRUCTION TIMELINE ══════
var STEPS = [
  {title:'Land Survey & Soil Testing',dur:'1-2 Weeks',desc:'Site survey, soil testing, and topography mapping to understand ground conditions.',items:['Soil test report','Boundary marking','Contour survey']},
  {title:'Architectural Design & Approval',dur:'3-6 Weeks',desc:'Floor plan, elevation design, structural drawings, and municipality building plan approval.',items:['Floor plan','Elevation','Structural design','Building permit']},
  {title:'Foundation Work',dur:'2-4 Weeks',desc:'Excavation, PCC, footing, and plinth beam construction.',items:['Excavation','PCC','Footing RCC','Plinth beam','Waterproofing']},
  {title:'Plinth & Superstructure',dur:'4-8 Weeks',desc:'Brick/block masonry, columns, beams, and slab casting.',items:['Column casting','Wall masonry','Lintel','Slab RCC','Curing']},
  {title:'Brickwork & Rough Plaster',dur:'3-5 Weeks',desc:'Internal partition walls, rough plastering, and window/door frame fixing.',items:['Internal walls','Door frames','Window frames','Rough plaster']},
  {title:'Plumbing & Electrical',dur:'2-3 Weeks',desc:'Concealed plumbing, drainage piping, electrical conduits and wiring.',items:['Water lines','Drainage','Conduits','Wiring','DB box']},
  {title:'Flooring & Tiling',dur:'2-4 Weeks',desc:'Floor tile laying, bathroom wall tiles, kitchen counter, and staircase work.',items:['Floor tiles','Wall tiles','Kitchen slab','Staircase']},
  {title:'Woodwork & Fixtures',dur:'3-5 Weeks',desc:'Doors, windows, wardrobes, kitchen cabinets, and bathroom fittings.',items:['Main door','Internal doors','Wardrobes','Kitchen','Bathroom']},
  {title:'Painting & Finishing',dur:'2-3 Weeks',desc:'Wall putty, primer, paint (interior & exterior), and final touch-ups.',items:['Putty','Primer','Interior paint','Exterior paint','Cleaning']},
  {title:'Handover & Move In',dur:'1 Week',desc:'Final inspection, utility connections, and key handover.',items:['Inspection','Water/electricity','Occupancy cert','Key handover']},
];
function renderTimeline() {
  var html='';
  STEPS.forEach(function(s,i){
    html+='<div class="timeline-step" data-step="'+(i+1)+'"><div class="step-card">'+
      '<div class="step-title">'+s.title+'</div>'+
      '<div class="step-duration"><i class="fas fa-clock"></i> '+s.dur+'</div>'+
      '<div class="step-desc">'+s.desc+'</div>'+
      '<div class="step-items">'+s.items.map(function(it){return'<span class="step-item">'+it+'</span>';}).join('')+'</div>'+
    '</div></div>';
  });
  document.getElementById('timeline').innerHTML=html;
}

// ══════ VERIFY PROPERTY ══════
function verifyProperty(e) {
  e.preventDefault();
  var id = document.getElementById('verifyInput').value.trim();
  var badges = [
    {name:'Basic Verified',icon:'fa-check-circle',color:'#4CAF50'},
    {name:'RERA Verified',icon:'fa-shield-alt',color:'#2196F3'},
    {name:'Legal Verified',icon:'fa-gavel',color:'#FF9800'},
    {name:'Premium Verified',icon:'fa-award',color:'#9C27B0'},
    {name:'PropNexus Certified',icon:'fa-certificate',color:'#FF6B35'}
  ];
  var level = Math.floor(Math.random()*5);
  var b = badges[level];
  var checks = ['basic document','RERA registration','legal due diligence','physical inspection','full comprehensive'];
  var html = '<div class="verify-result-card" style="background:'+b.color+'12;border:1px solid '+b.color+'40;border-radius:12px;padding:18px">'+
    '<div class="d-flex align-items-center gap-3 mb-2"><i class="fas '+b.icon+' fs-3" style="color:'+b.color+'"></i>'+
    '<div><div class="fw-bold" style="color:'+b.color+'">'+b.name+'</div><small class="text-muted">ID: '+id+'</small></div></div>'+
    '<div style="font-size:.8rem;color:var(--text-muted)">This property has passed <strong>'+checks[level]+'</strong> verification. '+(level>=3?'It meets our highest standards of trust.':'Additional checks recommended for higher verification.')+'</div></div>';
  document.getElementById('verifyResult').innerHTML = html;
  document.getElementById('verifyResult').style.display = 'block';
}

// ══════ INIT ══════
document.addEventListener('DOMContentLoaded', function() {
  drawElevation();
  renderMaterials();
  renderTimeline();
  updateBudget();
});
