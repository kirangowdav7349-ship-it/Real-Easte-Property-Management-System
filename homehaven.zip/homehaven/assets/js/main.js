// EstatePro Main JS
document.addEventListener('DOMContentLoaded', function () {

  // Navbar scroll effect
  window.addEventListener('scroll', function () {
    const nav = document.getElementById('mainNav');
    if (nav) {
      if (window.scrollY > 50) {
        nav.style.background = '#1a2d3d';
        nav.style.boxShadow = '0 2px 12px rgba(0,0,0,0.25)';
      } else {
        nav.style.background = '';
        nav.style.boxShadow = '';
      }
    }
  });

  // Search tab toggle
  const searchTabs = document.querySelectorAll('.search-tabs .btn');
  const searchTypeInput = document.getElementById('searchType');
  searchTabs.forEach(btn => {
    btn.addEventListener('click', () => {
      searchTabs.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      if (searchTypeInput) searchTypeInput.value = btn.dataset.type;
    });
  });

  // Property image gallery
  const thumbs = document.querySelectorAll('.thumb-img');
  const mainImg = document.getElementById('mainPropImg');
  thumbs.forEach(thumb => {
    thumb.addEventListener('click', function () {
      if (mainImg) {
        var src = this.src;
        // Replace any ?w=NNN with ?w=800 for higher quality
        src = src.replace(/[?&]w=\d+/, function(m) { return m.charAt(0) + 'w=800'; });
        mainImg.src = src;
      }
      thumbs.forEach(t => t.classList.remove('active'));
      this.classList.add('active');
    });
  });

  // Counter animation
  const counters = document.querySelectorAll('.counter');
  counters.forEach(counter => {
    const target = parseInt(counter.innerText.replace(/[^0-9]/g, ''));
    let count = 0;
    const step = Math.ceil(target / 50);
    const timer = setInterval(() => {
      count += step;
      if (count >= target) {
        counter.innerText = counter.innerText.replace(/[0-9]+/, target);
        clearInterval(timer);
      } else {
        counter.innerText = counter.innerText.replace(/[0-9]+/, count);
      }
    }, 30);
  });

  // Auto-dismiss alerts
  setTimeout(() => {
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(a => a.classList.remove('show'));
  }, 4000);

  // EMI Calculator
  const calcBtn = document.getElementById('calcEMI');
  if (calcBtn) {
    calcBtn.addEventListener('click', function () {
      const P = parseFloat(document.getElementById('loanAmount').value);
      const r = parseFloat(document.getElementById('interestRate').value) / 12 / 100;
      const n = parseFloat(document.getElementById('tenure').value) * 12;
      const emi = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
      document.getElementById('emiResult').innerHTML =
        `<div class="alert alert-success mt-3">Monthly EMI: <strong>₹${Math.round(emi).toLocaleString('en-IN')}</strong><br>Total Amount: <strong>₹${Math.round(emi * n).toLocaleString('en-IN')}</strong></div>`;
    });
  }
});
