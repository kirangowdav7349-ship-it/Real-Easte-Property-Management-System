// PropNexus Admin JS
(function () {
  // Apply dark mode from cookie on load
  if (document.cookie.includes('hh_dark=1')) {
    document.getElementById('adminBody')?.classList.add('dark');
    const ico = document.getElementById('adminDarkIco');
    if (ico) ico.className = 'fas fa-sun';
  }
})();

function adminToggleDark() {
  const body = document.getElementById('adminBody');
  const on = !body.classList.contains('dark');
  body.classList.toggle('dark', on);
  document.cookie = 'hh_dark=' + (on ? 1 : 0) + ';path=/;max-age=31536000';
  const ico = document.getElementById('adminDarkIco');
  if (ico) ico.className = on ? 'fas fa-sun' : 'fas fa-moon';
}

function toggleSidebar() {
  const sb = document.getElementById('adminSidebar');
  if (sb) sb.classList.toggle('open');
}

// Close sidebar on outside click (mobile)
document.addEventListener('click', function (e) {
  const sb = document.getElementById('adminSidebar');
  const btn = document.querySelector('.sidebar-toggle');
  if (sb && btn && !sb.contains(e.target) && !btn.contains(e.target)) {
    if (window.innerWidth < 992) sb.classList.remove('open');
  }
});

// Global search
const gsInput = document.getElementById('globalSearch');
if (gsInput) {
  gsInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      window.location.href = 'properties.php?s=' + encodeURIComponent(this.value);
    }
  });
}

// Auto-dismiss alerts
document.querySelectorAll('.alert').forEach(function (el) {
  setTimeout(function () {
    el.style.transition = 'opacity .5s';
    el.style.opacity = '0';
    setTimeout(function () { el.remove(); }, 600);
  }, 4000);
});

// Confirm delete
document.querySelectorAll('[data-confirm]').forEach(function (el) {
  el.addEventListener('click', function (e) {
    if (!confirm(this.dataset.confirm || 'Are you sure?')) e.preventDefault();
  });
});

// Table row hover
document.querySelectorAll('.admin-table tbody tr').forEach(function (tr) {
  tr.style.cursor = 'default';
});
