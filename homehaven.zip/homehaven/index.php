<?php
$pageTitle = 'Buy, Rent & PG Properties — Zero Brokerage';
require_once 'includes/header.php';

// -- Ensure news_guides table has the 'status' column (safe to run on every load)
$conn->query("ALTER TABLE news_guides ADD COLUMN IF NOT EXISTS status ENUM('published','draft') DEFAULT 'published'");

$featuredProps = $conn->query("SELECT p.*, pi.image_url FROM properties p LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 WHERE p.featured=1 AND p.status='available' LIMIT 6");
$pgProps       = $conn->query("SELECT p.*, pi.image_url FROM properties p LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 WHERE p.listing_type='pg' AND p.status='available' LIMIT 6");
$topEstabs     = $conn->query("SELECT p.*, pi.image_url FROM properties p LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 WHERE p.featured=1 AND p.status='available' ORDER BY p.price DESC LIMIT 4");
$highDemand    = $conn->query("SELECT p.*, pi.image_url FROM properties p LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 WHERE p.status='available' ORDER BY p.views DESC, p.price DESC LIMIT 10");

try {
    $newsTable  = $conn->query("SHOW TABLES LIKE 'news_guides'")->num_rows;
    $latestNews = $newsTable ? $conn->query("SELECT * FROM news_guides WHERE status='published' ORDER BY views DESC LIMIT 3") : null;
} catch (Exception $e) {
    $latestNews = null;
}

$cities = ['Bangalore','Mumbai','Delhi','Hyderabad','Chennai','Pune','Kolkata','Noida','Gurgaon','Ahmedabad','Jaipur','Kochi'];

// PG tag assignment
$pgTagSets=[['guys','food','private'],['girls','food'],['guys','private'],['girls','coliving'],['guys','food','coliving'],['girls','private','food']];
$catColors=['news'=>'cat-news','guide'=>'cat-guide','tips'=>'cat-tips','market'=>'cat-market'];
$catLabel=['news'=>'News','guide'=>'Guide','tips'=>'Tips','market'=>'Market'];
?>

<style>
/* ── Consistent card heights & images ── */
.property-card .p-card-body{flex:1;display:flex;flex-direction:column;padding:14px}
.property-card .p-card-body .btn{margin-top:auto}
.prop-img-wrap{height:210px;overflow:hidden;position:relative;flex-shrink:0}
.prop-img-wrap img{width:100%;height:100%;object-fit:cover;transition:transform .4s}
.property-card:hover .prop-img-wrap img{transform:scale(1.04)}
.news-img-wrap img{width:100%;height:180px;object-fit:cover;transition:transform .4s}
.news-card:hover .news-img-wrap img{transform:scale(1.04)}
.pg-img-wrap{height:200px;overflow:hidden;position:relative;flex-shrink:0}
.pg-img-wrap img{width:100%;height:100%;object-fit:cover;transition:transform .4s}
.property-card:hover .pg-img-wrap img{transform:scale(1.04)}
.stat-item h3{font-size:2rem;font-weight:800;color:#fff;font-variant-numeric:tabular-nums}
.category-card img{height:78px!important;object-fit:cover}
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(216,35,42,.35)}70%{box-shadow:0 0 0 8px rgba(216,35,42,0)}100%{box-shadow:0 0 0 0 rgba(216,35,42,0)}}
.search-tab-btn.active{animation:pulse 2s infinite}
.reveal{opacity:0;transform:translateY(24px);transition:opacity .5s ease,transform .5s ease}
.reveal.visible{opacity:1;transform:none}

/* ── High Demand Slider (99acres style) ── */
.hd-slider{display:flex;gap:16px;overflow-x:auto;scroll-behavior:smooth;padding:8px 4px 12px;-ms-overflow-style:none;scrollbar-width:none}
.hd-slider::-webkit-scrollbar{display:none}
.hd-card{min-width:280px;max-width:300px;flex-shrink:0;border:1px solid var(--border);border-radius:10px;overflow:hidden;background:var(--card-bg);transition:box-shadow .25s,transform .25s;cursor:pointer}
.hd-card:hover{box-shadow:0 6px 24px rgba(0,0,0,.1);transform:translateY(-3px)}
.hd-img-wrap{position:relative;height:190px;overflow:hidden}
.hd-img-wrap img{width:100%;height:100%;object-fit:cover;transition:transform .4s}
.hd-card:hover .hd-img-wrap img{transform:scale(1.04)}
.hd-wishlist{position:absolute;top:10px;right:10px;width:32px;height:32px;background:rgba(255,255,255,.85);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#666;font-size:.9rem;transition:.2s;cursor:pointer;z-index:2}
.hd-wishlist:hover{background:#fff;color:var(--accent)}
.hd-rera{position:absolute;top:10px;left:10px;background:rgba(38,59,79,.88);color:#fff;font-size:.68rem;font-weight:700;padding:3px 10px;border-radius:3px;display:flex;align-items:center}
.hd-rera i{color:#4caf50;font-size:.72rem}
.hd-status{position:absolute;bottom:0;left:0;right:0;background:rgba(20,30,45,.75);color:#fff;font-size:.72rem;font-weight:600;padding:6px 12px;backdrop-filter:blur(4px)}
.hd-status.hd-ready{background:rgba(46,125,50,.8)}
.hd-body{padding:14px 14px 16px}
.hd-title{font-size:.9rem;font-weight:700;color:var(--text-main);margin-bottom:4px;line-height:1.35;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hd-loc{font-size:.78rem;color:var(--text-muted);margin-bottom:8px;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.hd-price{font-size:1.05rem;font-weight:800;color:var(--primary)}
.hd-price .rupee{font-weight:700;font-size:.92rem}
.hd-price small{font-size:.72rem;font-weight:400;color:var(--text-muted)}

/* Arrows — shared between all sliders */
.hd-arrow,.slider-arrow{position:absolute;top:50%;transform:translateY(-50%);z-index:5;width:38px;height:38px;border-radius:50%;border:1px solid var(--border);background:var(--card-bg);color:var(--text-main);display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 2px 10px rgba(0,0,0,.1);transition:.2s;font-size:.85rem}
.hd-arrow:hover,.slider-arrow:hover{background:var(--primary);color:#fff;border-color:var(--primary)}
.hd-arrow-left,.slider-arrow-left{left:-18px}
.hd-arrow-right,.slider-arrow-right{right:-18px}

/* ── Popular Cities Slider ── */
.cities-slider{display:flex;gap:20px;overflow-x:auto;scroll-behavior:smooth;padding:8px 4px 12px;-ms-overflow-style:none;scrollbar-width:none}
.cities-slider::-webkit-scrollbar{display:none}
.city-card{min-width:160px;max-width:180px;flex-shrink:0;cursor:pointer;text-decoration:none;transition:transform .25s}
.city-card:hover{transform:translateY(-4px)}
.city-card-img{width:100%;height:110px;border-radius:12px;object-fit:cover;box-shadow:0 2px 12px rgba(0,0,0,.1);transition:box-shadow .3s}
.city-card:hover .city-card-img{box-shadow:0 6px 20px rgba(0,0,0,.15)}
.city-card-name{font-size:.88rem;font-weight:700;color:var(--text-main);margin-top:10px;line-height:1.2}
.city-card-count{font-size:.74rem;color:var(--text-muted);margin-top:2px}



/* ── Post Property CTA Banner ── */
.cta-post-banner{background:linear-gradient(135deg,#f0faf4 0%,#e8f5ec 50%,#dff0e5 100%);border-radius:0;padding:48px 0;overflow:hidden;position:relative}
.cta-post-banner .cta-title{font-size:2rem;font-weight:800;color:#1a2d3d;line-height:1.25;margin-bottom:8px}
.cta-post-banner .cta-sub{font-size:.92rem;color:#555;margin-bottom:24px}
.cta-post-btn{background:#0078db;color:#fff;border:none;font-size:1.05rem;font-weight:700;padding:15px 36px;border-radius:6px;cursor:pointer;transition:.3s;display:inline-block;text-decoration:none}
.cta-post-btn:hover{background:#005fa3;color:#fff;box-shadow:0 6px 20px rgba(0,120,219,.3);transform:translateY(-2px)}
.cta-whatsapp{display:inline-flex;align-items:center;gap:6px;margin-top:14px;font-size:.88rem;font-weight:600;color:#333;text-decoration:none;transition:.2s}
.cta-whatsapp:hover{color:#25d366}
.cta-whatsapp img{width:22px;height:22px}
.cta-person-img{max-height:340px;object-fit:contain;position:relative;z-index:2;mix-blend-mode:multiply}

@media(max-width:768px){
  .hd-card{min-width:240px;max-width:260px}
  .hd-img-wrap{height:160px}
  .hd-arrow-left,.slider-arrow-left{left:-6px}
  .hd-arrow-right,.slider-arrow-right{right:-6px}
  .hd-arrow,.slider-arrow{width:32px;height:32px;font-size:.75rem}
  .city-card{min-width:130px;max-width:150px}
  .city-card-img{height:85px;border-radius:10px}
  .city-card-name{font-size:.8rem}

  .cta-post-banner{padding:32px 0}
  .cta-post-banner .cta-title{font-size:1.5rem}
  .cta-post-btn{padding:12px 28px;font-size:.92rem}
  .cta-person-img{max-height:250px}
}
@media(max-width:576px){
  .city-card{min-width:110px;max-width:130px}
  .city-card-img{height:70px;border-radius:8px}
  .city-card-name{font-size:.74rem}
  .city-card-count{font-size:.66rem}

  .cta-post-banner .cta-title{font-size:1.25rem}
}
</style>

<!-- ════════════════ HERO ════════════════ -->
<section class="hero-section">
  <div class="container">
    <div class="hero-title mb-2">Find Your Perfect Property</div>
    <p class="hero-subtitle mb-3">Buy · Rent · PG / Co-Living · <span style="color:var(--accent);font-weight:700">Zero Brokerage</span></p>

    <div class="d-flex justify-content-center mb-3 gap-2 flex-wrap">
      <button class="search-tab-btn active" onclick="setTab(this,'buy')">🏠 Buy</button>
      <button class="search-tab-btn" onclick="setTab(this,'rent')">🔑 Rent</button>
      <button class="search-tab-btn" onclick="setTab(this,'pg')">🛏️ PG / Co-Living</button>
      <button class="search-tab-btn" onclick="setTab(this,'commercial')">🏢 Commercial</button>
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-10">
        <form action="properties.php" method="GET" class="hero-search-box d-flex align-items-center gap-2 flex-wrap flex-md-nowrap p-2">
          <input type="hidden" name="type" id="searchType" value="buy">
          <select name="city" class="form-select fw-bold" style="max-width:160px">
            <option value="">🏙️ All Cities</option>
            <?php foreach($cities as $c): ?><option value="<?=$c?>"><?=$c?></option><?php endforeach; ?>
          </select>
          <input type="text" name="search" class="form-control flex-grow-1" placeholder="Search locality, project, landmark...">
          <select name="property_type" id="heroTypeSel" class="form-select fw-bold" style="max-width:155px">
            <option value="">All Types</option>
            <option value="apartment">Apartment</option>
            <option value="home">House</option>
            <option value="villa">Villa</option>
            <option value="site">Plot</option>
            <option value="commercial">Commercial</option>
            <option value="pg">PG</option>
          </select>
          <button type="submit" class="btn-search flex-shrink-0"><i class="fas fa-search me-1"></i>Search</button>
        </form>
      </div>
    </div>

    <div class="text-center mt-3">
      <small class="opacity-75 me-1">Popular:</small>
      <?php foreach(['Bangalore','Mumbai','Delhi','Hyderabad','Chennai','Pune'] as $c): ?>
      <a href="properties.php?city=<?=$c?>" class="text-white opacity-75 text-decoration-none me-2" style="font-size:.82rem;border-bottom:1px dashed rgba(255,255,255,.35)"><?=$c?></a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════ STATS ════════════════ -->
<section class="stats-section">
  <div class="container">
    <div class="row text-center">
      <?php foreach([['50,000+','Properties Listed','fa-building'],['25,000+','Happy Customers','fa-smile'],['100+','Cities Covered','fa-map-marker-alt'],['Zero','Brokerage Fee','fa-handshake']] as $s): ?>
      <div class="col-md-3 col-6 mb-3">
        <div class="stat-item">
          <i class="fas <?=$s[2]?> fs-2 mb-2 text-accent"></i>
          <h3 class="mb-0"><?=$s[0]?></h3>
          <p class="mb-0 opacity-75 small"><?=$s[1]?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════ TYPES ════════════════ -->
<section class="py-5 bg-white">
  <div class="container reveal">
    <h2 class="section-title text-center mb-4">Browse by Type</h2>
    <div class="row g-3">
      <?php foreach([['buy','home','🏠 House','#d8232a','https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=400'],['buy','apartment','🏢 Apartment','#263b4f','https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=400'],['buy','villa','🏰 Villa','#2e7d32','https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=400'],['buy','site','🌿 Plot','#6a1b9a','https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=400'],['commercial','commercial','🏬 Commercial','#d84315','https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=400'],['pg','pg','🛏️ PG / Co-Living','#e65100','https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400']] as $c): ?>
      <div class="col-lg-2 col-md-4 col-6">
        <a href="properties.php?type=<?=$c[0]?>&property_type=<?=$c[1]?>" class="text-decoration-none">
          <div class="category-card">
            <img src="<?=$c[4]?>" class="w-100 rounded-3 mb-2" style="height:78px;object-fit:cover">
            <div style="color:<?=$c[3]?>;font-weight:700;font-size:.86rem"><?=$c[2]?></div>
          </div>
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════════════════ EXPLORE POPULAR CITIES (Slider) ════════════════ -->
<section class="py-5 bg-white">
  <div class="container reveal">
    <h2 class="section-title mb-1" style="font-weight:800;color:var(--primary)">Explore Real Estate in Popular Indian Cities</h2>
    <p class="section-sub mb-3">Find properties across India's top metropolitan cities</p>

    <div class="position-relative">
      <button class="slider-arrow slider-arrow-left" onclick="sliderScroll('citiesSlider',-1)" aria-label="Scroll left">
        <i class="fas fa-chevron-left"></i>
      </button>
      <button class="slider-arrow slider-arrow-right" onclick="sliderScroll('citiesSlider',1)" aria-label="Scroll right">
        <i class="fas fa-chevron-right"></i>
      </button>

      <div class="cities-slider" id="citiesSlider">
        <?php
        $cityData = [
          ['Delhi / NCR',   '180,000+', 'https://images.unsplash.com/photo-1587474260584-136574528ed5?w=400&h=300&fit=crop', 'delhi'],
          ['Bangalore',     '56,000+',  'assets/uploads/cities/bangalore.png', 'bangalore'],
          ['Pune',          '40,000+',  'assets/uploads/cities/pune.png', 'pune'],
          ['Chennai',       '42,000+',  'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=400&h=300&fit=crop', 'chennai'],
          ['Mumbai',        '45,000+',  'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=400&h=300&fit=crop', 'mumbai'],
          ['Hyderabad',     '31,000+',  'assets/uploads/cities/hyderabad.png', 'hyderabad'],
          ['Kolkata',       '35,000+',  'https://images.unsplash.com/photo-1536421469767-80559bb6f5e1?w=400&h=300&fit=crop', 'kolkata'],
          ['Ahmedabad',     '23,000+',  'assets/uploads/cities/ahmedabad.png', 'ahmedabad'],
          ['Jaipur',        '18,000+',  'https://images.unsplash.com/photo-1599661046289-e31897846e41?w=400&h=300&fit=crop', 'jaipur'],
          ['Noida',         '28,000+',  'assets/uploads/cities/noida.png', 'noida'],
          ['Gurgaon',       '25,000+',  'assets/uploads/cities/gurgaon.png', 'gurgaon'],
          ['Kochi',         '12,000+',  'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=400&h=300&fit=crop', 'kochi'],
        ];
        foreach($cityData as $cd): ?>
        <a href="properties.php?city=<?=$cd[3]?>" class="city-card">
          <img src="<?=$cd[2]?>" alt="<?=$cd[0]?>" class="city-card-img">
          <div class="city-card-name"><?=$cd[0]?></div>
          <div class="city-card-count"><?=$cd[1]?> Properties</div>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ════════════════ POST PROPERTY CTA BANNER ════════════════ -->
<section class="cta-post-banner">
  <div class="container reveal">
    <div class="row align-items-center">
      <div class="col-lg-7 col-md-6">
        <h2 class="cta-title">Sell or rent faster at the right price!</h2>
        <p class="cta-sub">Your perfect buyer is waiting, list your property now</p>
        <a href="<?=isClientLoggedIn()?'client/add-property.php':'client/login.php'?>" class="cta-post-btn">
          Post Property, It's FREE
        </a>
        <div>
          <a href="#" class="cta-whatsapp">
            Post via <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp"> Whatsapp →
          </a>
        </div>
      </div>
      <div class="col-lg-5 col-md-6 text-center mt-4 mt-md-0">
        <img src="assets/uploads/post_property_cta.png" alt="Post your property" class="cta-person-img">
      </div>
    </div>
  </div>
</section>



<!-- ════════════════ PROJECTS IN HIGH DEMAND (Slider) ════════════════ -->
<?php if($highDemand && $highDemand->num_rows > 0): ?>
<section class="py-5 bg-white">
  <div class="container reveal">
    <div class="d-flex justify-content-between align-items-center mb-1">
      <div>
        <h2 class="section-title mb-1" style="color:var(--primary);font-weight:800">Projects in High Demand</h2>
        <p class="section-sub mb-0">The most explored projects near you</p>
      </div>
      <a href="properties.php" class="btn btn-outline-primary btn-sm px-4" style="border-radius:4px">View All →</a>
    </div>

    <div class="position-relative mt-3">
      <!-- Left Arrow -->
      <button class="hd-arrow hd-arrow-left" onclick="hdScroll(-1)" aria-label="Scroll left">
        <i class="fas fa-chevron-left"></i>
      </button>
      <!-- Right Arrow -->
      <button class="hd-arrow hd-arrow-right" onclick="hdScroll(1)" aria-label="Scroll right">
        <i class="fas fa-chevron-right"></i>
      </button>

      <div class="hd-slider" id="hdSlider">
        <?php
        $hdStatuses = ['Ready To Move','Possession from Jun 2027','Under Construction','Ready To Move','Possession from Dec 2026','Ready To Move','Under Construction','Possession from Mar 2028','Ready To Move','Possession from Sep 2027'];
        $hdIdx = 0;
        while($hd = $highDemand->fetch_assoc()):
          $statusText = $hdStatuses[$hdIdx % count($hdStatuses)];
          $isReady = strpos($statusText, 'Ready') !== false;
        ?>
        <div class="hd-card">
          <a href="property-detail.php?id=<?=$hd['id']?>" class="text-decoration-none">
            <div class="hd-img-wrap">
              <img src="<?=$hd['image_url']?:'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=600'?>" alt="<?=htmlspecialchars($hd['title'])?>">
              <span class="hd-wishlist"><i class="far fa-heart"></i></span>
              <span class="hd-rera"><i class="fas fa-check-circle me-1"></i>RERA</span>
              <span class="hd-status <?=$isReady?'hd-ready':''?>"><?=$statusText?></span>
            </div>
            <div class="hd-body">
              <h6 class="hd-title"><?=$hd['title']?></h6>
              <p class="hd-loc">
                <?php
                  $beds = $hd['bedrooms'] > 0 ? $hd['bedrooms'] . ' BHK' : '';
                  $ptype = ucfirst($hd['property_type'] ?? 'Apartment');
                  echo trim("$beds $ptype") . ' in ' . $hd['location'] . ', ' . $hd['city'];
                ?>
              </p>
              <div class="hd-price">
                <span class="rupee">₹</span> <?=formatPrice($hd['price'])?><?=in_array($hd['listing_type'],['rent','pg'])?' <small>/mo</small>':''?>
              </div>
            </div>
          </a>
        </div>
        <?php $hdIdx++; endwhile; ?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ════════════════ FEATURED PROPERTIES (Slider) ════════════════ -->
<section class="py-5" style="background:var(--body-bg)">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4 reveal">
      <div>
        <h2 class="section-title mb-0">⭐ Featured Properties</h2>
        <p class="section-sub mb-0">Hand-picked premium listings</p>
      </div>
      <a href="properties.php" class="btn btn-outline-primary btn-sm px-4 rounded-pill">View All →</a>
    </div>
    <div class="position-relative reveal">
      <button class="slider-arrow slider-arrow-left" onclick="sliderScroll('featuredSlider',-1)" aria-label="Scroll left">
        <i class="fas fa-chevron-left"></i>
      </button>
      <button class="slider-arrow slider-arrow-right" onclick="sliderScroll('featuredSlider',1)" aria-label="Scroll right">
        <i class="fas fa-chevron-right"></i>
      </button>
      <div class="hd-slider" id="featuredSlider">
        <?php while($p=$featuredProps->fetch_assoc()): ?>
        <div class="hd-card" style="min-width:310px;max-width:340px">
          <a href="property-detail.php?id=<?=$p['id']?>" class="text-decoration-none">
            <div class="prop-img-wrap" style="height:190px">
              <img src="<?=$p['image_url']?:'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800'?>" alt="<?=htmlspecialchars($p['title'])?>">
              <span class="prop-tag" style="background:<?=$p['listing_type']==='pg'?'#6a1b9a':($p['listing_type']==='rent'?'#1565c0':'#2e7d32')?>;color:white"><?=strtoupper($p['listing_type'])?></span>
              <span class="prop-badge-right"><span class="badge bg-warning text-dark">⭐ Featured</span></span>
            </div>
            <div class="hd-body">
              <h6 class="hd-title"><?=$p['title']?></h6>
              <p class="hd-loc"><i class="fas fa-map-marker-alt me-1 text-danger"></i><?=$p['location']?>, <?=$p['city']?></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="hd-price"><span class="rupee">₹</span> <?=formatPrice($p['price'])?><?=in_array($p['listing_type'],['rent','pg'])?' <small>/mo</small>':''?></div>
                <div class="prop-features" style="border:none;padding:0;margin:0;gap:10px">
                  <?php if($p['bedrooms']>0): ?><span><i class="fas fa-bed"></i><?=$p['bedrooms']?></span><?php endif; ?>
                  <?php if($p['bathrooms']>0): ?><span><i class="fas fa-bath"></i><?=$p['bathrooms']?></span><?php endif; ?>
                  <?php if($p['area']): ?><span><i class="fas fa-ruler-combined"></i><?=$p['area']?></span><?php endif; ?>
                </div>
              </div>
            </div>
          </a>
        </div>
        <?php endwhile; ?>
      </div>
    </div>
  </div>
</section>

<!-- ════════════════ PG / CO-LIVING (Slider) ════════════════ -->
<section class="py-5 bg-white">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-2 reveal">
      <div>
        <h2 class="section-title mb-1">🛏️ PG / Co-Living</h2>
        <p class="section-sub mb-0">Verified PGs with food, WiFi & housekeeping</p>
      </div>
      <a href="properties.php?type=pg" class="btn btn-outline-primary btn-sm px-4 rounded-pill">View All →</a>
    </div>

    <div class="d-flex gap-2 mt-3 mb-4 flex-wrap reveal">
      <button class="pg-pill active" onclick="pgFilter(this,'all')">🏠 All</button>
      <button class="pg-pill" onclick="pgFilter(this,'guys')">👨 For Guys</button>
      <button class="pg-pill" onclick="pgFilter(this,'girls')">👩 For Girls</button>
      <button class="pg-pill" onclick="pgFilter(this,'food')">🍽️ Food Available</button>
      <button class="pg-pill" onclick="pgFilter(this,'private')">🔒 Private Room</button>
      <button class="pg-pill" onclick="pgFilter(this,'coliving')">🤝 Co-Living</button>
    </div>

    <div class="position-relative reveal">
      <button class="slider-arrow slider-arrow-left" onclick="sliderScroll('pgSlider',-1)" aria-label="Scroll left">
        <i class="fas fa-chevron-left"></i>
      </button>
      <button class="slider-arrow slider-arrow-right" onclick="sliderScroll('pgSlider',1)" aria-label="Scroll right">
        <i class="fas fa-chevron-right"></i>
      </button>
      <div class="hd-slider" id="pgSlider">
        <?php
        $pgi=0;
        while($p=$pgProps->fetch_assoc()):
          $tags=$pgTagSets[$pgi%6];
        ?>
        <div class="hd-card pg-item" data-tags="<?=implode(',',$tags)?>" style="min-width:290px;max-width:320px">
          <a href="property-detail.php?id=<?=$p['id']?>" class="text-decoration-none">
            <div class="hd-img-wrap" style="height:180px">
              <img src="<?=$p['image_url']?:'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800'?>" alt="<?=htmlspecialchars($p['title'])?>">
              <div style="position:absolute;top:8px;left:8px;display:flex;gap:4px;flex-wrap:wrap;z-index:2">
                <?php if(in_array('guys',$tags)): ?><span class="badge" style="background:#1a3c5e;font-size:.67rem">👨 Boys</span><?php endif; ?>
                <?php if(in_array('girls',$tags)): ?><span class="badge bg-danger" style="font-size:.67rem">👩 Girls</span><?php endif; ?>
                <?php if(in_array('food',$tags)): ?><span class="badge bg-success" style="font-size:.67rem">🍽️ Food</span><?php endif; ?>
                <?php if(in_array('private',$tags)): ?><span class="badge bg-warning text-dark" style="font-size:.67rem">🔒 Private</span><?php endif; ?>
                <?php if(in_array('coliving',$tags)): ?><span class="badge bg-info" style="font-size:.67rem">🤝 Co-Living</span><?php endif; ?>
              </div>
            </div>
            <div class="hd-body">
              <h6 class="hd-title"><?=$p['title']?></h6>
              <p class="hd-loc"><i class="fas fa-map-marker-alt me-1 text-danger"></i><?=$p['location']?>, <?=$p['city']?></p>
              <div class="hd-price"><span class="rupee">₹</span> <?=formatPrice($p['price'])?> <small>/mo</small></div>
            </div>
          </a>
        </div>
        <?php $pgi++; endwhile; ?>
      </div>
    </div>
  </div>
</section>

<!-- ════════════════ HANDPICKED COLLECTIONS (Slider) ════════════════ -->
<section class="py-5" style="background:linear-gradient(135deg,#263b4f,#1a2d3d)">
  <div class="container">
    <div class="text-center mb-4 reveal">
      <h2 class="text-white fw-bold mb-1">✨ Our Handpicked Collections</h2>
      <p class="text-white opacity-75 mb-0">Curated for every lifestyle & budget</p>
    </div>
    <div class="position-relative reveal">
      <button class="slider-arrow slider-arrow-left" onclick="sliderScroll('collSlider',-1)" aria-label="Scroll left" style="background:rgba(255,255,255,.15);border-color:rgba(255,255,255,.2);color:#fff">
        <i class="fas fa-chevron-left"></i>
      </button>
      <button class="slider-arrow slider-arrow-right" onclick="sliderScroll('collSlider',1)" aria-label="Scroll right" style="background:rgba(255,255,255,.15);border-color:rgba(255,255,255,.2);color:#fff">
        <i class="fas fa-chevron-right"></i>
      </button>
      <div class="cities-slider" id="collSlider">
        <?php foreach([
          ['👨 For Guys',        'Best PGs for working men',          'properties.php?type=pg&pg_for=guys',  '#d8232a','https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=200'],
          ['👩 For Girls',       'Safe PGs for women',                'properties.php?type=pg&pg_for=girls', '#e91e63','https://images.unsplash.com/photo-1560185007-cde436f6a4d0?w=200'],
          ['🍽️ Food Available', 'Home-cooked daily meals',           'properties.php?type=pg&food=1',        '#2e7d32','https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=200'],
          ['🔒 Private Room',    'Total privacy guaranteed',          'properties.php?type=pg&room=private',  '#6a1b9a','https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=200'],
          ['🏆 Top in City',     'Best-rated properties',             'properties.php?featured=1',            '#e65100','https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=200'],
          ['💸 Budget Pick',     'Quality under ₹10k/month',         'properties.php?max_price=10000',       '#0078db','https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=200'],
        ] as $col): ?>
        <a href="<?=$col[2]?>" class="text-decoration-none" style="min-width:150px;max-width:170px;flex-shrink:0">
          <div class="coll-card">
            <img src="<?=$col[4]?>" style="border-color:<?=$col[3]?>">
            <div class="text-white fw-bold" style="font-size:.84rem"><?=$col[0]?></div>
            <div class="text-white opacity-70" style="font-size:.72rem;margin-top:3px"><?=$col[1]?></div>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ════════════════ TOP ESTABLISHMENTS (Slider) ════════════════ -->
<section class="py-5 bg-white">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4 reveal">
      <div>
        <h2 class="section-title mb-1">🏆 Top Establishments in City</h2>
        <p class="section-sub mb-0">Highest-rated & most-booked</p>
      </div>
      <a href="properties.php?featured=1" class="btn btn-outline-warning btn-sm px-4 rounded-pill">View All →</a>
    </div>
    <div class="position-relative reveal">
      <button class="slider-arrow slider-arrow-left" onclick="sliderScroll('topSlider',-1)" aria-label="Scroll left">
        <i class="fas fa-chevron-left"></i>
      </button>
      <button class="slider-arrow slider-arrow-right" onclick="sliderScroll('topSlider',1)" aria-label="Scroll right">
        <i class="fas fa-chevron-right"></i>
      </button>
      <div class="hd-slider" id="topSlider">
        <?php while($p=$topEstabs->fetch_assoc()): ?>
        <div class="hd-card" style="min-width:280px;max-width:300px">
          <a href="property-detail.php?id=<?=$p['id']?>" class="text-decoration-none">
            <div class="hd-img-wrap">
              <img src="<?=$p['image_url']?:'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800'?>" alt="<?=htmlspecialchars($p['title'])?>">
              <span class="prop-tag" style="background:#FF8C00;color:white">🏆 Top Pick</span>
              <span style="position:absolute;bottom:8px;right:8px;z-index:2"><span class="badge bg-success">⭐ 4.9</span></span>
            </div>
            <div class="hd-body">
              <h6 class="hd-title"><?=$p['title']?></h6>
              <p class="hd-loc"><i class="fas fa-map-marker-alt me-1 text-danger"></i><?=$p['location']?>, <?=$p['city']?></p>
              <div class="hd-price"><span class="rupee">₹</span> <?=formatPrice($p['price'])?><?=in_array($p['listing_type'],['rent','pg'])?' <small>/mo</small>':''?></div>
            </div>
          </a>
        </div>
        <?php endwhile; ?>
      </div>
    </div>
  </div>
</section>



<!-- ════════════════ LOAN PROCESS CTA ════════════════ -->
<section class="py-5" style="background:var(--body-bg)">
  <div class="container reveal">
    <h2 class="section-title text-center mb-1">💰 Property Loan Approval</h2>
    <p class="section-sub text-center mb-4">Apply, upload documents & track your loan in real-time</p>
    <div class="row g-3 justify-content-center">
      <?php
      $loanSteps = [
        ['📝', 'Apply', 'Fill application form', '#d8232a'],
        ['📄', 'Upload Docs', 'Submit required documents', '#263b4f'],
        ['🔍', 'Verification', 'Documents reviewed by bank', '#2e7d32'],
        ['✅', 'Approval', 'Get loan sanctioned', '#6a1b9a'],
        ['📊', 'Track Status', 'Real-time tracking', '#e65100'],
      ];
      foreach($loanSteps as $i => $step): ?>
      <div class="col-lg-2 col-md-4 col-6">
        <div class="text-center p-3 rounded-4 bg-white h-100" style="border:2px solid transparent;transition:.3s;box-shadow:0 2px 10px rgba(0,0,0,.05);position:relative" onmouseover="this.style.borderColor='<?=$step[3]?>';this.style.transform='translateY(-4px)'" onmouseout="this.style.borderColor='transparent';this.style.transform='none'">
          <div style="font-size:2.2rem;margin-bottom:8px"><?=$step[0]?></div>
          <div class="fw-bold" style="font-size:.85rem;color:<?=$step[3]?>"><?=$step[1]?></div>
          <div style="font-size:.72rem;color:var(--text-muted)"><?=$step[2]?></div>
          <?php if($i < 4): ?><div style="position:absolute;right:-18px;top:50%;transform:translateY(-50%);font-size:1.2rem;color:#ccc;z-index:1" class="d-none d-lg-block">→</div><?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="text-center mt-4">
      <a href="loans.php" class="btn btn-accent btn-lg px-5 rounded-pill fw-bold shadow-sm">
        <i class="fas fa-file-invoice-dollar me-2"></i>Apply for Loan Now
      </a>
    </div>
  </div>
</section>

<!-- ════════════════ LEGAL PROCESS CTA ════════════════ -->
<section class="py-5 bg-white">
  <div class="container reveal">
    <h2 class="section-title text-center mb-1">⚖️ Legal Services Process</h2>
    <p class="section-sub text-center mb-4">Get legally valid documents — quick, transparent & tracked step by step</p>
    <div class="row g-3 justify-content-center">
      <?php
      $legalSteps = [
        ['📋', 'Choose Service', 'Pick the legal service', '#d8232a'],
        ['📝', 'Submit Details', 'Fill your property info', '#263b4f'],
        ['👨‍⚖️', 'Expert Review', 'Lawyer verifies documents', '#2e7d32'],
        ['📄', 'Draft & Stamp', 'Legal docs prepared', '#6a1b9a'],
        ['✅', 'Delivered', 'Get stamped documents', '#e65100'],
      ];
      foreach($legalSteps as $i => $step): ?>
      <div class="col-lg-2 col-md-4 col-6">
        <div class="text-center p-3 rounded-4 h-100" style="background:var(--body-bg,#f5f7ff);border:2px solid transparent;transition:.3s;box-shadow:0 2px 10px rgba(0,0,0,.05);position:relative" onmouseover="this.style.borderColor='<?=$step[3]?>';this.style.transform='translateY(-4px)'" onmouseout="this.style.borderColor='transparent';this.style.transform='none'">
          <div style="font-size:2.2rem;margin-bottom:8px"><?=$step[0]?></div>
          <div class="fw-bold" style="font-size:.85rem;color:<?=$step[3]?>"><?=$step[1]?></div>
          <div style="font-size:.72rem;color:var(--text-muted)"><?=$step[2]?></div>
          <?php if($i < 4): ?><div style="position:absolute;right:-18px;top:50%;transform:translateY(-50%);font-size:1.2rem;color:#ccc;z-index:1" class="d-none d-lg-block">→</div><?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="text-center mt-4">
      <a href="legal.php" class="btn btn-lg px-5 rounded-pill fw-bold shadow-sm" style="background:#1a3c5e;color:#fff;border:none">
        <i class="fas fa-gavel me-2"></i>Explore Legal Services
      </a>
    </div>
  </div>
</section>
<?php if($latestNews && $latestNews->num_rows > 0): ?>
<section class="py-5 bg-white">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4 reveal">
      <div>
        <h2 class="section-title mb-1">📰 Latest News & Guides</h2>
        <p class="section-sub mb-0">Real estate tips, market insights & property guides</p>
      </div>
      <a href="news.php" class="btn btn-outline-primary btn-sm px-4 rounded-pill">View All →</a>
    </div>
    <div class="row g-4">
      <?php while($n=$latestNews->fetch_assoc()): $cat=$n['category']; ?>
      <div class="col-lg-4 col-md-6 reveal">
        <a href="news-detail.php?slug=<?=htmlspecialchars($n['slug'])?>" class="text-decoration-none">
          <div class="news-card">
            <div class="news-img-wrap">
              <img src="<?=$n['image_url']?>" alt="<?=htmlspecialchars($n['title'])?>">
            </div>
            <div class="p-4">
              <div class="d-flex gap-2 mb-2 align-items-center">
                <span class="news-cat <?=$catColors[$cat]??'cat-news'?>"><?=$catLabel[$cat]??ucfirst($cat)?></span>
                <span style="font-size:.72rem;color:var(--text-muted)"><i class="fas fa-eye me-1"></i><?=number_format($n['views'])?></span>
              </div>
              <h6 style="font-size:.9rem;font-weight:700;color:var(--text-main);line-height:1.4;margin-bottom:8px"><?=$n['title']?></h6>
              <p style="font-size:.8rem;color:var(--text-muted);line-height:1.55;margin-bottom:12px"><?=substr($n['excerpt'],0,105)?>...</p>
              <div style="font-size:.74rem;color:var(--text-muted);display:flex;gap:12px;padding-top:10px;border-top:1px solid var(--border)">
                <span><i class="fas fa-user-circle me-1"></i><?=$n['author']?></span>
                <span class="ms-auto fw-bold text-accent">Read →</span>
              </div>
            </div>
          </div>
        </a>
      </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ════════════════ RENT RECEIPT CTA ════════════════ -->
<section class="py-4" style="background:linear-gradient(135deg,#263b4f,#1a2d3d)">
  <div class="container">
    <div class="row align-items-center text-white">
      <div class="col-md-8">
        <h4 class="fw-bold mb-1">📄 Generate Rent Receipts Instantly</h4>
        <p class="mb-0 opacity-75">Official receipts for tax savings & HR submission — free for all tenants</p>
      </div>
      <div class="col-md-4 text-md-end mt-3 mt-md-0">
        <a href="client/<?=isClientLoggedIn()?'rent-payment.php':'login.php'?>" class="btn fw-bold px-5 py-2 rounded-pill" style="background:var(--accent);color:#fff;border:none">Generate Now →</a>
      </div>
    </div>
  </div>
</section>

<script>
// Search tab
function setTab(el,t){
  document.querySelectorAll('.search-tab-btn').forEach(b=>b.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('searchType').value=t;
  var s=document.getElementById('heroTypeSel');
  s.value=t==='pg'?'pg':t==='commercial'?'commercial':'';
}

// PG filter
function pgFilter(el,t){
  document.querySelectorAll('.pg-pill').forEach(b=>b.classList.remove('active'));
  el.classList.add('active');
  document.querySelectorAll('.pg-item').forEach(c=>{
    var tags=c.dataset.tags||'';
    c.style.display=(t==='all'||tags.includes(t))?'':'none';
    if(c.style.display!=='none') c.style.animation='fadeIn .4s ease';
  });
}

// Scroll reveal
var observer=new IntersectionObserver(function(entries){
  entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');observer.unobserve(e.target);}});
},{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));



// Restore accent
var _ac=localStorage.getItem('hh_accent');
if(_ac) document.documentElement.style.setProperty('--accent',_ac);

// High Demand slider scroll
function hdScroll(dir){
  var s=document.getElementById('hdSlider');
  if(s) s.scrollBy({left: dir * 310, behavior:'smooth'});
}

// Generic slider scroll for cities, property types, etc.
function sliderScroll(id, dir){
  var s = document.getElementById(id);
  if(s) s.scrollBy({left: dir * 320, behavior:'smooth'});
}

// Enable touch/drag scrolling for all slider containers
(function(){
  var sliders = document.querySelectorAll('.cities-slider, .hd-slider');
  sliders.forEach(function(slider){
    var isDown = false, startX, scrollLeft;
    slider.addEventListener('mousedown', function(e){
      isDown = true; slider.style.cursor = 'grabbing';
      startX = e.pageX - slider.offsetLeft;
      scrollLeft = slider.scrollLeft;
    });
    slider.addEventListener('mouseleave', function(){ isDown = false; slider.style.cursor = 'grab'; });
    slider.addEventListener('mouseup', function(){ isDown = false; slider.style.cursor = 'grab'; });
    slider.addEventListener('mousemove', function(e){
      if(!isDown) return;
      e.preventDefault();
      var x = e.pageX - slider.offsetLeft;
      var walk = (x - startX) * 1.5;
      slider.scrollLeft = scrollLeft - walk;
    });
    slider.style.cursor = 'grab';
  });
})();
</script>

<?php require_once 'includes/footer.php'; ?>
