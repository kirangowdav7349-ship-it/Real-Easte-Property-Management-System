<?php
$pageTitle = 'Home Services';
require_once 'includes/header.php';

$services = $conn->query("SELECT * FROM services WHERE status='active'");
$msg = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
  $sid = (int)$_POST['service_id'];
  $name = sanitize($_POST['name']);
  $phone = sanitize($_POST['phone']);
  $email = sanitize($_POST['email']);
  $address = sanitize($_POST['address']);
  $date = sanitize($_POST['booking_date']);
  $slot = sanitize($_POST['time_slot']);
  // Use NULL for guests to avoid FK constraint error
  $cid = (!empty($_SESSION['client_id'])) ? (int)$_SESSION['client_id'] : 'NULL';
  $dateVal = !empty($date) ? "'$date'" : 'NULL';
  $conn->query("INSERT INTO service_bookings (client_id,service_id,name,phone,email,address,booking_date,time_slot) VALUES($cid,$sid,'$name','$phone','$email','$address',$dateVal,'$slot')");
  $msg = '<div class="alert alert-success alert-dismissible fade show">Service booked! We will contact you soon.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
}

// Perfectly matched real images for each service
$sdata = [
  'Home Cleaning'        => ['img'=>'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=700','icon'=>'fa-broom','color'=>'#FF6B35'],
  'Home Painting'        => ['img'=>'https://images.unsplash.com/photo-1562259949-e8e7689d7828?w=700','icon'=>'fa-paint-roller','color'=>'#1a3c5e'],
  'Packers & Movers'     => ['img'=>'https://images.unsplash.com/photo-1600518464441-9154a4dea21b?w=700','icon'=>'fa-truck-moving','color'=>'#2d6a4f'],
  'Commercial Interiors' => ['img'=>'https://images.unsplash.com/photo-1497366216548-37526070297c?w=700','icon'=>'fa-drafting-compass','color'=>'#6f42c1'],
  'Plumbing'             => ['img'=>'https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?w=700','icon'=>'fa-wrench','color'=>'#dc3545'],
  'Plumbing Services'    => ['img'=>'https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?w=700','icon'=>'fa-wrench','color'=>'#dc3545'],
  'Carpentry'            => ['img'=>'https://images.unsplash.com/photo-1588854337236-6889d631faa8?w=700','icon'=>'fa-hammer','color'=>'#fd7e14'],
  'Carpentry Work'       => ['img'=>'https://images.unsplash.com/photo-1588854337236-6889d631faa8?w=700','icon'=>'fa-hammer','color'=>'#fd7e14'],
  'Electrical Work'      => ['img'=>'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=700','icon'=>'fa-bolt','color'=>'#ffc107'],
  'Pest Control'         => ['img'=>'https://images.unsplash.com/photo-1563453392212-326f5e854473?w=700','icon'=>'fa-bug','color'=>'#28a745'],
];
$fallbackData = [
  ['img'=>'https://images.unsplash.com/photo-1628177142898-93e36e4e3a50?w=700','icon'=>'fa-tools','color'=>'#333'],
];
?>

<div class="page-banner">
  <div class="container text-center">
    <h2 class="fw-bold">🏠 Home Services</h2>
    <p class="opacity-75">Professional services at your doorstep — Trusted experts, guaranteed quality</p>
  </div>
</div>

<section class="py-5">
  <div class="container">
    <?= $msg ?>
    <div class="row g-4">
      <?php
      $si = 0;
      while($s = $services->fetch_assoc()):
        $sd = $sdata[$s['name']] ?? $fallbackData[0];
      ?>
      <div class="col-lg-4 col-md-6">
        <div class="property-card h-100">
          <div class="property-img-wrap" style="height:230px;overflow:hidden;position:relative">
            <img src="<?= $sd['img'] ?>" alt="<?= $s['name'] ?>"
                 style="width:100%;height:100%;object-fit:cover;transition:transform 0.4s"
                 onmouseover="this.style.transform='scale(1.07)'"
                 onmouseout="this.style.transform='scale(1)'">
            <div class="position-absolute top-0 start-0 w-100 h-100"
                 style="background:linear-gradient(transparent 40%, rgba(0,0,0,0.7))"></div>
            <div class="position-absolute bottom-0 start-0 p-3 w-100">
              <span style="background:<?= $sd['color'] ?>;color:#fff;padding:5px 14px;border-radius:20px;font-size:0.78rem;font-weight:600;">
                <i class="fas <?= $sd['icon'] ?> me-1"></i><?= $s['name'] ?>
              </span>
            </div>
          </div>
          <div class="card-body p-4">
            <p class="text-muted mb-3" style="font-size:0.9rem;min-height:42px"><?= $s['description'] ?></p>
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <div class="fw-bold fs-6" style="color:<?= $sd['color'] ?>"><?= $s['price_range'] ?></div>
                <small class="text-muted">Starting price</small>
              </div>
              <button class="btn btn-accent px-4" data-bs-toggle="modal" data-bs-target="#bookModal<?= $s['id'] ?>">
                <i class="fas fa-calendar-check me-1"></i>Book Now
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Booking Modal -->
      <div class="modal fade" id="bookModal<?= $s['id'] ?>">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0" style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:white;border-radius:12px 12px 0 0">
              <h5 class="modal-title fw-bold">
                <i class="fas <?= $sd['icon'] ?> me-2"></i>Book <?= $s['name'] ?>
              </h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
              <div class="modal-body p-4">
                <input type="hidden" name="service_id" value="<?= $s['id'] ?>">
                <div class="row g-3">
                  <div class="col-12">
                    <input type="text" name="name" class="form-control" placeholder="Your Full Name" required value="<?= $_SESSION['client_name'] ?? '' ?>">
                  </div>
                  <div class="col-6">
                    <input type="text" name="phone" class="form-control" placeholder="Phone Number" required>
                  </div>
                  <div class="col-6">
                    <input type="email" name="email" class="form-control" placeholder="Email" required value="<?= $_SESSION['client_email'] ?? '' ?>">
                  </div>
                  <div class="col-12">
                    <textarea name="address" class="form-control" placeholder="Full Service Address" required rows="2"></textarea>
                  </div>
                  <div class="col-6">
                    <label class="form-label text-muted small">Preferred Date</label>
                    <input type="date" name="booking_date" class="form-control" required min="<?= date('Y-m-d', strtotime('+1 day')) ?>">
                  </div>
                  <div class="col-6">
                    <label class="form-label text-muted small">Time Slot</label>
                    <select name="time_slot" class="form-select" required>
                      <option value="">Select Slot</option>
                      <option>9:00 AM - 11:00 AM</option>
                      <option>11:00 AM - 1:00 PM</option>
                      <option>2:00 PM - 4:00 PM</option>
                      <option>4:00 PM - 6:00 PM</option>
                    </select>
                  </div>
                </div>
              </div>
              <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-accent px-5 fw-bold">Confirm Booking</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <?php $si++; endwhile; ?>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
