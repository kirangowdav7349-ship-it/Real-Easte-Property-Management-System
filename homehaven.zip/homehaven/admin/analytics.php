<?php
$pageTitle = 'Analytics';
require_once 'includes/sidebar.php';

// ─── KPIs ───
$total_props    = (int)$conn->query("SELECT COUNT(*) as c FROM properties")->fetch_assoc()['c'];
$total_clients  = (int)$conn->query("SELECT COUNT(*) as c FROM clients")->fetch_assoc()['c'];
$total_enq      = (int)$conn->query("SELECT COUNT(*) as c FROM enquiries")->fetch_assoc()['c'];
$total_bookings = (int)$conn->query("SELECT COUNT(*) as c FROM service_bookings")->fetch_assoc()['c'];
$total_services = (int)$conn->query("SELECT COUNT(*) as c FROM services")->fetch_assoc()['c'];
$featured_props = (int)$conn->query("SELECT COUNT(*) as c FROM properties WHERE featured=1")->fetch_assoc()['c'];
$avail_props    = (int)$conn->query("SELECT COUNT(*) as c FROM properties WHERE status='available'")->fetch_assoc()['c'];
$rented_props   = (int)$conn->query("SELECT COUNT(*) as c FROM properties WHERE status='rented'")->fetch_assoc()['c'];
$sold_props     = (int)$conn->query("SELECT COUNT(*) as c FROM properties WHERE status='sold'")->fetch_assoc()['c'];
$avg_price      = (float)$conn->query("SELECT AVG(price) as a FROM properties WHERE status!='sold'")->fetch_assoc()['a'];
$total_value    = (float)$conn->query("SELECT SUM(price) as s FROM properties")->fetch_assoc()['s'];
$rent_listings  = (int)$conn->query("SELECT COUNT(*) as c FROM properties WHERE listing_type='rent'")->fetch_assoc()['c'];
$buy_listings   = (int)$conn->query("SELECT COUNT(*) as c FROM properties WHERE listing_type='buy'")->fetch_assoc()['c'];
$pg_listings    = (int)$conn->query("SELECT COUNT(*) as c FROM properties WHERE listing_type='pg'")->fetch_assoc()['c'];
$comm_listings  = (int)$conn->query("SELECT COUNT(*) as c FROM properties WHERE listing_type='commercial'")->fetch_assoc()['c'];

$top_city_res = $conn->query("SELECT city, COUNT(*) as c FROM properties GROUP BY city ORDER BY c DESC LIMIT 1");
$top_city     = $top_city_res->fetch_assoc();

// Revenue from rent_payments
$total_revenue = (float)$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE status='paid'")->fetch_assoc()['s'];

// Monthly property additions (last 6 months)
$prop_labels = []; $prop_data = [];
for ($m = 5; $m >= 0; $m--) {
    $r = $conn->query("SELECT COUNT(*) as c FROM properties WHERE MONTH(created_at)=MONTH(DATE_SUB(NOW(),INTERVAL $m MONTH)) AND YEAR(created_at)=YEAR(DATE_SUB(NOW(),INTERVAL $m MONTH))");
    $prop_data[] = (int)$r->fetch_assoc()['c'];
    $prop_labels[] = date('M Y', strtotime("-$m months"));
}

// Monthly revenue last 6 months
$rev_labels = []; $rev_data = [];
for ($m = 5; $m >= 0; $m--) {
    $r = $conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE status='paid' AND MONTH(created_at)=MONTH(DATE_SUB(NOW(),INTERVAL $m MONTH)) AND YEAR(created_at)=YEAR(DATE_SUB(NOW(),INTERVAL $m MONTH))");
    $rev_data[] = (float)$r->fetch_assoc()['s'];
    $rev_labels[] = date('M Y', strtotime("-$m months"));
}

// Property type breakdown
$pt_res = $conn->query("SELECT type, COUNT(*) as cnt FROM properties GROUP BY type ORDER BY cnt DESC");
$pt_labels=[]; $pt_data=[];
while($r=$pt_res->fetch_assoc()){ $pt_labels[]=ucfirst($r['type']); $pt_data[]=(int)$r['cnt']; }

// Listing type breakdown
$lt_res = $conn->query("SELECT listing_type, COUNT(*) as cnt FROM properties GROUP BY listing_type ORDER BY cnt DESC");
$lt_labels=[]; $lt_data=[];
while($r=$lt_res->fetch_assoc()){ $lt_labels[]=ucfirst($r['listing_type']); $lt_data[]=(int)$r['cnt']; }

// City distribution
$city_res = $conn->query("SELECT city, COUNT(*) as cnt FROM properties GROUP BY city ORDER BY cnt DESC LIMIT 8");
$city_labels=[]; $city_data=[];
while($r=$city_res->fetch_assoc()){ $city_labels[]=$r['city']; $city_data[]=(int)$r['cnt']; }

// Price range distribution
$price_ranges = [
    ['Under ₹10L',     0,         1000000],
    ['₹10L - ₹50L',    1000000,   5000000],
    ['₹50L - ₹1Cr',    5000000,   10000000],
    ['₹1Cr - ₹5Cr',    10000000,  50000000],
    ['Above ₹5Cr',     50000000,  999999999],
];
$pr_labels=[]; $pr_data=[];
foreach($price_ranges as $pr) {
    $cnt = (int)$conn->query("SELECT COUNT(*) as c FROM properties WHERE price >= {$pr[1]} AND price < {$pr[2]}")->fetch_assoc()['c'];
    $pr_labels[] = $pr[0];
    $pr_data[]   = $cnt;
}

// Bookings by service
$svc_res = $conn->query("SELECT s.name, COUNT(sb.id) as cnt FROM services s LEFT JOIN service_bookings sb ON s.id=sb.service_id GROUP BY s.id ORDER BY cnt DESC LIMIT 6");
$svc_names=[]; $svc_counts=[];
while($s=$svc_res->fetch_assoc()){ $svc_names[]=$s['name']; $svc_counts[]=(int)$s['cnt']; }

// Top 5 expensive properties
$top_expensive = $conn->query("SELECT p.title, p.price, p.city, p.type, p.listing_type, pi.image_url FROM properties p LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 ORDER BY p.price DESC LIMIT 5");

// Recent activities (combine enquiries, bookings, payments)
$activities = [];
$eq = $conn->query("SELECT 'enquiry' as atype, name as atitle, created_at FROM enquiries ORDER BY created_at DESC LIMIT 3");
while($a=$eq->fetch_assoc()) $activities[] = $a;
$bk = $conn->query("SELECT 'booking' as atype, name as atitle, created_at FROM service_bookings ORDER BY created_at DESC LIMIT 3");
while($a=$bk->fetch_assoc()) $activities[] = $a;
$rp = $conn->query("SELECT 'payment' as atype, receipt_number as atitle, created_at FROM rent_payments ORDER BY created_at DESC LIMIT 3");
while($a=$rp->fetch_assoc()) $activities[] = $a;
// Sort by date desc
usort($activities, function($a,$b) { return strtotime($b['created_at']) - strtotime($a['created_at']); });
$activities = array_slice($activities, 0, 5);
?>

<!-- KPI Row 1 -->
<div class="row g-3 mb-4">
  <?php foreach([
    ['Total Properties',$total_props,'fas fa-building','#FF6B35','linear-gradient(135deg,#FF6B35,#c0392b)'],
    ['Total Clients',$total_clients,'fas fa-users','#3b82f6','linear-gradient(135deg,#3b82f6,#1d4ed8)'],
    ['Total Enquiries',$total_enq,'fas fa-envelope','#10b981','linear-gradient(135deg,#10b981,#059669)'],
    ['Featured Properties',$featured_props,'fas fa-star','#f59e0b','linear-gradient(135deg,#f59e0b,#d97706)'],
    ['Avg Property Price',formatPrice($avg_price),'fas fa-rupee-sign','#8b5cf6','linear-gradient(135deg,#8b5cf6,#6d28d9)'],
    ['Top City',htmlspecialchars($top_city['city']??'N/A'),'fas fa-map-marker-alt','#ec4899','linear-gradient(135deg,#ec4899,#be185d)'],
    ['Portfolio Value',formatPrice($total_value),'fas fa-chart-line','#06b6d4','linear-gradient(135deg,#06b6d4,#0891b2)'],
    ['Total Services',$total_services,'fas fa-tools','#14b8a6','linear-gradient(135deg,#14b8a6,#0d9488)'],
  ] as $k): ?>
  <div class="col-xl-3 col-md-4 col-6">
    <div class="stat-card-new" style="background:<?=$k[4]?>">
      <div class="stat-icon"><i class="<?=$k[2]?>"></i></div>
      <div class="stat-val"><?=$k[1]?></div>
      <div class="stat-lbl"><?=$k[0]?></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Property Listing Breakdown -->
<div class="row g-3 mb-4">
  <?php foreach([
    ['Buy Listings',$buy_listings,'fas fa-home','#10b981'],
    ['Rent Listings',$rent_listings,'fas fa-key','#3b82f6'],
    ['PG / Co-Living',$pg_listings,'fas fa-door-open','#8b5cf6'],
    ['Commercial',$comm_listings,'fas fa-store','#f59e0b'],
  ] as $k): ?>
  <div class="col-md-3 col-6">
    <div class="admin-card">
      <div class="d-flex align-items-center gap-3">
        <div style="width:44px;height:44px;background:<?=$k[3]?>15;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1rem;color:<?=$k[3]?>;flex-shrink:0"><i class="<?=$k[2]?>"></i></div>
        <div>
          <div style="font-size:1.4rem;font-weight:800;color:var(--text-main);line-height:1.1"><?=$k[1]?></div>
          <div style="font-size:.72rem;color:var(--text-muted)"><?=$k[0]?></div>
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<div class="row g-4 mb-4">
  <!-- Property Growth -->
  <div class="col-lg-8">
    <div class="admin-card">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h6 class="fw-bold mb-0"><i class="fas fa-chart-area text-accent me-2"></i>Property Listings Growth (6 Months)</h6>
        <span class="badge-soft-primary"><?= $total_props ?> Total</span>
      </div>
      <div class="chart-container"><canvas id="propGrowthChart"></canvas></div>
    </div>
  </div>
  <!-- Property Status -->
  <div class="col-lg-4">
    <div class="admin-card">
      <h6 class="fw-bold mb-4"><i class="fas fa-chart-pie text-accent me-2"></i>Property Status</h6>
      <div class="chart-container-sm"><canvas id="statusChart"></canvas></div>
      <div class="mt-3">
        <?php foreach([['Available',$avail_props,'#10b981'],['Sold',$sold_props,'#ef4444'],['Rented',$rented_props,'#3b82f6']] as $st): ?>
        <div class="d-flex justify-content-between align-items-center mb-2">
          <div class="d-flex align-items-center gap-2">
            <div style="width:10px;height:10px;border-radius:50%;background:<?=$st[2]?>"></div>
            <span style="font-size:.82rem"><?=$st[0]?></span>
          </div>
          <span style="font-size:.82rem;font-weight:700"><?=$st[1]?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<div class="row g-4 mb-4">
  <!-- City Distribution -->
  <div class="col-lg-8">
    <div class="admin-card">
      <h6 class="fw-bold mb-4"><i class="fas fa-map-marked-alt text-accent me-2"></i>Properties by City</h6>
      <div class="chart-container"><canvas id="cityChart"></canvas></div>
    </div>
  </div>
  <!-- Price Range -->
  <div class="col-lg-4">
    <div class="admin-card">
      <h6 class="fw-bold mb-4"><i class="fas fa-tags text-accent me-2"></i>Price Distribution</h6>
      <div class="chart-container-sm"><canvas id="priceChart"></canvas></div>
    </div>
  </div>
</div>

<div class="row g-4 mb-4">
  <!-- Property Type -->
  <div class="col-md-4">
    <div class="admin-card">
      <h6 class="fw-bold mb-4"><i class="fas fa-th-large text-accent me-2"></i>By Property Type</h6>
      <div class="chart-container-sm"><canvas id="ptChart"></canvas></div>
    </div>
  </div>
  <!-- Listing Type -->
  <div class="col-md-4">
    <div class="admin-card">
      <h6 class="fw-bold mb-4"><i class="fas fa-layer-group text-accent me-2"></i>By Listing Type</h6>
      <div class="chart-container-sm"><canvas id="ltChart"></canvas></div>
    </div>
  </div>
  <!-- Performance -->
  <div class="col-md-4">
    <div class="admin-card">
      <h6 class="fw-bold mb-4"><i class="fas fa-tachometer-alt text-accent me-2"></i>Performance Scores</h6>
      <?php
      $occ_rate = $total_props>0 ? round((($rented_props + $sold_props) / $total_props)*100) : 0;
      $feat_rate = $total_props>0 ? round(($featured_props / $total_props)*100) : 0;
      $perf = [
        ['Portfolio Coverage', min($feat_rate*2, 100), '#10b981'],
        ['Listing Quality', 85, '#3b82f6'],
        ['City Diversity', min(count($city_labels)*12, 100), '#f59e0b'],
        ['Data Completeness', 92, '#8b5cf6'],
      ];
      foreach($perf as $pf):
      ?>
      <div class="mb-3">
        <div class="d-flex justify-content-between mb-1">
          <span style="font-size:.8rem;font-weight:600"><?= $pf[0] ?></span>
          <span style="font-size:.8rem;font-weight:700;color:<?= $pf[2] ?>"><?= $pf[1] ?>%</span>
        </div>
        <div class="progress"><div class="progress-bar" style="width:<?= $pf[1] ?>%;background:<?= $pf[2] ?>"></div></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="row g-4">
  <!-- Top Expensive Properties -->
  <div class="col-lg-7">
    <div class="admin-card">
      <h6 class="fw-bold mb-4"><i class="fas fa-crown text-accent me-2"></i>Top 5 Highest Value Properties</h6>
      <div class="table-responsive">
        <table class="table admin-table mb-0">
          <thead><tr><th>Property</th><th>City</th><th>Type</th><th>Price</th></tr></thead>
          <tbody>
          <?php while($tp = $top_expensive->fetch_assoc()): ?>
          <tr>
            <td>
              <div class="d-flex align-items-center gap-2">
                <img src="<?= htmlspecialchars($tp['image_url'] ?? 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=100') ?>" 
                     style="width:42px;height:32px;object-fit:cover;border-radius:6px" alt="">
                <span class="fw-bold" style="font-size:.82rem;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($tp['title']) ?></span>
              </div>
            </td>
            <td style="font-size:.82rem"><?= htmlspecialchars($tp['city']) ?></td>
            <td><span class="badge-soft-primary"><?= ucfirst($tp['type']) ?></span></td>
            <td class="fw-bold" style="color:#FF6B35"><?= formatPrice($tp['price']) ?></td>
          </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  
  <!-- Recent Activity -->
  <div class="col-lg-5">
    <div class="admin-card">
      <h6 class="fw-bold mb-4"><i class="fas fa-clock text-accent me-2"></i>Recent Activity</h6>
      <?php if(empty($activities)): ?>
      <div class="text-center py-4">
        <div style="font-size:3rem;margin-bottom:12px">📊</div>
        <p class="text-muted mb-0" style="font-size:.85rem">No recent activity yet. Enquiries, bookings and payments will appear here.</p>
      </div>
      <?php else: ?>
      <?php foreach($activities as $act):
        $icons = ['enquiry'=>'fas fa-envelope','booking'=>'fas fa-calendar-check','payment'=>'fas fa-credit-card'];
        $colors = ['enquiry'=>'#3b82f6','booking'=>'#10b981','payment'=>'#f59e0b'];
      ?>
      <div class="d-flex align-items-center gap-3 mb-3 pb-3" style="border-bottom:1px solid var(--border-c)">
        <div style="width:36px;height:36px;background:<?=$colors[$act['atype']]?>15;border-radius:10px;display:flex;align-items:center;justify-content:center;color:<?=$colors[$act['atype']]?>;flex-shrink:0">
          <i class="<?=$icons[$act['atype']]?>" style="font-size:.85rem"></i>
        </div>
        <div>
          <div style="font-size:.82rem;font-weight:600"><?= ucfirst($act['atype']) ?>: <?= htmlspecialchars($act['atitle'] ?? 'N/A') ?></div>
          <div style="font-size:.7rem;color:var(--text-muted)"><?= date('d M Y, H:i', strtotime($act['created_at'])) ?></div>
        </div>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
      
      <!-- Quick Stats Summary -->
      <div class="mt-3 p-3 rounded-3" style="background:var(--body-bg)">
        <h6 class="fw-bold mb-3" style="font-size:.82rem">📈 Quick Summary</h6>
        <div class="row g-2">
          <?php foreach([
            ['Available',$avail_props,'#10b981'],
            ['For Sale',$buy_listings,'#FF6B35'],
            ['Rental',$rent_listings,'#3b82f6'],
            ['PG',$pg_listings,'#8b5cf6'],
          ] as $qs): ?>
          <div class="col-6">
            <div class="d-flex align-items-center gap-2">
              <div style="width:8px;height:8px;border-radius:50%;background:<?=$qs[2]?>"></div>
              <span style="font-size:.75rem;color:var(--text-muted)"><?=$qs[0]?>:</span>
              <span style="font-size:.75rem;font-weight:700"><?=$qs[1]?></span>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
<script>
const clrs  = ['#FF6B35','#10b981','#3b82f6','#f59e0b','#8b5cf6','#ef4444','#06b6d4','#ec4899'];
const clrs2 = ['#10b981','#3b82f6','#f59e0b','#8b5cf6','#FF6B35','#ef4444','#06b6d4','#ec4899'];

// Property growth
new Chart(document.getElementById('propGrowthChart'),{
  type:'line',
  data:{labels:<?=json_encode($prop_labels)?>,
    datasets:[{label:'New Listings',data:<?=json_encode($prop_data)?>,borderColor:'#FF6B35',backgroundColor:'rgba(255,107,53,.12)',borderWidth:3,fill:true,tension:.4,pointBackgroundColor:'#FF6B35',pointRadius:5,pointHoverRadius:8}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,grid:{color:'rgba(0,0,0,.05)'},ticks:{stepSize:1}},x:{grid:{display:false}}}}
});

// Status chart
new Chart(document.getElementById('statusChart'),{
  type:'doughnut',
  data:{labels:['Available','Sold','Rented'],datasets:[{data:[<?=$avail_props?>,<?=$sold_props?>,<?=$rented_props?>],backgroundColor:['#10b981','#ef4444','#3b82f6'],borderWidth:0,hoverOffset:8}]},
  options:{responsive:true,maintainAspectRatio:false,cutout:'65%',plugins:{legend:{display:false}}}
});

// City chart
new Chart(document.getElementById('cityChart'),{
  type:'bar',
  data:{labels:<?=json_encode($city_labels)?>,datasets:[{label:'Properties',data:<?=json_encode($city_data)?>,backgroundColor:clrs,borderRadius:8,barThickness:32}]},
  options:{responsive:true,maintainAspectRatio:false,indexAxis:'y',plugins:{legend:{display:false}},scales:{x:{beginAtZero:true,grid:{color:'rgba(0,0,0,.05)'},ticks:{stepSize:1}},y:{grid:{display:false}}}}
});

// Price range
new Chart(document.getElementById('priceChart'),{
  type:'polarArea',
  data:{labels:<?=json_encode($pr_labels)?>,datasets:[{data:<?=json_encode($pr_data)?>,backgroundColor:['#10b98140','#3b82f640','#f59e0b40','#8b5cf640','#ef444440'],borderColor:['#10b981','#3b82f6','#f59e0b','#8b5cf6','#ef4444'],borderWidth:2}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{font:{size:9},boxWidth:8}}}}
});

// Property type doughnut
new Chart(document.getElementById('ptChart'),{
  type:'doughnut',
  data:{labels:<?=json_encode($pt_labels)?>,datasets:[{data:<?=json_encode($pt_data)?>,backgroundColor:clrs,borderWidth:0,hoverOffset:6}]},
  options:{responsive:true,maintainAspectRatio:false,cutout:'60%',plugins:{legend:{position:'bottom',labels:{font:{size:10},boxWidth:10}}}}
});

// Listing type pie
new Chart(document.getElementById('ltChart'),{
  type:'pie',
  data:{labels:<?=json_encode($lt_labels)?>,datasets:[{data:<?=json_encode($lt_data)?>,backgroundColor:clrs2,borderWidth:0,hoverOffset:6}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{font:{size:10},boxWidth:10}}}}
});
</script>
</body></html>
