<?php
$pageTitle = 'Settings';
require_once 'includes/sidebar.php';
$msg = ''; $msgType = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save_account'])) {
        $name  = sanitize($_POST['admin_name'] ?? '');
        $email = sanitize($_POST['admin_email'] ?? '');
        $pass  = $_POST['new_password'] ?? '';
        $cur   = $_POST['current_password'] ?? '';
        $res   = $conn->query("SELECT * FROM admins WHERE id=".(int)$_SESSION['admin_id']);
        $admin_row = $res ? $res->fetch_assoc() : null;
        if ($cur && $admin_row && !password_verify($cur, $admin_row['password'])) {
            $msg = 'Current password incorrect.'; $msgType = 'danger';
        } else {
            $updates = "name='$name',email='$email'";
            if ($pass && strlen($pass) >= 6) { $updates .= ",password='".password_hash($pass,PASSWORD_BCRYPT)."'"; }
            $conn->query("UPDATE admins SET $updates WHERE id=".(int)$_SESSION['admin_id']);
            $_SESSION['admin_name'] = $name;
            $msg = 'Account updated!';
        }
    } elseif (isset($_POST['save_general'])) { $msg = 'General settings saved!'; }
    elseif (isset($_POST['save_appearance'])) { $msg = 'Appearance saved!'; }
}
$admin_res = $conn->query("SELECT * FROM admins WHERE id=".(int)$_SESSION['admin_id']);
$admin = ($admin_res&&$admin_res->num_rows>0)?$admin_res->fetch_assoc():['name'=>'Admin','email'=>'admin@PropNexus.com'];
$active_tab = $_GET['tab'] ?? 'general';
?>
<?php if($msg): ?><div class="alert alert-<?=$msgType?> rounded-3 mb-4"><?=$msg?></div><?php endif; ?>
<div class="row g-4">
  <div class="col-lg-3">
    <div class="admin-card p-0 overflow-hidden">
      <?php foreach([['general','fas fa-cog','General'],['account','fas fa-user-shield','Account & Security'],['appearance','fas fa-paint-brush','Appearance'],['notifications','fas fa-bell','Notifications'],['system','fas fa-server','System']] as $t): ?>
      <a href="?tab=<?=$t[0]?>" class="d-flex align-items-center gap-3 px-4 py-3 text-decoration-none" style="border-bottom:1px solid var(--border-c);<?=$active_tab==$t[0]?'background:rgba(255,107,53,.1);border-left:3px solid #FF6B35':''?>">
        <i class="<?=$t[1]?>" style="color:<?=$active_tab==$t[0]?'#FF6B35':'var(--text-muted)'?>;width:16px"></i>
        <span style="font-size:.85rem;font-weight:<?=$active_tab==$t[0]?700:500?>;color:<?=$active_tab==$t[0]?'var(--text-main)':'var(--text-muted)'?>"><?=$t[2]?></span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="col-lg-9">
    <?php if($active_tab==='general'): ?>
    <div class="admin-card">
      <h5 class="fw-bold mb-4">General Settings</h5>
      <form method="POST">
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">Site Name</label><input type="text" class="form-control" value="PropNexus" name="site_name"></div>
          <div class="col-md-6"><label class="form-label">Tagline</label><input type="text" class="form-control" value="Find Your Dream Home"></div>
          <div class="col-md-6"><label class="form-label">Contact Email</label><input type="email" class="form-control" value="<?=ADMIN_EMAIL?>"></div>
          <div class="col-md-6"><label class="form-label">Phone</label><input type="text" class="form-control" value="+91 98765 43210"></div>
          <div class="col-md-6"><label class="form-label">Currency</label><select class="form-select"><option>INR (₹)</option><option>USD ($)</option></select></div>
          <div class="col-md-6"><label class="form-label">Properties per Page</label><select class="form-select"><option>6</option><option selected>9</option><option>12</option></select></div>
          <div class="col-12"><label class="form-label">Address</label><textarea class="form-control" rows="2">MG Road, Bangalore - 560001, Karnataka, India</textarea></div>
          <div class="col-12"><button type="submit" name="save_general" class="btn btn-accent px-5">Save Settings</button></div>
        </div>
      </form>
    </div>
    <?php elseif($active_tab==='account'): ?>
    <div class="admin-card">
      <h5 class="fw-bold mb-4">Account & Security</h5>
      <form method="POST">
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">Admin Name</label><input type="text" name="admin_name" class="form-control" value="<?=htmlspecialchars($admin['name'])?>" required></div>
          <div class="col-md-6"><label class="form-label">Email</label><input type="email" name="admin_email" class="form-control" value="<?=htmlspecialchars($admin['email'])?>" required></div>
          <div class="col-12"><hr style="border-color:var(--border-c)"><div class="fw-bold mb-2" style="font-size:.9rem">Change Password</div></div>
          <div class="col-md-4"><label class="form-label">Current Password</label><input type="password" name="current_password" class="form-control"></div>
          <div class="col-md-4"><label class="form-label">New Password</label><input type="password" name="new_password" class="form-control"></div>
          <div class="col-md-4"><label class="form-label">Confirm New</label><input type="password" class="form-control"></div>
          <div class="col-12 p-3 rounded-3" style="background:rgba(59,130,246,.08);border:1px solid rgba(59,130,246,.2);margin-left:12px">
            <strong style="font-size:.83rem;color:#3b82f6"><i class="fas fa-shield-alt me-2"></i>Security</strong>
            <ul style="font-size:.8rem;color:var(--text-muted);margin:6px 0 0;padding-left:16px">
              <li>BCrypt password hashing</li><li>SQL injection prevention via prepared statements</li><li>Session-based authentication</li>
            </ul>
          </div>
          <div class="col-12"><button type="submit" name="save_account" class="btn btn-accent px-5">Update Account</button></div>
        </div>
      </form>
    </div>
    <?php elseif($active_tab==='appearance'): ?>
    <div class="admin-card">
      <h5 class="fw-bold mb-4">Appearance</h5>
      <div class="mb-4 p-3 rounded-3" style="background:var(--body-bg);border:1px solid var(--border-c)">
        <div class="d-flex align-items-center justify-content-between">
          <div><div class="fw-bold" style="font-size:.9rem">Dark Mode</div><div style="font-size:.78rem;color:var(--text-muted)">Toggle admin panel dark/light theme</div></div>
          <button type="button" class="btn btn-accent" onclick="adminToggleDark()"><i class="fas fa-moon me-2"></i>Toggle</button>
        </div>
      </div>
      <label class="form-label">Accent Colour</label>
      <div class="d-flex gap-3 flex-wrap mb-4">
        <?php foreach(['#FF6B35','#2d6a4f','#3b82f6','#8b5cf6','#10b981','#ef4444'] as $c): ?>
        <div style="width:38px;height:38px;border-radius:50%;background:<?=$c?>;cursor:pointer;border:3px solid transparent;transition:.2s" onclick="this.style.border='3px solid #aaa'" title="<?=$c?>"></div>
        <?php endforeach; ?>
      </div>
      <button class="btn btn-accent px-5" onclick="alert('Saved!')">Save Appearance</button>
    </div>
    <?php elseif($active_tab==='notifications'): ?>
    <div class="admin-card">
      <h5 class="fw-bold mb-4">Notifications</h5>
      <?php foreach([['New Enquiry','Alert when client sends enquiry',true],['New Registration','Alert on new client signup',true],['Payment','Alert on rent payment',true],['Booking','Alert on service booking',true],['Loan Application','Alert on loan application',false],['Alert Match','Alert when property matches criteria',false]] as $n): ?>
      <div class="d-flex justify-content-between align-items-center p-3 mb-2 rounded-3" style="background:var(--body-bg);border:1px solid var(--border-c)">
        <div><div class="fw-bold" style="font-size:.85rem"><?=$n[0]?></div><div style="font-size:.75rem;color:var(--text-muted)"><?=$n[1]?></div></div>
        <div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" <?=$n[2]?'checked':''?>></div>
      </div>
      <?php endforeach; ?>
      <button class="btn btn-accent mt-3 px-5" onclick="alert('Saved!')">Save</button>
    </div>
    <?php elseif($active_tab==='system'): ?>
    <div class="admin-card">
      <h5 class="fw-bold mb-4">System Information</h5>
      <div class="row g-3 mb-4">
        <?php foreach([['PHP Version',phpversion(),'#3b82f6'],['MySQL',$conn->query("SELECT VERSION() as v")->fetch_assoc()['v'],'#10b981'],['Server',$_SERVER['SERVER_SOFTWARE']??'Apache','#f59e0b'],['Upload Max',ini_get('upload_max_filesize'),'#8b5cf6'],['Memory',ini_get('memory_limit'),'#ef4444'],['Max Exec',ini_get('max_execution_time').'s','#FF6B35']] as $si): ?>
        <div class="col-md-4"><div class="p-3 rounded-3" style="background:var(--body-bg);border:1px solid var(--border-c)"><div style="font-size:.72rem;color:var(--text-muted)"><?=$si[0]?></div><div style="font-weight:700;color:<?=$si[2]?>;font-size:.9rem"><?=htmlspecialchars($si[1])?></div></div></div>
        <?php endforeach; ?>
      </div>
      <div class="p-4 rounded-3" style="background:rgba(16,185,129,.06);border:1px solid rgba(16,185,129,.2)">
        <div class="fw-bold mb-3" style="color:#10b981"><i class="fas fa-database me-2"></i>DB Stats</div>
        <div class="row g-2">
          <?php foreach([['Properties',$conn->query("SELECT COUNT(*) as c FROM properties")->fetch_assoc()['c']],['Clients',$conn->query("SELECT COUNT(*) as c FROM clients")->fetch_assoc()['c']],['Enquiries',$conn->query("SELECT COUNT(*) as c FROM enquiries")->fetch_assoc()['c']],['Bookings',$conn->query("SELECT COUNT(*) as c FROM service_bookings")->fetch_assoc()['c']],['Payments',$conn->query("SELECT COUNT(*) as c FROM rent_payments")->fetch_assoc()['c']],['Images',$conn->query("SELECT COUNT(*) as c FROM property_images")->fetch_assoc()['c']]] as $db): ?>
          <div class="col-4 col-md-2"><div class="text-center p-2 rounded-3" style="background:rgba(255,255,255,.5)"><div style="font-size:1.1rem;font-weight:800;color:#10b981"><?=$db[1]?></div><div style="font-size:.68rem;color:var(--text-muted)"><?=$db[0]?></div></div></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body></html>
