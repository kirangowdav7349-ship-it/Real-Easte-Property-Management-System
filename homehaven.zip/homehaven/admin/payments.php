<?php
$pageTitle = 'Rent Payments';
require_once 'includes/sidebar.php';

// Handle status update
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $payId     = (int)$_POST['payment_id'];
    $newStatus = $conn->real_escape_string($_POST['new_status']);
    $conn->query("UPDATE rent_payments SET status='$newStatus' WHERE id=$payId");
    $statusMsg = "<div class='alert alert-success alert-dismissible fade show'><strong>✅ Updated!</strong> Payment status changed to <strong>" . strtoupper($newStatus) . "</strong>.<button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>";
}

// Handle creating a pending payment for a client
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_pending'])) {
    $clientId  = (int)$_POST['client_id'];
    $propId    = (int)$_POST['property_id'];
    $amount    = (float)$_POST['amount'];
    $month     = $conn->real_escape_string($_POST['payment_month']);
    $receipt   = 'RCP' . strtoupper(uniqid());
    $conn->query("INSERT INTO rent_payments (client_id, property_id, receipt_number, amount, payment_month, status, created_at) VALUES ($clientId, $propId, '$receipt', $amount, '$month', 'pending', NOW())");
    $statusMsg = "<div class='alert alert-success alert-dismissible fade show'><strong>✅ Created!</strong> Pending payment of ₹" . number_format($amount) . " assigned. Receipt: <strong>$receipt</strong><button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>";
}

// Stats
$totalPaid    = (float)$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE status='paid'")->fetch_assoc()['s'];
$totalPending = (float)$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE status='pending'")->fetch_assoc()['s'];
$totalFailed  = (float)$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE status='failed'")->fetch_assoc()['s'];
$countPending = (int)$conn->query("SELECT COUNT(*) as c FROM rent_payments WHERE status='pending'")->fetch_assoc()['c'];
$countPaid    = (int)$conn->query("SELECT COUNT(*) as c FROM rent_payments WHERE status='paid'")->fetch_assoc()['c'];
$countAll     = (int)$conn->query("SELECT COUNT(*) as c FROM rent_payments")->fetch_assoc()['c'];

// Filter
$filter = $_GET['status'] ?? 'all';
$whereClause = '';
if($filter === 'pending') $whereClause = "WHERE rp.status='pending'";
elseif($filter === 'paid') $whereClause = "WHERE rp.status='paid'";
elseif($filter === 'failed') $whereClause = "WHERE rp.status='failed'";

$payments = $conn->query("SELECT rp.*, c.name as cname, c.email as cemail, p.title as ptitle FROM rent_payments rp LEFT JOIN clients c ON rp.client_id=c.id LEFT JOIN properties p ON rp.property_id=p.id $whereClause ORDER BY rp.created_at DESC");

// For create pending form
$clients    = $conn->query("SELECT id, name, email FROM clients ORDER BY name ASC");
$properties = $conn->query("SELECT id, title, city, price FROM properties WHERE listing_type='rent' AND status='available' ORDER BY title ASC");
?>

<?php if(!empty($statusMsg)) echo $statusMsg; ?>

<!-- STAT CARDS -->
<div class="row g-3 mb-4">
  <div class="col-md-3 col-6">
    <div class="stat-card-new" style="background:linear-gradient(135deg,#dc3545,#c0392b)">
      <div class="stat-icon"><i class="fas fa-clock"></i></div>
      <div class="stat-val">₹<?= number_format($totalPending) ?></div>
      <div class="stat-lbl">Pending Amount</div>
      <div class="stat-change"><i class="fas fa-exclamation-circle me-1"></i><?= $countPending ?> payment(s)</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="stat-card-new" style="background:linear-gradient(135deg,#10b981,#059669)">
      <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
      <div class="stat-val">₹<?= number_format($totalPaid) ?></div>
      <div class="stat-lbl">Total Collected</div>
      <div class="stat-change"><i class="fas fa-circle-dot me-1"></i><?= $countPaid ?> payments</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="stat-card-new" style="background:linear-gradient(135deg,#f59e0b,#d97706)">
      <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
      <div class="stat-val">₹<?= number_format($totalFailed) ?></div>
      <div class="stat-lbl">Failed Payments</div>
      <div class="stat-change"><i class="fas fa-circle-dot me-1"></i>Needs attention</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="stat-card-new" style="background:linear-gradient(135deg,#3b82f6,#1d4ed8)">
      <div class="stat-icon"><i class="fas fa-receipt"></i></div>
      <div class="stat-val"><?= $countAll ?></div>
      <div class="stat-lbl">Total Transactions</div>
      <div class="stat-change"><i class="fas fa-circle-dot me-1"></i>All time</div>
    </div>
  </div>
</div>

<!-- CREATE PENDING PAYMENT + FILTERS -->
<div class="row g-4 mb-4">
  <div class="col-lg-5">
    <div class="admin-card">
      <h6 class="fw-bold mb-3"><i class="fas fa-plus-circle text-danger me-2"></i>Create Pending Payment</h6>
      <p style="font-size:.78rem;color:var(--text-muted);margin-bottom:16px">Assign a rent payment to a client. They'll see it as pending in their dashboard.</p>
      <form method="POST">
        <input type="hidden" name="create_pending" value="1">
        <div class="mb-3">
          <label class="form-label fw-bold" style="font-size:.83rem">Client</label>
          <select name="client_id" class="form-select form-select-sm" required>
            <option value="">Select Client</option>
            <?php while($c = $clients->fetch_assoc()): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['email']) ?>)</option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label fw-bold" style="font-size:.83rem">Property</label>
          <select name="property_id" class="form-select form-select-sm" required>
            <option value="">Select Property</option>
            <?php while($pr = $properties->fetch_assoc()): ?>
            <option value="<?= $pr['id'] ?>"><?= htmlspecialchars($pr['title']) ?> - <?= $pr['city'] ?> (₹<?= number_format($pr['price']) ?>/mo)</option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="row g-2 mb-3">
          <div class="col-6">
            <label class="form-label fw-bold" style="font-size:.83rem">Amount (₹)</label>
            <input type="number" name="amount" class="form-control form-control-sm" placeholder="e.g. 25000" required>
          </div>
          <div class="col-6">
            <label class="form-label fw-bold" style="font-size:.83rem">Payment Month</label>
            <input type="text" name="payment_month" class="form-control form-control-sm" value="<?= date('F Y') ?>" required>
          </div>
        </div>
        <button type="submit" class="btn btn-danger w-100 rounded-pill fw-bold"><i class="fas fa-paper-plane me-1"></i>Create Pending Payment</button>
      </form>
    </div>
  </div>
  <div class="col-lg-7">
    <div class="admin-card h-100">
      <h6 class="fw-bold mb-3"><i class="fas fa-chart-pie text-accent me-2"></i>Payment Overview</h6>
      <div class="row g-3 mb-3">
        <?php
        $overview = [
          ['Pending', $countPending, $totalPending, '#dc3545', 'fas fa-clock'],
          ['Paid', $countPaid, $totalPaid, '#10b981', 'fas fa-check-circle'],
          ['Failed', (int)$conn->query("SELECT COUNT(*) as c FROM rent_payments WHERE status='failed'")->fetch_assoc()['c'], $totalFailed, '#f59e0b', 'fas fa-times-circle'],
        ];
        foreach($overview as $ov):
        ?>
        <div class="col-4">
          <div class="p-3 rounded-3 text-center" style="background:<?= $ov[3] ?>10;border:1px solid <?= $ov[3] ?>30">
            <i class="<?= $ov[4] ?> mb-2" style="font-size:1.4rem;color:<?= $ov[3] ?>"></i>
            <div class="fw-bold" style="font-size:1.1rem;color:<?= $ov[3] ?>"><?= $ov[1] ?></div>
            <div style="font-size:.72rem;color:var(--text-muted)"><?= $ov[0] ?></div>
            <div class="fw-bold mt-1" style="font-size:.85rem">₹<?= number_format($ov[2]) ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <!-- Filter Tabs -->
      <div class="d-flex gap-2 flex-wrap">
        <?php foreach(['all'=>'All','pending'=>'Pending','paid'=>'Paid','failed'=>'Failed'] as $key=>$label): ?>
        <a href="?status=<?= $key ?>" class="btn btn-sm rounded-pill px-3 <?= $filter===$key?'btn-accent':'btn-outline-secondary' ?>" style="font-size:.78rem"><?= $label ?>
          <?php if($key==='pending' && $countPending > 0): ?><span class="badge bg-danger ms-1"><?= $countPending ?></span><?php endif; ?>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- PAYMENTS TABLE -->
<div class="admin-card">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h6 class="fw-bold mb-0"><i class="fas fa-list me-2"></i><?= $filter === 'all' ? 'All Payments' : ucfirst($filter) . ' Payments' ?></h6>
    <span class="badge-soft-primary"><?= $payments->num_rows ?> records</span>
  </div>
  <div class="table-responsive">
    <table class="table admin-table align-middle">
      <thead>
        <tr><th>Receipt</th><th>Client</th><th>Property</th><th>Amount</th><th>Month</th><th>Mode</th><th>Date</th><th>Status</th><th>Action</th></tr>
      </thead>
      <tbody>
        <?php if($payments && $payments->num_rows > 0): while($p = $payments->fetch_assoc()):
          $statusColor = $p['status']==='paid'?'success':($p['status']==='pending'?'warning':'danger');
          $statusIcon  = $p['status']==='paid'?'✅':($p['status']==='pending'?'⏳':'❌');
        ?>
        <tr>
          <td><code style="font-size:.75rem"><?= htmlspecialchars($p['receipt_number'] ?? '-') ?></code></td>
          <td>
            <div class="fw-bold" style="font-size:.83rem"><?= htmlspecialchars($p['cname'] ?? 'N/A') ?></div>
            <div style="font-size:.7rem;color:var(--text-muted)"><?= htmlspecialchars($p['cemail'] ?? '') ?></div>
          </td>
          <td style="font-size:.8rem;max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($p['ptitle'] ?? 'N/A') ?></td>
          <td class="fw-bold" style="color:<?= $p['status']==='pending'?'#dc3545':'#10b981' ?>">₹<?= number_format((float)$p['amount']) ?></td>
          <td style="font-size:.8rem"><?= htmlspecialchars($p['payment_month'] ?? '-') ?></td>
          <td style="font-size:.8rem"><?= htmlspecialchars($p['payment_mode'] ?? '-') ?></td>
          <td style="font-size:.78rem;color:var(--text-muted)"><?= $p['payment_date'] ? date('d M Y', strtotime($p['payment_date'])) : '-' ?></td>
          <td><span class="badge bg-<?= $statusColor ?> <?= $statusColor==='warning'?'text-dark':'' ?> px-2 py-1"><?= $statusIcon ?> <?= strtoupper($p['status']) ?></span></td>
          <td>
            <div class="dropdown">
              <button class="btn btn-sm btn-outline-secondary rounded-pill px-2" data-bs-toggle="dropdown" style="font-size:.75rem"><i class="fas fa-ellipsis-v"></i></button>
              <ul class="dropdown-menu dropdown-menu-end">
                <?php if($p['status'] !== 'paid'): ?>
                <li>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="update_status" value="1">
                    <input type="hidden" name="payment_id" value="<?= $p['id'] ?>">
                    <input type="hidden" name="new_status" value="paid">
                    <button type="submit" class="dropdown-item text-success"><i class="fas fa-check-circle me-2"></i>Mark as Paid</button>
                  </form>
                </li>
                <?php endif; ?>
                <?php if($p['status'] !== 'pending'): ?>
                <li>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="update_status" value="1">
                    <input type="hidden" name="payment_id" value="<?= $p['id'] ?>">
                    <input type="hidden" name="new_status" value="pending">
                    <button type="submit" class="dropdown-item text-warning"><i class="fas fa-clock me-2"></i>Mark as Pending</button>
                  </form>
                </li>
                <?php endif; ?>
                <?php if($p['status'] !== 'failed'): ?>
                <li>
                  <form method="POST" style="display:inline">
                    <input type="hidden" name="update_status" value="1">
                    <input type="hidden" name="payment_id" value="<?= $p['id'] ?>">
                    <input type="hidden" name="new_status" value="failed">
                    <button type="submit" class="dropdown-item text-danger"><i class="fas fa-times-circle me-2"></i>Mark as Failed</button>
                  </form>
                </li>
                <?php endif; ?>
              </ul>
            </div>
          </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="9" class="text-center py-4" style="color:var(--text-muted);font-size:.85rem">No payments found</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
