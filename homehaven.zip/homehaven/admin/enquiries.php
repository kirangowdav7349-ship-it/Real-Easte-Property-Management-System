<?php
// ALL redirects BEFORE sidebar (which outputs HTML)
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../includes/config.php';
if (!isAdminLoggedIn()) redirect(SITE_URL . '/admin/login.php');

if (isset($_GET['read'])) {
    $conn->query("UPDATE enquiries SET status='read' WHERE id=" . (int)$_GET['read']);
    header("Location: enquiries.php"); exit();
}
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM enquiries WHERE id=" . (int)$_GET['delete']);
    header("Location: enquiries.php?deleted=1"); exit();
}

$pageTitle = 'Enquiries';
require_once 'includes/sidebar.php';

$enq = $conn->query("SELECT e.*, p.title as prop FROM enquiries e LEFT JOIN properties p ON e.property_id=p.id ORDER BY e.created_at DESC");
?>
<?php if(isset($_GET['deleted'])): ?><div class="alert alert-success rounded-3 mb-3">Enquiry deleted.</div><?php endif; ?>
<div class="admin-card">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="fw-bold mb-0">All Enquiries</h5>
    <span class="badge-soft-warning"><?= $enq ? $enq->num_rows : 0 ?> Total</span>
  </div>
  <div class="table-responsive">
    <table class="table admin-table">
      <thead><tr><th>Name</th><th>Contact</th><th>Property</th><th>Message</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>
      <tbody>
        <?php if($enq && $enq->num_rows > 0): while($e = $enq->fetch_assoc()): ?>
        <tr>
          <td class="fw-bold" style="font-size:.85rem"><?= htmlspecialchars($e['name'] ?? '-') ?></td>
          <td style="font-size:.78rem"><?= htmlspecialchars($e['email'] ?? '') ?><br><?= htmlspecialchars($e['phone'] ?? '') ?></td>
          <td style="font-size:.78rem;max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($e['prop'] ?? 'General') ?></td>
          <td style="font-size:.78rem;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($e['message'] ?? '-') ?></td>
          <td><span class="badge-soft-<?= $e['status']=='new'?'warning':'success' ?>"><?= strtoupper($e['status']) ?></span></td>
          <td style="font-size:.75rem;color:var(--text-muted)"><?= date('d M Y', strtotime($e['created_at'])) ?></td>
          <td>
            <div class="d-flex gap-1">
              <?php if($e['status']=='new'): ?>
              <a href="?read=<?= $e['id'] ?>" class="btn btn-sm" style="background:#10b98115;color:#10b981;border-radius:8px" title="Mark Read"><i class="fas fa-check"></i></a>
              <?php endif; ?>
              <a href="?delete=<?= $e['id'] ?>" onclick="return confirm('Delete this enquiry?')" class="btn btn-sm" style="background:#ef444415;color:#ef4444;border-radius:8px" title="Delete"><i class="fas fa-trash"></i></a>
            </div>
          </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="7" class="text-center py-4" style="color:var(--text-muted)">No enquiries yet</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body></html>
