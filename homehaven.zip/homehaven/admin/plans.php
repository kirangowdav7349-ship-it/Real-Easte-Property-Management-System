<?php
$pageTitle = 'Subscription Plans';
require_once 'includes/sidebar.php';
$plans = $conn->query("SELECT * FROM plans ORDER BY plan_type, price");
?>
<div class="d-flex justify-content-end mb-3">
  <a href="<?= SITE_URL ?>/plans.php" target="_blank" class="btn btn-accent">View Plans Page</a>
</div>
<div class="admin-card">
  <div class="table-responsive">
    <table class="table table-hover">
      <thead class="table-dark">
        <tr><th>Name</th><th>Type</th><th>Price</th><th>Duration</th><th>Listings</th><th>Popular</th><th>Features</th></tr>
      </thead>
      <tbody>
        <?php while($p = $plans->fetch_assoc()): ?>
        <tr>
          <td class="fw-bold"><?= $p['name'] ?></td>
          <td><span class="badge bg-<?= $p['plan_type']=='residential'?'primary':'warning' ?>"><?= $p['plan_type'] ?></span></td>
          <td class="text-accent fw-bold">₹<?= number_format($p['price']) ?></td>
          <td><?= $p['duration_days'] ?> days</td>
          <td><?= $p['listings_allowed'] ?></td>
          <td><?= $p['is_popular'] ? '⭐ Yes' : 'No' ?></td>
          <td class="small"><?= $p['features'] ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
