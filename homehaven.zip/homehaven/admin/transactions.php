<?php
$pageTitle = 'Buy/Rent Transactions';
require_once 'includes/sidebar.php';

// Handle status update
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
  $txnId = (int)$_POST['txn_id'];
  $newStatus = $conn->real_escape_string($_POST['new_status']);
  $remarks = $conn->real_escape_string(trim($_POST['remarks'] ?? ''));
  
  // Get transaction details before updating
  $txnData = $conn->query("SELECT * FROM property_transactions WHERE id=$txnId")->fetch_assoc();
  
  $conn->query("UPDATE property_transactions SET status='$newStatus', admin_remarks='$remarks' WHERE id=$txnId");
  
  // When APPROVED: update property status and create rent payment if rental
  if($newStatus === 'approved' && $txnData) {
    $pid = (int)$txnData['property_id'];
    $cid = (int)$txnData['client_id'];
    
    if($txnData['transaction_type'] === 'buy') {
      $conn->query("UPDATE properties SET status='sold' WHERE id=$pid");
    } elseif($txnData['transaction_type'] === 'rent') {
      $conn->query("UPDATE properties SET status='rented' WHERE id=$pid");
      // Create first month rent payment (must be paid before client can use dashboard)
      $currentMonth = date('F Y');
      $receipt = 'RCP' . strtoupper(uniqid());
      $rentAmt = (float)$txnData['amount'];
      $conn->query("INSERT INTO rent_payments (client_id, property_id, receipt_number, amount, payment_month, status) 
        VALUES($cid, $pid, '$receipt', $rentAmt, '$currentMonth', 'pending')");
    }
  }
  
  $statusMsg = '<div class="alert alert-success alert-dismissible fade show" role="alert"><i class="fas fa-check-circle me-2"></i>Transaction #' . $txnId . ' updated to <strong>' . strtoupper($newStatus) . '</strong>.' . ($newStatus === 'approved' ? ' Property status has been updated.' : '') . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
}

$filter = $_GET['filter'] ?? '';
$where = '';
if($filter === 'buy') $where = "WHERE t.transaction_type='buy'";
elseif($filter === 'rent') $where = "WHERE t.transaction_type='rent'";
elseif($filter === 'pending') $where = "WHERE t.status='pending'";

$txns = $conn->query("SELECT t.*, p.title as ptitle, p.location, p.city, p.type as ptype, p.listing_type, pi.image_url, c.name as cname
  FROM property_transactions t
  LEFT JOIN properties p ON t.property_id=p.id
  LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1
  LEFT JOIN clients c ON t.client_id=c.id
  $where
  ORDER BY t.created_at DESC");

$totalTxns = $txns ? $txns->num_rows : 0;
$buyCount = (int)$conn->query("SELECT COUNT(*) c FROM property_transactions WHERE transaction_type='buy'")->fetch_assoc()['c'];
$rentCount = (int)$conn->query("SELECT COUNT(*) c FROM property_transactions WHERE transaction_type='rent'")->fetch_assoc()['c'];
$pendingCount = (int)$conn->query("SELECT COUNT(*) c FROM property_transactions WHERE status='pending'")->fetch_assoc()['c'];
?>

<?= $statusMsg ?? '' ?>

<!-- Stat Summary -->
<div class="row g-3 mb-4">
  <div class="col-md-3">
    <a href="transactions.php" class="text-decoration-none">
      <div class="stat-card-new" style="background:linear-gradient(135deg,#6366f1,#4f46e5)">
        <div class="stat-icon"><i class="fas fa-exchange-alt"></i></div>
        <div class="stat-val"><?= $buyCount + $rentCount ?></div>
        <div class="stat-lbl">Total Transactions</div>
      </div>
    </a>
  </div>
  <div class="col-md-3">
    <a href="transactions.php?filter=buy" class="text-decoration-none">
      <div class="stat-card-new" style="background:linear-gradient(135deg,#10b981,#059669)">
        <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
        <div class="stat-val"><?= $buyCount ?></div>
        <div class="stat-lbl">Purchase Requests</div>
      </div>
    </a>
  </div>
  <div class="col-md-3">
    <a href="transactions.php?filter=rent" class="text-decoration-none">
      <div class="stat-card-new" style="background:linear-gradient(135deg,#3b82f6,#2563eb)">
        <div class="stat-icon"><i class="fas fa-key"></i></div>
        <div class="stat-val"><?= $rentCount ?></div>
        <div class="stat-lbl">Rental Requests</div>
      </div>
    </a>
  </div>
  <div class="col-md-3">
    <a href="transactions.php?filter=pending" class="text-decoration-none">
      <div class="stat-card-new" style="background:linear-gradient(135deg,#f59e0b,#d97706)">
        <div class="stat-icon"><i class="fas fa-clock"></i></div>
        <div class="stat-val"><?= $pendingCount ?></div>
        <div class="stat-lbl">Pending Review</div>
      </div>
    </a>
  </div>
</div>

<!-- Filter Tabs -->
<div class="admin-card mb-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h6 class="fw-bold mb-0">
      <i class="fas fa-handshake me-2" style="color:#6366f1"></i>
      <?= $filter ? ucfirst($filter) . ' Transactions' : 'All Transactions' ?>
      <span class="badge bg-secondary ms-2"><?= $totalTxns ?></span>
    </h6>
    <div class="d-flex gap-2">
      <a href="transactions.php" class="btn btn-sm <?= !$filter ? 'btn-accent' : 'btn-outline-secondary' ?>">All</a>
      <a href="transactions.php?filter=buy" class="btn btn-sm <?= $filter==='buy' ? 'btn-accent' : 'btn-outline-secondary' ?>">🏠 Buy</a>
      <a href="transactions.php?filter=rent" class="btn btn-sm <?= $filter==='rent' ? 'btn-accent' : 'btn-outline-secondary' ?>">🔑 Rent</a>
      <a href="transactions.php?filter=pending" class="btn btn-sm <?= $filter==='pending' ? 'btn-accent' : 'btn-outline-secondary' ?>">⏳ Pending</a>
    </div>
  </div>

  <?php if($totalTxns === 0): ?>
    <div class="text-center py-5">
      <div style="font-size:3rem;opacity:.4">📋</div>
      <h5 class="text-muted mt-2">No transactions found</h5>
      <p class="text-muted" style="font-size:.85rem">When clients buy or rent properties, their requests will appear here.</p>
    </div>
  <?php else: ?>
    <?php while($tx = $txns->fetch_assoc()): ?>
    <div class="d-flex gap-3 align-items-start p-3 mb-3 rounded-3" style="background:var(--card-bg);border:1px solid var(--border-c);transition:.2s" onmouseover="this.style.boxShadow='0 4px 12px rgba(0,0,0,.08)'" onmouseout="this.style.boxShadow='none'">
      <!-- Type Badge -->
      <div class="text-center" style="flex-shrink:0;width:50px">
        <?php if($tx['transaction_type'] === 'buy'): ?>
          <div style="width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#10b981,#059669);display:flex;align-items:center;justify-content:center;margin:0 auto">
            <i class="fas fa-shopping-cart text-white"></i>
          </div>
          <div style="font-size:.6rem;font-weight:700;color:#10b981;margin-top:4px">BUY</div>
        <?php else: ?>
          <div style="width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#3b82f6,#2563eb);display:flex;align-items:center;justify-content:center;margin:0 auto">
            <i class="fas fa-key text-white"></i>
          </div>
          <div style="font-size:.6rem;font-weight:700;color:#3b82f6;margin-top:4px">RENT</div>
        <?php endif; ?>
      </div>
      
      <!-- Property Image -->
      <img src="<?= $tx['image_url'] ?? 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=200' ?>" style="width:80px;height:65px;object-fit:cover;border-radius:10px;flex-shrink:0" alt="">
      
      <!-- Details -->
      <div style="flex:1;min-width:0">
        <div class="d-flex justify-content-between align-items-start mb-1">
          <div>
            <h6 class="fw-bold mb-0" style="font-size:.9rem"><?= htmlspecialchars($tx['ptitle'] ?? 'Unknown Property') ?></h6>
            <div style="font-size:.72rem;color:var(--text-muted)"><i class="fas fa-map-marker-alt me-1"></i><?= htmlspecialchars(($tx['location'] ?? '') . ', ' . ($tx['city'] ?? '')) ?></div>
          </div>
          <div class="text-end">
            <div class="fw-bold" style="font-size:1.1rem;color:#FF6B35">₹<?= number_format($tx['amount']) ?><?= $tx['transaction_type']==='rent' ? '<small style="font-size:.6em;color:var(--text-muted)">/mo</small>' : '' ?></div>
            <?php
              $statusColors = ['pending'=>'warning','approved'=>'success','rejected'=>'danger','completed'=>'primary'];
              $sc = $statusColors[$tx['status']] ?? 'secondary';
            ?>
            <span class="badge bg-<?= $sc ?> <?= $sc==='warning'?'text-dark':'' ?>" style="font-size:.68rem"><?= strtoupper($tx['status']) ?></span>
          </div>
        </div>
        
        <!-- Client Info Row -->
        <div class="d-flex flex-wrap gap-3 mt-2 py-2 px-3 rounded-2" style="background:var(--content-bg);font-size:.8rem">
          <div><i class="fas fa-user me-1" style="color:#6366f1"></i><strong><?= htmlspecialchars($tx['full_name']) ?></strong></div>
          <div><i class="fas fa-phone me-1 text-success"></i><?= htmlspecialchars($tx['phone']) ?></div>
          <div><i class="fas fa-envelope me-1 text-info"></i><?= htmlspecialchars($tx['email']) ?></div>
          <?php if($tx['address']): ?>
            <div><i class="fas fa-map-pin me-1 text-danger"></i><?= htmlspecialchars($tx['address']) ?></div>
          <?php endif; ?>
        </div>
        
        <?php if($tx['message']): ?>
        <div class="mt-2" style="font-size:.78rem;color:var(--text-muted)">
          <i class="fas fa-comment-alt me-1"></i><em>"<?= htmlspecialchars($tx['message']) ?>"</em>
        </div>
        <?php endif; ?>
        
        <?php if($tx['admin_remarks']): ?>
        <div class="mt-1" style="font-size:.75rem;color:#6366f1">
          <i class="fas fa-reply me-1"></i>Admin: <?= htmlspecialchars($tx['admin_remarks']) ?>
        </div>
        <?php endif; ?>
        
        <!-- Actions -->
        <div class="d-flex justify-content-between align-items-center mt-2">
          <div style="font-size:.7rem;color:var(--text-muted)">
            <i class="fas fa-clock me-1"></i><?= date('d M Y, h:i A', strtotime($tx['created_at'])) ?>
            &nbsp;•&nbsp; Transaction #TXN<?= str_pad($tx['id'], 6, '0', STR_PAD_LEFT) ?>
          </div>
          <?php if($tx['status'] === 'pending'): ?>
          <div class="d-flex gap-2">
            <form method="POST" style="display:inline">
              <input type="hidden" name="txn_id" value="<?= $tx['id'] ?>">
              <input type="hidden" name="new_status" value="approved">
              <input type="hidden" name="remarks" value="Approved by admin">
              <button type="submit" name="update_status" class="btn btn-sm rounded-pill px-3" style="background:#10b981;color:white;font-size:.72rem">
                <i class="fas fa-check me-1"></i>Approve
              </button>
            </form>
            <form method="POST" style="display:inline">
              <input type="hidden" name="txn_id" value="<?= $tx['id'] ?>">
              <input type="hidden" name="new_status" value="rejected">
              <input type="hidden" name="remarks" value="Rejected by admin">
              <button type="submit" name="update_status" class="btn btn-sm rounded-pill px-3" style="background:#ef4444;color:white;font-size:.72rem">
                <i class="fas fa-times me-1"></i>Reject
              </button>
            </form>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endwhile; ?>
  <?php endif; ?>
</div>

<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body></html>
