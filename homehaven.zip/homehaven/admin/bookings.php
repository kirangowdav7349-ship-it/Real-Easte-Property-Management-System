<?php
// ALL redirects BEFORE sidebar
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../includes/config.php';
if (!isAdminLoggedIn()) redirect(SITE_URL . '/admin/login.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bid'])) {
    $conn->query("UPDATE service_bookings SET status='" . sanitize($_POST['status']) . "' WHERE id=" . (int)$_POST['bid']);
    header("Location: bookings.php"); exit();
}

$pageTitle = 'Bookings';
require_once 'includes/sidebar.php';

$filter   = sanitize($_GET['status'] ?? '');
$where    = $filter ? "WHERE sb.status='$filter'" : '';
$bookings = $conn->query("SELECT sb.*, s.name as sname, c.name as cname FROM service_bookings sb LEFT JOIN services s ON sb.service_id=s.id LEFT JOIN clients c ON sb.client_id=c.id $where ORDER BY sb.created_at DESC");
?>
<div class="d-flex justify-content-between align-items-center mb-4">
  <div class="d-flex gap-2">
    <?php foreach([''=>'All','pending'=>'Pending','confirmed'=>'Confirmed','completed'=>'Completed','cancelled'=>'Cancelled'] as $v=>$l): ?>
    <a href="?status=<?= $v ?>" class="btn btn-sm <?= $filter===$v?'btn-accent':'btn-outline-accent' ?>" style="border-radius:10px"><?= $l ?></a>
    <?php endforeach; ?>
  </div>
  <span class="badge-soft-primary"><?= $bookings ? $bookings->num_rows : 0 ?> bookings</span>
</div>
<div class="admin-card">
  <div class="table-responsive">
    <table class="table admin-table">
      <thead><tr><th>Client</th><th>Service</th><th>Contact</th><th>Date</th><th>Slot</th><th>Update Status</th><th>Badge</th></tr></thead>
      <tbody>
        <?php if($bookings && $bookings->num_rows > 0): while($b = $bookings->fetch_assoc()): ?>
        <tr>
          <td class="fw-bold" style="font-size:.85rem"><?= htmlspecialchars($b['cname'] ?: $b['name']) ?></td>
          <td style="font-size:.85rem"><?= htmlspecialchars($b['sname']) ?></td>
          <td style="font-size:.78rem"><?= htmlspecialchars($b['phone'] ?? '-') ?></td>
          <td style="font-size:.8rem"><?= $b['booking_date'] ? date('d M Y', strtotime($b['booking_date'])) : 'TBD' ?></td>
          <td style="font-size:.78rem"><?= htmlspecialchars($b['time_slot'] ?? '-') ?></td>
          <td>
            <form method="POST" class="d-flex gap-1 align-items-center">
              <input type="hidden" name="bid" value="<?= $b['id'] ?>">
              <select name="status" class="form-select form-select-sm" style="width:130px" onchange="this.form.submit()">
                <?php foreach(['pending','confirmed','completed','cancelled'] as $s): ?>
                <option value="<?= $s ?>" <?= $b['status']==$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                <?php endforeach; ?>
              </select>
            </form>
          </td>
          <td>
            <span class="badge-soft-<?= ['pending'=>'warning','confirmed'=>'success','completed'=>'primary','cancelled'=>'danger'][$b['status']] ?? 'warning' ?>">
              <?= strtoupper($b['status']) ?>
            </span>
          </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="7" class="text-center py-4" style="color:var(--text-muted)">No bookings found</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body></html>
