<?php
$pageTitle = 'Edit Property';
require_once 'includes/sidebar.php';

$id = (int)($_GET['id'] ?? 0);
$prop = $conn->query("SELECT * FROM properties WHERE id=$id")->fetch_assoc();
if(!$prop) { header("Location: properties.php"); exit(); }

$images = $conn->query("SELECT * FROM property_images WHERE property_id=$id ORDER BY is_primary DESC");
$imgArr = [];
while($img = $images->fetch_assoc()) $imgArr[$img['image_type']] = $img;

$msg = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
  $title = sanitize($_POST['title']);
  $desc = sanitize($_POST['description']);
  $type = sanitize($_POST['type']);
  $ltype = sanitize($_POST['listing_type']);
  $price = (float)$_POST['price'];
  $area = sanitize($_POST['area']);
  $beds = (int)$_POST['bedrooms'];
  $baths = (int)$_POST['bathrooms'];
  $location = sanitize($_POST['location']);
  $city = sanitize($_POST['city']);
  $state = sanitize($_POST['state']);
  $pin = sanitize($_POST['pincode']);
  $amenities = sanitize($_POST['amenities']);
  $status = sanitize($_POST['status']);
  $featured = isset($_POST['featured']) ? 1 : 0;

  $conn->query("UPDATE properties SET title='$title',description='$desc',type='$type',listing_type='$ltype',price=$price,area='$area',bedrooms=$beds,bathrooms=$baths,location='$location',city='$city',state='$state',pincode='$pin',amenities='$amenities',status='$status',featured=$featured WHERE id=$id");

  // Update images
  $imgTypes = ['exterior','hall','bedroom','bathroom','kitchen'];
  $imgKeys = ['img_exterior','img_hall','img_bedroom','img_bathroom','img_kitchen'];
  foreach($imgTypes as $ii => $itype) {
    $url = sanitize($_POST[$imgKeys[$ii]] ?? '');
    if(!empty($url)) {
      $isPrimary = ($itype == 'exterior') ? 1 : 0;
      $existing = $conn->query("SELECT id FROM property_images WHERE property_id=$id AND image_type='$itype'")->num_rows;
      if($existing > 0) {
        $conn->query("UPDATE property_images SET image_url='$url' WHERE property_id=$id AND image_type='$itype'");
      } else {
        $conn->query("INSERT INTO property_images (property_id,image_url,image_type,is_primary) VALUES($id,'$url','$itype',$isPrimary)");
      }
    }
  }

  $msg = '<div class="alert alert-success">✅ Property updated! <a href="properties.php">Back to list</a></div>';
  $prop = $conn->query("SELECT * FROM properties WHERE id=$id")->fetch_assoc();
}

$imgDefaults = [
  'exterior' => 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800',
  'hall' => 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800',
  'bedroom' => 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800',
  'bathroom' => 'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800',
  'kitchen' => 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800',
];
?>

<?= $msg ?>

<div class="admin-card">
  <form method="POST">
    <div class="row g-4">
      <div class="col-md-8">
        <h5 class="fw-bold mb-3">Edit Property</h5>
        <div class="row g-3">
          <div class="col-12">
            <label class="fw-bold">Title</label>
            <input type="text" name="title" class="form-control" value="<?= $prop['title'] ?>" required>
          </div>
          <div class="col-md-6">
            <label class="fw-bold">Type</label>
            <select name="type" class="form-select">
              <?php foreach(['home','apartment','villa','site','commercial'] as $t): ?>
              <option value="<?= $t ?>" <?= $prop['type']==$t?'selected':'' ?>><?= ucfirst($t) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="fw-bold">Listing Type</label>
            <select name="listing_type" class="form-select">
              <?php foreach(['buy','rent','commercial'] as $t): ?>
              <option value="<?= $t ?>" <?= $prop['listing_type']==$t?'selected':'' ?>><?= ucfirst($t) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-4">
            <label class="fw-bold">Price</label>
            <input type="number" name="price" class="form-control" value="<?= $prop['price'] ?>">
          </div>
          <div class="col-md-4">
            <label class="fw-bold">Area</label>
            <input type="text" name="area" class="form-control" value="<?= $prop['area'] ?>">
          </div>
          <div class="col-md-2">
            <label class="fw-bold">Beds</label>
            <input type="number" name="bedrooms" class="form-control" value="<?= $prop['bedrooms'] ?>">
          </div>
          <div class="col-md-2">
            <label class="fw-bold">Baths</label>
            <input type="number" name="bathrooms" class="form-control" value="<?= $prop['bathrooms'] ?>">
          </div>
          <div class="col-md-6">
            <label class="fw-bold">Location</label>
            <input type="text" name="location" class="form-control" value="<?= $prop['location'] ?>">
          </div>
          <div class="col-md-6">
            <label class="fw-bold">City</label>
            <input type="text" name="city" class="form-control" value="<?= $prop['city'] ?>">
          </div>
          <div class="col-md-6">
            <label class="fw-bold">State</label>
            <input type="text" name="state" class="form-control" value="<?= $prop['state'] ?>">
          </div>
          <div class="col-md-6">
            <label class="fw-bold">Pincode</label>
            <input type="text" name="pincode" class="form-control" value="<?= $prop['pincode'] ?>">
          </div>
          <div class="col-12">
            <label class="fw-bold">Amenities</label>
            <input type="text" name="amenities" class="form-control" value="<?= $prop['amenities'] ?>">
          </div>
          <div class="col-12">
            <label class="fw-bold">Description</label>
            <textarea name="description" class="form-control" rows="4"><?= $prop['description'] ?></textarea>
          </div>
          <div class="col-md-6">
            <label class="fw-bold">Status</label>
            <select name="status" class="form-select">
              <option value="available" <?= $prop['status']=='available'?'selected':'' ?>>Available</option>
              <option value="sold" <?= $prop['status']=='sold'?'selected':'' ?>>Sold</option>
              <option value="rented" <?= $prop['status']=='rented'?'selected':'' ?>>Rented</option>
            </select>
          </div>
          <div class="col-12">
            <div class="form-check">
              <input type="checkbox" name="featured" class="form-check-input" <?= $prop['featured']?'checked':'' ?>>
              <label class="form-check-label fw-bold">⭐ Featured Property</label>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <h5 class="fw-bold mb-3">Room Images</h5>
        <?php
        $fields = [
          ['img_exterior','exterior','fa-home','Exterior'],
          ['img_hall','hall','fa-couch','Living Hall'],
          ['img_bedroom','bedroom','fa-bed','Bedroom'],
          ['img_bathroom','bathroom','fa-bath','Bathroom'],
          ['img_kitchen','kitchen','fa-utensils','Kitchen'],
        ];
        foreach($fields as $fi => [$fname, $ftype, $ficon, $flabel]):
          $currentUrl = $imgArr[$ftype]['image_url'] ?? $imgDefaults[$ftype];
        ?>
        <div class="mb-3">
          <label class="fw-bold small"><i class="fas <?= $ficon ?> me-1 text-accent"></i><?= $flabel ?></label>
          <input type="url" name="<?= $fname ?>" class="form-control form-control-sm img-url-input" value="<?= $currentUrl ?>" data-preview="prev_<?= $fi ?>">
          <img src="<?= $currentUrl ?>" class="mt-1 w-100 rounded" style="height:70px;object-fit:cover" id="prev_<?= $fi ?>">
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <hr>
    <div class="d-flex gap-3">
      <button type="submit" class="btn btn-accent px-5 py-2 fw-bold">Update Property</button>
      <a href="properties.php" class="btn btn-secondary px-4 py-2">Cancel</a>
    </div>
  </form>
</div>

<script>
document.querySelectorAll('.img-url-input').forEach(input => {
  input.addEventListener('input', function() {
    const prevId = this.dataset.preview;
    document.getElementById(prevId).src = this.value;
  });
});
</script>

<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body></html>

