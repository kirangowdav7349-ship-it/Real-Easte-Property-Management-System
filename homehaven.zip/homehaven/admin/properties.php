<?php
// ALL redirects BEFORE sidebar
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../includes/config.php';
if (!isAdminLoggedIn()) redirect(SITE_URL . '/admin/login.php');

if (isset($_GET['delete'])) {
    $did = (int)$_GET['delete'];
    // Delete child records first (foreign key constraints)
    $conn->query("DELETE FROM property_images WHERE property_id=$did");
    $conn->query("DELETE FROM enquiries WHERE property_id=$did");
    $conn->query("DELETE FROM rent_payments WHERE property_id=$did");
    $conn->query("DELETE FROM maintenance_requests WHERE property_id=$did");
    $conn->query("DELETE FROM properties WHERE id=$did");
    header("Location: properties.php?msg=deleted"); exit();
}
if (isset($_GET['toggle'])) {
    $tid  = (int)$_GET['toggle'];
    $curr = $conn->query("SELECT status FROM properties WHERE id=$tid")->fetch_assoc()['status'];
    $new  = $curr == 'available' ? 'sold' : 'available';
    $conn->query("UPDATE properties SET status='$new' WHERE id=$tid");
    header("Location: properties.php"); exit();
}
if (isset($_GET['feature'])) {
    $tid  = (int)$_GET['feature'];
    $curr = (int)$conn->query("SELECT featured FROM properties WHERE id=$tid")->fetch_assoc()['featured'];
    $conn->query("UPDATE properties SET featured=" . ($curr ? 0 : 1) . " WHERE id=$tid");
    header("Location: properties.php"); exit();
}

$pageTitle = 'Properties';
require_once 'includes/sidebar.php';

$search = sanitize($_GET['s'] ?? '');
$type   = sanitize($_GET['type'] ?? '');
$lt     = sanitize($_GET['listing_type'] ?? '');
$where  = "1=1";
if ($search) $where .= " AND (p.title LIKE '%$search%' OR p.city LIKE '%$search%')";
if ($type)   $where .= " AND p.type='$type'";
if ($lt)     $where .= " AND p.listing_type='$lt'";

$props = $conn->query("SELECT p.*, pi.image_url FROM properties p LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 WHERE $where ORDER BY p.created_at DESC");
$msgs = ['deleted'=>['danger','Property deleted.'],'saved'=>['success','Property saved!']];
?>
<?php if(isset($_GET['msg']) && isset($msgs[$_GET['msg']])): ?>
<div class="alert alert-<?= $msgs[$_GET['msg']][0] ?> rounded-3 mb-3"><?= $msgs[$_GET['msg']][1] ?></div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
  <form class="d-flex gap-2 flex-wrap" method="GET">
    <input type="text" name="s" class="form-control" placeholder="Search..." value="<?= htmlspecialchars($search) ?>" style="width:180px">
    <select name="type" class="form-select" style="width:130px">
      <option value="">All Types</option>
      <?php foreach(['apartment','villa','home','site','commercial'] as $t): ?>
      <option value="<?= $t ?>" <?= $type===$t?'selected':'' ?>><?= ucfirst($t) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="listing_type" class="form-select" style="width:120px">
      <option value="">Buy/Rent</option>
      <option value="buy" <?= $lt==='buy'?'selected':'' ?>>Buy</option>
      <option value="rent" <?= $lt==='rent'?'selected':'' ?>>Rent</option>
      <option value="commercial" <?= $lt==='commercial'?'selected':'' ?>>Commercial</option>
    </select>
    <button type="submit" class="btn btn-accent btn-sm">Filter</button>
    <a href="properties.php" class="btn btn-outline-accent btn-sm">Clear</a>
  </form>
  <a href="add-property.php" class="btn btn-accent"><i class="fas fa-plus me-2"></i>Add Property</a>
</div>

<div class="admin-card">
  <div class="table-responsive">
    <table class="table admin-table">
      <thead>
        <tr><th>Property</th><th>Type</th><th>Listing</th><th>Price</th><th>City</th><th>Status</th><th>Featured</th><th style="min-width:160px">Actions</th></tr>
      </thead>
      <tbody>
        <?php if($props && $props->num_rows > 0): while($p = $props->fetch_assoc()): ?>
        <tr>
          <td>
            <div class="d-flex align-items-center gap-2">
              <img src="<?= htmlspecialchars($p['image_url'] ?? 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=100') ?>"
                   onerror="this.src='https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=100'"
                   style="width:40px;height:30px;object-fit:cover;border-radius:6px;flex-shrink:0" alt="">
              <div>
                <div class="fw-bold" style="font-size:.83rem;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($p['title']) ?></div>
                <div style="font-size:.72rem;color:var(--text-muted)"><?= date('d M Y', strtotime($p['created_at'])) ?></div>
              </div>
            </div>
          </td>
          <td><span class="badge-soft-primary"><?= ucfirst($p['type']) ?></span></td>
          <td><span class="badge-soft-<?= $p['listing_type']==='buy'?'success':($p['listing_type']==='rent'?'warning':'purple') ?>"><?= strtoupper($p['listing_type']) ?></span></td>
          <td class="fw-bold" style="color:#FF6B35"><?= formatPrice($p['price']) ?></td>
          <td style="font-size:.83rem"><?= htmlspecialchars($p['city']) ?></td>
          <td>
            <a href="?toggle=<?= $p['id'] ?>" class="badge-soft-<?= $p['status']=='available'?'success':'danger' ?>" style="text-decoration:none;cursor:pointer" title="Click to toggle">
              <?= strtoupper($p['status']) ?>
            </a>
          </td>
          <td>
            <a href="?feature=<?= $p['id'] ?>" title="Toggle featured" style="text-decoration:none">
              <i class="fa<?= $p['featured']?'s':'r' ?> fa-star" style="color:<?= $p['featured']?'#f59e0b':'var(--border-c)' ?>"></i>
            </a>
          </td>
          <td>
            <div class="d-flex gap-1 flex-nowrap">
              <a href="edit-property.php?id=<?= $p['id'] ?>" class="btn btn-sm" style="background:rgba(59,130,246,.1);color:#3b82f6;border-radius:8px;white-space:nowrap" title="Edit"><i class="fas fa-edit"></i></a>
              <a href="<?= SITE_URL ?>/property-detail.php?id=<?= $p['id'] ?>" target="_blank" class="btn btn-sm" style="background:rgba(16,185,129,.1);color:#10b981;border-radius:8px;white-space:nowrap" title="View"><i class="fas fa-eye"></i></a>
              <a href="?delete=<?= $p['id'] ?>" onclick="return confirm('⚠️ Are you sure? This will permanently delete this property and all its images.')" class="btn btn-sm" style="background:rgba(239,68,68,.1);color:#ef4444;border-radius:8px;white-space:nowrap" title="Delete"><i class="fas fa-trash-alt"></i></a>
            </div>
          </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="8" class="text-center py-4" style="color:var(--text-muted)">No properties found. <a href="add-property.php" style="color:#FF6B35">Add one</a></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body></html>
