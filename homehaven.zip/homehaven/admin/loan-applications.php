<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../includes/config.php';
if (!isAdminLoggedIn()) redirect(SITE_URL . '/admin/login.php');

// Update status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_loan'])) {
    $lid = (int)$_POST['loan_id'];
    $status = $conn->real_escape_string($_POST['status'] ?? 'pending');
    $remarks = $conn->real_escape_string(trim($_POST['remarks'] ?? ''));
    $step = 1;
    switch($status) {
        case 'pending': $step=1; break;
        case 'documents_required': $step=2; break;
        case 'under_review': $step=3; break;
        case 'verified': $step=4; break;
        case 'approved': $step=5; break;
        case 'rejected': $step=5; break;
    }
    $extra = '';
    if ($status === 'verified') $extra = ", verified_at=NOW()";
    if ($status === 'approved') $extra = ", approved_at=NOW()";
    $conn->query("UPDATE loan_applications SET status='$status', current_step=$step, admin_remarks='$remarks' $extra WHERE id=$lid");
    header("Location: loan-applications.php?msg=updated"); exit();
}

// Update document status
if (isset($_GET['doc_action']) && isset($_GET['doc_id'])) {
    $did = (int)$_GET['doc_id'];
    $dstatus = $_GET['doc_action'] === 'approve' ? 'approved' : 'rejected';
    $conn->query("UPDATE loan_documents SET status='$dstatus' WHERE id=$did");
    header("Location: loan-applications.php?msg=doc_updated"); exit();
}

$pageTitle = 'Loan Applications';
require_once 'includes/sidebar.php';

$applications = $conn->query("SELECT la.*, c.name as client_name, c.email as client_email
    FROM loan_applications la
    LEFT JOIN clients c ON la.client_id=c.id
    ORDER BY la.created_at DESC");

$statusColors = [
    'pending'=>'#f59e0b','documents_required'=>'#3b82f6','under_review'=>'#8b5cf6',
    'verified'=>'#10b981','approved'=>'#059669','rejected'=>'#ef4444'
];
$statusLabels = [
    'pending'=>'Pending','documents_required'=>'Docs Required','under_review'=>'Under Review',
    'verified'=>'Verified','approved'=>'Approved','rejected'=>'Rejected'
];

$flashMsg = '';
if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'updated') $flashMsg = '✅ Loan application updated!';
    if ($_GET['msg'] === 'doc_updated') $flashMsg = '✅ Document status updated!';
}

// Stats
$totalApps = (int)$conn->query("SELECT COUNT(*) as c FROM loan_applications")->fetch_assoc()['c'];
$pendApps = (int)$conn->query("SELECT COUNT(*) as c FROM loan_applications WHERE status='pending'")->fetch_assoc()['c'];
$reviewApps = (int)$conn->query("SELECT COUNT(*) as c FROM loan_applications WHERE status='under_review'")->fetch_assoc()['c'];
$approvedApps = (int)$conn->query("SELECT COUNT(*) as c FROM loan_applications WHERE status='approved'")->fetch_assoc()['c'];
?>

<?php if ($flashMsg): ?>
<div class="alert alert-success rounded-3 mb-3"><?= $flashMsg ?></div>
<?php endif; ?>

<!-- Stats -->
<div class="row g-3 mb-4">
  <?php foreach([
    ['Total','fa-layer-group',$totalApps,'linear-gradient(135deg,#1a3c5e,#2d6a4f)'],
    ['Pending','fa-clock',$pendApps,'linear-gradient(135deg,#f59e0b,#d97706)'],
    ['Under Review','fa-search',$reviewApps,'linear-gradient(135deg,#8b5cf6,#6d28d9)'],
    ['Approved','fa-check-circle',$approvedApps,'linear-gradient(135deg,#059669,#047857)'],
  ] as $s): ?>
  <div class="col-md-3 col-6">
    <div class="p-3 rounded-3 text-white text-center" style="background:<?=$s[3]?>">
      <i class="fas <?=$s[1]?> mb-1" style="font-size:1.3rem;opacity:.7"></i>
      <div class="fw-bold" style="font-size:1.6rem"><?=$s[2]?></div>
      <div style="font-size:.78rem;opacity:.85"><?=$s[0]?></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="fw-bold mb-0"><i class="fas fa-file-invoice-dollar me-2" style="color:#FF6B35"></i>Loan Applications</h5>
</div>

<div class="admin-card">
  <?php if ($applications && $applications->num_rows > 0): ?>
    <?php while ($app = $applications->fetch_assoc()):
      $sColor = $statusColors[$app['status']] ?? '#888';
      $sLabel = $statusLabels[$app['status']] ?? $app['status'];
      $docs = $conn->query("SELECT * FROM loan_documents WHERE application_id=" . (int)$app['id']);
    ?>
    <div class="p-3 mb-3 rounded-3" style="background:var(--card-bg,#fff);border:1px solid var(--border,#e5e9ef)">
      <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
        <div>
          <h6 class="fw-bold mb-1">#<?=$app['id']?> — <?=htmlspecialchars($app['bank_name'])?> · ₹<?=number_format((float)$app['loan_amount'])?></h6>
          <div style="font-size:.8rem;color:var(--text-muted)">
            <i class="fas fa-user me-1"></i><?=htmlspecialchars($app['full_name'])?> ·
            <i class="fas fa-phone me-1"></i><?=htmlspecialchars($app['phone'])?> ·
            <i class="far fa-clock me-1"></i><?=date('d M Y', strtotime($app['created_at']))?>
            <?php if($app['client_name']): ?> · <i class="fas fa-user-circle me-1"></i>Client: <?=htmlspecialchars($app['client_name'])?><?php endif; ?>
          </div>
        </div>
        <span class="badge rounded-pill px-3 py-2" style="background:<?=$sColor?>15;color:<?=$sColor?>;font-weight:600;font-size:.78rem"><?=$sLabel?></span>
      </div>

      <div class="row g-2 mb-2" style="font-size:.82rem">
        <div class="col-md-3"><strong>Income:</strong> ₹<?=number_format((float)$app['monthly_income'])?></div>
        <div class="col-md-3"><strong>Property:</strong> <?=htmlspecialchars($app['property_type'] ?? '-')?></div>
        <div class="col-md-3"><strong>Employment:</strong> <?=htmlspecialchars($app['employment'] ?? '-')?></div>
        <div class="col-md-3"><strong>Step:</strong> <?=$app['current_step']?>/5</div>
      </div>

      <!-- Documents -->
      <?php if($docs && $docs->num_rows > 0): ?>
      <div class="mb-2">
        <strong style="font-size:.8rem">📄 Documents:</strong>
        <div class="d-flex gap-2 flex-wrap mt-1">
          <?php while($d = $docs->fetch_assoc()):
            $dColor = $d['status']==='approved'?'#059669':($d['status']==='rejected'?'#ef4444':'#f59e0b');
          ?>
          <div class="d-flex align-items-center gap-1 px-2 py-1 rounded-2" style="background:<?=$dColor?>10;border:1px solid <?=$dColor?>30;font-size:.75rem">
            <span style="color:<?=$dColor?>"><?=str_replace('_',' ',ucfirst($d['doc_type']))?></span>
            <?php if($d['status']==='pending'): ?>
            <a href="?doc_action=approve&doc_id=<?=$d['id']?>" class="text-success ms-1" title="Approve"><i class="fas fa-check"></i></a>
            <a href="?doc_action=reject&doc_id=<?=$d['id']?>" class="text-danger ms-1" title="Reject"><i class="fas fa-times"></i></a>
            <?php else: ?>
            <span class="fw-bold" style="color:<?=$dColor?>"><?=ucfirst($d['status'])?></span>
            <?php endif; ?>
          </div>
          <?php endwhile; ?>
        </div>
      </div>
      <?php endif; ?>

      <!-- Update Form -->
      <form method="POST" class="d-flex gap-2 align-items-end flex-wrap mt-2">
        <input type="hidden" name="update_loan" value="1">
        <input type="hidden" name="loan_id" value="<?=$app['id']?>">
        <div>
          <label class="small fw-bold">Status</label>
          <select name="status" class="form-select form-select-sm" style="min-width:160px">
            <?php foreach($statusLabels as $k => $v): ?>
            <option value="<?=$k?>" <?=$app['status']===$k?'selected':''?>><?=$v?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="flex-fill">
          <label class="small fw-bold">Admin Remarks</label>
          <input type="text" name="remarks" class="form-control form-control-sm" value="<?=htmlspecialchars($app['admin_remarks'] ?? '')?>" placeholder="Add remarks...">
        </div>
        <button type="submit" class="btn btn-accent btn-sm px-3">Update</button>
      </form>
    </div>
    <?php endwhile; ?>
  <?php else: ?>
    <div class="text-center py-5" style="color:var(--text-muted)">
      <i class="fas fa-inbox mb-2" style="font-size:2rem;opacity:.5"></i>
      <p>No loan applications yet.</p>
    </div>
  <?php endif; ?>
</div>

<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
