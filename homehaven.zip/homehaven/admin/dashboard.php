<?php
$pageTitle = 'Dashboard';
require_once 'includes/sidebar.php';
$total_props    = $conn->query("SELECT COUNT(*) as c FROM properties")->fetch_assoc()['c'];
$avail_props    = $conn->query("SELECT COUNT(*) as c FROM properties WHERE status='available'")->fetch_assoc()['c'];
$sold_props     = $conn->query("SELECT COUNT(*) as c FROM properties WHERE status='sold'")->fetch_assoc()['c'];
$rented_props   = $conn->query("SELECT COUNT(*) as c FROM properties WHERE status='rented'")->fetch_assoc()['c'];
$total_clients  = $conn->query("SELECT COUNT(*) as c FROM clients")->fetch_assoc()['c'];
$new_clients    = $conn->query("SELECT COUNT(*) as c FROM clients WHERE MONTH(created_at)=MONTH(NOW())")->fetch_assoc()['c'];
$total_enq      = $conn->query("SELECT COUNT(*) as c FROM enquiries WHERE status='new'")->fetch_assoc()['c'];
$total_bookings = $conn->query("SELECT COUNT(*) as c FROM service_bookings")->fetch_assoc()['c'];
$pending_books  = $conn->query("SELECT COUNT(*) as c FROM service_bookings WHERE status='pending'")->fetch_assoc()['c'];
$rev_total      = (float)$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE status='paid'")->fetch_assoc()['s'];
$rev_month      = (float)$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE status='paid' AND MONTH(created_at)=MONTH(NOW())")->fetch_assoc()['s'];
$pending_pay    = (float)$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE status='pending'")->fetch_assoc()['s'];
$pending_pay_count = (int)$conn->query("SELECT COUNT(*) as c FROM rent_payments WHERE status='pending'")->fetch_assoc()['c'];
$recent_enq     = $conn->query("SELECT e.*,p.title as ptitle FROM enquiries e LEFT JOIN properties p ON e.property_id=p.id ORDER BY e.created_at DESC LIMIT 6");
$recent_props   = $conn->query("SELECT p.*,pi.image_url FROM properties p LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 ORDER BY p.created_at DESC LIMIT 5");
$top_clients    = $conn->query("SELECT c.name,c.email,COUNT(sb.id) as bookings FROM clients c LEFT JOIN service_bookings sb ON c.id=sb.client_id GROUP BY c.id ORDER BY bookings DESC LIMIT 5");

// Transaction notifications
$unread_txn_count = 0;
$txn_check = $conn->query("SELECT COUNT(*) as c FROM property_transactions WHERE admin_read=0");
if($txn_check) $unread_txn_count = (int)$txn_check->fetch_assoc()['c'];
$pending_txn_count = 0;
$txn_pending = $conn->query("SELECT COUNT(*) as c FROM property_transactions WHERE status='pending'");
if($txn_pending) $pending_txn_count = (int)$txn_pending->fetch_assoc()['c'];
$recent_txns = $conn->query("SELECT t.*, p.title as ptitle, p.location, p.city, p.price as prop_price, pi.image_url 
  FROM property_transactions t 
  LEFT JOIN properties p ON t.property_id=p.id 
  LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 
  ORDER BY t.created_at DESC LIMIT 10");

// Mark admin notifications as read if viewing
if($unread_txn_count > 0) {
  $conn->query("UPDATE property_transactions SET admin_read=1 WHERE admin_read=0");
}
$chart_data = []; $chart_labels = [];
for ($m = 6; $m >= 0; $m--) {
    $r = $conn->query("SELECT COUNT(*) as c FROM service_bookings WHERE MONTH(created_at)=MONTH(DATE_SUB(NOW(),INTERVAL $m MONTH)) AND YEAR(created_at)=YEAR(DATE_SUB(NOW(),INTERVAL $m MONTH))");
    $chart_data[] = (int)$r->fetch_assoc()['c'];
    $chart_labels[] = date('M', strtotime("-$m months"));
}
?>
<!-- STAT CARDS -->
<div class="row g-3 mb-4">
<?php
$stats = [
  ['Total Properties',$total_props,'fas fa-building','linear-gradient(135deg,#1a3c5e,#2d6a4f)','+'.($avail_props).' available'],
  ['Total Clients',$total_clients,'fas fa-users','linear-gradient(135deg,#10b981,#059669)','+'.$new_clients.' this month'],
  ['New Enquiries',$total_enq,'fas fa-envelope','linear-gradient(135deg,#f59e0b,#d97706)','Needs attention'],
  ['Buy/Rent Requests',$pending_txn_count,'fas fa-handshake','linear-gradient(135deg,#6366f1,#4f46e5)',$unread_txn_count.' new notification(s)'],
  ['Monthly Revenue','₹'.number_format($rev_month),'fas fa-rupee-sign','linear-gradient(135deg,#FF6B35,#c0392b)','₹'.number_format($pending_pay).' pending'],
  ['Total Revenue','₹'.number_format($rev_total),'fas fa-chart-line','linear-gradient(135deg,#8b5cf6,#7c3aed)','All time'],
];
foreach($stats as $s):
?>
<div class="col-xl-4 col-md-4 col-6">
  <div class="stat-card-new" style="background:<?= $s[3] ?>">
    <div class="stat-icon"><i class="<?= $s[2] ?>"></i></div>
    <div class="stat-val"><?= $s[1] ?></div>
    <div class="stat-lbl"><?= $s[0] ?></div>
    <div class="stat-change"><i class="fas fa-circle-dot me-1"></i><?= $s[4] ?></div>
  </div>
</div>
<?php endforeach; ?>
</div>

<!-- QUICK ACTIONS -->
<div class="admin-card mb-4">
  <h6 class="fw-bold mb-3">Quick Actions</h6>
  <div class="row g-2">
    <?php foreach([
      ['Add Property','fas fa-plus-circle','#FF6B35','add-property.php'],
      ['Enquiries','fas fa-envelope','#10b981','enquiries.php'],
      ['Clients','fas fa-users','#3b82f6','clients.php'],
      ['Finance','fas fa-wallet','#f59e0b','finance.php'],
      ['Maintenance','fas fa-wrench','#ef4444','maintenance.php'],
      ['Analytics','fas fa-chart-line','#8b5cf6','analytics.php'],
      ['Settings','fas fa-cog','#64748b','settings.php'],
      ['Reports','fas fa-chart-bar','#1a3c5e','reports.php'],
    ] as $q): ?>
    <div class="col-lg-3 col-6">
      <a href="<?= $q[3] ?>" class="text-decoration-none d-flex align-items-center gap-3 p-3 rounded-3" style="background:<?= $q[2] ?>12;border:1px solid <?= $q[2] ?>25;transition:.2s" onmouseover="this.style.background='<?= $q[2] ?>22'" onmouseout="this.style.background='<?= $q[2] ?>12'">
        <div style="width:38px;height:38px;background:<?= $q[2] ?>;border-radius:10px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:.9rem;flex-shrink:0"><i class="<?= $q[1] ?>"></i></div>
        <span style="font-size:.85rem;font-weight:600;color:var(--text-main)"><?= $q[0] ?></span>
      </a>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- BUY/RENT TRANSACTION NOTIFICATIONS -->
<?php if($recent_txns && $recent_txns->num_rows > 0): ?>
<div class="admin-card mb-4" style="border-left:4px solid #6366f1">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h6 class="fw-bold mb-0">
      <i class="fas fa-bell me-2" style="color:#6366f1"></i>Buy / Rent Notifications
      <?php if($unread_txn_count > 0): ?>
        <span class="badge rounded-pill" style="background:#6366f1;font-size:.65rem;vertical-align:middle;margin-left:6px"><?= $unread_txn_count ?> NEW</span>
      <?php endif; ?>
    </h6>
    <a href="transactions.php" class="btn btn-sm btn-outline-accent">View All</a>
  </div>
  <div class="table-responsive">
    <table class="table admin-table mb-0">
      <thead>
        <tr>
          <th style="width:50px">Type</th>
          <th>Property</th>
          <th>Client Details</th>
          <th>Contact</th>
          <th>Amount</th>
          <th>Status</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php while($tx = $recent_txns->fetch_assoc()): ?>
        <tr style="<?= !$tx['admin_read'] ? 'background:#f0f0ff;' : '' ?>">
          <td>
            <?php if($tx['transaction_type'] === 'buy'): ?>
              <span class="badge" style="background:#10b981;font-size:.7rem"><i class="fas fa-shopping-cart me-1"></i>BUY</span>
            <?php else: ?>
              <span class="badge" style="background:#3b82f6;font-size:.7rem"><i class="fas fa-key me-1"></i>RENT</span>
            <?php endif; ?>
          </td>
          <td>
            <div class="d-flex align-items-center gap-2">
              <img src="<?= $tx['image_url'] ?? 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=100' ?>" style="width:40px;height:32px;object-fit:cover;border-radius:6px;flex-shrink:0" alt="">
              <div>
                <div style="font-size:.8rem;font-weight:600;max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($tx['ptitle'] ?? 'Unknown') ?></div>
                <div style="font-size:.68rem;color:var(--text-muted)"><?= htmlspecialchars(($tx['location'] ?? '') . ', ' . ($tx['city'] ?? '')) ?></div>
              </div>
            </div>
          </td>
          <td>
            <div style="font-size:.82rem;font-weight:600"><?= htmlspecialchars($tx['full_name']) ?></div>
            <?php if($tx['address']): ?>
              <div style="font-size:.68rem;color:var(--text-muted)"><i class="fas fa-map-pin me-1"></i><?= htmlspecialchars(substr($tx['address'],0,30)) ?></div>
            <?php endif; ?>
          </td>
          <td>
            <div style="font-size:.78rem"><i class="fas fa-phone me-1 text-success"></i><?= htmlspecialchars($tx['phone']) ?></div>
            <div style="font-size:.68rem;color:var(--text-muted)"><i class="fas fa-envelope me-1"></i><?= htmlspecialchars($tx['email']) ?></div>
          </td>
          <td>
            <div style="font-size:.85rem;font-weight:700;color:#FF6B35">₹<?= number_format($tx['amount']) ?></div>
            <?php if($tx['transaction_type'] === 'rent'): ?>
              <div style="font-size:.65rem;color:var(--text-muted)">/month</div>
            <?php endif; ?>
          </td>
          <td>
            <?php
              $statusColors = ['pending'=>'warning','approved'=>'success','rejected'=>'danger','completed'=>'primary'];
              $sc = $statusColors[$tx['status']] ?? 'secondary';
            ?>
            <span class="badge bg-<?= $sc ?> <?= $sc==='warning'?'text-dark':'' ?>" style="font-size:.68rem"><?= strtoupper($tx['status']) ?></span>
          </td>
          <td style="font-size:.72rem;color:var(--text-muted);white-space:nowrap">
            <?= date('d M Y', strtotime($tx['created_at'])) ?>
            <br><?= date('h:i A', strtotime($tx['created_at'])) ?>
          </td>
        </tr>
        <?php if($tx['message']): ?>
        <tr style="<?= !$tx['admin_read'] ? 'background:#f0f0ff;' : '' ?>">
          <td colspan="7" style="padding-top:0;border-top:0">
            <div style="font-size:.75rem;color:var(--text-muted);padding:4px 0 4px 52px"><i class="fas fa-comment-alt me-1"></i><em><?= htmlspecialchars($tx['message']) ?></em></div>
          </td>
        </tr>
        <?php endif; ?>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>
<div class="row g-4 mb-4">
  <div class="col-lg-8">
    <div class="admin-card">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h6 class="fw-bold mb-0">Bookings (Last 7 Months)</h6>
        <a href="analytics.php" class="btn btn-sm btn-outline-accent">Full Analytics</a>
      </div>
      <div class="chart-container"><canvas id="bookingsChart"></canvas></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="admin-card">
      <h6 class="fw-bold mb-4">Property Status</h6>
      <div class="chart-container-sm"><canvas id="propChart"></canvas></div>
      <div class="mt-3">
        <?php foreach([['Available',$avail_props,'#10b981'],['Sold',$sold_props,'#3b82f6'],['Rented',$rented_props,'#f59e0b']] as $d): ?>
        <div class="d-flex justify-content-between align-items-center mb-2">
          <div class="d-flex align-items-center gap-2"><span style="width:10px;height:10px;border-radius:50%;background:<?=$d[2]?>;display:inline-block"></span><span style="font-size:.8rem"><?=$d[0]?></span></div>
          <span style="font-size:.8rem;font-weight:700"><?=$d[1]?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<div class="row g-4">
  <div class="col-lg-7">
    <div class="admin-card">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="fw-bold mb-0">Recent Enquiries</h6>
        <a href="enquiries.php" class="btn btn-sm btn-accent">View All</a>
      </div>
      <div class="table-responsive">
        <table class="table admin-table">
          <thead><tr><th>Name</th><th>Property</th><th>Contact</th><th>Status</th><th>Time</th></tr></thead>
          <tbody>
            <?php if($recent_enq&&$recent_enq->num_rows>0): while($e=$recent_enq->fetch_assoc()): ?>
            <tr>
              <td class="fw-bold" style="font-size:.85rem"><?= htmlspecialchars($e['name']??'-') ?></td>
              <td style="max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.78rem"><?= htmlspecialchars($e['ptitle']??'General') ?></td>
              <td style="font-size:.78rem"><?= htmlspecialchars($e['phone']??$e['email']??'-') ?></td>
              <td><span class="badge-soft-<?= $e['status']=='new'?'warning':'success' ?>"><?= strtoupper($e['status']) ?></span></td>
              <td style="font-size:.72rem;color:var(--text-muted)"><?= date('d M',strtotime($e['created_at'])) ?></td>
            </tr>
            <?php endwhile; else: ?>
            <tr><td colspan="5" class="text-center py-4" style="color:var(--text-muted);font-size:.85rem">No enquiries yet</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="admin-card mb-4">
      <h6 class="fw-bold mb-3">Top Clients</h6>
      <?php if($top_clients&&$top_clients->num_rows>0): while($c=$top_clients->fetch_assoc()): ?>
      <div class="d-flex align-items-center gap-3 mb-3">
        <div style="width:36px;height:36px;background:linear-gradient(135deg,#FF6B35,#c0392b);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:.85rem;flex-shrink:0"><?= strtoupper(substr($c['name'],0,1)) ?></div>
        <div style="flex:1;min-width:0">
          <div style="font-size:.83rem;font-weight:600"><?= htmlspecialchars($c['name']) ?></div>
          <div style="font-size:.72rem;color:var(--text-muted)"><?= htmlspecialchars($c['email']??'-') ?></div>
        </div>
        <span class="badge-soft-primary"><?= $c['bookings'] ?> bkgs</span>
      </div>
      <?php endwhile; endif; ?>
    </div>
    <div class="admin-card">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="fw-bold mb-0">Recent Properties</h6>
        <a href="add-property.php" class="btn btn-sm btn-accent">+ Add</a>
      </div>
      <?php if($recent_props&&$recent_props->num_rows>0): while($p=$recent_props->fetch_assoc()): ?>
      <div class="d-flex gap-3 align-items-center mb-3 pb-3" style="border-bottom:1px solid var(--border-c)">
        <img src="<?= $p['image_url']??'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=100' ?>" style="width:48px;height:40px;object-fit:cover;border-radius:8px;flex-shrink:0" alt="">
        <div style="flex:1;min-width:0">
          <div style="font-size:.8rem;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($p['title']) ?></div>
          <div style="font-size:.72rem;color:var(--text-muted)"><?= formatPrice($p['price']) ?></div>
        </div>
        <a href="edit-property.php?id=<?= $p['id'] ?>" style="background:#3b82f615;color:#3b82f6;border-radius:7px;padding:4px 10px;font-size:.75rem;text-decoration:none"><i class="fas fa-edit"></i></a>
      </div>
      <?php endwhile; endif; ?>
    </div>
  </div>
</div>

<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
<script>
new Chart(document.getElementById('bookingsChart'), {
  type: 'bar',
  data: {
    labels: <?= json_encode($chart_labels) ?>,
    datasets: [{ label: 'Bookings', data: <?= json_encode($chart_data) ?>, backgroundColor: 'rgba(255,107,53,.2)', borderColor: '#FF6B35', borderWidth: 2, borderRadius: 8 }]
  },
  options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,.06)' } }, x: { grid: { display: false } } } }
});
new Chart(document.getElementById('propChart'), {
  type: 'doughnut',
  data: {
    labels: ['Available','Sold','Rented'],
    datasets: [{ data: [<?= $avail_props ?>,<?= $sold_props ?>,<?= $rented_props ?>], backgroundColor: ['#10b981','#3b82f6','#f59e0b'], borderWidth: 0, hoverOffset: 6 }]
  },
  options: { responsive: true, maintainAspectRatio: false, cutout: '68%', plugins: { legend: { display: false } } }
});
</script>
</body></html>
