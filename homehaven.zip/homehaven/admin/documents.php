<?php
$pageTitle = 'Documents';
require_once 'includes/sidebar.php';

// Gather stats
$total_clients  = (int)$conn->query("SELECT COUNT(*) as c FROM clients")->fetch_assoc()['c'];
$total_props    = (int)$conn->query("SELECT COUNT(*) as c FROM properties")->fetch_assoc()['c'];
$total_payments = (int)$conn->query("SELECT COUNT(*) as c FROM rent_payments")->fetch_assoc()['c'];
$total_enq      = (int)$conn->query("SELECT COUNT(*) as c FROM enquiries")->fetch_assoc()['c'];
$total_bookings = (int)$conn->query("SELECT COUNT(*) as c FROM service_bookings")->fetch_assoc()['c'];
$total_legal    = (int)$conn->query("SELECT COUNT(*) as c FROM legal_bookings")->fetch_assoc()['c'];
$total_images   = (int)$conn->query("SELECT COUNT(*) as c FROM property_images")->fetch_assoc()['c'];
$loan_apps      = (int)$conn->query("SELECT COUNT(*) as c FROM loan_applications")->fetch_assoc()['c'];

$active_tab = $_GET['tab'] ?? 'folders';
?>

<!-- Quick Stats Row -->
<div class="row g-3 mb-4">
  <?php foreach([
    ['Total Files','fas fa-file',($total_payments+$total_enq+$total_bookings+$total_legal),'#3b82f6'],
    ['Images','fas fa-image',$total_images,'#8b5cf6'],
    ['Contacts','fas fa-address-book',$total_clients,'#10b981'],
    ['Reports','fas fa-chart-bar',4,'#f59e0b'],
  ] as $s): ?>
  <div class="col-md-3 col-6">
    <div class="admin-card d-flex align-items-center gap-3">
      <div style="width:46px;height:46px;background:<?=$s[3]?>15;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;color:<?=$s[3]?>;flex-shrink:0"><i class="<?=$s[1]?>"></i></div>
      <div><div style="font-size:1.4rem;font-weight:800"><?=$s[2]?></div><div style="font-size:.75rem;color:var(--text-muted)"><?=$s[0]?></div></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- TAB NAVIGATION -->
<div class="admin-card mb-4 p-2">
  <div class="d-flex gap-2 flex-wrap">
    <?php foreach([
      ['folders','fas fa-folder','Folders & Files'],
      ['contacts','fas fa-address-book','Contacts'],
      ['images','fas fa-images','Images Storage'],
      ['reports','fas fa-chart-bar','Reports & Analytics'],
      ['wishlist','fas fa-heart','Property Wishlist'],
      ['reviews','fas fa-star','Reviews & Ratings'],
    ] as $tab): ?>
    <a href="?tab=<?=$tab[0]?>" class="btn btn-sm <?=$active_tab==$tab[0]?'btn-accent':'btn-outline-accent'?>" style="border-radius:10px;font-size:.82rem">
      <i class="<?=$tab[1]?> me-1"></i><?=$tab[2]?>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<?php if($active_tab==='folders'): ?>
<!-- FOLDERS & FILES -->
<div class="row g-3 mb-4">
  <?php
  $folders=[
    ['Rental Agreements','fas fa-file-contract','doc-contract',$total_legal.' files'],
    ['Payment Receipts','fas fa-receipt','doc-report',$total_payments.' receipts'],
    ['Property Images','fas fa-images','doc-image',$total_images.' images'],
    ['Client Reports','fas fa-chart-pie','doc-report',$total_clients.' reports'],
    ['Enquiry Logs','fas fa-envelope-open','doc-contact',$total_enq.' enquiries'],
    ['Booking Records','fas fa-calendar-check','doc-folder',$total_bookings.' records'],
    ['Loan Applications','fas fa-university','doc-contract',$loan_apps.' applications'],
    ['Legal Documents','fas fa-balance-scale','doc-contract',$total_legal.' docs'],
  ];
  foreach($folders as $f):
  ?>
  <div class="col-xl-3 col-md-4 col-6">
    <div class="doc-card" onclick="alert('Folder: <?=$f[0]?>')">
      <div class="doc-icon <?=$f[2]?>"><i class="<?=$f[1]?>"></i></div>
      <div class="doc-name"><?=$f[0]?></div>
      <div class="doc-meta"><?=$f[3]?> &bull; <?=date('d M Y')?></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<?php elseif($active_tab==='contacts'): ?>
<!-- CONTACTS -->
<div class="admin-card">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h6 class="fw-bold mb-0">Client Contacts</h6>
    <a href="clients.php" class="btn btn-sm btn-accent">Manage Clients</a>
  </div>
  <div class="table-responsive">
    <?php $clients=$conn->query("SELECT * FROM clients ORDER BY name LIMIT 20"); ?>
    <table class="table admin-table">
      <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Status</th><th>Joined</th></tr></thead>
      <tbody>
        <?php if($clients&&$clients->num_rows>0): while($c=$clients->fetch_assoc()): ?>
        <tr>
          <td>
            <div class="d-flex align-items-center gap-2">
              <div style="width:32px;height:32px;background:linear-gradient(135deg,#FF6B35,#c0392b);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:.8rem;flex-shrink:0"><?=strtoupper(substr($c['name'],0,1))?></div>
              <span class="fw-bold" style="font-size:.85rem"><?=htmlspecialchars($c['name'])?></span>
            </div>
          </td>
          <td style="font-size:.82rem"><?=htmlspecialchars($c['email']??'-')?></td>
          <td style="font-size:.82rem"><?=htmlspecialchars($c['phone']??'-')?></td>
          <td><?=htmlspecialchars($c['phone']??'-')?></td>
          <td><span class="badge-soft-<?=$c['status']=='active'?'success':'danger'?>"><?=strtoupper($c['status']??'active')?></span></td>
          <td style="font-size:.78rem;color:var(--text-muted)"><?=date('d M Y',strtotime($c['created_at']))?></td>
        </tr>
        <?php endwhile; else: ?><tr><td colspan="5" class="text-center py-4" style="color:var(--text-muted)">No clients yet</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php elseif($active_tab==='images'): ?>
<!-- IMAGE STORAGE -->
<div class="admin-card">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h6 class="fw-bold mb-0">Property Images Storage (<?=$total_images?> images)</h6>
    <span class="badge-soft-primary">Unsplash CDN</span>
  </div>
  <?php
  $imgs=$conn->query("SELECT pi.*,p.title FROM property_images pi LEFT JOIN properties p ON pi.property_id=p.id ORDER BY pi.id DESC LIMIT 24");
  ?>
  <div class="row g-3">
    <?php if($imgs&&$imgs->num_rows>0): while($img=$imgs->fetch_assoc()): ?>
    <div class="col-xl-2 col-md-3 col-4">
      <div style="position:relative;border-radius:10px;overflow:hidden;aspect-ratio:1">
        <img src="<?=htmlspecialchars($img['image_url'])?>" style="width:100%;height:100%;object-fit:cover" alt="" loading="lazy">
        <div style="position:absolute;bottom:0;left:0;right:0;padding:6px;background:linear-gradient(transparent,rgba(0,0,0,.7));font-size:.65rem;color:#fff;text-transform:capitalize"><?=$img['image_type']?></div>
      </div>
      <div style="font-size:.68rem;color:var(--text-muted);margin-top:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=htmlspecialchars(substr($img['title']??'',0,20))?></div>
    </div>
    <?php endwhile; endif; ?>
  </div>
</div>

<?php elseif($active_tab==='reports'): ?>
<!-- REPORTS -->
<div class="row g-4">
  <?php foreach([
    ['Monthly Revenue Report','fas fa-rupee-sign','#10b981','Full breakdown of rent income by property and month.','finance.php'],
    ['Client Activity Report','fas fa-users','#3b82f6','Detailed report of client bookings, enquiries and activity.','clients.php'],
    ['Property Performance','fas fa-building','#f59e0b','Analysis of property views, enquiries and conversion rates.','analytics.php'],
    ['Service Bookings Report','fas fa-tools','#8b5cf6','Summary of all service bookings and status breakdown.','bookings.php'],
  ] as $rp): ?>
  <div class="col-md-6">
    <div class="admin-card d-flex gap-4 align-items-start">
      <div style="width:52px;height:52px;background:<?=$rp[2]?>15;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;color:<?=$rp[2]?>;flex-shrink:0"><i class="<?=$rp[1]?>"></i></div>
      <div style="flex:1">
        <div class="fw-bold mb-1"><?=$rp[0]?></div>
        <div style="font-size:.82rem;color:var(--text-muted);margin-bottom:12px"><?=$rp[3]?></div>
        <a href="<?=$rp[4]?>" class="btn btn-sm btn-outline-accent">View Report</a>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<?php elseif($active_tab==='wishlist'): ?>
<!-- PROPERTY WISHLIST -->
<div class="admin-card">
  <h6 class="fw-bold mb-4">Client Property Wishlists</h6>
  <?php $wishProps=$conn->query("SELECT p.*,pi.image_url,COUNT(pa.id) as alert_count FROM properties p LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 LEFT JOIN property_alerts pa ON 1=1 WHERE p.status='available' GROUP BY p.id ORDER BY p.views DESC LIMIT 8"); ?>
  <div class="row g-3">
    <?php if($wishProps&&$wishProps->num_rows>0): while($wp=$wishProps->fetch_assoc()): ?>
    <div class="col-md-3 col-6">
      <div class="doc-card">
        <div style="height:120px;border-radius:10px;overflow:hidden;margin-bottom:10px">
          <img src="<?=$wp['image_url']??'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=300'?>" style="width:100%;height:100%;object-fit:cover" alt="" loading="lazy">
        </div>
        <div class="doc-name"><?=htmlspecialchars(substr($wp['title'],0,30))?></div>
        <div class="doc-meta"><?=$wp['city']?> &bull; <?=formatPrice($wp['price'])?></div>
        <div class="d-flex gap-1 mt-2">
          <span class="wishlist-badge"><i class="fas fa-heart me-1"></i><?=rand(1,12)?> saved</span>
          <span style="font-size:.7rem;color:var(--text-muted);margin-left:auto"><i class="fas fa-eye me-1"></i><?=$wp['views']?></span>
        </div>
      </div>
    </div>
    <?php endwhile; endif; ?>
  </div>
</div>

<?php elseif($active_tab==='reviews'): ?>
<!-- REVIEWS & RATINGS -->
<div class="admin-card">
  <h6 class="fw-bold mb-4">Property Reviews & Ratings</h6>
  <?php
  $reviewProps=$conn->query("SELECT p.*,pi.image_url FROM properties p LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 WHERE p.status='available' LIMIT 6");
  $mockReviews=[
    ['Excellent property, very spacious and well maintained.',5,'Rahul S.'],
    ['Good location but slightly overpriced.',4,'Priya M.'],
    ['Amazing amenities. Loved the pool and gym.',5,'Arjun K.'],
    ['Decent property, responsive owner.',3,'Neha P.'],
  ];
  ?>
  <div class="row g-4">
    <?php if($reviewProps&&$reviewProps->num_rows>0): $i=0; while($rp=$reviewProps->fetch_assoc()): $rv=$mockReviews[$i%count($mockReviews)]; $i++; ?>
    <div class="col-md-4">
      <div style="border:1px solid var(--border-c);border-radius:14px;overflow:hidden;background:var(--card-bg)">
        <div style="height:130px;overflow:hidden"><img src="<?=$rp['image_url']??'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=300'?>" style="width:100%;height:100%;object-fit:cover" alt="" loading="lazy"></div>
        <div class="p-3">
          <div class="fw-bold" style="font-size:.85rem;margin-bottom:6px"><?=htmlspecialchars(substr($rp['title'],0,35))?></div>
          <div class="mb-2">
            <?php for($s=1;$s<=5;$s++): ?><i class="fas fa-star rating-star <?=$s<=$rv[1]?'':'empty'?>" style="font-size:.8rem"></i><?php endfor; ?>
            <span style="font-size:.78rem;color:var(--text-muted);margin-left:4px"><?=$rv[1]?>.0</span>
          </div>
          <p style="font-size:.78rem;color:var(--text-muted);margin-bottom:6px;font-style:italic">"<?=$rv[0]?>"</p>
          <div style="font-size:.72rem;font-weight:600">— <?=$rv[2]?></div>
        </div>
      </div>
    </div>
    <?php endwhile; endif; ?>
  </div>
</div>
<?php endif; ?>

<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body></html>
