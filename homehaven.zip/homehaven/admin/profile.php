<?php
$pageTitle = 'My Profile';
require_once 'includes/sidebar.php';

$msg = ''; $msgType = 'success';

// Fetch admin data
$admin_res = $conn->query("SELECT * FROM admins WHERE id=" . (int)$_SESSION['admin_id']);
$admin = ($admin_res && $admin_res->num_rows > 0) ? $admin_res->fetch_assoc() : ['name'=>'Admin','email'=>'admin@PropNexus.com','created_at'=>date('Y-m-d')];

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name  = sanitize($_POST['admin_name'] ?? '');
    $email = sanitize($_POST['admin_email'] ?? '');
    $phone = sanitize($_POST['admin_phone'] ?? '');

    if ($name && $email) {
        $conn->query("UPDATE admins SET name='$name', email='$email' WHERE id=" . (int)$_SESSION['admin_id']);
        $_SESSION['admin_name'] = $name;
        $admin['name'] = $name;
        $admin['email'] = $email;
        $msg = 'Profile updated successfully!';
    } else {
        $msg = 'Name and email are required.'; $msgType = 'danger';
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $curPass = $_POST['current_password'] ?? '';
    $newPass = $_POST['new_password'] ?? '';
    $confPass = $_POST['confirm_password'] ?? '';

    if (empty($curPass) || empty($newPass)) {
        $msg = 'Please fill in all password fields.'; $msgType = 'danger';
    } elseif ($newPass !== $confPass) {
        $msg = 'New passwords do not match.'; $msgType = 'danger';
    } elseif (strlen($newPass) < 6) {
        $msg = 'Password must be at least 6 characters.'; $msgType = 'danger';
    } elseif (!password_verify($curPass, $admin['password'])) {
        $msg = 'Current password is incorrect.'; $msgType = 'danger';
    } else {
        $hashed = password_hash($newPass, PASSWORD_BCRYPT);
        $conn->query("UPDATE admins SET password='$hashed' WHERE id=" . (int)$_SESSION['admin_id']);
        $msg = 'Password changed successfully!';
    }
}

// Stats
$totalProps = (int)$conn->query("SELECT COUNT(*) as c FROM properties")->fetch_assoc()['c'];
$totalClients = (int)$conn->query("SELECT COUNT(*) as c FROM clients")->fetch_assoc()['c'];
$totalEnquiries = (int)$conn->query("SELECT COUNT(*) as c FROM enquiries")->fetch_assoc()['c'];
$totalLoans = (int)$conn->query("SELECT COUNT(*) as c FROM loan_applications")->fetch_assoc()['c'];

$avatarUrl = 'https://ui-avatars.com/api/?name=' . urlencode($admin['name']) . '&background=FF6B35&color=fff&size=128&bold=true&font-size=0.4';
$joined = date('d M Y', strtotime($admin['created_at']));
?>

<?php if($msg): ?>
<div class="alert alert-<?=$msgType?> alert-dismissible fade show rounded-3 mb-4">
  <i class="fas fa-<?=$msgType==='success'?'check-circle':'exclamation-circle'?> me-2"></i><?=$msg?>
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row g-4">

  <!-- Profile Card -->
  <div class="col-lg-4">
    <div class="admin-card text-center" style="position:relative;overflow:hidden">
      <!-- Header background -->
      <div style="position:absolute;top:0;left:0;right:0;height:100px;background:linear-gradient(135deg,#1a3c5e,#2d6a4f);border-radius:16px 16px 0 0"></div>

      <div style="position:relative;z-index:2;padding-top:40px">
        <img src="<?=$avatarUrl?>" class="rounded-circle mb-3" style="width:90px;height:90px;border:4px solid #fff;box-shadow:0 4px 15px rgba(0,0,0,.15)" alt="Admin Avatar">
        <h5 class="fw-bold mb-1"><?=htmlspecialchars($admin['name'])?></h5>
        <p class="text-muted mb-1" style="font-size:.85rem"><i class="fas fa-envelope me-1"></i><?=htmlspecialchars($admin['email'])?></p>
        <span class="badge rounded-pill px-3 py-2 mb-3" style="background:rgba(255,107,53,.12);color:#FF6B35;font-weight:600;font-size:.78rem"><i class="fas fa-shield-alt me-1"></i>Super Admin</span>

        <hr style="border-color:var(--border-c)">

        <div class="row g-2 text-center">
          <div class="col-6">
            <div class="p-2 rounded-3" style="background:var(--body-bg)">
              <div class="fw-bold" style="font-size:1.3rem;color:#1a3c5e"><?=$totalProps?></div>
              <div style="font-size:.72rem;color:var(--text-muted)">Properties</div>
            </div>
          </div>
          <div class="col-6">
            <div class="p-2 rounded-3" style="background:var(--body-bg)">
              <div class="fw-bold" style="font-size:1.3rem;color:#2d6a4f"><?=$totalClients?></div>
              <div style="font-size:.72rem;color:var(--text-muted)">Clients</div>
            </div>
          </div>
          <div class="col-6">
            <div class="p-2 rounded-3" style="background:var(--body-bg)">
              <div class="fw-bold" style="font-size:1.3rem;color:#FF6B35"><?=$totalEnquiries?></div>
              <div style="font-size:.72rem;color:var(--text-muted)">Enquiries</div>
            </div>
          </div>
          <div class="col-6">
            <div class="p-2 rounded-3" style="background:var(--body-bg)">
              <div class="fw-bold" style="font-size:1.3rem;color:#6f42c1"><?=$totalLoans?></div>
              <div style="font-size:.72rem;color:var(--text-muted)">Loan Apps</div>
            </div>
          </div>
        </div>

        <hr style="border-color:var(--border-c)">
        <div style="font-size:.78rem;color:var(--text-muted)">
          <i class="fas fa-calendar-alt me-1"></i>Joined: <?=$joined?>
        </div>
      </div>
    </div>
  </div>

  <!-- Edit Profile -->
  <div class="col-lg-8">

    <!-- Personal Info -->
    <div class="admin-card mb-4">
      <h5 class="fw-bold mb-4"><i class="fas fa-user-edit me-2" style="color:#FF6B35"></i>Personal Information</h5>
      <form method="POST">
        <input type="hidden" name="update_profile" value="1">
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label fw-bold" style="font-size:.82rem">Full Name</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fas fa-user" style="color:#FF6B35"></i></span>
              <input type="text" name="admin_name" class="form-control" value="<?=htmlspecialchars($admin['name'])?>" required>
            </div>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-bold" style="font-size:.82rem">Email Address</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fas fa-envelope" style="color:#FF6B35"></i></span>
              <input type="email" name="admin_email" class="form-control" value="<?=htmlspecialchars($admin['email'])?>" required>
            </div>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-bold" style="font-size:.82rem">Role</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fas fa-shield-alt" style="color:#FF6B35"></i></span>
              <input type="text" class="form-control" value="Super Admin" disabled>
            </div>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-bold" style="font-size:.82rem">Member Since</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fas fa-calendar" style="color:#FF6B35"></i></span>
              <input type="text" class="form-control" value="<?=$joined?>" disabled>
            </div>
          </div>
          <div class="col-12">
            <button type="submit" class="btn px-5" style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:#fff;border:none;border-radius:10px;padding:10px 30px;font-weight:600">
              <i class="fas fa-save me-2"></i>Update Profile
            </button>
          </div>
        </div>
      </form>
    </div>

    <!-- Change Password -->
    <div class="admin-card">
      <h5 class="fw-bold mb-4"><i class="fas fa-lock me-2" style="color:#FF6B35"></i>Change Password</h5>
      <form method="POST">
        <input type="hidden" name="change_password" value="1">
        <div class="row g-3">
          <div class="col-md-12">
            <label class="form-label fw-bold" style="font-size:.82rem">Current Password</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fas fa-key" style="color:#f59e0b"></i></span>
              <input type="password" name="current_password" class="form-control" required>
            </div>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-bold" style="font-size:.82rem">New Password</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fas fa-lock" style="color:#10b981"></i></span>
              <input type="password" name="new_password" class="form-control" minlength="6" required>
            </div>
          </div>
          <div class="col-md-6">
            <label class="form-label fw-bold" style="font-size:.82rem">Confirm New Password</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fas fa-lock" style="color:#10b981"></i></span>
              <input type="password" name="confirm_password" class="form-control" minlength="6" required>
            </div>
          </div>
          <div class="col-12">
            <div class="p-3 rounded-3 mb-3" style="background:rgba(59,130,246,.06);border:1px solid rgba(59,130,246,.15)">
              <div style="font-size:.8rem;color:var(--text-muted)">
                <i class="fas fa-info-circle me-1 text-primary"></i>
                Password must be at least 6 characters. Uses BCrypt hashing for security.
              </div>
            </div>
            <button type="submit" class="btn px-5" style="background:linear-gradient(135deg,#FF6B35,#e55a2b);color:#fff;border:none;border-radius:10px;padding:10px 30px;font-weight:600">
              <i class="fas fa-key me-2"></i>Change Password
            </button>
          </div>
        </div>
      </form>
    </div>

  </div>
</div>

<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body></html>
