<?php
$pageTitle = 'Property Alerts';
require_once 'includes/sidebar.php';
$alerts = $conn->query("SELECT pa.*, c.name as cname FROM property_alerts pa LEFT JOIN clients c ON pa.client_id=c.id ORDER BY pa.created_at DESC");
?>
<div class="admin-card">
  <div class="table-responsive">
    <table class="table table-hover">
      <thead class="table-dark">
        <tr><th>Client</th><th>Email</th><th>Property Type</th><th>Listing</th><th>City</th><th>Budget</th><th>Beds</th><th>Date</th></tr>
      </thead>
      <tbody>
        <?php while($a = $alerts->fetch_assoc()): ?>
        <tr>
          <td><?= $a['cname'] ?? 'Guest' ?></td>
          <td><?= $a['email'] ?></td>
          <td><?= $a['property_type'] ?: 'Any' ?></td>
          <td><?= $a['listing_type'] ?: 'Any' ?></td>
          <td><?= $a['city'] ?: 'Any' ?></td>
          <td>₹<?= number_format($a['min_budget']) ?> - ₹<?= number_format($a['max_budget']) ?></td>
          <td><?= $a['min_bedrooms'] ?: 'Any' ?></td>
          <td><?= date('d M Y', strtotime($a['created_at'])) ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
