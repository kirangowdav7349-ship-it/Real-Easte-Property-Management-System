<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once '../includes/config.php';
if(!isAdminLoggedIn()) redirect(SITE_URL . '/admin/login.php');
$cur = basename($_SERVER['PHP_SELF']);
$darkMode = $_COOKIE['hh_dark'] ?? '0';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280">
<title><?= isset($pageTitle) ? $pageTitle . ' - Admin' : 'Admin Panel' ?> | PropNexus</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="<?= SITE_URL ?>/assets/css/style.css" rel="stylesheet">
<link href="<?= SITE_URL ?>/assets/css/admin.css" rel="stylesheet">
</head>
<body class="admin-body <?= $darkMode=='1'?'dark':'' ?>" id="adminBody">
<div class="d-flex">

<!-- SIDEBAR -->
<aside class="admin-sidebar" id="adminSidebar">
  <div class="sidebar-brand">
    <i class="fas fa-home"></i>
    <span>PropNexus</span>
  </div>

  <!-- Admin Profile -->
  <div class="sidebar-profile">
    <div class="avatar-ring">
      <i class="fas fa-user-shield"></i>
    </div>
    <div class="profile-info">
      <span class="profile-name"><?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?></span>
      <span class="profile-role">Super Admin</span>
    </div>
  </div>

  <!-- NAV -->
  <nav class="sidebar-nav">
    <div class="nav-section-label">MAIN</div>
    <a href="dashboard.php" class="nav-item <?= $cur=='dashboard.php'?'active':'' ?>">
      <i class="fas fa-chart-pie"></i><span>Dashboard</span>
    </a>

    <a href="analytics.php" class="nav-item <?= $cur=='analytics.php'?'active':'' ?>">
      <i class="fas fa-chart-line"></i><span>Analytics</span>
    </a>
    <a href="<?= SITE_URL ?>/ai-recommend.php" class="nav-item" style="color:#FF6B35" target="_blank">
      <i class="fas fa-robot"></i><span>AI Agent</span>
    </a>
    <a href="finance.php" class="nav-item <?= $cur=='finance.php'?'active':'' ?>">
      <i class="fas fa-wallet"></i><span>Finance</span>
      <?php $pendingPay=$conn->query("SELECT COUNT(*) as c FROM rent_payments WHERE status='pending'")->fetch_assoc()['c']; if($pendingPay>0): ?><span class="nav-badge"><?=$pendingPay?></span><?php endif; ?>
    </a>

    <div class="nav-section-label">PROPERTIES</div>
    <a href="properties.php" class="nav-item <?= $cur=='properties.php'?'active':'' ?>">
      <i class="fas fa-building"></i><span>Properties</span>
    </a>
    <a href="add-property.php" class="nav-item <?= in_array($cur,['add-property.php','edit-property.php'])?'active':'' ?>">
      <i class="fas fa-plus-circle"></i><span>Add Property</span>
    </a>

    <div class="nav-section-label">PEOPLE</div>
    <a href="clients.php" class="nav-item <?= $cur=='clients.php'?'active':'' ?>">
      <i class="fas fa-users"></i><span>Clients</span>
    </a>
    <a href="enquiries.php" class="nav-item <?= $cur=='enquiries.php'?'active':'' ?>">
      <i class="fas fa-envelope"></i><span>Enquiries</span>
      <?php $newEnq=$conn->query("SELECT COUNT(*) as c FROM enquiries WHERE status='new'")->fetch_assoc()['c']; if($newEnq>0): ?><span class="nav-badge"><?=$newEnq?></span><?php endif; ?>
    </a>
    <a href="transactions.php" class="nav-item <?= $cur=='transactions.php'?'active':'' ?>">
      <i class="fas fa-handshake"></i><span>Transactions</span>
      <?php $txnPending=$conn->query("SELECT COUNT(*) as c FROM property_transactions WHERE status='pending'")->fetch_assoc()['c']; if($txnPending>0): ?><span class="nav-badge"><?=$txnPending?></span><?php endif; ?>
    </a>

    <div class="nav-section-label">OPERATIONS</div>
    <a href="loan-applications.php" class="nav-item <?= $cur=='loan-applications.php'?'active':'' ?>">
      <i class="fas fa-file-invoice-dollar"></i><span>Loan Applications</span>
      <?php $pendingLoans=$conn->query("SELECT COUNT(*) as c FROM loan_applications WHERE status='pending'")->fetch_assoc()['c']; if($pendingLoans>0): ?><span class="nav-badge"><?=$pendingLoans?></span><?php endif; ?>
    </a>
    <a href="bookings.php" class="nav-item <?= $cur=='bookings.php'?'active':'' ?>">
      <i class="fas fa-calendar-check"></i><span>Bookings</span>
    </a>
    <a href="payments.php" class="nav-item <?= $cur=='payments.php'?'active':'' ?>">
      <i class="fas fa-credit-card"></i><span>Payments</span>
    </a>
    <a href="plans.php" class="nav-item <?= $cur=='plans.php'?'active':'' ?>">
      <i class="fas fa-tag"></i><span>Plans</span>
    </a>
    <a href="alerts.php" class="nav-item <?= $cur=='alerts.php'?'active':'' ?>">
      <i class="fas fa-bell"></i><span>Alerts</span>
    </a>
    <a href="maintenance.php" class="nav-item <?= $cur=='maintenance.php'?'active':'' ?>">
      <i class="fas fa-wrench"></i><span>Maintenance</span>
      <?php $mPending=$conn->query("SELECT COUNT(*) as c FROM maintenance_requests WHERE status='pending'")->fetch_assoc()['c']; if($mPending>0): ?><span class="nav-badge"><?=$mPending?></span><?php endif; ?>
    </a>
    <a href="legal.php" class="nav-item <?= $cur=='legal.php'?'active':'' ?>">
      <i class="fas fa-gavel"></i><span>Legal Services</span>
      <?php $lPending=$conn->query("SELECT COUNT(*) as c FROM legal_bookings WHERE status='pending'")->fetch_assoc()['c']; if($lPending>0): ?><span class="nav-badge"><?=$lPending?></span><?php endif; ?>
    </a>
    <a href="services.php" class="nav-item <?= $cur=='services.php'?'active':'' ?>">
      <i class="fas fa-tools"></i><span>Home Services</span>
    </a>

    <div class="nav-section-label">DOCUMENTS</div>
    <a href="documents.php" class="nav-item <?= $cur=='documents.php'?'active':'' ?>">
      <i class="fas fa-folder"></i><span>Files & Folders</span>
    </a>
    <a href="reports.php" class="nav-item <?= $cur=='reports.php'?'active':'' ?>">
      <i class="fas fa-chart-bar"></i><span>Reports</span>
    </a>

    <div class="nav-section-label">SYSTEM</div>
    <a href="settings.php" class="nav-item <?= $cur=='settings.php'?'active':'' ?>">
      <i class="fas fa-cog"></i><span>Settings</span>
    </a>
    <a href="help.php" class="nav-item <?= $cur=='help.php'?'active':'' ?>">
      <i class="fas fa-question-circle"></i><span>Help</span>
    </a>
    <a href="profile.php" class="nav-item <?= $cur=='profile.php'?'active':'' ?>">
      <i class="fas fa-user-circle"></i><span>My Profile</span>
    </a>
    <hr style="border-color:rgba(255,255,255,.1);margin:8px 0">
    <a href="<?= SITE_URL ?>" target="_blank" class="nav-item">
      <i class="fas fa-external-link-alt"></i><span>View Website</span>
    </a>
    <a href="logout.php" class="nav-item logout-link">
      <i class="fas fa-sign-out-alt"></i><span>Logout</span>
    </a>
  </nav>
</aside>

<!-- MAIN WRAPPER -->
<div class="admin-main" id="adminMain">
  <!-- TOPBAR -->
  <header class="admin-topbar">
    <div class="topbar-left">
      <button class="sidebar-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb mb-0">
          <li class="breadcrumb-item"><a href="dashboard.php" style="color:var(--accent)">Admin</a></li>
          <li class="breadcrumb-item active"><?= $pageTitle ?? 'Dashboard' ?></li>
        </ol>
      </nav>
    </div>
    <div class="topbar-right">
      <!-- Search -->
      <div class="topbar-search">
        <i class="fas fa-search"></i>
        <input type="text" placeholder="Search anything..." id="globalSearch">
      </div>
      <!-- Notifications -->
      <div class="dropdown">
        <button class="topbar-btn" data-bs-toggle="dropdown">
          <i class="fas fa-bell"></i>
          <?php
            $txnUnread = 0;
            $txnUR = $conn->query("SELECT COUNT(*) as c FROM property_transactions WHERE admin_read=0");
            if($txnUR) $txnUnread = (int)$txnUR->fetch_assoc()['c'];
            if($newEnq > 0 || $txnUnread > 0): ?><span class="btn-dot"></span><?php endif; ?>
        </button>
        <div class="dropdown-menu dropdown-menu-end notif-dropdown p-0">
          <div class="p-3 border-bottom fw-bold">Notifications</div>
          <?php
          $notifs=$conn->query("SELECT e.name,e.email,p.title as ptitle,e.created_at FROM enquiries e LEFT JOIN properties p ON e.property_id=p.id WHERE e.status='new' ORDER BY e.created_at DESC LIMIT 5");
          $txnNotifs=$conn->query("SELECT t.full_name,t.transaction_type,p.title as ptitle,t.created_at,t.amount FROM property_transactions t LEFT JOIN properties p ON t.property_id=p.id WHERE t.admin_read=0 ORDER BY t.created_at DESC LIMIT 5");
          $hasNotifs = ($notifs && $notifs->num_rows > 0) || ($txnNotifs && $txnNotifs->num_rows > 0);
          if($txnNotifs && $txnNotifs->num_rows > 0): while($tn=$txnNotifs->fetch_assoc()):
          ?>
          <div class="notif-item">
            <div class="notif-dot" style="background:<?= $tn['transaction_type']==='buy'?'#10b981':'#3b82f6' ?>"></div>
            <div>
              <div style="font-size:.83rem;font-weight:600"><?=htmlspecialchars($tn['full_name'])?> wants to <?=$tn['transaction_type']?></div>
              <div style="font-size:.75rem;color:var(--text-muted)"><?=htmlspecialchars($tn['ptitle']??'Property')?> — ₹<?=number_format($tn['amount'])?></div>
              <div style="font-size:.7rem;color:var(--text-muted)"><?=date('d M, H:i',strtotime($tn['created_at']))?></div>
            </div>
          </div>
          <?php endwhile; endif; ?>
          <?php if($notifs&&$notifs->num_rows>0): while($n=$notifs->fetch_assoc()):
          ?>
          <div class="notif-item">
            <div class="notif-dot"></div>
            <div>
              <div style="font-size:.83rem;font-weight:600"><?=htmlspecialchars($n['name'])?> sent enquiry</div>
              <div style="font-size:.75rem;color:var(--text-muted)"><?=htmlspecialchars($n['ptitle']??'General')?></div>
              <div style="font-size:.7rem;color:var(--text-muted)"><?=date('d M, H:i',strtotime($n['created_at']))?></div>
            </div>
          </div>
          <?php endwhile; endif; ?>
          <?php if(!$hasNotifs): ?>
          <div class="p-3 text-center text-muted" style="font-size:.85rem">No new notifications</div>
          <?php endif; ?>
          <div class="p-2 border-top text-center"><a href="transactions.php" style="font-size:.82rem;color:var(--accent)">View all transactions</a></div>
        </div>
      </div>
      <!-- Dark mode -->
      <button class="topbar-btn" onclick="adminToggleDark()" title="Toggle dark mode">
        <i class="fas fa-moon" id="adminDarkIco"></i>
      </button>
      <!-- Profile -->
      <div class="dropdown">
        <button class="admin-avatar-btn" data-bs-toggle="dropdown">
          <i class="fas fa-user-shield"></i>
        </button>
        <ul class="dropdown-menu dropdown-menu-end">
          <li class="dropdown-item-text px-3 py-2"><strong><?=htmlspecialchars($_SESSION['admin_name']??'Admin')?></strong><br><small class="text-muted">Super Admin</small></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-circle me-2"></i>My Profile</a></li>
          <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
          <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
        </ul>
      </div>
    </div>
  </header>

  <!-- PAGE CONTENT -->
  <main class="admin-content">
