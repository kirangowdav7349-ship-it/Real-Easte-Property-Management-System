<?php
// ALL redirects BEFORE sidebar
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../includes/config.php';
if (!isAdminLoggedIn()) redirect(SITE_URL . '/admin/login.php');

if (isset($_GET['toggle'])) {
    $cid  = (int)$_GET['toggle'];
    $curr = $conn->query("SELECT status FROM clients WHERE id=$cid")->fetch_assoc()['status'];
    $new  = $curr == 'active' ? 'inactive' : 'active';
    $conn->query("UPDATE clients SET status='$new' WHERE id=$cid");
    header("Location: clients.php"); exit();
}
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM clients WHERE id=" . (int)$_GET['delete']);
    header("Location: clients.php?deleted=1"); exit();
}

$pageTitle = 'Clients';
require_once 'includes/sidebar.php';

$search  = sanitize($_GET['s'] ?? '');
$where   = $search ? "WHERE name LIKE '%$search%' OR email LIKE '%$search%'" : '';
$clients = $conn->query("SELECT * FROM clients $where ORDER BY created_at DESC");
?>
<?php if(isset($_GET['deleted'])): ?><div class="alert alert-success rounded-3 mb-3">Client deleted.</div><?php endif; ?>
<div class="d-flex justify-content-between align-items-center mb-4">
  <form class="d-flex gap-2" style="width:300px">
    <input type="text" name="s" class="form-control" placeholder="Search clients..." value="<?= htmlspecialchars($search) ?>">
    <button type="submit" class="btn btn-accent btn-sm">Go</button>
  </form>
  <span class="badge-soft-primary"><?= $clients ? $clients->num_rows : 0 ?> clients</span>
</div>
<div class="admin-card">
  <div class="table-responsive">
    <table class="table admin-table">
      <thead><tr><th>Client</th><th>Email</th><th>Phone</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
      <tbody>
        <?php if($clients && $clients->num_rows > 0): while($c = $clients->fetch_assoc()): ?>
        <tr>
          <td>
            <div class="d-flex align-items-center gap-2">
              <div style="width:34px;height:34px;background:linear-gradient(135deg,#FF6B35,#c0392b);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:.85rem;flex-shrink:0"><?= strtoupper(substr($c['name'],0,1)) ?></div>
              <span class="fw-bold" style="font-size:.85rem"><?= htmlspecialchars($c['name']) ?></span>
            </div>
          </td>
          <td style="font-size:.82rem"><?= htmlspecialchars($c['email']) ?></td>
          <td style="font-size:.82rem"><?= htmlspecialchars($c['phone'] ?? '-') ?></td>
          <td>
            <a href="?toggle=<?= $c['id'] ?>" class="badge-soft-<?= $c['status']=='active'?'success':'danger' ?>" style="text-decoration:none;cursor:pointer" title="Click to toggle">
              <?= strtoupper($c['status']) ?>
            </a>
          </td>
          <td style="font-size:.78rem;color:var(--text-muted)"><?= date('d M Y', strtotime($c['created_at'])) ?></td>
          <td>
            <a href="?delete=<?= $c['id'] ?>" onclick="return confirm('Delete this client? This cannot be undone.')" class="btn btn-sm" style="background:#ef444415;color:#ef4444;border-radius:8px"><i class="fas fa-trash"></i></a>
          </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="6" class="text-center py-4" style="color:var(--text-muted)">No clients found</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body></html>
