<?php
// Redirect to the actual loan applications page
header("Location: loan-applications.php");
exit();
