<?php
$pageTitle = 'Maintenance Requests';
require_once 'includes/sidebar.php';

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $rid    = (int)$_POST['request_id'];
    $status = $conn->real_escape_string($_POST['status']);
    $notes  = $conn->real_escape_string(trim($_POST['notes'] ?? ''));
    $assigned = $conn->real_escape_string(trim($_POST['assigned_to'] ?? ''));
    $completed = ($status === 'completed') ? "NOW()" : "NULL";
    $conn->query("UPDATE maintenance_requests SET status='$status', notes='$notes', assigned_to='$assigned', completed_at=$completed WHERE id=$rid");
    echo '<div class="alert alert-success alert-dismissible fade show"><i class="fas fa-check-circle me-2"></i>Request #'.$rid.' updated!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
}

// Stats
$total     = (int)$conn->query("SELECT COUNT(*) as c FROM maintenance_requests")->fetch_assoc()['c'];
$pending   = (int)$conn->query("SELECT COUNT(*) as c FROM maintenance_requests WHERE status='pending'")->fetch_assoc()['c'];
$progress  = (int)$conn->query("SELECT COUNT(*) as c FROM maintenance_requests WHERE status='in_progress'")->fetch_assoc()['c'];
$completed = (int)$conn->query("SELECT COUNT(*) as c FROM maintenance_requests WHERE status='completed'")->fetch_assoc()['c'];

// Filter
$filter = $_GET['status'] ?? 'all';
$where = '';
if ($filter !== 'all') $where = "WHERE mr.status='" . $conn->real_escape_string($filter) . "'";

$requests = $conn->query("SELECT mr.*, c.name as client_name, c.email as client_email, c.phone as client_phone, p.title as property_title
    FROM maintenance_requests mr
    LEFT JOIN clients c ON mr.client_id=c.id
    LEFT JOIN properties p ON mr.property_id=p.id
    $where
    ORDER BY FIELD(mr.priority,'urgent','high','medium','low'), mr.created_at DESC");

$catIcons = [
    'plumbing'     => ['fas fa-faucet', '#3b82f6'],
    'electrical'   => ['fas fa-bolt', '#f59e0b'],
    'carpentry'    => ['fas fa-hammer', '#8b5cf6'],
    'painting'     => ['fas fa-paint-roller', '#ec4899'],
    'cleaning'     => ['fas fa-broom', '#10b981'],
    'pest_control' => ['fas fa-bug', '#ef4444'],
    'appliance'    => ['fas fa-blender', '#6366f1'],
    'other'        => ['fas fa-wrench', '#64748b'],
];
$prioColors = ['low' => '#10b981', 'medium' => '#f59e0b', 'high' => '#FF6B35', 'urgent' => '#ef4444'];
$statusColors = ['pending' => '#f59e0b', 'in_progress' => '#3b82f6', 'completed' => '#10b981', 'cancelled' => '#94a3b8'];
?>

<!-- STAT CARDS -->
<div class="row g-3 mb-4">
  <?php foreach([
    ['Total Requests', $total, 'fas fa-wrench', 'linear-gradient(135deg,#1a3c5e,#2d6a4f)'],
    ['Pending', $pending, 'fas fa-clock', 'linear-gradient(135deg,#f59e0b,#d97706)'],
    ['In Progress', $progress, 'fas fa-spinner', 'linear-gradient(135deg,#3b82f6,#1d4ed8)'],
    ['Completed', $completed, 'fas fa-check-circle', 'linear-gradient(135deg,#10b981,#059669)'],
  ] as $s): ?>
  <div class="col-md-3 col-6">
    <div class="stat-card-new" style="background:<?= $s[3] ?>">
      <div class="stat-icon"><i class="<?= $s[2] ?>"></i></div>
      <div class="stat-val"><?= $s[1] ?></div>
      <div class="stat-lbl"><?= $s[0] ?></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- FILTER TABS -->
<div class="admin-card mb-4 p-2">
  <div class="d-flex gap-2 flex-wrap">
    <?php foreach(['all'=>'All','pending'=>'Pending','in_progress'=>'In Progress','completed'=>'Completed','cancelled'=>'Cancelled'] as $key=>$label): ?>
    <a href="?status=<?= $key ?>" class="btn btn-sm <?= $filter===$key ? 'btn-accent' : 'btn-outline-accent' ?>" style="border-radius:10px;font-size:.82rem">
      <?= $label ?>
      <?php if($key==='pending' && $pending>0): ?><span class="badge bg-warning text-dark ms-1"><?= $pending ?></span><?php endif; ?>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<!-- REQUESTS TABLE -->
<div class="admin-card">
  <div class="table-responsive">
    <table class="table admin-table">
      <thead>
        <tr>
          <th>#</th>
          <th>Category</th>
          <th>Title</th>
          <th>Client</th>
          <th>Property</th>
          <th>Priority</th>
          <th>Status</th>
          <th>Date</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if($requests && $requests->num_rows > 0): while($r = $requests->fetch_assoc()):
          $cat = $catIcons[$r['category']] ?? $catIcons['other'];
          $pColor = $prioColors[$r['priority']] ?? '#64748b';
          $sColor = $statusColors[$r['status']] ?? '#64748b';
        ?>
        <tr>
          <td class="fw-bold" style="color:var(--accent)">#<?= $r['id'] ?></td>
          <td>
            <div class="d-flex align-items-center gap-2">
              <div style="width:30px;height:30px;background:<?= $cat[1] ?>15;border-radius:8px;display:flex;align-items:center;justify-content:center;color:<?= $cat[1] ?>;font-size:.8rem">
                <i class="<?= $cat[0] ?>"></i>
              </div>
              <span style="font-size:.78rem;text-transform:capitalize"><?= str_replace('_',' ',$r['category']) ?></span>
            </div>
          </td>
          <td>
            <div style="font-size:.83rem;font-weight:600;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($r['title']) ?></div>
            <?php if($r['description']): ?>
            <div style="font-size:.7rem;color:var(--text-muted);max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars(substr($r['description'],0,60)) ?></div>
            <?php endif; ?>
          </td>
          <td style="font-size:.82rem"><?= htmlspecialchars($r['client_name'] ?? 'N/A') ?></td>
          <td style="font-size:.78rem;max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($r['property_title'] ?? 'N/A') ?></td>
          <td>
            <span style="background:<?= $pColor ?>15;color:<?= $pColor ?>;padding:3px 10px;border-radius:20px;font-size:.72rem;font-weight:700;text-transform:uppercase">
              <?= $r['priority'] ?>
            </span>
          </td>
          <td>
            <span style="background:<?= $sColor ?>15;color:<?= $sColor ?>;padding:3px 10px;border-radius:20px;font-size:.72rem;font-weight:700;text-transform:capitalize">
              <?= str_replace('_',' ',$r['status']) ?>
            </span>
          </td>
          <td style="font-size:.75rem;color:var(--text-muted)"><?= date('d M Y', strtotime($r['created_at'])) ?></td>
          <td>
            <button class="btn btn-sm btn-outline-accent" style="border-radius:8px;font-size:.75rem;padding:3px 10px"
                    data-bs-toggle="modal" data-bs-target="#updateModal"
                    onclick="fillModal(<?= $r['id'] ?>,'<?= htmlspecialchars(addslashes($r['status'])) ?>','<?= htmlspecialchars(addslashes($r['assigned_to'] ?? '')) ?>','<?= htmlspecialchars(addslashes($r['notes'] ?? '')) ?>')">
              <i class="fas fa-edit me-1"></i>Update
            </button>
          </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="9" class="text-center py-4" style="color:var(--text-muted);font-size:.85rem">
          <i class="fas fa-clipboard-check me-2" style="font-size:1.5rem;opacity:.4"></i><br>
          No maintenance requests found
        </td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- UPDATE MODAL -->
<div class="modal fade" id="updateModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content" style="border-radius:16px;border:none">
      <div class="modal-header" style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:#fff;border-radius:16px 16px 0 0">
        <h6 class="modal-title fw-bold"><i class="fas fa-wrench me-2"></i>Update Request</h6>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
        <div class="modal-body p-4">
          <input type="hidden" name="update_status" value="1">
          <input type="hidden" name="request_id" id="mReqId">
          <div class="mb-3">
            <label class="form-label fw-bold small">Status</label>
            <select name="status" id="mStatus" class="form-select">
              <option value="pending">⏳ Pending</option>
              <option value="in_progress">🔧 In Progress</option>
              <option value="completed">✅ Completed</option>
              <option value="cancelled">❌ Cancelled</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label fw-bold small">Assigned To</label>
            <input type="text" name="assigned_to" id="mAssigned" class="form-control" placeholder="e.g. John (Plumber)">
          </div>
          <div class="mb-3">
            <label class="form-label fw-bold small">Admin Notes</label>
            <textarea name="notes" id="mNotes" class="form-control" rows="3" placeholder="Internal notes..."></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-accent btn-sm px-4 fw-bold"><i class="fas fa-save me-1"></i>Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function fillModal(id, status, assigned, notes) {
  document.getElementById('mReqId').value = id;
  document.getElementById('mStatus').value = status;
  document.getElementById('mAssigned').value = assigned;
  document.getElementById('mNotes').value = notes;
}
</script>

<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
