<?php
$pageTitle = 'Finance';
require_once 'includes/sidebar.php';

$total_income  = (float)$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE status='paid'")->fetch_assoc()['s'];
$month_income  = (float)$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE status='paid' AND MONTH(created_at)=MONTH(NOW())")->fetch_assoc()['s'];
$pending_amt   = (float)$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE status='pending'")->fetch_assoc()['s'];
// Mock expenses (for demo)
$month_expense = round($month_income * 0.32);
$net_profit    = $month_income - $month_expense;
$total_txn     = (int)$conn->query("SELECT COUNT(*) as c FROM rent_payments")->fetch_assoc()['c'];

// Monthly breakdown
$months=[]; $incomes=[]; $expenses=[];
for($m=5;$m>=0;$m--){
    $r=$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE status='paid' AND MONTH(created_at)=MONTH(DATE_SUB(NOW(),INTERVAL $m MONTH)) AND YEAR(created_at)=YEAR(DATE_SUB(NOW(),INTERVAL $m MONTH))");
    $inc=(float)$r->fetch_assoc()['s'];
    $months[]=date('M',strtotime("-$m months"));
    $incomes[]=$inc;
    $expenses[]=round($inc*0.3+rand(1000,5000));
}

// Expense breakdown (mock %s)
$exp_cats=[['Maintenance',35,'#ef4444'],['Staff',25,'#f59e0b'],['Marketing',20,'#3b82f6'],['Utilities',12,'#10b981'],['Others',8,'#8b5cf6']];

// All transactions
$txns = $conn->query("SELECT rp.*,p.title as ptitle,c.name as cname FROM rent_payments rp LEFT JOIN properties p ON rp.property_id=p.id LEFT JOIN clients c ON rp.client_id=c.id ORDER BY rp.created_at DESC LIMIT 20");
?>

<!-- Finance KPIs -->
<div class="row g-3 mb-4">
  <div class="col-md-3 col-6">
    <div class="fin-card income">
      <div class="fin-lbl">Total Income</div>
      <div class="fin-val">₹<?= number_format($total_income) ?></div>
      <div class="fin-trend up"><i class="fas fa-arrow-up me-1"></i>All Time</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="fin-card expense">
      <div class="fin-lbl">Total Expenses (This Month)</div>
      <div class="fin-val">₹<?= number_format($month_expense) ?></div>
      <div class="fin-trend down"><i class="fas fa-arrow-down me-1"></i>Estimated</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="fin-card profit">
      <div class="fin-lbl">Net Profit (This Month)</div>
      <div class="fin-val">₹<?= number_format($net_profit) ?></div>
      <div class="fin-trend up"><i class="fas fa-arrow-up me-1"></i><?= $month_income>0?round(($net_profit/$month_income)*100):0 ?>% margin</div>
    </div>
  </div>
  <div class="col-md-3 col-6">
    <div class="fin-card pending">
      <div class="fin-lbl">Pending Payments</div>
      <div class="fin-val">₹<?= number_format($pending_amt) ?></div>
      <div class="fin-trend down"><i class="fas fa-clock me-1"></i>Awaiting collection</div>
    </div>
  </div>
</div>

<div class="row g-4 mb-4">
  <!-- Cash Flow Chart -->
  <div class="col-lg-8">
    <div class="admin-card">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h6 class="fw-bold mb-0">Cash Flow Analysis (6 Months)</h6>
        <div class="d-flex gap-3">
          <span style="font-size:.78rem"><span style="display:inline-block;width:12px;height:12px;border-radius:3px;background:#10b981;margin-right:4px"></span>Revenue</span>
          <span style="font-size:.78rem"><span style="display:inline-block;width:12px;height:12px;border-radius:3px;background:#ef4444;margin-right:4px"></span>Expenses</span>
        </div>
      </div>
      <div class="chart-container"><canvas id="cashflowChart"></canvas></div>
    </div>
  </div>
  <!-- Expense Breakdown -->
  <div class="col-lg-4">
    <div class="admin-card">
      <h6 class="fw-bold mb-4">Expense Breakdown</h6>
      <div class="chart-container-sm"><canvas id="expChart"></canvas></div>
      <div class="mt-3">
        <?php foreach($exp_cats as $e): ?>
        <div class="d-flex align-items-center mb-2">
          <span style="width:10px;height:10px;border-radius:50%;background:<?=$e[2]?>;display:inline-block;flex-shrink:0"></span>
          <span style="font-size:.8rem;margin-left:8px;flex:1"><?=$e[0]?></span>
          <div class="progress flex-grow-1 mx-2" style="height:5px"><div class="progress-bar" style="width:<?=$e[1]?>%;background:<?=$e[2]?>"></div></div>
          <span style="font-size:.78rem;font-weight:700;color:<?=$e[2]?>"><?=$e[1]?>%</span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- Revenue vs Comparison -->
<div class="row g-4 mb-4">
  <div class="col-lg-6">
    <div class="admin-card">
      <h6 class="fw-bold mb-4">Revenue Comparison (Month vs Last Month)</h6>
      <div class="chart-container-sm"><canvas id="compChart"></canvas></div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="admin-card">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="fw-bold mb-0">Quick Stats</h6>
      </div>
      <?php
      $qs=[
        ['Total Transactions',$total_txn,'fas fa-exchange-alt','#3b82f6'],
        ['This Month Income','₹'.number_format($month_income),'fas fa-arrow-up','#10b981'],
        ['Pending Payments','₹'.number_format($pending_amt),'fas fa-clock','#f59e0b'],
        ['Avg Transaction','₹'.number_format($total_txn>0?$total_income/$total_txn:0),'fas fa-calculator','#8b5cf6'],
        ['Net Profit Margin',($month_income>0?round(($net_profit/$month_income)*100):0).'%','fas fa-percent','#10b981'],
        ['Total Properties Earning',(int)$conn->query("SELECT COUNT(DISTINCT property_id) as c FROM rent_payments WHERE status='paid'")->fetch_assoc()['c'],'fas fa-building','#FF6B35'],
      ];
      foreach($qs as $q):
      ?>
      <div class="qs-item">
        <div class="qs-icon" style="background:<?=$q[3]?>15;color:<?=$q[3]?>"><i class="<?=$q[2]?>"></i></div>
        <div style="flex:1"><span style="font-size:.83rem;font-weight:600"><?=$q[0]?></span></div>
        <span style="font-size:.9rem;font-weight:800;color:<?=$q[3]?>"><?=$q[1]?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- Transactions Table -->
<div class="admin-card">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h6 class="fw-bold mb-0">All Transactions & Invoices</h6>
    <a href="payments.php" class="btn btn-sm btn-accent">Manage Payments</a>
  </div>
  <div class="table-responsive">
    <table class="table admin-table">
      <thead><tr><th>Receipt</th><th>Client</th><th>Property</th><th>Amount</th><th>Month</th><th>Mode</th><th>Date</th><th>Status</th></tr></thead>
      <tbody>
        <?php if($txns&&$txns->num_rows>0): while($t=$txns->fetch_assoc()): ?>
        <tr>
          <td><code style="font-size:.75rem"><?= htmlspecialchars($t['receipt_number']??'-') ?></code></td>
          <td style="font-size:.83rem"><?= htmlspecialchars($t['cname']??'Guest') ?></td>
          <td style="font-size:.78rem;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($t['ptitle']??'General') ?></td>
          <td class="fw-bold" style="color:#10b981">₹<?= number_format($t['amount']) ?></td>
          <td style="font-size:.8rem"><?= htmlspecialchars($t['payment_month']??'-') ?></td>
          <td><span class="badge-soft-primary"><?= htmlspecialchars($t['payment_mode']??'-') ?></span></td>
          <td style="font-size:.78rem;color:var(--text-muted)"><?= $t['payment_date']?date('d M Y',strtotime($t['payment_date'])):'-' ?></td>
          <td><span class="badge-soft-<?= $t['status']=='paid'?'success':'warning' ?>"><?= strtoupper($t['status']) ?></span></td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="8" class="text-center py-4" style="color:var(--text-muted)">No transactions yet</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
<script>
new Chart(document.getElementById('cashflowChart'),{type:'line',data:{labels:<?=json_encode($months)?>,datasets:[{label:'Revenue',data:<?=json_encode($incomes)?>,borderColor:'#10b981',backgroundColor:'rgba(16,185,129,.1)',borderWidth:2,fill:true,tension:.4},{label:'Expenses',data:<?=json_encode($expenses)?>,borderColor:'#ef4444',backgroundColor:'rgba(239,68,68,.08)',borderWidth:2,fill:true,tension:.4}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,grid:{color:'rgba(0,0,0,.05)'}},x:{grid:{display:false}}}}});
new Chart(document.getElementById('expChart'),{type:'doughnut',data:{labels:<?=json_encode(array_column($exp_cats,0))?>,datasets:[{data:<?=json_encode(array_column($exp_cats,1))?>,backgroundColor:<?=json_encode(array_column($exp_cats,2))?>,borderWidth:0,hoverOffset:6}]},options:{responsive:true,maintainAspectRatio:false,cutout:'60%',plugins:{legend:{display:false}}}});
// Comparison: This month vs last month
const thisMonth=<?=json_encode($month_income)?>;
const lastMonth=<?=json_encode(end($incomes)-rand(2000,8000))?>;
new Chart(document.getElementById('compChart'),{type:'bar',data:{labels:['Last Month','This Month'],datasets:[{data:[lastMonth,thisMonth],backgroundColor:['rgba(100,116,139,.3)','rgba(255,107,53,.7)'],borderRadius:10,borderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true},x:{grid:{display:false}}}}});
</script>
</body></html>
