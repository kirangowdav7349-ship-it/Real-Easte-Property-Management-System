<?php $pageTitle='Reports'; require_once 'includes/sidebar.php'; ?>
<div class="row g-4 mb-4">
  <div class="col-12">
    <div class="admin-card">
      <h5 class="fw-bold mb-4"><i class="fas fa-chart-bar me-2" style="color:#FF6B35"></i>Reports & Analytics</h5>
      <div class="row g-3">
        <?php foreach([
          ['Monthly Revenue Report','fas fa-rupee-sign','#10b981','Full income breakdown by property and period.','finance.php'],
          ['Client Activity Report','fas fa-users','#3b82f6','Bookings, enquiries and activity per client.','clients.php'],
          ['Property Performance','fas fa-building','#f59e0b','Views, enquiries and conversion rates per property.','analytics.php'],
          ['Service Bookings','fas fa-tools','#8b5cf6','All service bookings grouped by service type.','bookings.php'],
          ['Legal Services','fas fa-file-contract','#ef4444','Legal service requests and completion status.','legal.php'],
          ['Loan Applications','fas fa-university','#FF6B35','Loan applications by plan type and status.','loans.php'],
        ] as $rp): ?>
        <div class="col-md-6">
          <div class="admin-card d-flex gap-4 align-items-start" style="padding:20px">
            <div style="width:50px;height:50px;background:<?=$rp[2]?>15;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;color:<?=$rp[2]?>;flex-shrink:0"><i class="<?=$rp[1]?>"></i></div>
            <div style="flex:1">
              <div class="fw-bold mb-1"><?=$rp[0]?></div>
              <div style="font-size:.8rem;color:var(--text-muted);margin-bottom:12px"><?=$rp[3]?></div>
              <a href="<?=$rp[4]?>" class="btn btn-sm btn-outline-accent">Open Report</a>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script></body></html>
