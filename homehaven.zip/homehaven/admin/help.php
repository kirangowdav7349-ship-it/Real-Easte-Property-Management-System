<?php $pageTitle='Help'; require_once 'includes/sidebar.php'; ?>
<div class="row g-4">
  <div class="col-lg-8">
    <div class="admin-card mb-4">
      <h5 class="fw-bold mb-4"><i class="fas fa-question-circle me-2" style="color:#FF6B35"></i>Help & Documentation</h5>
      <div class="row g-3">
        <?php foreach([
          ['Getting Started','fas fa-rocket','#3b82f6','Learn how to set up and use PropNexus admin panel effectively.'],
          ['Managing Properties','fas fa-building','#10b981','How to add, edit, feature and manage your property listings.'],
          ['Client Management','fas fa-users','#f59e0b','Managing clients, their bookings, enquiries and communications.'],
          ['Finance & Payments','fas fa-wallet','#8b5cf6','Track income, expenses and manage rent payment records.'],
          ['Service Bookings','fas fa-tools','#ef4444','Handling home service bookings and updating their status.'],
          ['Legal & Loans','fas fa-file-contract','#FF6B35','Managing legal service requests and loan applications.'],
        ] as $h): ?>
        <div class="col-md-6">
          <div class="help-card">
            <div style="width:44px;height:44px;background:<?=$h[2]?>15;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;color:<?=$h[2]?>;margin-bottom:12px"><i class="<?=$h[1]?>"></i></div>
            <div class="fw-bold mb-2"><?=$h[0]?></div>
            <div style="font-size:.82rem;color:var(--text-muted)"><?=$h[3]?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="admin-card">
      <h6 class="fw-bold mb-4">Frequently Asked Questions</h6>
      <div class="accordion" id="faqAccordion">
        <?php
        $faqs=[
          ['How do I add a new property?','Go to Properties → Add Property. Fill in details and the system auto-assigns images based on property type. You can also paste custom image URLs.'],
          ['How do I change admin password?','Go to Settings → Account & Security. Enter your current password, then set new password. All passwords are BCrypt hashed.'],
          ['How do I process a rent payment?','In Payments, you can update status of pending payments. Clients can also pay through their dashboard.'],
          ['How do I view property analytics?','Visit the Analytics page for full charts on revenue, bookings, property types and performance metrics.'],
          ['How are enquiries managed?','New enquiries appear on dashboard. Go to Enquiries page to view, mark as read, or reply via email.'],
        ];
        foreach($faqs as $i=>$faq):
        ?>
        <div class="accordion-item" style="border:1px solid var(--border-c);border-radius:10px!important;margin-bottom:8px;overflow:hidden">
          <h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq<?=$i?>" style="background:var(--card-bg);color:var(--text-main);font-size:.88rem;font-weight:600"><?=$faq[0]?></button></h2>
          <div id="faq<?=$i?>" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
            <div class="accordion-body" style="font-size:.83rem;color:var(--text-muted)"><?=$faq[1]?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="admin-card mb-4">
      <h6 class="fw-bold mb-3">Quick Links</h6>
      <?php foreach([['Dashboard','fas fa-chart-pie','dashboard.php'],['Add Property','fas fa-plus','add-property.php'],['View Clients','fas fa-users','clients.php'],['Finance','fas fa-wallet','finance.php'],['Settings','fas fa-cog','settings.php']] as $l): ?>
      <a href="<?=$l[2]?>" class="d-flex align-items-center gap-3 p-2 mb-2 rounded-3 text-decoration-none" style="background:var(--body-bg);transition:.2s" onmouseover="this.style.background='rgba(255,107,53,.1)'" onmouseout="this.style.background='var(--body-bg)'">
        <i class="<?=$l[1]?>" style="color:#FF6B35;width:16px"></i><span style="font-size:.85rem;font-weight:500"><?=$l[0]?></span>
      </a>
      <?php endforeach; ?>
    </div>
    <div class="admin-card">
      <h6 class="fw-bold mb-3">Contact Support</h6>
      <p style="font-size:.82rem;color:var(--text-muted)">Need help? Reach out to our support team.</p>
      <div style="font-size:.83rem" class="mb-2"><i class="fas fa-envelope me-2" style="color:#FF6B35"></i><?=ADMIN_EMAIL?></div>
      <div style="font-size:.83rem" class="mb-3"><i class="fas fa-phone me-2" style="color:#FF6B35"></i>+91 98765 43210</div>
      <a href="mailto:<?=ADMIN_EMAIL?>" class="btn btn-accent w-100"><i class="fas fa-paper-plane me-2"></i>Email Support</a>
    </div>
  </div>
</div>
<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body></html>
