<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../includes/config.php';
if (!isAdminLoggedIn()) redirect(SITE_URL . '/admin/login.php');

// 3-Step Approval Flow: pending → under_review → verified → completed
// Admin can only advance one step at a time, or cancel at any point

$stepFlow = ['pending', 'under_review', 'verified', 'completed'];
$stepLabels = [
    'pending'      => 'Pending',
    'under_review' => 'Under Review',
    'verified'     => 'Verified',
    'completed'    => 'Completed',
    'cancelled'    => 'Cancelled'
];
$stepColors = [
    'pending'      => '#f59e0b',
    'under_review' => '#3b82f6',
    'verified'     => '#8b5cf6',
    'completed'    => '#10b981',
    'cancelled'    => '#ef4444'
];
$stepIcons = [
    'pending'      => 'fa-clock',
    'under_review' => 'fa-search',
    'verified'     => 'fa-clipboard-check',
    'completed'    => 'fa-check-double',
    'cancelled'    => 'fa-times-circle'
];

// --- ADVANCE BOOKING TO NEXT STEP ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['advance_step'])) {
    $bid = (int)$_POST['booking_id'];
    $remarks = $conn->real_escape_string(trim($_POST['admin_remarks'] ?? ''));

    // Get current status
    $cur = $conn->query("SELECT status FROM legal_bookings WHERE id=$bid")->fetch_assoc();
    if ($cur) {
        $currentStatus = $cur['status'];
        $currentIdx = array_search($currentStatus, $stepFlow);

        if ($currentIdx !== false && $currentIdx < count($stepFlow) - 1) {
            $nextStatus = $stepFlow[$currentIdx + 1];
            $timestampCol = '';
            if ($nextStatus === 'under_review') $timestampCol = ", reviewed_at=NOW()";
            elseif ($nextStatus === 'verified') $timestampCol = ", verified_at=NOW()";
            elseif ($nextStatus === 'completed') $timestampCol = ", completed_at=NOW()";

            $remarksSql = $remarks ? ", admin_remarks='$remarks'" : "";
            $conn->query("UPDATE legal_bookings SET status='$nextStatus' $timestampCol $remarksSql WHERE id=$bid");
            header("Location: legal.php?msg=step_advanced"); exit();
        }
    }
}

// --- CANCEL BOOKING ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_booking'])) {
    $bid = (int)$_POST['booking_id'];
    $remarks = $conn->real_escape_string(trim($_POST['admin_remarks'] ?? ''));
    $remarksSql = $remarks ? ", admin_remarks='$remarks'" : "";
    $conn->query("UPDATE legal_bookings SET status='cancelled' $remarksSql WHERE id=$bid");
    header("Location: legal.php?msg=booking_cancelled"); exit();
}

// --- DELETE LEGAL SERVICE ---
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM legal_services WHERE id=" . (int)$_GET['delete']);
    header("Location: legal.php?msg=deleted"); exit();
}

// --- TOGGLE LEGAL SERVICE STATUS ---
if (isset($_GET['toggle'])) {
    $sid = (int)$_GET['toggle'];
    $row = $conn->query("SELECT status FROM legal_services WHERE id=$sid")->fetch_assoc();
    $new = ($row['status'] === 'active') ? 'inactive' : 'active';
    $conn->query("UPDATE legal_services SET status='$new' WHERE id=$sid");
    header("Location: legal.php?msg=toggled"); exit();
}

// --- ADD LEGAL SERVICE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_legal'])) {
    $name  = $conn->real_escape_string(trim($_POST['name']        ?? ''));
    $desc  = $conn->real_escape_string(trim($_POST['description'] ?? ''));
    $price = (float)($_POST['price'] ?? 0);
    $turn  = $conn->real_escape_string(trim($_POST['turnaround']  ?? ''));
    $img   = $conn->real_escape_string(trim($_POST['image_url']   ?? ''));
    $stat  = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';
    if ($name) {
        $conn->query("INSERT INTO legal_services (name,description,price,image_url,turnaround,status) VALUES('$name','$desc',$price,'$img','$turn','$stat')");
        header("Location: legal.php?msg=added"); exit();
    }
}

// --- EDIT LEGAL SERVICE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_legal'])) {
    $sid   = (int)$_POST['service_id'];
    $name  = $conn->real_escape_string(trim($_POST['name']        ?? ''));
    $desc  = $conn->real_escape_string(trim($_POST['description'] ?? ''));
    $price = (float)($_POST['price'] ?? 0);
    $turn  = $conn->real_escape_string(trim($_POST['turnaround']  ?? ''));
    $img   = $conn->real_escape_string(trim($_POST['image_url']   ?? ''));
    $stat  = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';
    if ($name && $sid) {
        $conn->query("UPDATE legal_services SET name='$name',description='$desc',price=$price,image_url='$img',turnaround='$turn',status='$stat' WHERE id=$sid");
        header("Location: legal.php?msg=updated"); exit();
    }
}

// --- Load edit data if ?edit=ID ---
$editRow = null;
if (isset($_GET['edit'])) {
    $er = $conn->query("SELECT * FROM legal_services WHERE id=" . (int)$_GET['edit']);
    if ($er && $er->num_rows) $editRow = $er->fetch_assoc();
}

$pageTitle = 'Legal Services';
require_once 'includes/sidebar.php';

// Stats
$totalServices = (int)$conn->query("SELECT COUNT(*) as c FROM legal_services")->fetch_assoc()['c'];
$totalBookings = (int)$conn->query("SELECT COUNT(*) as c FROM legal_bookings")->fetch_assoc()['c'];
$pendingBookings = (int)$conn->query("SELECT COUNT(*) as c FROM legal_bookings WHERE status='pending'")->fetch_assoc()['c'];
$completedBookings = (int)$conn->query("SELECT COUNT(*) as c FROM legal_bookings WHERE status='completed'")->fetch_assoc()['c'];

// Fetch bookings
$bookings = $conn->query("SELECT lb.*, ls.name as service_name, ls.price as service_price
    FROM legal_bookings lb
    LEFT JOIN legal_services ls ON lb.service_id=ls.id
    ORDER BY lb.created_at DESC");

// Fetch services
$services = $conn->query("SELECT * FROM legal_services ORDER BY id");

$flashMap = [
    'added'             => ['success', '✅ Legal service added successfully!'],
    'updated'           => ['success', '✅ Legal service updated successfully!'],
    'deleted'           => ['danger',  '🗑️ Legal service deleted.'],
    'toggled'           => ['success', '✅ Service status toggled!'],
    'step_advanced'     => ['success', '✅ Booking advanced to next step!'],
    'booking_cancelled' => ['warning', '⚠️ Booking has been cancelled.'],
];
$flashMsg  = '';
$flashType = 'success';
if (isset($_GET['msg'], $flashMap[$_GET['msg']])) {
    $flashMsg  = $flashMap[$_GET['msg']][1];
    $flashType = $flashMap[$_GET['msg']][0];
}
?>

<?php if ($flashMsg): ?>
<div class="alert alert-<?= $flashType ?> rounded-3 mb-3"><?= $flashMsg ?></div>
<?php endif; ?>

<!-- Stats -->
<div class="row g-3 mb-4">
  <?php foreach([
    ['Total Services','fa-gavel',$totalServices,'linear-gradient(135deg,#1a3c5e,#2d6a4f)'],
    ['Total Bookings','fa-file-contract',$totalBookings,'linear-gradient(135deg,#FF6B35,#e55a25)'],
    ['Pending','fa-clock',$pendingBookings,'linear-gradient(135deg,#f59e0b,#d97706)'],
    ['Completed','fa-check-circle',$completedBookings,'linear-gradient(135deg,#059669,#047857)'],
  ] as $s): ?>
  <div class="col-md-3 col-6">
    <div class="p-3 rounded-3 text-white text-center" style="background:<?=$s[3]?>">
      <i class="fas <?=$s[1]?> mb-1" style="font-size:1.3rem;opacity:.7"></i>
      <div class="fw-bold" style="font-size:1.6rem"><?=$s[2]?></div>
      <div style="font-size:.78rem;opacity:.85"><?=$s[0]?></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Legal Services List -->
<div class="admin-card mb-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="fw-bold mb-0"><i class="fas fa-gavel me-2" style="color:#FF6B35"></i>Legal Services</h5>
    <a href="legal.php?add=1" class="btn btn-accent"><i class="fas fa-plus me-2"></i>Add Service</a>
  </div>
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light">
        <tr>
          <th>#</th>
          <th>Service Name</th>
          <th>Description</th>
          <th>Price</th>
          <th>Turnaround</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if($services && $services->num_rows > 0): ?>
          <?php while($s = $services->fetch_assoc()): ?>
          <tr>
            <td><?=$s['id']?></td>
            <td class="fw-bold"><?=htmlspecialchars($s['name'])?></td>
            <td style="font-size:.82rem;max-width:250px"><?=htmlspecialchars(substr($s['description'],0,80))?>...</td>
            <td class="fw-bold" style="color:#FF6B35">₹<?=number_format((float)$s['price'])?></td>
            <td><span class="badge bg-info text-dark"><?=htmlspecialchars($s['turnaround'] ?? '-')?></span></td>
            <td>
              <a href="legal.php?toggle=<?=$s['id']?>"
                 class="badge <?=$s['status']==='active'?'bg-success':'bg-secondary'?>"
                 style="text-decoration:none;cursor:pointer" title="Click to toggle">
                <?=ucfirst($s['status'])?>
              </a>
            </td>
            <td>
              <div class="d-flex gap-1">
                <a href="legal.php?edit=<?=$s['id']?>"
                   class="btn btn-sm" style="background:#3b82f615;color:#3b82f6;border-radius:8px">
                    <i class="fas fa-edit"></i> Edit
                </a>
                <a href="legal.php?delete=<?=$s['id']?>"
                   onclick="return confirm('Delete this legal service?')"
                   class="btn btn-sm" style="background:#ef444415;color:#ef4444;border-radius:8px">
                    <i class="fas fa-trash"></i>
                </a>
              </div>
            </td>
          </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr>
            <td colspan="7" class="text-center text-muted py-4">
              No legal services found. <a href="legal.php?add=1" style="color:#FF6B35">Add one</a>
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ============== LEGAL BOOKINGS WITH 3-STEP APPROVAL ============== -->
<div class="admin-card">
  <h5 class="fw-bold mb-3"><i class="fas fa-file-contract me-2" style="color:#FF6B35"></i>Service Bookings — 3-Step Approval</h5>
  <div class="mb-3 p-3 rounded-3" style="background:var(--section-bg,#f8fafc);border:1px dashed var(--border,#e2e8f0)">
    <div class="d-flex align-items-center gap-3 flex-wrap justify-content-center">
      <?php
      $approvalSteps = [
        ['Step 1', 'Review Request', 'fa-search', '#f59e0b'],
        ['Step 2', 'Verify Documents', 'fa-clipboard-check', '#8b5cf6'],
        ['Step 3', 'Approve & Complete', 'fa-check-double', '#10b981'],
      ];
      foreach($approvalSteps as $ai => $as): ?>
      <div class="d-flex align-items-center gap-2">
        <div style="width:32px;height:32px;border-radius:50%;background:<?=$as[3]?>18;color:<?=$as[3]?>;display:flex;align-items:center;justify-content:center;font-size:.8rem;border:2px solid <?=$as[3]?>">
          <i class="fas <?=$as[2]?>"></i>
        </div>
        <div>
          <div class="fw-bold" style="font-size:.72rem;color:<?=$as[3]?>"><?=$as[0]?></div>
          <div style="font-size:.7rem;color:var(--text-muted)"><?=$as[1]?></div>
        </div>
      </div>
      <?php if($ai < 2): ?>
      <i class="fas fa-chevron-right" style="color:var(--text-muted);opacity:.4;font-size:.7rem"></i>
      <?php endif; ?>
      <?php endforeach; ?>
    </div>
  </div>

  <?php if ($bookings && $bookings->num_rows > 0): ?>
    <?php while ($b = $bookings->fetch_assoc()):
      $bStatus  = $b['status'];
      $bColor   = $stepColors[$bStatus] ?? '#888';
      $bLabel   = $stepLabels[$bStatus] ?? ucfirst($bStatus);
      $bIcon    = $stepIcons[$bStatus]  ?? 'fa-circle';
      $bIdx     = array_search($bStatus, $stepFlow);
      $isCancelled = ($bStatus === 'cancelled');
      $isCompleted = ($bStatus === 'completed');
      $canAdvance  = !$isCancelled && !$isCompleted && $bIdx !== false;
      $nextLabel   = ($canAdvance && isset($stepFlow[$bIdx + 1])) ? $stepLabels[$stepFlow[$bIdx + 1]] : '';
    ?>
    <div class="p-3 mb-3 rounded-3" style="background:var(--card-bg,#fff);border:1px solid var(--border,#e5e9ef)">
      <!-- Header -->
      <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
        <div>
          <h6 class="fw-bold mb-1">#LGL<?=str_pad($b['id'],4,'0',STR_PAD_LEFT)?> — <?=htmlspecialchars($b['service_name'] ?? 'Unknown Service')?></h6>
          <div style="font-size:.8rem;color:var(--text-muted)">
            <i class="fas fa-user me-1"></i><?=htmlspecialchars($b['name'])?> ·
            <i class="fas fa-phone me-1"></i><?=htmlspecialchars($b['phone'])?> ·
            <i class="fas fa-envelope me-1"></i><?=htmlspecialchars($b['email'])?> ·
            <i class="far fa-clock me-1"></i><?=date('d M Y', strtotime($b['created_at']))?>
          </div>
          <?php if(!empty($b['notes'])): ?>
          <div class="mt-1" style="font-size:.8rem"><strong>Notes:</strong> <?=htmlspecialchars($b['notes'])?></div>
          <?php endif; ?>
          <?php if(!empty($b['admin_remarks'])): ?>
          <div class="mt-1" style="font-size:.8rem;color:#6f42c1"><strong>Admin Remarks:</strong> <?=htmlspecialchars($b['admin_remarks'])?></div>
          <?php endif; ?>
          <?php if(!empty($b['service_price'])): ?>
          <div class="mt-1 fw-bold" style="color:#FF6B35;font-size:.85rem">₹<?=number_format((float)$b['service_price'])?></div>
          <?php endif; ?>
        </div>
        <span class="badge rounded-pill px-3 py-2" style="background:<?=$bColor?>15;color:<?=$bColor?>;font-weight:600;font-size:.78rem">
          <i class="fas <?=$bIcon?> me-1"></i><?=$bLabel?>
        </span>
      </div>

      <!-- 3-Step Progress Bar -->
      <div class="step-progress-bar mb-3">
        <?php
        $progressSteps = [
          ['Pending',      'Request Received',     'fa-clock',           0],
          ['Under Review', 'Admin Reviewing',       'fa-search',          1],
          ['Verified',     'Documents Verified',    'fa-clipboard-check', 2],
          ['Completed',    'Approved & Completed',  'fa-check-double',    3],
        ];
        foreach($progressSteps as $pi => $ps):
          $pColor = ['#f59e0b','#3b82f6','#8b5cf6','#10b981'][$pi];
          if ($isCancelled) {
            $stepState = 'cancelled';
          } elseif ($bIdx !== false && $pi < $bIdx) {
            $stepState = 'done';
          } elseif ($bIdx !== false && $pi == $bIdx) {
            $stepState = ($bStatus === 'completed') ? 'done' : 'active';
          } else {
            $stepState = 'waiting';
          }
          // Timestamps
          $stepTime = '';
          if ($pi == 0 && !empty($b['created_at'])) $stepTime = date('d M, H:i', strtotime($b['created_at']));
          if ($pi == 1 && !empty($b['reviewed_at'])) $stepTime = date('d M, H:i', strtotime($b['reviewed_at']));
          if ($pi == 2 && !empty($b['verified_at'])) $stepTime = date('d M, H:i', strtotime($b['verified_at']));
          if ($pi == 3 && !empty($b['completed_at'])) $stepTime = date('d M, H:i', strtotime($b['completed_at']));
        ?>
        <div class="step-item <?=$stepState?>">
          <div class="step-dot" style="--step-color:<?=$pColor?>">
            <?php if($stepState === 'done'): ?>
              <i class="fas fa-check"></i>
            <?php elseif($stepState === 'active'): ?>
              <i class="fas <?=$ps[2]?>"></i>
            <?php elseif($stepState === 'cancelled'): ?>
              <i class="fas fa-times"></i>
            <?php else: ?>
              <span><?=$pi+1?></span>
            <?php endif; ?>
          </div>
          <?php if($pi < 3): ?>
          <div class="step-line <?=$stepState === 'done' ? 'done' : ''?>"></div>
          <?php endif; ?>
          <div class="step-label">
            <div class="step-title"><?=$ps[0]?></div>
            <div class="step-desc"><?=$ps[1]?></div>
            <?php if($stepTime): ?>
            <div class="step-time"><i class="far fa-clock"></i> <?=$stepTime?></div>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Action Buttons -->
      <?php if($canAdvance): ?>
      <form method="POST" class="d-flex gap-2 align-items-end flex-wrap mt-2 p-3 rounded-3" style="background:var(--section-bg,#f8fafc);border:1px solid var(--border,#e5e9ef)">
        <input type="hidden" name="advance_step" value="1">
        <input type="hidden" name="booking_id" value="<?=$b['id']?>">
        <div class="flex-fill">
          <label class="small fw-bold mb-1">Admin Remarks (Optional)</label>
          <input type="text" name="admin_remarks" class="form-control form-control-sm" placeholder="Add remarks for this step..." value="<?=htmlspecialchars($b['admin_remarks'] ?? '')?>">
        </div>
        <button type="submit" class="btn btn-sm px-4 fw-bold" style="background:<?=$stepColors[$stepFlow[$bIdx+1]] ?? '#3b82f6'?>;color:#fff;border-radius:10px;white-space:nowrap">
          <i class="fas fa-arrow-right me-1"></i>Advance to <?=$nextLabel?>
        </button>
      </form>
      <form method="POST" class="mt-2">
        <input type="hidden" name="cancel_booking" value="1">
        <input type="hidden" name="booking_id" value="<?=$b['id']?>">
        <button type="submit" onclick="return confirm('Are you sure you want to cancel this booking?')" class="btn btn-sm px-3" style="background:#ef444415;color:#ef4444;border-radius:8px;font-size:.78rem">
          <i class="fas fa-times me-1"></i>Cancel Booking
        </button>
      </form>
      <?php elseif($isCancelled): ?>
      <div class="p-2 rounded-3 text-center" style="background:#ef444410;color:#ef4444;font-size:.82rem;font-weight:600">
        <i class="fas fa-times-circle me-1"></i>This booking has been cancelled
      </div>
      <?php elseif($isCompleted): ?>
      <div class="p-2 rounded-3 text-center" style="background:#10b98110;color:#10b981;font-size:.82rem;font-weight:600">
        <i class="fas fa-check-circle me-1"></i>All 3 steps completed — Service approved!
      </div>
      <?php endif; ?>
    </div>
    <?php endwhile; ?>
  <?php else: ?>
    <div class="text-center py-5" style="color:var(--text-muted)">
      <i class="fas fa-inbox mb-2" style="font-size:2rem;opacity:.5"></i>
      <p>No legal service bookings yet.</p>
    </div>
  <?php endif; ?>
</div>

<!-- ===================== ADD MODAL ===================== -->
<?php if (isset($_GET['add'])): ?>
<div class="modal-overlay" id="legalModal">
    <div class="modal-box">
        <a href="legal.php" class="modal-close">✕</a>
        <h5 class="fw-bold mb-4"><i class="fas fa-gavel me-2" style="color:#FF6B35"></i>Add Legal Service</h5>
        <form method="POST">
            <input type="hidden" name="add_legal" value="1">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Service Name *</label>
                    <input type="text" name="name" class="form-control" required placeholder="e.g. Rental Agreement">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Price (₹)</label>
                    <input type="number" name="price" class="form-control" step="0.01" placeholder="e.g. 2999">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Turnaround Time</label>
                    <input type="text" name="turnaround" class="form-control" placeholder="e.g. 2-3 days">
                </div>
                <div class="col-12">
                    <label class="form-label">Image URL</label>
                    <input type="url" name="image_url" class="form-control" placeholder="https://images.unsplash.com/...">
                </div>
                <div class="col-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="Describe the legal service..."></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <div class="col-12 d-flex gap-2 mt-2">
                    <button type="submit" class="btn btn-accent flex-fill">Add Legal Service</button>
                    <a href="legal.php" class="btn btn-outline-accent">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- ===================== EDIT MODAL ===================== -->
<?php if ($editRow): ?>
<div class="modal-overlay" id="legalModal">
    <div class="modal-box">
        <a href="legal.php" class="modal-close">✕</a>
        <h5 class="fw-bold mb-4"><i class="fas fa-gavel me-2" style="color:#FF6B35"></i>Edit Legal Service</h5>
        <form method="POST">
            <input type="hidden" name="edit_legal" value="1">
            <input type="hidden" name="service_id" value="<?= (int)$editRow['id'] ?>">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Service Name *</label>
                    <input type="text" name="name" class="form-control" required
                           value="<?= htmlspecialchars($editRow['name']) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Price (₹)</label>
                    <input type="number" name="price" class="form-control" step="0.01"
                           value="<?= htmlspecialchars($editRow['price'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Turnaround Time</label>
                    <input type="text" name="turnaround" class="form-control"
                           value="<?= htmlspecialchars($editRow['turnaround'] ?? '') ?>">
                </div>
                <div class="col-12">
                    <label class="form-label">Image URL</label>
                    <input type="url" name="image_url" class="form-control"
                           value="<?= htmlspecialchars($editRow['image_url'] ?? '') ?>"
                           placeholder="https://images.unsplash.com/...">
                </div>
                <?php if (!empty($editRow['image_url'])): ?>
                <div class="col-12">
                    <img src="<?= htmlspecialchars($editRow['image_url']) ?>"
                         onerror="this.style.display='none'"
                         style="width:100%;height:140px;object-fit:cover;border-radius:10px">
                </div>
                <?php endif; ?>
                <div class="col-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="3"><?= htmlspecialchars($editRow['description'] ?? '') ?></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="active"   <?= ($editRow['status'] === 'active')   ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= ($editRow['status'] === 'inactive') ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-12 d-flex gap-2 mt-2">
                    <button type="submit" class="btn btn-accent flex-fill">Save Changes</button>
                    <a href="legal.php" class="btn btn-outline-accent">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<style>
/* 3-Step Progress Bar */
.step-progress-bar {
    display: flex;
    align-items: flex-start;
    gap: 0;
    padding: 16px 8px;
    background: var(--section-bg, #f8fafc);
    border-radius: 12px;
    border: 1px solid var(--border, #e5e9ef);
    overflow-x: auto;
}
.step-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    flex: 1;
    min-width: 100px;
}
.step-dot {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: .75rem;
    font-weight: 700;
    z-index: 2;
    transition: all .3s;
    border: 3px solid var(--border, #ddd);
    background: var(--card-bg, #fff);
    color: var(--text-muted, #999);
}
.step-item.done .step-dot {
    background: var(--step-color, #10b981);
    border-color: var(--step-color, #10b981);
    color: #fff;
}
.step-item.active .step-dot {
    background: #fff;
    border-color: var(--step-color, #3b82f6);
    color: var(--step-color, #3b82f6);
    box-shadow: 0 0 0 4px color-mix(in srgb, var(--step-color, #3b82f6) 20%, transparent);
    animation: stepPulse 2s infinite;
}
.step-item.cancelled .step-dot {
    background: #ef4444;
    border-color: #ef4444;
    color: #fff;
}
@keyframes stepPulse {
    0%, 100% { box-shadow: 0 0 0 4px rgba(59,130,246,.2); }
    50% { box-shadow: 0 0 0 8px rgba(59,130,246,.1); }
}
.step-line {
    position: absolute;
    top: 18px;
    left: calc(50% + 18px);
    right: calc(-50% + 18px);
    height: 3px;
    background: var(--border, #ddd);
    z-index: 1;
}
.step-line.done {
    background: linear-gradient(90deg, #10b981, #3b82f6);
}
.step-label {
    text-align: center;
    margin-top: 8px;
}
.step-title {
    font-size: .72rem;
    font-weight: 700;
    color: var(--text-main, #333);
}
.step-item.waiting .step-title {
    color: var(--text-muted, #999);
}
.step-desc {
    font-size: .65rem;
    color: var(--text-muted, #999);
}
.step-time {
    font-size: .62rem;
    color: #10b981;
    font-weight: 600;
    margin-top: 2px;
}
.step-item.cancelled .step-title,
.step-item.cancelled .step-desc {
    color: #ef4444;
}

/* Modals */
.modal-overlay {
    position: fixed; inset: 0;
    background: rgba(0,0,0,.6);
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
    animation: fadeIn .2s;
}
.modal-box {
    background: var(--card-bg);
    border-radius: 20px;
    padding: 32px;
    width: 100%;
    max-width: 520px;
    max-height: 90vh;
    overflow-y: auto;
    position: relative;
    animation: slideUp .25s;
}
.modal-close {
    position: absolute; top: 14px; right: 18px;
    font-size: 1.3rem; color: var(--text-muted);
    text-decoration: none; line-height: 1;
}
.modal-close:hover { color: #ef4444; }
@keyframes fadeIn  { from{opacity:0} to{opacity:1} }
@keyframes slideUp { from{transform:translateY(24px);opacity:0} to{transform:translateY(0);opacity:1} }
</style>

<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
