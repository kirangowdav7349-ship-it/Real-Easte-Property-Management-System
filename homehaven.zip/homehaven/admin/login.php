<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once '../includes/config.php';

if(isAdminLoggedIn()) {
    header("Location: " . SITE_URL . "/admin/dashboard.php");
    exit();
}

$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $pass  = trim($_POST['password']);

    // Use prepared statement - no sanitize() to avoid corruption
    $stmt = $conn->prepare("SELECT * FROM admins WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin  = $result->fetch_assoc();
    $stmt->close();

    if ($admin) {
        $stored = $admin['password'];
        $valid  = false;

        // 1. Plain text match (fresh SQL import)
        if ($stored === $pass) {
            $valid = true;
            // Upgrade to bcrypt for security
            $hash = password_hash($pass, PASSWORD_BCRYPT);
            $id   = (int)$admin['id'];
            $conn->query("UPDATE admins SET password='$hash' WHERE id=$id");
        }
        // 2. Bcrypt hash match
        elseif (password_verify($pass, $stored)) {
            $valid = true;
        }
        // 3. MD5 fallback
        elseif ($stored === md5($pass)) {
            $valid = true;
        }

        if ($valid) {
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            header("Location: " . SITE_URL . "/admin/dashboard.php");
            exit();
        } else {
            $error = 'Wrong password. Click <a href="../install.php"><strong>Run Setup</strong></a> below to reset admin password.';
        }
    } else {
        $error = 'Email not found. Click <a href="../install.php"><strong>Run Setup</strong></a> below to create admin account.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280">
<title>Admin Login - PropNexus</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
  * { font-family: 'Poppins', sans-serif; }
  body {
    min-height: 100vh;
    background: linear-gradient(rgba(10,20,35,0.92), rgba(10,20,35,0.92)),
                url('https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1600') center/cover no-repeat;
    display: flex; align-items: center;
  }
  .auth-card {
    background: #fff;
    border-radius: 16px;
    padding: 28px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    max-width: 380px;
    margin: 0 auto;
  }
  .btn-login {
    background: linear-gradient(135deg,#FF6B35,#e85d28);
    border: none; color: #fff;
    border-radius: 25px;
    padding: 10px;
    font-weight: 600;
    font-size: .88rem;
    transition: .3s;
  }
  .btn-login:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(255,107,53,.5); color:#fff; }
  .input-group-text { background: #f8f9fa; border-right: none; font-size:.85rem; }
  .form-control { border-left: none; font-size:.85rem; }
  .form-control:focus { box-shadow: none; border-color: #ced4da; }
  .brand { font-size: 1.4rem; font-weight: 700; color: #1a3c5e; }
  .brand span { color: #FF6B35; }
  .form-label { font-size: .8rem; margin-bottom: 4px; }
</style>
</head>
<body>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-lg-4 col-md-6">
      <div class="auth-card">

        <div class="text-center mb-3">
          <div style="width:48px;height:48px;background:linear-gradient(135deg,#1a3c5e,#2d6a4f);border-radius:14px;display:flex;align-items:center;justify-content:center;margin:0 auto 10px;font-size:1.3rem;color:white;">
            <i class="fas fa-shield-alt"></i>
          </div>
          <div class="brand">Home<span>Crest</span></div>
          <p class="text-muted mb-0" style="font-size:.82rem">Admin Management Panel</p>
        </div>

        <?php if($error): ?>
        <div class="alert alert-danger py-2" style="font-size:.8rem"><?= $error ?></div>
        <?php endif; ?>

        <div class="alert alert-info py-2 mb-3" style="font-size:.75rem">
          <i class="fas fa-info-circle me-1"></i>
          Email: <strong>admin@PropNexus.com</strong> &nbsp;|&nbsp; Password: <strong>Admin@123</strong>
        </div>

        <form method="POST">
          <div class="mb-2">
            <label class="form-label fw-bold">Email Address</label>
            <div class="input-group input-group-sm">
              <span class="input-group-text"><i class="fas fa-envelope text-muted"></i></span>
              <input type="email" name="email" class="form-control"
                     value="admin@PropNexus.com" required>
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label fw-bold">Password</label>
            <div class="input-group input-group-sm">
              <span class="input-group-text"><i class="fas fa-lock text-muted"></i></span>
              <input type="text" name="password" class="form-control"
                     value="Admin@123" required>
            </div>
          </div>
          <button type="submit" class="btn btn-login w-100">
            <i class="fas fa-sign-in-alt me-2"></i>Login to Admin Panel
          </button>
        </form>

        <hr class="my-2">
        <div class="text-center">
          <a href="../install.php" class="btn btn-sm btn-outline-warning me-1" style="font-size:.75rem">
            <i class="fas fa-cog me-1"></i>Run Setup
          </a>
          <a href="../index.php" class="btn btn-sm btn-outline-secondary" style="font-size:.75rem">
            <i class="fas fa-home me-1"></i>Back to Site
          </a>
        </div>

      </div>
    </div>
  </div>
</div>
</body>
</html>
