<?php
$pageTitle = 'Add Property';
require_once 'includes/sidebar.php';

$msg = ''; $errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title    = $conn->real_escape_string(trim($_POST['title']        ?? ''));
    $desc     = $conn->real_escape_string(trim($_POST['description']  ?? ''));
    $ptype    = $conn->real_escape_string(trim($_POST['type']         ?? 'apartment'));
    $ltype    = $conn->real_escape_string(trim($_POST['listing_type'] ?? 'rent'));
    $price    = floatval($_POST['price'] ?? 0);
    $area     = $conn->real_escape_string(trim($_POST['area']         ?? ''));
    $beds     = intval($_POST['bedrooms']  ?? 0);
    $baths    = intval($_POST['bathrooms'] ?? 0);
    $location = $conn->real_escape_string(trim($_POST['location']     ?? ''));
    $city     = $conn->real_escape_string(trim($_POST['city']         ?? ''));
    $state    = $conn->real_escape_string(trim($_POST['state']        ?? ''));
    $pin      = $conn->real_escape_string(trim($_POST['pincode']      ?? ''));
    $amenities= $conn->real_escape_string(trim($_POST['amenities']    ?? ''));
    $status   = $conn->real_escape_string(trim($_POST['status']       ?? 'available'));
    $featured = isset($_POST['featured']) ? 1 : 0;

    // Images: real_escape_string ONLY (never htmlspecialchars on URLs)
    $ie = $conn->real_escape_string(trim($_POST['img_exterior'] ?? ''));
    $ih = $conn->real_escape_string(trim($_POST['img_hall']     ?? ''));
    $ib = $conn->real_escape_string(trim($_POST['img_bedroom']  ?? ''));
    $ibt= $conn->real_escape_string(trim($_POST['img_bathroom'] ?? ''));
    $ik = $conn->real_escape_string(trim($_POST['img_kitchen']  ?? ''));

    if (!$title)    $errors[] = 'Property title is required.';
    if ($price <= 0)$errors[] = 'Enter a valid price.';
    if (!$city)     $errors[] = 'City is required.';
    if (!$location) $errors[] = 'Locality is required.';

    if (empty($errors)) {
        $sql = "INSERT INTO properties (title,description,type,listing_type,price,area,bedrooms,bathrooms,location,city,state,pincode,amenities,featured,status)
                VALUES('$title','$desc','$ptype','$ltype',$price,'$area',$beds,$baths,'$location','$city','$state','$pin','$amenities',$featured,'$status')";
        if ($conn->query($sql)) {
            $pid = $conn->insert_id;
            $imap = ['exterior'=>$ie,'hall'=>$ih,'bedroom'=>$ib,'bathroom'=>$ibt,'kitchen'=>$ik];
            $first = true;
            foreach ($imap as $t => $u) {
                if ($u) {
                    $p = $first ? 1 : 0;
                    $conn->query("INSERT INTO property_images(property_id,image_url,image_type,is_primary) VALUES($pid,'$u','$t',$p)");
                    $first = false;
                }
            }
            $msg = 'success';
        } else { $errors[] = 'DB Error: '.$conn->error; }
    }
}

$cityMap = [
  'Bangalore' =>['state'=>'Karnataka', 'areas'=>['Koramangala','Whitefield','Indiranagar','HSR Layout','JP Nagar','Marathahalli','Electronic City','Hebbal','Jayanagar','BTM Layout','Sarjapur Road','Bannerghatta Road','Yelahanka','Rajajinagar','Banashankari','Bellandur','Kadugodi','Domlur','Frazer Town','Shivajinagar']],
  'Mumbai'    =>['state'=>'Maharashtra','areas'=>['Andheri West','Andheri East','Bandra West','Bandra East','Juhu','Powai','Thane','Borivali','Malad','Goregaon','Kandivali','Navi Mumbai','Chembur','Mulund','Dadar','Worli','Versova','Santacruz','Vile Parle','Colaba']],
  'Delhi'     =>['state'=>'Delhi',      'areas'=>['Dwarka','Rohini','Lajpat Nagar','Saket','Vasant Kunj','Janakpuri','Pitampura','Karol Bagh','Greater Kailash','Hauz Khas','Rajouri Garden','Preet Vihar','Mayur Vihar','Vikaspuri','Uttam Nagar','Vasant Vihar','Defence Colony','Punjabi Bagh','Paschim Vihar','Tilak Nagar']],
  'Hyderabad' =>['state'=>'Telangana',  'areas'=>['Hitech City','Gachibowli','Banjara Hills','Jubilee Hills','Madhapur','Kondapur','Manikonda','Kukatpally','Secunderabad','Ameerpet','Miyapur','Kompally','LB Nagar','Uppal','Dilsukhnagar','Begumpet','Somajiguda','Tarnaka','Nacharam','Chintal']],
  'Chennai'   =>['state'=>'Tamil Nadu', 'areas'=>['Anna Nagar','Velachery','OMR','ECR','Adyar','Nungambakkam','Tambaram','Porur','Sholinganallur','Perungudi','Chromepet','Pallavaram','Ambattur','Besant Nagar','Mylapore','T Nagar','Kodambakkam','Kilpauk','Egmore','Perambur']],
  'Pune'      =>['state'=>'Maharashtra','areas'=>['Baner','Hinjewadi','Kothrud','Viman Nagar','Wakad','Hadapsar','Magarpatta','Aundh','Kalyani Nagar','Shivajinagar','Kondhwa','Pimple Saudagar','Undri','Warje','Pisoli','Pashan','Sus Road','Bavdhan','Mundhwa','Kharadi']],
  'Kolkata'   =>['state'=>'West Bengal','areas'=>['Salt Lake','New Town','Park Street','Ballygunge','Behala','Alipore','Dum Dum','Rajarhat','Garia','Jadavpur','Tollygunge','Kasba','New Garia','Ultadanga','Kankurgachi','Lake Town','Bagha Jatin','Santoshpur','Dhakuria','Gariahat']],
  'Noida'     =>['state'=>'Uttar Pradesh','areas'=>['Sector 62','Sector 18','Sector 137','Sector 150','Greater Noida West','Sector 76','Sector 45','Sector 50','Sector 44','Sector 52','Sector 61','Sector 78','Sector 93','Sector 100','Sector 119','Sector 1','Sector 15','Sector 25','Sector 35','Sector 47']],
  'Gurgaon'   =>['state'=>'Haryana',    'areas'=>['DLF Phase 1','DLF Phase 2','DLF Phase 3','Sohna Road','Golf Course Road','MG Road','Sector 56','Sector 57','Sector 49','Sector 47','Palam Vihar','Udyog Vihar','Cybercity','Sector 14','Sector 15','Sector 23','New Colony','South City','Nirvana Country','Vatika City']],
  'Ahmedabad' =>['state'=>'Gujarat',    'areas'=>['Prahlad Nagar','Satellite','Bopal','Science City','Vastrapur','Thaltej','Navrangpura','Maninagar','Chandkheda','Gota','Nikol','Naroda','Vastral','Isanpur','Vatva','Paldi','Ellis Bridge','Ambawadi','Bodakdev','Shyamal']],
  'Jaipur'    =>['state'=>'Rajasthan',  'areas'=>['Malviya Nagar','Vaishali Nagar','C Scheme','Mansarovar','Jagatpura','Tonk Road','Sanganer','Nirman Nagar','Raja Park','Civil Lines','Bani Park','Tilak Nagar','Pratap Nagar','Shastri Nagar','Hasanpura','Sodala','Vidhyadhar Nagar','Bajaj Nagar','Gopalpura','Lal Kothi']],
  'Kochi'     =>['state'=>'Kerala',     'areas'=>['Edapally','Kakkanad','MG Road','Kaloor','Thevara','Panampilly Nagar','Palarivattom','Aluva','Vyttila','Fort Kochi','Mattancherry','Marine Drive','Ernakulam','Kadavanthra','Vytilla','Tripunithura','Kalamassery','Thrikkakara','Maradu','Cheranallur']],
  'Surat'     =>['state'=>'Gujarat',    'areas'=>['Adajan','Vesu','Pal','City Light','Katargam','Udhna','Rander','Piplod','Ghod Dod Road','Athwa','Nanpura','Majura Gate','Varachha','Limbayat','Bamroli']],
  'Lucknow'   =>['state'=>'Uttar Pradesh','areas'=>['Gomti Nagar','Hazratganj','Aliganj','Indira Nagar','Alambagh','Chinhat','Mahanagar','Rajajipuram','Vibhuti Khand','Sector 14']],
  'Chandigarh'=>['state'=>'Chandigarh', 'areas'=>['Sector 7','Sector 9','Sector 10','Sector 15','Sector 17','Sector 20','Sector 21','Sector 22','Sector 35','Sector 38','Mohali','Panchkula']],
];
$allCities = array_keys($cityMap);
sort($allCities);

$typeImgs = [
  'home'       =>['ext'=>'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800','hall'=>'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800','bed'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800','bath'=>'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800','kit'=>'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800'],
  'apartment'  =>['ext'=>'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800','hall'=>'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800','bed'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800','bath'=>'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800','kit'=>'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800'],
  'villa'      =>['ext'=>'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800','hall'=>'https://images.unsplash.com/photo-1600210492493-0946911123ea?w=800','bed'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800','bath'=>'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800','kit'=>'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800'],
  'site'       =>['ext'=>'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800','hall'=>'','bed'=>'','bath'=>'','kit'=>''],
  'commercial' =>['ext'=>'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=800','hall'=>'https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=800','bed'=>'','bath'=>'','kit'=>''],
  'pg'         =>['ext'=>'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800','hall'=>'https://images.unsplash.com/photo-1560185007-cde436f6a4d0?w=800','bed'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800','bath'=>'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800','kit'=>'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800'],
];
$ct = $_POST['type'] ?? 'apartment';
$di = $typeImgs[$ct] ?? $typeImgs['apartment'];
?>

<?php if ($msg==='success'): ?>
<div class="alert alert-success alert-dismissible fade show">
  <i class="fas fa-check-circle me-2"></i><strong>Property added!</strong>
  <a href="properties.php" class="alert-link ms-2">View All Properties →</a>
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<?php if ($errors): ?>
<div class="alert alert-danger alert-dismissible fade show">
  <strong><i class="fas fa-exclamation-triangle me-2"></i>Fix the following:</strong>
  <ul class="mb-0 mt-1"><?php foreach($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul>
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<style>
.ap-box{background:#fff;border-radius:14px;border:1px solid #e5e9ef;padding:20px;margin-bottom:16px}
.ap-head{font-size:.88rem;font-weight:700;color:#1a3c5e;padding-bottom:10px;margin-bottom:14px;border-bottom:2px solid #f0f4f8;display:flex;align-items:center;gap:8px}
.chip{display:inline-block;padding:4px 13px;border-radius:20px;font-size:.75rem;font-weight:600;background:#f0f4f8;color:#555;cursor:pointer;border:2px solid transparent;transition:.2s;margin:3px;user-select:none}
.chip:hover{border-color:#1a3c5e;color:#1a3c5e}
.chip.on{background:#1a3c5e;color:#fff;border-color:#1a3c5e}
.chip.pg.on{background:#6f42c1;border-color:#6f42c1;color:#fff}
.img-thumb{width:100%;height:72px;object-fit:cover;border-radius:8px;border:2px solid #e5e9ef;transition:.2s}
.img-thumb:hover{border-color:#FF6B35}
.img-wrap{position:relative}
.img-lbl{position:absolute;bottom:4px;left:6px;background:rgba(0,0,0,.6);color:#fff;font-size:.62rem;padding:1px 6px;border-radius:6px}
.img-rst{position:absolute;top:4px;right:4px;background:#FF6B35;color:#fff;border:none;border-radius:5px;font-size:.62rem;padding:2px 6px;cursor:pointer}
.loc-drop{position:absolute;z-index:999;width:100%;background:#fff;border:1px solid #dee2e6;border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.1);max-height:190px;overflow-y:auto;top:100%}
.loc-item{padding:8px 14px;cursor:pointer;font-size:.83rem;border-bottom:1px solid #f5f5f5}
.loc-item:hover{background:#eef2ff;color:#1a3c5e;font-weight:600}
</style>

<form method="POST" id="apf">
<div class="row g-3">

<!-- ====== LEFT ====== -->
<div class="col-lg-8">

  <!-- Basic Info -->
  <div class="ap-box">
    <div class="ap-head"><i class="fas fa-home text-accent"></i> Basic Information</div>
    <div class="row g-3">

      <div class="col-12">
        <label class="fw-bold small">Title <span class="text-danger">*</span></label>
        <input type="text" name="title" class="form-control" placeholder="e.g. Spacious 3BHK Villa in Koramangala" required value="<?= htmlspecialchars($_POST['title']??'') ?>">
      </div>

      <div class="col-md-6">
        <label class="fw-bold small">Property Type</label>
        <select name="type" id="propType" class="form-select" onchange="onType(this.value)">
          <option value="apartment"  <?= ($ct==='apartment' ?'selected':'') ?>>🏢 Apartment / Flat</option>
          <option value="home"       <?= ($ct==='home'      ?'selected':'') ?>>🏠 Independent House</option>
          <option value="villa"      <?= ($ct==='villa'     ?'selected':'') ?>>🏰 Villa / Bungalow</option>
          <option value="site"       <?= ($ct==='site'      ?'selected':'') ?>>🌿 Site / Plot / Land</option>
          <option value="commercial" <?= ($ct==='commercial'?'selected':'') ?>>🏬 Commercial Space</option>
          <option value="pg"         <?= ($ct==='pg'        ?'selected':'') ?>>🛏️ PG / Co-Living</option>
        </select>
      </div>

      <div class="col-md-6">
        <label class="fw-bold small">Listing Type</label>
        <select name="listing_type" id="listType" class="form-select">
          <option value="rent"       <?= (($_POST['listing_type']??'')==='rent'      ?'selected':'') ?>>🔑 For Rent</option>
          <option value="buy"        <?= (($_POST['listing_type']??'')==='buy'       ?'selected':'') ?>>💰 For Sale</option>
          <option value="pg"         <?= (($_POST['listing_type']??'')==='pg'        ?'selected':'') ?>>🛏️ PG / Co-Living</option>
          <option value="commercial" <?= (($_POST['listing_type']??'')==='commercial'?'selected':'') ?>>🏢 Commercial Lease</option>
        </select>
      </div>

      <div class="col-md-5">
        <label class="fw-bold small">Price (₹) <span class="text-danger">*</span></label>
        <div class="input-group">
          <span class="input-group-text fw-bold">₹</span>
          <input type="number" name="price" id="priceIn" class="form-control" min="1" required placeholder="0" value="<?= $_POST['price']??'' ?>" oninput="priceLabel(this.value)">
        </div>
        <small class="fw-bold text-muted" id="pLbl"></small>
      </div>

      <div class="col-md-4">
        <label class="fw-bold small">Area</label>
        <div class="input-group">
          <input type="text" name="area" class="form-control" placeholder="1200" value="<?= htmlspecialchars($_POST['area']??'') ?>">
          <span class="input-group-text">sqft</span>
        </div>
      </div>

      <div class="col-md-3">
        <label class="fw-bold small">Status</label>
        <select name="status" class="form-select">
          <option value="available">✅ Available</option>
          <option value="sold">🔴 Sold</option>
          <option value="rented">🔵 Rented</option>
        </select>
      </div>

      <div class="col-md-3">
        <label class="fw-bold small">Bedrooms</label>
        <select name="bedrooms" class="form-select">
          <option value="0">Studio/0</option>
          <?php for($i=1;$i<=10;$i++): ?><option value="<?=$i?>"><?=$i?> BHK</option><?php endfor; ?>
        </select>
      </div>

      <div class="col-md-3">
        <label class="fw-bold small">Bathrooms</label>
        <select name="bathrooms" class="form-select">
          <?php for($i=0;$i<=8;$i++): ?><option value="<?=$i?>"><?=$i?></option><?php endfor; ?>
        </select>
      </div>

      <div class="col-12">
        <label class="fw-bold small">Description</label>
        <textarea name="description" class="form-control" rows="3" placeholder="Nearby landmarks, highlights, condition..."><?= htmlspecialchars($_POST['description']??'') ?></textarea>
      </div>

    </div>
  </div>

  <!-- Location -->
  <div class="ap-box">
    <div class="ap-head"><i class="fas fa-map-marker-alt text-danger"></i> Location</div>
    <div class="row g-3">

      <div class="col-md-6">
        <label class="fw-bold small">City <span class="text-danger">*</span></label>
        <select name="city" id="citySel" class="form-select" required onchange="cityChange(this.value)">
          <option value="">-- Select City --</option>
          <?php foreach($allCities as $c): ?>
          <option value="<?=$c?>" <?= (($_POST['city']??'')===$c?'selected':'') ?>><?=$c?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-6" style="position:relative">
        <label class="fw-bold small">Locality / Area <span class="text-danger">*</span></label>
        <input type="text" name="location" id="locIn" class="form-control" placeholder="Type or select area..." required
               value="<?= htmlspecialchars($_POST['location']??'') ?>"
               oninput="filterLoc(this.value)" autocomplete="off">
        <div class="loc-drop d-none" id="locDrop"></div>
      </div>

      <div class="col-md-6">
        <label class="fw-bold small">State</label>
        <input type="text" name="state" id="stateIn" class="form-control" placeholder="Auto-filled on city select" value="<?= htmlspecialchars($_POST['state']??'') ?>">
      </div>

      <div class="col-md-6">
        <label class="fw-bold small">Pincode</label>
        <input type="text" name="pincode" class="form-control" maxlength="6" placeholder="6-digit pincode" value="<?= htmlspecialchars($_POST['pincode']??'') ?>">
      </div>

      <div class="col-12">
        <label class="fw-bold small">Amenities <span class="text-muted">(click to select)</span></label>
        <div class="mb-2">
          <?php foreach(['Parking','Security','Gym','Swimming Pool','Power Backup','Lift','Garden','Clubhouse','CCTV','WiFi','AC','Furnished','Semi-Furnished','Water 24/7','Gas Pipeline','Solar','Pet Friendly','Play Area','Terrace','Balcony'] as $a): ?>
          <span class="chip" onclick="toggleChip(this,'<?=$a?>')"><?=$a?></span>
          <?php endforeach; ?>
        </div>
        <input type="text" name="amenities" id="amenIn" class="form-control form-control-sm" placeholder="Selected amenities show here..." value="<?= htmlspecialchars($_POST['amenities']??'') ?>">
      </div>

    </div>
  </div>

  <!-- PG Section (shows only for PG type) -->
  <div class="ap-box <?= ($ct!=='pg'?'d-none':'') ?>" id="pgBox">
    <div class="ap-head"><i class="fas fa-door-open" style="color:#6f42c1"></i> PG / Co-Living Details</div>
    <div class="row g-3">

      <div class="col-12">
        <label class="fw-bold small">PG Available For</label>
        <div class="mt-1">
          <span class="chip pg" id="pg_boys"    onclick="pickPG(this,'boys')">👨 Boys Only</span>
          <span class="chip pg" id="pg_girls"   onclick="pickPG(this,'girls')">👩 Girls Only</span>
          <span class="chip pg" id="pg_coliving"onclick="pickPG(this,'coliving')">🤝 Co-Living (Any)</span>
        </div>
        <input type="hidden" name="pg_for" id="pgForIn" value="">
      </div>

      <div class="col-12">
        <label class="fw-bold small">Room Type</label>
        <div class="mt-1">
          <span class="chip pg on" id="rt_private"onclick="pickRT(this,'private')">🔒 Private Room</span>
          <span class="chip pg"   id="rt_double" onclick="pickRT(this,'double')">👥 Double Sharing</span>
          <span class="chip pg"   id="rt_triple" onclick="pickRT(this,'triple')">👥 Triple Sharing</span>
          <span class="chip pg"   id="rt_dorm"   onclick="pickRT(this,'dorm')">🛏️ Dormitory</span>
        </div>
        <input type="hidden" name="room_type" id="rtIn" value="private">
      </div>

      <div class="col-12">
        <label class="fw-bold small">PG Facilities</label>
        <div>
          <?php foreach(['Food Available (Veg)','Food Available (Non-Veg)','WiFi','AC Room','Attached Bathroom','Laundry','Housekeeping','CCTV','Geyser','TV','Fridge','Parking','Biometric Entry','24x7 Security','Water Purifier','Study Table','Locker'] as $f): ?>
          <span class="chip pg" onclick="togglePGFac(this,'<?=$f?>')"><?=$f?></span>
          <?php endforeach; ?>
        </div>
        <input type="hidden" name="pg_facilities" id="pgFacIn" value="">
      </div>

      <div class="col-md-6">
        <div class="form-check form-switch mt-1">
          <input class="form-check-input" type="checkbox" name="food_avail" id="foodSwitch" role="switch">
          <label class="form-check-label fw-bold small" for="foodSwitch">🍽️ Meals Included in Rent</label>
        </div>
      </div>

    </div>
  </div>

  <!-- Collections & Flags -->
  <div class="ap-box">
    <div class="ap-head"><i class="fas fa-star text-warning"></i> Collections & Highlights</div>
    <div class="row g-3">

      <div class="col-md-6">
        <label class="fw-bold small">Add to Handpicked Collection</label>
        <select name="collection" class="form-select">
          <option value="">-- None --</option>
          <option value="for_guys">👨 For Guys</option>
          <option value="for_girls">👩 For Girls</option>
          <option value="couple_friendly">💑 Couple Friendly</option>
          <option value="family_special">👨‍👩‍👧 Family Special</option>
          <option value="budget_picks">💸 Budget Picks</option>
          <option value="premium_picks">⭐ Premium Picks</option>
          <option value="top_city">🏆 Top Establishment in City</option>
        </select>
      </div>

      <div class="col-md-6 d-flex flex-column gap-2 justify-content-end">
        <div class="form-check form-switch">
          <input class="form-check-input" type="checkbox" name="featured" id="featSw" role="switch" <?= isset($_POST['featured'])?'checked':'' ?>>
          <label class="form-check-label fw-bold small" for="featSw">⭐ Featured on Homepage</label>
        </div>
        <div class="form-check form-switch">
          <input class="form-check-input" type="checkbox" name="top_city" id="topSw" role="switch">
          <label class="form-check-label fw-bold small" for="topSw">🏆 Top Establishment in City</label>
        </div>
      </div>

      <!-- Rent Receipt -->
      <div class="col-12 pt-1">
        <div class="p-3 rounded-3" style="background:#f0fff4;border:1px solid #c6f6d5">
          <div class="d-flex align-items-center gap-3 flex-wrap">
            <div class="form-check form-switch mb-0">
              <input class="form-check-input" type="checkbox" name="receipt_enabled" id="rcptSw" role="switch" checked>
              <label class="form-check-label fw-bold small" for="rcptSw">📄 Enable Rent Receipts for Tenants</label>
            </div>
            <div>
              <label class="fw-bold small me-2">Due Date:</label>
              <select name="rent_due_day" class="form-select form-select-sm d-inline-block" style="width:auto">
                <?php for($d=1;$d<=28;$d++): ?>
                <option value="<?=$d?>"><?=$d?><?=($d==1?'st':($d==2?'nd':($d==3?'rd':'th')))?> of month</option>
                <?php endfor; ?>
              </select>
            </div>
          </div>
          <small class="text-muted mt-1 d-block">Tenants can generate monthly rent receipts from their dashboard.</small>
        </div>
      </div>

    </div>
  </div>

</div><!-- end left -->

<!-- ====== RIGHT: Images ====== -->
<div class="col-lg-4">
  <div class="ap-box" style="position:sticky;top:78px">
    <div class="ap-head"><i class="fas fa-images text-accent"></i> Property Images</div>
    <p class="text-muted mb-3" style="font-size:.76rem"><i class="fas fa-magic text-warning me-1"></i>Images auto-change by type. Paste any image URL to override.</p>

    <?php
    $imgRows=[
      ['img_exterior','🏠 Exterior','ext', 0],
      ['img_hall',    '🛋️ Hall',    'hall',1],
      ['img_bedroom', '🛏️ Bedroom', 'bed', 2],
      ['img_bathroom','🚿 Bathroom','bath',3],
      ['img_kitchen', '🍳 Kitchen', 'kit', 4],
    ];
    ?>
    <?php foreach($imgRows as [$fn,$lbl,$key,$idx]): ?>
    <?php $cv = $_POST[$fn] ?? ($di[$key]??''); ?>
    <div class="mb-3">
      <label class="d-flex justify-content-between fw-bold" style="font-size:.78rem">
        <?=$lbl?>
        <span style="color:#FF6B35;cursor:pointer;font-size:.7rem" onclick="rstImg(<?=$idx?>,'<?=$key?>')">↺ Reset</span>
      </label>
      <!-- type="text" NOT type="url" — browser rejects ?w=800 query params with url type -->
      <input type="text" name="<?=$fn?>" id="ii<?=$idx?>"
             class="form-control form-control-sm mb-1"
             value="<?= htmlspecialchars($cv) ?>"
             placeholder="Paste image URL here"
             oninput="updPrev(<?=$idx?>)">
      <div class="img-wrap">
        <img id="ip<?=$idx?>"
             src="<?= htmlspecialchars($cv?:'https://via.placeholder.com/400x120?text=No+Image') ?>"
             class="img-thumb"
             onerror="this.src='https://via.placeholder.com/400x120?text=Invalid+URL'">
        <span class="img-lbl"><?=$lbl?></span>
        <button type="button" class="img-rst" onclick="rstImg(<?=$idx?>,'<?=$key?>')">↺</button>
      </div>
    </div>
    <?php endforeach; ?>

    <div class="p-2 rounded-3 mt-1" style="background:#fff8f0;border:1px solid #ffd9c0;font-size:.73rem;color:#777">
      <i class="fas fa-info-circle text-warning me-1"></i>
      <strong>Tip:</strong> Select a property type above and images auto-load. You can paste any direct URL.
    </div>
  </div>
</div>

</div><!-- end main row -->

<div class="d-flex gap-3 mt-2">
  <button type="submit" class="btn btn-accent px-5 py-2 fw-bold">
    <i class="fas fa-plus-circle me-2"></i>Add Property
  </button>
  <a href="properties.php" class="btn btn-outline-secondary px-4">Cancel</a>
  <button type="button" class="btn btn-outline-danger px-4" onclick="document.getElementById('apf').reset();rstAll()">
    <i class="fas fa-redo me-1"></i>Clear
  </button>
</div>

</form>

<script>
const TI  = <?= json_encode($typeImgs) ?>;
const CM  = <?= json_encode($cityMap)  ?>;
let locList = [], amenSet = new Set(), pgFacSet = new Set();

/* --- Image helpers --- */
function setImg(i,u){ document.getElementById('ii'+i).value=u; document.getElementById('ip'+i).src=u||'https://via.placeholder.com/400x120?text=No+Image'; }
function updPrev(i){ const v=document.getElementById('ii'+i).value.trim(); document.getElementById('ip'+i).src=v||'https://via.placeholder.com/400x120?text=No+Image'; }
function rstImg(i,k){ const t=document.getElementById('propType').value||'apartment'; const imgs=TI[t]||TI['apartment']; setImg(i,imgs[k]||''); }
function rstAll(){ ['ext','hall','bed','bath','kit'].forEach((k,i)=>rstImg(i,k)); }

/* --- Type change --- */
function onType(t){
  const imgs=TI[t]||TI['apartment'];
  setImg(0,imgs.ext||''); setImg(1,imgs.hall||''); setImg(2,imgs.bed||''); setImg(3,imgs.bath||''); setImg(4,imgs.kit||'');
  document.getElementById('pgBox').classList.toggle('d-none', t!=='pg');
  if(t==='pg')         document.getElementById('listType').value='pg';
  else if(t==='commercial') document.getElementById('listType').value='commercial';
  else if(t==='site')  document.getElementById('listType').value='buy';
}

/* --- City / locality --- */
function cityChange(c){
  const d=CM[c];
  if(d){ document.getElementById('stateIn').value=d.state; locList=d.areas; }
  else { locList=[]; }
  document.getElementById('locIn').value='';
  showLocDrop(locList);
}
function filterLoc(q){
  if(!q.trim()){ showLocDrop(locList); return; }
  showLocDrop(locList.filter(l=>l.toLowerCase().includes(q.toLowerCase())));
}
function showLocDrop(items){
  const box=document.getElementById('locDrop');
  if(!items.length){ box.classList.add('d-none'); return; }
  box.innerHTML=items.slice(0,10).map(l=>`<div class="loc-item" onclick="pickLoc('${l}')">${l}</div>`).join('');
  box.classList.remove('d-none');
}
function pickLoc(v){ document.getElementById('locIn').value=v; document.getElementById('locDrop').classList.add('d-none'); }
document.addEventListener('click',e=>{ if(!e.target.closest('#locIn')&&!e.target.closest('#locDrop')) document.getElementById('locDrop').classList.add('d-none'); });

/* --- Amenities --- */
function toggleChip(el,n){ if(amenSet.has(n)){amenSet.delete(n);el.classList.remove('on');}else{amenSet.add(n);el.classList.add('on');} document.getElementById('amenIn').value=[...amenSet].join(', '); }

/* --- PG For --- */
function pickPG(el,v){
  ['pg_boys','pg_girls','pg_coliving'].forEach(id=>document.getElementById(id).classList.remove('on'));
  el.classList.add('on');
  document.getElementById('pgForIn').value=v;
}

/* --- Room Type --- */
function pickRT(el,v){
  ['rt_private','rt_double','rt_triple','rt_dorm'].forEach(id=>document.getElementById(id).classList.remove('on'));
  el.classList.add('on');
  document.getElementById('rtIn').value=v;
}

/* --- PG Facilities --- */
function togglePGFac(el,n){ if(pgFacSet.has(n)){pgFacSet.delete(n);el.classList.remove('on');}else{pgFacSet.add(n);el.classList.add('on');} document.getElementById('pgFacIn').value=[...pgFacSet].join(', '); }

/* --- Price label --- */
function priceLabel(v){ const n=parseFloat(v); let t=''; if(n>=10000000) t='= ₹'+(n/10000000).toFixed(2)+' Cr'; else if(n>=100000) t='= ₹'+(n/100000).toFixed(2)+' L'; document.getElementById('pLbl').textContent=t; }

/* --- Init --- */
window.addEventListener('DOMContentLoaded',()=>{
  const c=document.getElementById('citySel').value;
  if(c) cityChange(c);
  const p=document.getElementById('priceIn').value;
  if(p) priceLabel(p);
});
</script>

    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
