<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../includes/config.php';
if (!isAdminLoggedIn()) redirect(SITE_URL . '/admin/login.php');

// --- DELETE ---
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM services WHERE id=" . (int)$_GET['delete']);
    header("Location: services.php?msg=deleted"); exit();
}

// --- TOGGLE STATUS ---
if (isset($_GET['toggle'])) {
    $sid  = (int)$_GET['toggle'];
    $row  = $conn->query("SELECT status FROM services WHERE id=$sid")->fetch_assoc();
    $new  = ($row['status'] === 'active') ? 'inactive' : 'active';
    $conn->query("UPDATE services SET status='$new' WHERE id=$sid");
    header("Location: services.php"); exit();
}

// --- ADD ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_service'])) {
    $name  = $conn->real_escape_string(trim($_POST['name']        ?? ''));
    $cat   = $conn->real_escape_string(trim($_POST['category']    ?? ''));
    $desc  = $conn->real_escape_string(trim($_POST['description'] ?? ''));
    $price = $conn->real_escape_string(trim($_POST['price_range'] ?? ''));
    $img   = $conn->real_escape_string(trim($_POST['image_url']   ?? ''));
    $stat  = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';
    if ($name) {
        $conn->query("INSERT INTO services (name,category,description,price_range,image_url,status) VALUES('$name','$cat','$desc','$price','$img','$stat')");
        header("Location: services.php?msg=added"); exit();
    }
}

// --- EDIT ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_service'])) {
    $sid   = (int)$_POST['service_id'];
    $name  = $conn->real_escape_string(trim($_POST['name']        ?? ''));
    $cat   = $conn->real_escape_string(trim($_POST['category']    ?? ''));
    $desc  = $conn->real_escape_string(trim($_POST['description'] ?? ''));
    $price = $conn->real_escape_string(trim($_POST['price_range'] ?? ''));
    $img   = $conn->real_escape_string(trim($_POST['image_url']   ?? ''));
    $stat  = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';
    if ($name && $sid) {
        $conn->query("UPDATE services SET name='$name',category='$cat',description='$desc',price_range='$price',image_url='$img',status='$stat' WHERE id=$sid");
        header("Location: services.php?msg=updated"); exit();
    }
}

// --- Load edit data if ?edit=ID ---
$editRow = null;
if (isset($_GET['edit'])) {
    $er = $conn->query("SELECT * FROM services WHERE id=" . (int)$_GET['edit']);
    if ($er && $er->num_rows) $editRow = $er->fetch_assoc();
}

$pageTitle = 'Services';
require_once 'includes/sidebar.php';

$services = $conn->query("SELECT * FROM services ORDER BY id DESC");

$flashMap = [
    'added'   => ['success', '✅ Service added successfully!'],
    'updated' => ['success', '✅ Service updated successfully!'],
    'deleted' => ['danger',  '🗑️ Service deleted.'],
];
$flashMsg  = '';
$flashType = 'success';
if (isset($_GET['msg'], $flashMap[$_GET['msg']])) {
    $flashMsg  = $flashMap[$_GET['msg']][1];
    $flashType = $flashMap[$_GET['msg']][0];
}

$cats = ['Cleaning','Painting','Moving','Interiors','Plumbing','Carpentry','Electrical','Other'];
?>

<?php if ($flashMsg): ?>
<div class="alert alert-<?= $flashType ?> rounded-3 mb-3"><?= $flashMsg ?></div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="fw-bold mb-0"><i class="fas fa-tools me-2" style="color:#FF6B35"></i>Home Services</h5>
    <a href="services.php?add=1" class="btn btn-accent"><i class="fas fa-plus me-2"></i>Add Service</a>
</div>

<div class="admin-card">
    <div class="table-responsive">
        <table class="table admin-table">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price Range</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($services && $services->num_rows > 0): ?>
                <?php while ($s = $services->fetch_assoc()): ?>
                <tr>
                    <td>
                        <img src="<?= htmlspecialchars($s['image_url'] ?? '') ?>"
                             onerror="this.src='https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=100'"
                             style="width:64px;height:48px;object-fit:cover;border-radius:8px">
                    </td>
                    <td class="fw-bold"><?= htmlspecialchars($s['name']) ?></td>
                    <td><span class="badge-soft-primary"><?= htmlspecialchars($s['category'] ?? '-') ?></span></td>
                    <td><?= htmlspecialchars($s['price_range'] ?? '-') ?></td>
                    <td>
                        <a href="services.php?toggle=<?= $s['id'] ?>"
                           class="badge-soft-<?= $s['status'] === 'active' ? 'success' : 'danger' ?>"
                           style="text-decoration:none;cursor:pointer" title="Click to toggle">
                            <?= strtoupper($s['status']) ?>
                        </a>
                    </td>
                    <td>
                        <div class="d-flex gap-1">
                            <a href="services.php?edit=<?= $s['id'] ?>"
                               class="btn btn-sm" style="background:#3b82f615;color:#3b82f6;border-radius:8px">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="services.php?delete=<?= $s['id'] ?>"
                               onclick="return confirm('Delete this service?')"
                               class="btn btn-sm" style="background:#ef444415;color:#ef4444;border-radius:8px">
                                <i class="fas fa-trash"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center py-4" style="color:var(--text-muted)">
                        No services yet. <a href="services.php?add=1" style="color:#FF6B35">Add one</a>
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ===================== ADD MODAL ===================== -->
<?php if (isset($_GET['add'])): ?>
<div class="modal-overlay" id="svcModal">
    <div class="modal-box">
        <a href="services.php" class="modal-close">✕</a>
        <h5 class="fw-bold mb-4">Add New Service</h5>
        <form method="POST">
            <input type="hidden" name="add_service" value="1">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Service Name *</label>
                    <input type="text" name="name" class="form-control" required placeholder="e.g. Home Cleaning">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Category</label>
                    <select name="category" class="form-select">
                        <?php foreach ($cats as $c): ?>
                        <option value="<?= $c ?>"><?= $c ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Price Range</label>
                    <input type="text" name="price_range" class="form-control" placeholder="e.g. ₹499 - ₹1,999">
                </div>
                <div class="col-12">
                    <label class="form-label">Image URL</label>
                    <input type="url" name="image_url" class="form-control" placeholder="https://images.unsplash.com/...">
                </div>
                <div class="col-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="Describe the service..."></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <div class="col-12 d-flex gap-2 mt-2">
                    <button type="submit" class="btn btn-accent flex-fill">Add Service</button>
                    <a href="services.php" class="btn btn-outline-accent">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- ===================== EDIT MODAL ===================== -->
<?php if ($editRow): ?>
<div class="modal-overlay" id="svcModal">
    <div class="modal-box">
        <a href="services.php" class="modal-close">✕</a>
        <h5 class="fw-bold mb-4">Edit Service</h5>
        <form method="POST">
            <input type="hidden" name="edit_service" value="1">
            <input type="hidden" name="service_id" value="<?= (int)$editRow['id'] ?>">
            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Service Name *</label>
                    <input type="text" name="name" class="form-control" required
                           value="<?= htmlspecialchars($editRow['name']) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Category</label>
                    <select name="category" class="form-select">
                        <?php foreach ($cats as $c): ?>
                        <option value="<?= $c ?>" <?= ($editRow['category'] === $c) ? 'selected' : '' ?>>
                            <?= $c ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Price Range</label>
                    <input type="text" name="price_range" class="form-control"
                           value="<?= htmlspecialchars($editRow['price_range'] ?? '') ?>"
                           placeholder="e.g. ₹499 - ₹1,999">
                </div>
                <div class="col-12">
                    <label class="form-label">Image URL</label>
                    <input type="url" name="image_url" class="form-control"
                           value="<?= htmlspecialchars($editRow['image_url'] ?? '') ?>"
                           placeholder="https://images.unsplash.com/...">
                </div>
                <?php if (!empty($editRow['image_url'])): ?>
                <div class="col-12">
                    <img src="<?= htmlspecialchars($editRow['image_url']) ?>"
                         onerror="this.style.display='none'"
                         style="width:100%;height:140px;object-fit:cover;border-radius:10px">
                </div>
                <?php endif; ?>
                <div class="col-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="3"><?= htmlspecialchars($editRow['description'] ?? '') ?></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="active"   <?= ($editRow['status'] === 'active')   ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= ($editRow['status'] === 'inactive') ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-12 d-flex gap-2 mt-2">
                    <button type="submit" class="btn btn-accent flex-fill">Save Changes</button>
                    <a href="services.php" class="btn btn-outline-accent">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<style>
.modal-overlay {
    position: fixed; inset: 0;
    background: rgba(0,0,0,.6);
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
    animation: fadeIn .2s;
}
.modal-box {
    background: var(--card-bg);
    border-radius: 20px;
    padding: 32px;
    width: 100%;
    max-width: 520px;
    max-height: 90vh;
    overflow-y: auto;
    position: relative;
    animation: slideUp .25s;
}
.modal-close {
    position: absolute; top: 14px; right: 18px;
    font-size: 1.3rem; color: var(--text-muted);
    text-decoration: none; line-height: 1;
}
.modal-close:hover { color: #ef4444; }
@keyframes fadeIn  { from{opacity:0} to{opacity:1} }
@keyframes slideUp { from{transform:translateY(24px);opacity:0} to{transform:translateY(0);opacity:1} }
</style>

<?php echo '</main></div></div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
