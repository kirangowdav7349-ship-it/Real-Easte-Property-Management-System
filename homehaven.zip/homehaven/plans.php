<?php
$pageTitle = 'Subscription Plans';
require_once 'includes/header.php';
$resPlans = $conn->query("SELECT * FROM plans WHERE plan_type='residential' ORDER BY price ASC");
$comPlans = $conn->query("SELECT * FROM plans WHERE plan_type='commercial' ORDER BY price ASC");

// Handle plan purchase
$msg = '';
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['plan_id'])) {
    if(!isClientLoggedIn()) {
        $msg = '<div class="alert alert-warning">Please <a href="client/login.php">login</a> to purchase a plan.</div>';
    } else {
        $msg = '<div class="alert alert-success">✅ Plan selected! Our team will contact you within 24 hours to complete your subscription.</div>';
    }
}
?>

<div class="page-banner">
  <div class="container text-center">
    <h2 class="fw-bold mb-2">📋 Subscription Plans</h2>
    <p class="opacity-75 mb-0">Choose the perfect plan to list and manage your properties</p>
  </div>
</div>

<section class="py-5">
  <div class="container">
    <?= $msg ?>

    <!-- Tab Buttons -->
    <div class="text-center mb-5">
      <div class="d-inline-flex bg-white rounded-pill p-1 shadow-sm">
        <button class="btn px-5 py-2 rounded-pill fw-bold plan-tab-btn active" id="btn-residential" onclick="switchPlan('residential')">
          🏠 Residential
        </button>
        <button class="btn px-5 py-2 rounded-pill fw-bold plan-tab-btn" id="btn-commercial" onclick="switchPlan('commercial')">
          🏢 Commercial
        </button>
      </div>
    </div>

    <!-- Residential Plans -->
    <div id="tab-residential">
      <div class="row justify-content-center g-4">
        <?php while($p = $resPlans->fetch_assoc()):
          $features = explode(',', $p['features']);
        ?>
        <div class="col-lg-4 col-md-6">
          <div class="plan-card <?= $p['is_popular'] ? 'popular' : '' ?>" style="position:relative;overflow:hidden">
            <?php if($p['is_popular']): ?>
            <div style="position:absolute;top:15px;right:-30px;background:#FF6B35;color:white;padding:5px 40px;transform:rotate(45deg);font-size:0.75rem;font-weight:700;">POPULAR</div>
            <?php endif; ?>
            <div style="font-size:2.5rem;margin-bottom:10px">
              <?= $p['listings_allowed'] <= 1 ? '🌱' : ($p['listings_allowed'] <= 5 ? '⭐' : '🚀') ?>
            </div>
            <h4 class="fw-bold"><?= $p['name'] ?></h4>
            <div class="plan-price my-3">₹<?= number_format($p['price']) ?><span>/plan</span></div>
            <div class="d-flex justify-content-center gap-3 mb-3 text-muted small">
              <span><i class="fas fa-clock me-1"></i><?= $p['duration_days'] ?> days</span>
              <span><i class="fas fa-home me-1"></i><?= $p['listings_allowed'] ?> listings</span>
            </div>
            <hr>
            <ul class="list-unstyled text-start mb-4">
              <?php foreach($features as $f): ?>
              <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i><?= trim($f) ?></li>
              <?php endforeach; ?>
            </ul>
            <form method="POST">
              <input type="hidden" name="plan_id" value="<?= $p['id'] ?>">
              <input type="hidden" name="plan_name" value="<?= $p['name'] ?>">
              <button type="submit" class="btn <?= $p['is_popular'] ? 'btn-accent' : 'btn-primary-custom' ?> w-100 py-2 fw-bold">
                Get Started →
              </button>
            </form>
          </div>
        </div>
        <?php endwhile; ?>
      </div>
    </div>

    <!-- Commercial Plans -->
    <div id="tab-commercial" style="display:none">
      <div class="row justify-content-center g-4">
        <?php while($p = $comPlans->fetch_assoc()):
          $features = explode(',', $p['features']);
        ?>
        <div class="col-lg-4 col-md-6">
          <div class="plan-card <?= $p['is_popular'] ? 'popular' : '' ?>" style="position:relative;overflow:hidden">
            <?php if($p['is_popular']): ?>
            <div style="position:absolute;top:15px;right:-30px;background:#FF6B35;color:white;padding:5px 40px;transform:rotate(45deg);font-size:0.75rem;font-weight:700;">BEST VALUE</div>
            <?php endif; ?>
            <div style="font-size:2.5rem;margin-bottom:10px">
              <?= $p['listings_allowed'] <= 1 ? '🏬' : '🏙️' ?>
            </div>
            <h4 class="fw-bold"><?= $p['name'] ?></h4>
            <div class="plan-price my-3">₹<?= number_format($p['price']) ?><span>/plan</span></div>
            <div class="d-flex justify-content-center gap-3 mb-3 text-muted small">
              <span><i class="fas fa-clock me-1"></i><?= $p['duration_days'] ?> days</span>
              <span><i class="fas fa-building me-1"></i><?= $p['listings_allowed'] ?> listings</span>
            </div>
            <hr>
            <ul class="list-unstyled text-start mb-4">
              <?php foreach($features as $f): ?>
              <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i><?= trim($f) ?></li>
              <?php endforeach; ?>
            </ul>
            <form method="POST">
              <input type="hidden" name="plan_id" value="<?= $p['id'] ?>">
              <input type="hidden" name="plan_name" value="<?= $p['name'] ?>">
              <button type="submit" class="btn btn-primary-custom w-100 py-2 fw-bold">Get Started →</button>
            </form>
          </div>
        </div>
        <?php endwhile; ?>
      </div>
    </div>

    <!-- Why Choose Us -->
    <div class="row g-4 mt-5">
      <div class="col-12 text-center mb-2">
        <h3 class="section-title">Why Choose PropNexus Plans?</h3>
      </div>
      <?php
      $whys = [
        ['fa-bolt','Instant Listing','Your property goes live immediately after plan activation','#FF6B35'],
        ['fa-eye','Maximum Visibility','Featured placement for more buyer/renter enquiries','#1a3c5e'],
        ['fa-headset','Dedicated Support','Personal relationship manager for premium plans','#2d6a4f'],
        ['fa-shield-alt','Verified Listings','Blue tick verification builds trust with buyers','#6f42c1'],
      ];
      foreach($whys as $w): ?>
      <div class="col-md-3 col-6 text-center">
        <div class="p-4 bg-white rounded-4 shadow-sm h-100">
          <div style="width:60px;height:60px;background:<?= $w[3] ?>20;color:<?= $w[3] ?>;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.5rem;margin:0 auto 15px">
            <i class="fas <?= $w[0] ?>"></i>
          </div>
          <h6 class="fw-bold"><?= $w[1] ?></h6>
          <p class="text-muted small mb-0"><?= $w[2] ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<style>
.plan-tab-btn { transition:0.3s; color:#666; }
.plan-tab-btn.active { background:linear-gradient(135deg,#1a3c5e,#2d6a4f); color:white !important; }
</style>

<script>
function switchPlan(type) {
  document.getElementById('tab-residential').style.display = type === 'residential' ? 'block' : 'none';
  document.getElementById('tab-commercial').style.display  = type === 'commercial'  ? 'block' : 'none';
  document.getElementById('btn-residential').classList.toggle('active', type === 'residential');
  document.getElementById('btn-commercial').classList.toggle('active',  type === 'commercial');
}
</script>

<?php require_once 'includes/footer.php'; ?>
