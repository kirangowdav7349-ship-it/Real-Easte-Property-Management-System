<style>
/* ── 99acres-style Mega Footer ── */
.mega-footer{background:#fff;border-top:1px solid #e0e0e0;padding:0}
.mega-footer-inner{display:flex;min-height:360px}
.mega-footer-sidebar{width:220px;flex-shrink:0;border-right:1px solid #e8e8e8;padding:28px 0}
.mega-footer-sidebar a{display:block;padding:10px 22px;font-size:.88rem;font-weight:600;color:#333;text-decoration:none;transition:.2s;border-left:3px solid transparent}
.mega-footer-sidebar a:hover,.mega-footer-sidebar a.active{color:var(--primary);background:#f5f8fa;border-left-color:var(--primary)}
.mega-footer-sidebar a .new-badge{background:#ff5722;color:#fff;font-size:.6rem;padding:1px 6px;border-radius:3px;margin-left:6px;font-weight:700;vertical-align:middle}
.mega-footer-content{flex:1;padding:28px 32px;display:flex;gap:48px}
.mega-footer-col h6{font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#888;margin-bottom:14px}
.mega-footer-col ul{list-style:none;padding:0;margin:0}
.mega-footer-col ul li{margin-bottom:8px}
.mega-footer-col ul li a{color:#333;text-decoration:none;font-size:.86rem;transition:.2s}
.mega-footer-col ul li a:hover{color:var(--accent)}
.mega-footer-insights{width:300px;flex-shrink:0;border-left:1px solid #e8e8e8;padding:28px 24px}
.insights-card{background:#f5f8fa;border-radius:12px;padding:20px;border:1px solid #e0e0e0}
.insights-card h5{font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:#888;margin-bottom:4px}
.insights-card h4{font-size:1.15rem;font-weight:800;color:#1a2d3d;margin-bottom:14px;display:flex;align-items:center;gap:8px}
.insights-card h4 i{color:#0078db}
.insights-card ul{list-style:none;padding:0;margin:0}
.insights-card ul li{padding:6px 0;font-size:.84rem;color:#333;display:flex;align-items:center;gap:8px}
.insights-card ul li i{color:#4caf50;font-size:.8rem}
.mega-footer-contact{background:#f5f8fa;border-top:1px solid #e8e8e8;padding:16px 0}
.mega-footer-contact p{margin:0;font-size:.82rem;color:#555}
.mega-footer-contact a{color:var(--accent);text-decoration:none;font-weight:600}
.mega-footer-contact strong{color:#1a2d3d}
body.dark .mega-footer{background:var(--card-bg);border-color:var(--border)}
body.dark .mega-footer-sidebar{border-color:var(--border)}
body.dark .mega-footer-sidebar a{color:var(--text-main)}
body.dark .mega-footer-sidebar a:hover,body.dark .mega-footer-sidebar a.active{background:rgba(255,255,255,.05);color:var(--accent);border-left-color:var(--accent)}
body.dark .mega-footer-insights{border-color:var(--border)}
body.dark .mega-footer-col h6{color:var(--text-muted)}
body.dark .mega-footer-col ul li a{color:var(--text-main)}
body.dark .insights-card{background:rgba(255,255,255,.04);border-color:var(--border)}
body.dark .insights-card h4{color:var(--text-main)}
body.dark .insights-card ul li{color:var(--text-main)}
body.dark .mega-footer-contact{background:rgba(0,0,0,.15);border-color:var(--border)}
body.dark .mega-footer-contact p{color:var(--text-muted)}
body.dark .mega-footer-contact strong{color:var(--text-main)}
@media(max-width:992px){
  .mega-footer-inner{flex-direction:column}
  .mega-footer-sidebar{width:100%;border-right:none;border-bottom:1px solid #e8e8e8;padding:14px 0;display:flex;flex-wrap:wrap;gap:0}
  .mega-footer-sidebar a{padding:8px 16px;font-size:.82rem;border-left:none;border-bottom:2px solid transparent}
  .mega-footer-sidebar a.active{border-bottom-color:var(--primary);border-left:none;background:none}
  .mega-footer-content{flex-direction:column;gap:24px;padding:20px 16px}
  .mega-footer-insights{width:100%;border-left:none;border-top:1px solid #e8e8e8;padding:16px}
  .mega-footer-sidebar>div{width:100%;border-top:1px solid #e8e8e8;padding:12px 16px!important;margin-top:0!important}
}
</style>

<!-- ════════════════ 99ACRES MEGA FOOTER ════════════════ -->
<section class="mega-footer">
  <div class="container-fluid px-0">
    <div class="mega-footer-inner">
      <!-- Sidebar -->
      <div class="mega-footer-sidebar">
        <a href="properties.php?type=buy" class="active">BUY A HOME</a>
        <a href="properties.php?property_type=site">Land/Plot</a>
        <a href="properties.php?type=commercial">COMMERCIAL</a>
        <a href="properties.php">POPULAR AREAS</a>
        <a href="news.php">INSIGHTS <span class="new-badge">NEW</span></a>
        <a href="news.php">ARTICLES & NEWS</a>
        <div style="padding:18px 22px;margin-top:auto;border-top:1px solid #e8e8e8">
          <p style="font-size:.78rem;font-weight:700;color:#333;margin:0">contact us toll free on</p>
          <p style="font-size:1rem;font-weight:800;color:var(--primary);margin:4px 0 0">1800 41 99099</p>
          <p style="font-size:.7rem;color:#888;margin:2px 0 0">(9AM-11PM IST)</p>
        </div>
      </div>

      <!-- Content Columns -->
      <div class="mega-footer-content">
        <div class="mega-footer-col" style="flex:1">
          <h6>Properties in Bangalore East</h6>
          <ul>
            <li><a href="properties.php?property_type=apartment&city=Bangalore">Flats</a></li>
            <li><a href="properties.php?property_type=home&city=Bangalore">Builder Floors</a></li>
            <li><a href="properties.php?property_type=villa&city=Bangalore">Independent House</a></li>
            <li><a href="properties.php?property_type=site&city=Bangalore">Plots in Bangalore East</a></li>
            <li><a href="properties.php?property_type=commercial&city=Bangalore">Serviced Apartments</a></li>
            <li><a href="properties.php?property_type=pg&city=Bangalore">Studio Apartments/1 RK Flats</a></li>
            <li><a href="properties.php?property_type=villa&city=Bangalore">Farm Houses</a></li>
          </ul>
        </div>
        <div class="mega-footer-col" style="flex:1">
          <h6>Popular Searches</h6>
          <ul>
            <li><a href="properties.php?city=Bangalore">Property in Bangalore East</a></li>
            <li><a href="properties.php?city=Bangalore&verified=1">Verified Property in Bangalore East</a></li>
            <li><a href="properties.php?city=Bangalore&new=1">New Projects in Bangalore East</a></li>
            <li><a href="properties.php?type=rent&city=Bangalore">Rental Property in Bangalore</a></li>
            <li><a href="properties.php?type=buy&city=Mumbai">Property for sale in Mumbai</a></li>
            <li><a href="properties.php?type=buy&city=Delhi">Property for sale in Delhi</a></li>
          </ul>
        </div>
      </div>

      <!-- Insights Panel -->
      <div class="mega-footer-insights">
        <div class="insights-card">
          <h5>Introducing</h5>
          <h4><i class="fas fa-chart-line"></i> Insights <a href="news.php" style="margin-left:auto;font-size:.8rem;color:var(--accent);text-decoration:none">↗</a></h4>
          <ul>
            <li><i class="fas fa-check-circle"></i> Understand localities</li>
            <li><i class="fas fa-check-circle"></i> Read Resident Reviews</li>
            <li><i class="fas fa-check-circle"></i> Check Price Trends</li>
            <li><i class="fas fa-check-circle"></i> Tools, Utilities & more</li>
          </ul>
        </div>
      </div>
    </div>

    <!-- Contact bar -->
    <div class="mega-footer-contact">
      <div class="container text-center">
        <p>Email us at <a href="mailto:admin@propnexus.com">admin@propnexus.com</a> or call us at <strong>1800 41 99099</strong> (IND Toll-Free)</p>
      </div>
    </div>
  </div>
</section>

<footer class="footer-main">
  <div class="container">
    <div class="row py-5">
      <div class="col-lg-3 col-md-6 mb-4">
        <h5 class="footer-brand"><i class="fas fa-home me-2"></i>PropNexus</h5>
        <p class="footer-desc">India's trusted real estate platform for buying, renting & selling properties.</p>
        <div class="social-links">
          <a href="https://facebook.com" target="_blank" class="fb" title="Facebook"><i class="fab fa-facebook-f"></i></a>
          <a href="https://twitter.com" target="_blank" class="tw" title="Twitter"><i class="fab fa-twitter"></i></a>
          <a href="https://instagram.com/kirxn.007" target="_blank" class="ig" title="Instagram"><i class="fab fa-instagram"></i></a>
          <a href="https://linkedin.com" target="_blank" class="li" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
        </div>
      </div>
      <div class="col-lg-2 col-md-6 mb-4">
        <h6 class="footer-heading">Properties</h6>
        <ul class="footer-links">
          <li><a href="properties.php?type=buy">Buy</a></li>
          <li><a href="properties.php?type=rent">Rent</a></li>
          <li><a href="properties.php?type=commercial">Commercial</a></li>
          <li><a href="properties.php?property_type=villa">Villa</a></li>
          <li><a href="properties.php?property_type=apartment">Apartment</a></li>
          <li><a href="ai-recommend.php" style="color:var(--accent)"><i class="fas fa-robot me-1"></i>AI Recommendations</a></li>

        </ul>
      </div>
      <div class="col-lg-2 col-md-6 mb-4">
        <h6 class="footer-heading">Loan Tracker</h6>
        <ul class="footer-links">
          <li><a href="loans.php">Apply for Loan</a></li>
          <li><a href="loans.php#track">Track Application</a></li>
          <li><a href="loans.php#upload">Upload Documents</a></li>
          <li><a href="loans.php#emi">EMI Calculator</a></li>
          <li><a href="loans.php#banks">Compare Banks</a></li>
        </ul>
      </div>
      <div class="col-lg-2 col-md-6 mb-4">
        <h6 class="footer-heading">Legal</h6>
        <ul class="footer-links">
          <li><a href="legal.php">Rental Agreement</a></li>
          <li><a href="legal.php">Tenant Verification</a></li>
          <li><a href="legal.php">Sale Agreement</a></li>
          <li><a href="loans.php">Home Loans</a></li>
          <li><a href="plans.php">Plans</a></li>
          <li><a href="services.php">Home Services</a></li>
          <li><a href="news.php">News & Guides</a></li>
        </ul>
      </div>
      <div class="col-lg-3 col-md-6 mb-4">
        <h6 class="footer-heading">Contact</h6>
        <p><i class="fas fa-map-marker-alt me-2 text-accent"></i>MG Road, Bangalore - 560001</p>
        <p><i class="fas fa-phone me-2 text-accent"></i>+91 98765 43210</p>
        <p><i class="fas fa-envelope me-2 text-accent"></i>admin@PropNexus.com</p>
        <p class="mt-3 fw-bold text-accent">Admin Login: admin@PropNexus.com / Admin@123</p>
      </div>
    </div>
    <hr class="footer-hr">
    <div class="text-center py-3">
      <p class="mb-0">© 2026 PropNexus. All rights reserved. | Designed with <i class="fas fa-heart text-danger"></i></p>
    </div>
  </div>
</footer>
<?php include_once __DIR__ . '/ai-chatbot.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
