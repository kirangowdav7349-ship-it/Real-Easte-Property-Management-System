<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280">
<title><?= isset($pageTitle) ? $pageTitle.' - '.SITE_NAME : SITE_NAME ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="<?= SITE_URL ?>/assets/css/style.css" rel="stylesheet">
<script>
// Apply dark before render — no flash
(function(){
  if(localStorage.getItem('hh_dark')==='1') document.documentElement.style.background='#0e1621';
})();
</script>
</head>
<body>
<script>
if(localStorage.getItem('hh_dark')==='1') document.body.classList.add('dark');
// Restore accent
var _ac=localStorage.getItem('hh_accent');
if(_ac) document.documentElement.style.setProperty('--accent',_ac);
</script>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top" id="mainNav">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center gap-2" href="<?= SITE_URL ?>">
      <div style="width:32px;height:32px;background:var(--accent);border-radius:6px;display:flex;align-items:center;justify-content:center">
        <i class="fas fa-home text-white" style="font-size:.85rem"></i>
      </div>
      <span class="brand-text">PropNexus</span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav me-auto gap-1">
        <li class="nav-item"><a class="nav-link" href="<?= SITE_URL ?>">Home</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Properties</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?= SITE_URL ?>/properties.php?type=buy">🏠 Buy</a></li>
            <li><a class="dropdown-item" href="<?= SITE_URL ?>/properties.php?type=rent">🔑 Rent</a></li>
            <li><a class="dropdown-item" href="<?= SITE_URL ?>/properties.php?type=pg">🛏️ PG / Co-Living</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="<?= SITE_URL ?>/properties.php?type=commercial">🏢 Commercial</a></li>

          </ul>
        </li>
        <li class="nav-item"><a class="nav-link" href="<?= SITE_URL ?>/legal.php">Legal</a></li>
        <li class="nav-item"><a class="nav-link" style="white-space:nowrap" href="<?= SITE_URL ?>/loans.php">Loans</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= SITE_URL ?>/plans.php">Plans</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" style="color:var(--accent) !important;font-weight:600"><i class="fas fa-tools me-1"></i>Tools</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?= SITE_URL ?>/ai-recommend.php"><i class="fas fa-robot me-2 text-danger"></i>AI Agent</a></li>
            <li><a class="dropdown-item" href="<?= SITE_URL ?>/blueprint.php"><i class="fas fa-drafting-compass me-2" style="color:#6f42c1"></i>Blueprint Generator</a></li>

            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="<?= SITE_URL ?>/services.php"><i class="fas fa-tools me-2 text-warning"></i>Home Services</a></li>
          </ul>
        </li>
        <li class="nav-item"><a class="nav-link" href="<?= SITE_URL ?>/news.php">📰 News & Guides</a></li>
      </ul>
      <ul class="navbar-nav ms-auto align-items-center gap-2">
        <li class="nav-item">
          <button class="dark-toggle" onclick="toggleDark()" id="darkBtn">
            <i class="fas fa-moon" id="darkIco"></i> <span id="darkTxt">Dark</span>
          </button>
        </li>
        <?php if(isClientLoggedIn()): ?>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle d-flex align-items-center gap-2" href="#" data-bs-toggle="dropdown">
            <?php
              $av = $_SESSION['client_pic'] ?? '';
              $init = strtoupper(substr($_SESSION['client_name'],0,1));
              if($av && strpos($av,'data:image')===0):
            ?>
            <img src="<?=$av?>" style="width:30px;height:30px;border-radius:50%;object-fit:cover;border:2px solid var(--accent)">
            <?php else: ?>
            <span style="width:30px;height:30px;background:var(--accent);border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:.82rem;color:white"><?=$init?></span>
            <?php endif; ?>
            <?= $_SESSION['client_name'] ?>
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="<?= SITE_URL ?>/client/dashboard.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a></li>
            <li><a class="dropdown-item" href="<?= SITE_URL ?>/client/settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
            <li><a class="dropdown-item" href="<?= SITE_URL ?>/client/rent-payment.php"><i class="fas fa-receipt me-2"></i>Rent Receipts</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="<?= SITE_URL ?>/client/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
          </ul>
        </li>
        <?php else: ?>
        <li class="nav-item"><a class="nav-link btn-nav-outline me-1" href="<?= SITE_URL ?>/client/login.php">Login</a></li>
        <li class="nav-item"><a class="nav-link btn-nav-filled" href="<?= SITE_URL ?>/client/register.php">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<script>
function toggleDark(){
  var on=document.body.classList.toggle('dark');
  localStorage.setItem('hh_dark',on?'1':'0');
  _updateDarkUI();
}
function _updateDarkUI(){
  var on=document.body.classList.contains('dark');
  document.getElementById('darkIco').className=on?'fas fa-sun':'fas fa-moon';
  document.getElementById('darkTxt').textContent=on?'Light':'Dark';
}
document.addEventListener('DOMContentLoaded',_updateDarkUI);
</script>
