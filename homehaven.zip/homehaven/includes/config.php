<?php
// Output buffering — header() always works regardless of output order
if (ob_get_level() === 0) ob_start();

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'homehaven_db');
define('SITE_NAME', 'PropNexus');
define('SITE_URL', 'http://localhost/homehaven');
define('ADMIN_EMAIL', 'admin@PropNexus.com');
define('ADMIN_PASSWORD', 'Admin@123');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die('<b>DB Error:</b> ' . $conn->connect_error . '<br>Run <a href="/homehaven/install.php">install.php</a> first.');
}
$conn->set_charset("utf8mb4");

function sanitize($data) {
    global $conn;
    return htmlspecialchars(strip_tags(trim($conn->real_escape_string($data))));
}

function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

function isClientLoggedIn() {
    return isset($_SESSION['client_id']) && !empty($_SESSION['client_id']);
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function formatPrice($price) {
    if ($price >= 10000000) return '₹' . number_format($price/10000000, 2) . ' Cr';
    if ($price >= 100000) return '₹' . number_format($price/100000, 2) . ' L';
    return '₹' . number_format($price);
}
?>
