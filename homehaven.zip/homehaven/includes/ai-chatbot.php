<!-- ══════════════════════════════════════════════════════════════
     PropNexus AI Property Recommendation Agent — Chatbot Widget
     ══════════════════════════════════════════════════════════════ -->
<div id="aiChatbot">

  <!-- Floating Trigger Button -->
  <button class="ai-fab" id="aiFab" onclick="toggleAiChat()" aria-label="AI Agent">
    <div class="ai-fab-inner">
      <i class="fas fa-robot ai-fab-icon" id="aiFabIcon"></i>
      <span class="ai-fab-pulse"></span>
    </div>
    <span class="ai-fab-label">AI Agent</span>
  </button>

  <!-- Chat Window -->
  <div class="ai-chat-window" id="aiChatWindow">

    <!-- Header -->
    <div class="ai-chat-header">
      <div class="d-flex align-items-center gap-2">
        <div class="ai-avatar">
          <i class="fas fa-robot"></i>
          <span class="ai-status-dot"></span>
        </div>
        <div>
          <div class="ai-header-title">PropNexus AI</div>
          <div class="ai-header-sub"><span class="ai-typing-dot"></span><span class="ai-typing-dot"></span><span class="ai-typing-dot"></span> Smart Property Agent</div>
        </div>
      </div>
      <div class="d-flex gap-2">
        <button class="ai-header-btn" onclick="clearAiChat()" title="Clear chat"><i class="fas fa-trash-alt"></i></button>
        <button class="ai-header-btn" onclick="toggleAiChat()" title="Close"><i class="fas fa-times"></i></button>
      </div>
    </div>

    <!-- Quick Actions Bar -->
    <div class="ai-quick-bar">
      <button class="ai-quick-pill" onclick="aiQuickAction('recommend')">🤖 Recommendations</button>
      <button class="ai-quick-pill" onclick="aiQuickAction('budget')">💰 Budget Search</button>
      <button class="ai-quick-pill" onclick="aiQuickAction('pg')">🛏️ Find PG</button>
      <button class="ai-quick-pill" onclick="aiQuickAction('loan')">🏦 EMI Calculator</button>
    </div>

    <!-- Messages Area -->
    <div class="ai-chat-body" id="aiChatBody">
      <!-- Welcome message -->
      <div class="ai-msg ai-msg-bot">
        <div class="ai-msg-avatar"><i class="fas fa-robot"></i></div>
        <div class="ai-msg-bubble">
          <p>👋 <strong>Hello!</strong> I'm your AI Property Agent.</p>
          <p>I can help you find the perfect property. Try asking:</p>
          <div class="ai-suggestions">
            <button onclick="sendAiSuggestion('Show me 3BHK apartments in Bangalore')">🏠 3BHK in Bangalore</button>
            <button onclick="sendAiSuggestion('Properties under 50 Lakh in Pune')">💰 Under ₹50L in Pune</button>
            <button onclick="sendAiSuggestion('Best PG for boys in Koramangala')">🛏️ PG in Koramangala</button>
            <button onclick="sendAiSuggestion('Luxury villas with pool')">🏰 Luxury Villas</button>
            <button onclick="sendAiSuggestion('EMI for 80 Lakh home loan')">🏦 EMI Calculator</button>
            <button onclick="sendAiSuggestion('Best properties for families')">👨‍👩‍👧 For Families</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Input Area -->
    <div class="ai-chat-footer">
      <form onsubmit="sendAiMessage(event)" class="ai-input-group">
        <input type="text" id="aiChatInput" placeholder="Ask about any property..." autocomplete="off" />
        <button type="submit" class="ai-send-btn" id="aiSendBtn">
          <i class="fas fa-paper-plane"></i>
        </button>
      </form>
      <div class="ai-footer-hint">
        <i class="fas fa-sparkles"></i> Powered by PropNexus AI Engine
      </div>
    </div>

  </div>
</div>

<!-- AI Chatbot Styles -->
<style>
/* ──── AI FAB Button ──── */
.ai-fab{position:fixed;bottom:28px;right:28px;z-index:9998;background:linear-gradient(135deg,#FF6B35,#ff8f5e);border:none;border-radius:58px;padding:0 22px 0 0;height:56px;display:flex;align-items:center;gap:10px;cursor:pointer;box-shadow:0 8px 32px rgba(255,107,53,.45);transition:all .4s cubic-bezier(.4,0,.2,1);color:white;font-weight:700;font-size:.88rem;font-family:inherit}
.ai-fab:hover{transform:translateY(-4px) scale(1.05);box-shadow:0 14px 44px rgba(255,107,53,.55)}
.ai-fab-inner{width:56px;height:56px;display:flex;align-items:center;justify-content:center;position:relative}
.ai-fab-icon{font-size:1.3rem;transition:transform .3s}
.ai-fab:hover .ai-fab-icon{transform:rotate(15deg) scale(1.1)}
.ai-fab-pulse{position:absolute;inset:0;border-radius:50%;background:rgba(255,255,255,.2);animation:aiFabPulse 2s infinite}
@keyframes aiFabPulse{0%{transform:scale(1);opacity:.6}70%{transform:scale(1.3);opacity:0}100%{transform:scale(1);opacity:0}}
.ai-fab-label{white-space:nowrap}
.ai-fab.open{border-radius:50%;width:56px;padding:0}
.ai-fab.open .ai-fab-label{display:none}
.ai-fab.open .ai-fab-icon{transform:rotate(0)}

/* ──── Chat Window ──── */
.ai-chat-window{position:fixed;bottom:100px;right:28px;width:420px;max-height:600px;background:#ffffff;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,.2),0 0 0 1px rgba(0,0,0,.05);z-index:9999;display:none;flex-direction:column;overflow:hidden;animation:aiSlideUp .35s cubic-bezier(.4,0,.2,1)}
.ai-chat-window.open{display:flex}
@keyframes aiSlideUp{from{opacity:0;transform:translateY(30px) scale(.95)}to{opacity:1;transform:none}}

/* ──── Header ──── */
.ai-chat-header{background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:white;padding:16px 18px;display:flex;justify-content:space-between;align-items:center;flex-shrink:0}
.ai-avatar{width:42px;height:42px;border-radius:50%;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;font-size:1.15rem;position:relative;flex-shrink:0}
.ai-status-dot{position:absolute;bottom:1px;right:1px;width:10px;height:10px;border-radius:50%;background:#4ade80;border:2px solid #1a3c5e}
.ai-header-title{font-weight:700;font-size:.95rem;line-height:1.2}
.ai-header-sub{font-size:.7rem;opacity:.8;display:flex;align-items:center;gap:4px}
.ai-header-btn{background:rgba(255,255,255,.15);border:none;color:white;width:32px;height:32px;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:.78rem;transition:.2s}
.ai-header-btn:hover{background:rgba(255,255,255,.3)}

/* Typing dots */
.ai-typing-dot{width:4px;height:4px;border-radius:50%;background:white;display:inline-block;animation:aiDots 1.4s infinite both;margin-right:2px}
.ai-typing-dot:nth-child(2){animation-delay:.2s}
.ai-typing-dot:nth-child(3){animation-delay:.4s}
@keyframes aiDots{0%,80%,100%{opacity:.3;transform:scale(.8)}40%{opacity:1;transform:scale(1.1)}}

/* ──── Quick Actions ──── */
.ai-quick-bar{padding:10px 14px;display:flex;gap:6px;overflow-x:auto;flex-shrink:0;border-bottom:1px solid #f0f2f5;background:#fafbfd}
.ai-quick-bar::-webkit-scrollbar{height:0}
.ai-quick-pill{background:#f0f3f8;border:1px solid #e4e8f0;border-radius:20px;padding:6px 14px;font-size:.73rem;font-weight:600;cursor:pointer;white-space:nowrap;transition:.2s;font-family:inherit;color:#1a3c5e}
.ai-quick-pill:hover{background:#FF6B35;color:white;border-color:#FF6B35}

/* ──── Messages ──── */
.ai-chat-body{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:14px;background:#f8f9fc;min-height:200px;max-height:340px}
.ai-chat-body::-webkit-scrollbar{width:4px}
.ai-chat-body::-webkit-scrollbar-thumb{background:rgba(26,60,94,.2);border-radius:4px}

.ai-msg{display:flex;gap:8px;animation:aiFadeMsg .35s ease}
@keyframes aiFadeMsg{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.ai-msg-bot{align-items:flex-start}
.ai-msg-user{flex-direction:row-reverse}
.ai-msg-avatar{width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.75rem;flex-shrink:0}
.ai-msg-bot .ai-msg-avatar{background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:white}
.ai-msg-user .ai-msg-avatar{background:var(--accent,#FF6B35);color:white}
.ai-msg-bubble{max-width:85%;border-radius:16px;padding:12px 16px;font-size:.82rem;line-height:1.6;word-wrap:break-word}
.ai-msg-bot .ai-msg-bubble{background:white;color:#1e2b3c;border:1px solid #e8ecf2;border-top-left-radius:4px;box-shadow:0 2px 8px rgba(0,0,0,.04)}
.ai-msg-user .ai-msg-bubble{background:linear-gradient(135deg,#FF6B35,#ff8f5e);color:white;border-top-right-radius:4px}
.ai-msg-bubble p{margin:0 0 6px}
.ai-msg-bubble p:last-child{margin-bottom:0}
.ai-msg-bubble strong{font-weight:700}

/* Suggestions chips */
.ai-suggestions{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}
.ai-suggestions button{background:#f0f3f8;border:1px solid #dce0e8;border-radius:18px;padding:5px 12px;font-size:.72rem;cursor:pointer;transition:.2s;font-family:inherit;color:#1a3c5e;font-weight:500}
.ai-suggestions button:hover{background:#FF6B35;color:white;border-color:#FF6B35;transform:scale(1.03)}

/* Property cards in chat */
.ai-prop-card{background:#fff;border-radius:12px;border:1px solid #e8ecf2;overflow:hidden;margin-top:8px;cursor:pointer;transition:.2s}
.ai-prop-card:hover{box-shadow:0 6px 18px rgba(0,0,0,.1);transform:translateY(-2px)}
.ai-prop-card img{width:100%;height:100px;object-fit:cover}
.ai-prop-card-body{padding:8px 12px}
.ai-prop-card-title{font-weight:700;font-size:.78rem;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ai-prop-card-loc{font-size:.7rem;color:#6b7a8d}
.ai-prop-card-price{font-size:.88rem;font-weight:800;color:#FF6B35}
.ai-prop-match{display:inline-block;font-size:.64rem;font-weight:700;padding:2px 8px;border-radius:12px;background:linear-gradient(135deg,#4ade80,#22c55e);color:white}

/* Loading indicator */
.ai-loading{display:flex;gap:4px;padding:8px 14px}
.ai-loading-dot{width:8px;height:8px;border-radius:50%;background:linear-gradient(135deg,#1a3c5e,#2d6a4f);animation:aiLoadBounce .8s infinite alternate}
.ai-loading-dot:nth-child(2){animation-delay:.2s}
.ai-loading-dot:nth-child(3){animation-delay:.4s}
@keyframes aiLoadBounce{to{transform:translateY(-8px);opacity:.5}}

/* ──── Footer ──── */
.ai-chat-footer{padding:12px 14px;background:white;border-top:1px solid #f0f2f5;flex-shrink:0}
.ai-input-group{display:flex;gap:8px;align-items:center}
.ai-input-group input{flex:1;border:2px solid #e4e8f0;border-radius:24px;padding:10px 18px;font-size:.84rem;outline:none;transition:.2s;font-family:inherit;background:#f8f9fc}
.ai-input-group input:focus{border-color:#FF6B35;background:white;box-shadow:0 0 0 3px rgba(255,107,53,.1)}
.ai-send-btn{width:42px;height:42px;border-radius:50%;border:none;background:linear-gradient(135deg,#FF6B35,#ff8f5e);color:white;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:.9rem;transition:all .2s;flex-shrink:0}
.ai-send-btn:hover{transform:scale(1.08);box-shadow:0 4px 12px rgba(255,107,53,.4)}
.ai-send-btn:active{transform:scale(.95)}
.ai-footer-hint{text-align:center;font-size:.62rem;color:#aab;margin-top:6px;font-weight:500}
.ai-footer-hint i{color:#FF6B35;margin-right:2px}

/* ──── Dark Mode ──── */
body.dark .ai-chat-window{background:#162030;box-shadow:0 20px 60px rgba(0,0,0,.5)}
body.dark .ai-chat-body{background:#0e1621}
body.dark .ai-msg-bot .ai-msg-bubble{background:#1e2d40;color:#dce6f0;border-color:#2a3d52}
body.dark .ai-suggestions button{background:#1e2d40;border-color:#2a3d52;color:#9ab}
body.dark .ai-suggestions button:hover{background:#FF6B35;color:white;border-color:#FF6B35}
body.dark .ai-quick-bar{background:#1a2838;border-color:#2a3d52}
body.dark .ai-quick-pill{background:#1e2d40;border-color:#2a3d52;color:#9ab}
body.dark .ai-quick-pill:hover{background:#FF6B35;color:white;border-color:#FF6B35}
body.dark .ai-chat-footer{background:#162030;border-color:#2a3d52}
body.dark .ai-input-group input{background:#1a2d42;border-color:#2a3d52;color:#dce6f0}
body.dark .ai-input-group input:focus{border-color:#FF6B35}
body.dark .ai-prop-card{background:#1e2d40;border-color:#2a3d52}
body.dark .ai-prop-card-title{color:#dce6f0}
body.dark .ai-prop-card-loc{color:#7a9ab5}

/* Also support .dark-mode class (dashboard) */
body.dark-mode .ai-chat-window{background:#162030;box-shadow:0 20px 60px rgba(0,0,0,.5)}
body.dark-mode .ai-chat-body{background:#0e1621}
body.dark-mode .ai-msg-bot .ai-msg-bubble{background:#1e2d40;color:#dce6f0;border-color:#2a3d52}
body.dark-mode .ai-suggestions button{background:#1e2d40;border-color:#2a3d52;color:#9ab}
body.dark-mode .ai-quick-bar{background:#1a2838;border-color:#2a3d52}
body.dark-mode .ai-quick-pill{background:#1e2d40;border-color:#2a3d52;color:#9ab}
body.dark-mode .ai-chat-footer{background:#162030;border-color:#2a3d52}
body.dark-mode .ai-input-group input{background:#1a2d42;border-color:#2a3d52;color:#dce6f0}
body.dark-mode .ai-prop-card{background:#1e2d40;border-color:#2a3d52}

/* ──── Responsive ──── */
@media(max-width:480px){
  .ai-chat-window{right:0;left:0;bottom:0;width:100%;max-height:100vh;border-radius:20px 20px 0 0}
  .ai-fab{bottom:18px;right:18px}
  .ai-fab-label{display:none}
  .ai-fab{border-radius:50%;width:54px;padding:0}
}
</style>

<!-- AI Chatbot Script -->
<script>
var AI_API = '<?= SITE_URL ?>/api/ai-recommend.php';
var aiChatOpen = false;

function toggleAiChat() {
  aiChatOpen = !aiChatOpen;
  var win = document.getElementById('aiChatWindow');
  var fab = document.getElementById('aiFab');
  var icon = document.getElementById('aiFabIcon');
  if (aiChatOpen) {
    win.classList.add('open');
    fab.classList.add('open');
    icon.className = 'fas fa-times ai-fab-icon';
    document.getElementById('aiChatInput').focus();
  } else {
    win.classList.remove('open');
    fab.classList.remove('open');
    icon.className = 'fas fa-robot ai-fab-icon';
  }
}

function sendAiMessage(e) {
  if (e) e.preventDefault();
  var input = document.getElementById('aiChatInput');
  var msg = input.value.trim();
  if (!msg) return;
  input.value = '';
  appendUserMsg(msg);
  showLoading();

  fetch(AI_API, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({action:'chat', message: msg})
  })
  .then(r => r.json())
  .then(data => {
    hideLoading();
    if (data.success) {
      appendBotMsg(data.reply, data.properties || null);
    } else {
      appendBotMsg('Sorry, something went wrong. Please try again! 😅');
    }
  })
  .catch(err => {
    hideLoading();
    appendBotMsg('Connection error. Please check your internet and try again. 🔌');
  });
}

function sendAiSuggestion(text) {
  document.getElementById('aiChatInput').value = text;
  sendAiMessage(null);
}

function aiQuickAction(type) {
  var msgs = {
    'recommend': 'Show me best property recommendations',
    'budget': 'Show me affordable properties under 50 Lakh',
    'pg': 'Best PG options with food and WiFi',
    'loan': 'What is the EMI for 50 Lakh home loan?'
  };
  sendAiSuggestion(msgs[type] || 'Help');
}

function appendUserMsg(text) {
  var body = document.getElementById('aiChatBody');
  var div = document.createElement('div');
  div.className = 'ai-msg ai-msg-user';
  div.innerHTML = '<div class="ai-msg-avatar"><i class="fas fa-user"></i></div>' +
    '<div class="ai-msg-bubble">' + escHtml(text) + '</div>';
  body.appendChild(div);
  scrollAiChat();
}

function appendBotMsg(text, properties) {
  var body = document.getElementById('aiChatBody');
  var div = document.createElement('div');
  div.className = 'ai-msg ai-msg-bot';
  var html = '<div class="ai-msg-avatar"><i class="fas fa-robot"></i></div>' +
    '<div class="ai-msg-bubble">' + formatAiText(text);

  // Add property cards if available
  if (properties && properties.length > 0) {
    html += '<div style="margin-top:10px">';
    var shown = Math.min(properties.length, 3);
    for (var i = 0; i < shown; i++) {
      var p = properties[i];
      html += '<a href="' + '<?= SITE_URL ?>/property-detail.php?id=' + p.id + '" class="text-decoration-none" target="_blank">' +
        '<div class="ai-prop-card">' +
        '<img src="' + escHtml(p.image_url) + '" alt="' + escHtml(p.title) + '">' +
        '<div class="ai-prop-card-body">' +
        '<div class="d-flex justify-content-between align-items-center">' +
        '<div class="ai-prop-card-title">' + escHtml(p.title) + '</div>' +
        '<span class="ai-prop-match">' + p.match_score + '% match</span>' +
        '</div>' +
        '<div class="ai-prop-card-loc"><i class="fas fa-map-marker-alt me-1"></i>' + escHtml(p.location) + ', ' + escHtml(p.city) + '</div>' +
        '<div class="ai-prop-card-price">' + escHtml(p.price_fmt) + '</div>' +
        '</div></div></a>';
    }
    if (properties.length > 3) {
      html += '<div style="text-align:center;margin-top:6px">' +
        '<a href="<?= SITE_URL ?>/properties.php" class="ai-suggestions" style="display:inline">' +
        '<button onclick="event.stopPropagation()">View all ' + properties.length + ' matches →</button></a></div>';
    }
    html += '</div>';
  }

  html += '</div>';
  div.innerHTML = html;
  body.appendChild(div);
  scrollAiChat();
}

function showLoading() {
  var body = document.getElementById('aiChatBody');
  var div = document.createElement('div');
  div.className = 'ai-msg ai-msg-bot ai-loading-msg';
  div.innerHTML = '<div class="ai-msg-avatar"><i class="fas fa-robot"></i></div>' +
    '<div class="ai-loading"><div class="ai-loading-dot"></div><div class="ai-loading-dot"></div><div class="ai-loading-dot"></div></div>';
  body.appendChild(div);
  scrollAiChat();
}

function hideLoading() {
  var msgs = document.querySelectorAll('.ai-loading-msg');
  msgs.forEach(function(m) { m.remove(); });
}

function clearAiChat() {
  var body = document.getElementById('aiChatBody');
  body.innerHTML = '';
  appendBotMsg("Chat cleared! 🧹 How can I help you find your perfect property?");
}

function scrollAiChat() {
  var body = document.getElementById('aiChatBody');
  setTimeout(function() { body.scrollTop = body.scrollHeight; }, 60);
}

function escHtml(s) {
  if (!s) return '';
  var d = document.createElement('div');
  d.appendChild(document.createTextNode(s));
  return d.innerHTML;
}

function formatAiText(text) {
  if (!text) return '';
  // Bold
  text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  // Line breaks
  text = text.replace(/\n/g, '<br>');
  return text;
}

// Auto-show hint after 3 seconds if not opened
setTimeout(function() {
  if (!aiChatOpen) {
    var fab = document.getElementById('aiFab');
    if (fab) fab.style.animation = 'aiFabBounce 1s ease 2';
  }
}, 3000);
</script>
<style>
@keyframes aiFabBounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
</style>
