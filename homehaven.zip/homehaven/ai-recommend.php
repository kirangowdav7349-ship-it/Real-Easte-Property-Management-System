<?php
$pageTitle = 'AI Property Recommendations';
require_once 'includes/header.php';

$cities = $conn->query("SELECT DISTINCT city FROM properties WHERE status='available' ORDER BY city");
$cityList = [];
while ($c = $cities->fetch_assoc()) $cityList[] = $c['city'];

$states = $conn->query("SELECT DISTINCT state FROM properties WHERE status='available' AND state IS NOT NULL AND state != '' ORDER BY state");
$stateList = [];
while ($s = $states->fetch_assoc()) $stateList[] = $s['state'];
?>

<style>
/* ── AI Recommendation Page Styles ── */
.ai-hero{background:linear-gradient(135deg,#1a3c5e 0%,#0d2438 50%,#2d6a4f 100%);color:white;padding:80px 0 60px;position:relative;overflow:hidden}
.ai-hero::before{content:'';position:absolute;top:-50%;left:-30%;width:100%;height:200%;background:radial-gradient(circle,rgba(255,107,53,.12) 0%,transparent 60%);animation:aiOrb 12s ease-in-out infinite alternate}
.ai-hero::after{content:'';position:absolute;bottom:-50%;right:-20%;width:80%;height:200%;background:radial-gradient(circle,rgba(45,106,79,.15) 0%,transparent 60%);animation:aiOrb 15s ease-in-out infinite alternate-reverse}
@keyframes aiOrb{0%{transform:translate(0,0)}100%{transform:translate(30px,-20px)}}
.ai-hero-title{font-size:2.8rem;font-weight:800;letter-spacing:-1px;line-height:1.15;position:relative;z-index:1}
.ai-hero-sub{font-size:1.05rem;opacity:.85;position:relative;z-index:1}
.ai-glow{display:inline-block;background:linear-gradient(90deg,#FF6B35,#fbbf24,#FF6B35);background-size:200%;-webkit-background-clip:text;-webkit-text-fill-color:transparent;animation:aiGlow 3s linear infinite}
@keyframes aiGlow{0%{background-position:200%}100%{background-position:-200%}}

/* AI Wizard */
.ai-wizard{background:var(--card-bg);border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,.12);margin-top:-40px;position:relative;z-index:10;border:1px solid var(--border);overflow:hidden}
.ai-wizard-header{background:linear-gradient(135deg,rgba(26,60,94,.06),rgba(45,106,79,.06));padding:28px 32px 20px;border-bottom:1px solid var(--border)}
.ai-step-indicators{display:flex;gap:8px;margin-top:12px}
.ai-step-ind{width:100%;height:4px;border-radius:4px;background:var(--border);transition:.4s}
.ai-step-ind.active{background:linear-gradient(90deg,#FF6B35,#2d6a4f)}
.ai-step-ind.done{background:#4ade80}
.ai-wizard-body{padding:32px}
.ai-wizard-footer{padding:20px 32px;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center}

/* Form elements */
.ai-pref-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}
.ai-pref-card{border:2px solid var(--border);border-radius:14px;padding:18px 14px;text-align:center;cursor:pointer;transition:.3s;background:var(--card-bg)}
.ai-pref-card:hover{border-color:#FF6B35;transform:translateY(-3px);box-shadow:0 8px 22px rgba(255,107,53,.12)}
.ai-pref-card.selected{border-color:#FF6B35;background:rgba(255,107,53,.06);box-shadow:0 4px 18px rgba(255,107,53,.15)}
.ai-pref-card .emoji{font-size:2rem;display:block;margin-bottom:8px}
.ai-pref-card .label{font-weight:700;font-size:.82rem;color:var(--text-main)}
.ai-pref-card .desc{font-size:.7rem;color:var(--text-muted);margin-top:3px}

/* Budget slider */
.ai-budget-display{font-size:1.6rem;font-weight:800;color:#FF6B35;text-align:center;margin:16px 0}
.ai-range-track{width:100%;height:6px;border-radius:6px;-webkit-appearance:none;background:linear-gradient(90deg,#FF6B35,#2d6a4f);outline:none;margin:8px 0}
.ai-range-track::-webkit-slider-thumb{-webkit-appearance:none;width:22px;height:22px;border-radius:50%;background:white;border:3px solid #FF6B35;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.15)}

/* Amenity chips */
.ai-amenity-chip{display:inline-flex;align-items:center;gap:5px;padding:8px 16px;border-radius:24px;border:2px solid var(--border);font-size:.78rem;font-weight:600;cursor:pointer;transition:.2s;margin:4px;background:var(--card-bg)}
.ai-amenity-chip:hover{border-color:#FF6B35}
.ai-amenity-chip.on{background:#FF6B35;color:white;border-color:#FF6B35}

/* Results section */
.ai-results-section{padding:40px 0}
.ai-insight-card{background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:white;border-radius:16px;padding:24px;margin-bottom:28px;position:relative;overflow:hidden}
.ai-insight-card::before{content:'🤖';position:absolute;top:-10px;right:-10px;font-size:5rem;opacity:.12}
.ai-result-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:20px}
.ai-result-card{background:var(--card-bg);border-radius:16px;border:1px solid var(--border);overflow:hidden;box-shadow:var(--card-shadow);transition:.3s;position:relative}
.ai-result-card:hover{transform:translateY(-6px);box-shadow:0 18px 50px rgba(26,60,94,.18)}
.ai-result-card img{width:100%;height:200px;object-fit:cover;transition:transform .4s}
.ai-result-card:hover img{transform:scale(1.06)}
.ai-result-body{padding:18px}
.ai-match-badge{position:absolute;top:14px;right:14px;background:linear-gradient(135deg,#4ade80,#22c55e);color:white;padding:4px 12px;border-radius:20px;font-size:.72rem;font-weight:700;box-shadow:0 4px 12px rgba(34,197,94,.4)}
.ai-featured-badge{position:absolute;top:14px;left:14px;background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#1e2b3c;padding:4px 12px;border-radius:20px;font-size:.72rem;font-weight:700}

/* Stats */
.ai-stat-mini{display:flex;gap:14px;padding-top:10px;border-top:1px solid var(--border);margin-top:10px}
.ai-stat-mini span{font-size:.76rem;color:var(--text-muted);display:flex;align-items:center;gap:4px}
.ai-stat-mini i{color:#FF6B35;font-size:.7rem}

/* Loading skeleton */
.ai-skeleton{background:linear-gradient(90deg,var(--border) 25%,var(--card-bg) 50%,var(--border) 75%);background-size:200%;animation:aiShimmer 1.5s infinite;border-radius:10px}
@keyframes aiShimmer{0%{background-position:200%}100%{background-position:-200%}}

/* Responsive */
@media(max-width:768px){
  .ai-hero-title{font-size:1.8rem}
  .ai-pref-grid{grid-template-columns:repeat(2,1fr)}
  .ai-result-grid{grid-template-columns:1fr}
  .ai-wizard-body{padding:20px}
}
</style>

<!-- ════════════════ AI HERO ════════════════ -->
<section class="ai-hero">
  <div class="container text-center">
    <div class="ai-hero-title">🤖 AI Property <span class="ai-glow">Recommendation</span> Agent</div>
    <p class="ai-hero-sub mt-3">Tell us your preferences — Our AI finds the <strong>perfect properties</strong> for you</p>
    <div class="d-flex justify-content-center gap-3 mt-4 flex-wrap">
      <div class="d-flex align-items-center gap-2 px-3 py-2 rounded-pill" style="background:rgba(255,255,255,.1)">
        <i class="fas fa-brain"></i> Smart Matching
      </div>
      <div class="d-flex align-items-center gap-2 px-3 py-2 rounded-pill" style="background:rgba(255,255,255,.1)">
        <i class="fas fa-chart-line"></i> Market Insights
      </div>
      <div class="d-flex align-items-center gap-2 px-3 py-2 rounded-pill" style="background:rgba(255,255,255,.1)">
        <i class="fas fa-magic"></i> Lifestyle Match
      </div>
    </div>
  </div>
</section>

<!-- ════════════════ AI WIZARD ════════════════ -->
<section class="py-4">
  <div class="container">
    <div class="ai-wizard">

      <div class="ai-wizard-header">
        <h5 class="fw-bold mb-1"><i class="fas fa-sliders-h text-accent me-2"></i>Tell Us Your Preferences</h5>
        <p class="text-muted mb-0" style="font-size:.84rem">Answer a few questions and our AI will find the best matches</p>
        <div class="ai-step-indicators">
          <div class="ai-step-ind active" id="step1Ind"></div>
          <div class="ai-step-ind" id="step2Ind"></div>
          <div class="ai-step-ind" id="step3Ind"></div>
          <div class="ai-step-ind" id="step4Ind"></div>
        </div>
      </div>

      <div class="ai-wizard-body">
        <!-- Step 1: State & Budget (PRIMARY) -->
        <div class="ai-step" id="step1">
          <h6 class="fw-bold mb-3">📍 Select Your State & Budget</h6>
          <p class="text-muted" style="font-size:.84rem">Tell us where you're looking and your budget — we'll find the best properties for you</p>
          <div class="row g-4">
            <div class="col-md-6">
              <label class="form-label fw-bold"><i class="fas fa-map-marked-alt text-accent me-1"></i>State</label>
              <select class="form-select form-select-lg" id="aiState">
                <option value="">All States</option>
                <?php foreach($stateList as $s): ?>
                <option value="<?= $s ?>"><?= $s ?></option>
                <?php endforeach; ?>
              </select>
              <label class="form-label fw-bold mt-3"><i class="fas fa-city text-accent me-1"></i>City</label>
              <select class="form-select" id="aiCity">
                <option value="">All Cities</option>
                <?php foreach($cityList as $c): ?>
                <option value="<?= $c ?>"><?= $c ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-bold"><i class="fas fa-wallet text-accent me-1"></i>Max Budget</label>
              <div class="ai-budget-display" id="budgetDisplay">₹50 Lakh</div>
              <input type="range" class="ai-range-track w-100" id="budgetSlider" min="500000" max="100000000" step="500000" value="5000000" oninput="updateBudget(this.value)">
              <div class="d-flex justify-content-between">
                <small class="text-muted">₹5 L</small>
                <small class="text-muted">₹10 Cr</small>
              </div>
            </div>
          </div>
        </div>

        <!-- Step 2: Purpose -->
        <div class="ai-step" id="step2" style="display:none">
          <h6 class="fw-bold mb-3">🎯 What's your purpose?</h6>
          <div class="ai-pref-grid">
            <div class="ai-pref-card" data-value="buy" onclick="selectPref(this,'listing')">
              <span class="emoji">🏠</span>
              <div class="label">Buy Property</div>
              <div class="desc">Own your dream home</div>
            </div>
            <div class="ai-pref-card" data-value="rent" onclick="selectPref(this,'listing')">
              <span class="emoji">🔑</span>
              <div class="label">Rent</div>
              <div class="desc">Find rental homes</div>
            </div>
            <div class="ai-pref-card" data-value="pg" onclick="selectPref(this,'listing')">
              <span class="emoji">🛏️</span>
              <div class="label">PG / Co-Living</div>
              <div class="desc">Shared accommodation</div>
            </div>
            <div class="ai-pref-card" data-value="commercial" onclick="selectPref(this,'listing')">
              <span class="emoji">🏢</span>
              <div class="label">Commercial</div>
              <div class="desc">Office & shop space</div>
            </div>
            <div class="ai-pref-card" data-value="investment" onclick="selectPref(this,'listing')">
              <span class="emoji">📈</span>
              <div class="label">Investment</div>
              <div class="desc">Best ROI properties</div>
            </div>
          </div>
          <label class="form-label fw-bold mt-4"><i class="fas fa-building text-accent me-1"></i>Property Type</label>
          <select class="form-select" id="aiPropType">
            <option value="">All Types</option>
            <option value="apartment">Apartment</option>
            <option value="home">House</option>
            <option value="villa">Villa</option>
            <option value="site">Plot / Land</option>
            <option value="commercial">Commercial</option>
          </select>
        </div>

        <!-- Step 3: Configuration -->
        <div class="ai-step" id="step3" style="display:none">
          <h6 class="fw-bold mb-3">🛏️ Configuration & Lifestyle</h6>
          <div class="row g-4">
            <div class="col-md-6">
              <label class="form-label fw-bold">Bedrooms</label>
              <div class="ai-pref-grid" style="grid-template-columns:repeat(5,1fr)">
                <div class="ai-pref-card" data-value="0" onclick="selectPref(this,'bedrooms')"><span class="emoji" style="font-size:1.3rem">🏠</span><div class="label">Any</div></div>
                <div class="ai-pref-card" data-value="1" onclick="selectPref(this,'bedrooms')"><span class="emoji" style="font-size:1.3rem">1️⃣</span><div class="label">1 BHK</div></div>
                <div class="ai-pref-card" data-value="2" onclick="selectPref(this,'bedrooms')"><span class="emoji" style="font-size:1.3rem">2️⃣</span><div class="label">2 BHK</div></div>
                <div class="ai-pref-card" data-value="3" onclick="selectPref(this,'bedrooms')"><span class="emoji" style="font-size:1.3rem">3️⃣</span><div class="label">3 BHK</div></div>
                <div class="ai-pref-card" data-value="4" onclick="selectPref(this,'bedrooms')"><span class="emoji" style="font-size:1.3rem">4️⃣</span><div class="label">4+ BHK</div></div>
              </div>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-bold">Lifestyle</label>
              <div class="ai-pref-grid" style="grid-template-columns:repeat(2,1fr)">
                <div class="ai-pref-card" data-value="family" onclick="selectPref(this,'lifestyle')"><span class="emoji" style="font-size:1.3rem">👨‍👩‍👧</span><div class="label">Family</div></div>
                <div class="ai-pref-card" data-value="bachelor" onclick="selectPref(this,'lifestyle')"><span class="emoji" style="font-size:1.3rem">🧑</span><div class="label">Bachelor</div></div>
                <div class="ai-pref-card" data-value="luxury" onclick="selectPref(this,'lifestyle')"><span class="emoji" style="font-size:1.3rem">✨</span><div class="label">Luxury</div></div>
                <div class="ai-pref-card" data-value="student" onclick="selectPref(this,'lifestyle')"><span class="emoji" style="font-size:1.3rem">🎓</span><div class="label">Student</div></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Step 4: Amenities -->
        <div class="ai-step" id="step4" style="display:none">
          <h6 class="fw-bold mb-3">✅ Must-Have Amenities</h6>
          <p class="text-muted" style="font-size:.82rem">Select the amenities that matter most to you</p>
          <div class="d-flex flex-wrap">
            <?php
            $amenities = [
              ['🏊','Pool'],['🏋️','Gym'],['🅿️','Parking'],['🌿','Garden'],
              ['🔒','Security'],['📶','WiFi'],['🍽️','Food'],['❄️','AC'],
              ['🛗','Lift'],['⚡','Power Backup'],['🧹','Housekeeping'],['📹','CCTV'],
              ['🏘️','Clubhouse'],['🧖','Spa'],['🎾','Tennis'],['🏃','Jogging Track']
            ];
            foreach($amenities as $a):
            ?>
            <span class="ai-amenity-chip" onclick="toggleAmenity(this)" data-amenity="<?= $a[1] ?>">
              <?= $a[0] ?> <?= $a[1] ?>
            </span>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <div class="ai-wizard-footer">
        <button class="btn btn-outline-secondary rounded-pill px-4" id="prevBtn" onclick="prevStep()" style="display:none">
          <i class="fas fa-chevron-left me-1"></i> Back
        </button>
        <div></div>
        <button class="btn btn-accent rounded-pill px-5 fw-bold" id="nextBtn" onclick="nextStep()">
          Next <i class="fas fa-chevron-right ms-1"></i>
        </button>
      </div>

    </div>
  </div>
</section>

<!-- ════════════════ AI RESULTS ════════════════ -->
<section class="ai-results-section" id="aiResultsSection" style="display:none">
  <div class="container">

    <!-- Insight -->
    <div class="ai-insight-card" id="aiInsight">
      <div class="d-flex align-items-center gap-3 mb-2">
        <div style="width:44px;height:44px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:1.2rem">🤖</div>
        <div>
          <div class="fw-bold">AI Insight</div>
          <div id="aiInsightText" style="font-size:.88rem;opacity:.9">Analyzing your preferences...</div>
        </div>
      </div>
    </div>

    <!-- Filters summary -->
    <div class="d-flex flex-wrap gap-2 mb-4" id="aiFilterSummary"></div>

    <!-- Results Grid -->
    <div class="ai-result-grid" id="aiResultGrid">
      <!-- Populated by JS -->
    </div>

    <!-- No results -->
    <div id="aiNoResults" style="display:none" class="text-center py-5">
      <div style="font-size:4rem;margin-bottom:16px">😔</div>
      <h4 class="fw-bold">No exact matches found</h4>
      <p class="text-muted">Try adjusting your preferences or expand your budget range</p>
      <button class="btn btn-accent rounded-pill px-5 mt-2" onclick="resetWizard()">
        <i class="fas fa-redo me-2"></i>Try Again
      </button>
    </div>

    <!-- Actions -->
    <div class="text-center mt-4" id="aiResultActions" style="display:none">
      <button class="btn btn-primary-custom px-5 me-2" onclick="resetWizard()">
        <i class="fas fa-redo me-2"></i>Refine Search
      </button>
      <a href="properties.php" class="btn btn-outline-primary px-5 rounded-pill">
        <i class="fas fa-th me-2"></i>Browse All Properties
      </a>
    </div>

  </div>
</section>

<script>
var currentStep = 1;
var totalSteps = 4;
var aiPrefs = {listing:'',budget_max:5000000,city:'',state:'',property_type:'',bedrooms:0,lifestyle:'',amenities:[]};

function selectPref(el, type) {
  // Deselect siblings
  el.parentElement.querySelectorAll('.ai-pref-card').forEach(function(c) { c.classList.remove('selected'); });
  el.classList.add('selected');
  aiPrefs[type] = el.dataset.value;

  // Handle investment as listing=buy + lifestyle=investment
  if (type === 'listing' && el.dataset.value === 'investment') {
    aiPrefs.listing = 'buy';
    aiPrefs.lifestyle = 'investment';
  }
}

function toggleAmenity(el) {
  el.classList.toggle('on');
  var a = el.dataset.amenity;
  var idx = aiPrefs.amenities.indexOf(a);
  if (idx > -1) aiPrefs.amenities.splice(idx, 1);
  else aiPrefs.amenities.push(a);
}

function updateBudget(val) {
  var v = parseInt(val);
  var display = '';
  if (v >= 10000000) display = '₹' + (v / 10000000).toFixed(1) + ' Cr';
  else if (v >= 100000) display = '₹' + (v / 100000).toFixed(0) + ' Lakh';
  else display = '₹' + v.toLocaleString('en-IN');
  document.getElementById('budgetDisplay').textContent = display;
  aiPrefs.budget_max = v;
}

function nextStep() {
  if (currentStep < totalSteps) {
    document.getElementById('step' + currentStep).style.display = 'none';
    currentStep++;
    document.getElementById('step' + currentStep).style.display = 'block';
    updateStepUI();
  } else {
    // Gather data from dropdowns
    aiPrefs.city = document.getElementById('aiCity').value;
    aiPrefs.state = document.getElementById('aiState').value;
    aiPrefs.property_type = document.getElementById('aiPropType').value;
    runAiRecommendation();
  }
}

function prevStep() {
  if (currentStep > 1) {
    document.getElementById('step' + currentStep).style.display = 'none';
    currentStep--;
    document.getElementById('step' + currentStep).style.display = 'block';
    updateStepUI();
  }
}

function updateStepUI() {
  document.getElementById('prevBtn').style.display = currentStep > 1 ? 'inline-block' : 'none';
  var nextBtn = document.getElementById('nextBtn');
  if (currentStep === totalSteps) {
    nextBtn.innerHTML = '<i class="fas fa-magic me-2"></i>Get AI Recommendations';
    nextBtn.classList.add('btn-lg');
  } else {
    nextBtn.innerHTML = 'Next <i class="fas fa-chevron-right ms-1"></i>';
    nextBtn.classList.remove('btn-lg');
  }
  for (var i = 1; i <= totalSteps; i++) {
    var ind = document.getElementById('step' + i + 'Ind');
    ind.classList.remove('active', 'done');
    if (i < currentStep) ind.classList.add('done');
    if (i === currentStep) ind.classList.add('active');
  }
}

function runAiRecommendation() {
  // Show results section with loading
  document.getElementById('aiResultsSection').style.display = 'block';
  document.getElementById('aiResultGrid').innerHTML = '<div class="col-12"><div class="ai-skeleton" style="height:200px;margin-bottom:16px"></div><div class="ai-skeleton" style="height:200px;margin-bottom:16px"></div></div>';
  document.getElementById('aiNoResults').style.display = 'none';
  document.getElementById('aiResultActions').style.display = 'none';
  document.getElementById('aiInsightText').textContent = 'Analyzing your preferences...';

  // Scroll to results
  document.getElementById('aiResultsSection').scrollIntoView({behavior:'smooth',block:'start'});

  // Change button
  var nextBtn = document.getElementById('nextBtn');
  nextBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Finding Matches...';
  nextBtn.disabled = true;

  fetch('<?= SITE_URL ?>/api/ai-recommend.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({
      action: 'recommend',
      listing_type: aiPrefs.listing,
      budget_max: aiPrefs.budget_max,
      city: aiPrefs.city,
      state: aiPrefs.state,
      property_type: aiPrefs.property_type,
      bedrooms: aiPrefs.bedrooms,
      lifestyle: aiPrefs.lifestyle,
      amenities: aiPrefs.amenities
    })
  })
  .then(function(r) { return r.json(); })
  .then(function(data) {
    nextBtn.innerHTML = '<i class="fas fa-redo me-2"></i>Refine & Search Again';
    nextBtn.disabled = false;
    nextBtn.onclick = resetWizard;

    if (data.success && data.count > 0) {
      renderResults(data);
    } else {
      document.getElementById('aiResultGrid').innerHTML = '';
      document.getElementById('aiNoResults').style.display = 'block';
    }
  })
  .catch(function(err) {
    nextBtn.innerHTML = '<i class="fas fa-redo me-2"></i>Retry';
    nextBtn.disabled = false;
    document.getElementById('aiResultGrid').innerHTML = '<div class="text-center py-4 text-danger"><i class="fas fa-exclamation-circle fa-2x mb-2"></i><p>Connection error. Please try again.</p></div>';
  });
}

function renderResults(data) {
  // Insight
  document.getElementById('aiInsightText').textContent = data.insight;

  // Filter summary
  var filterHtml = '';
  var f = data.filters;
  if (f.listing !== 'All') filterHtml += '<span class="badge rounded-pill bg-primary">' + f.listing + '</span>';
  if (f.state && f.state !== 'All States') filterHtml += '<span class="badge rounded-pill bg-success">' + f.state + '</span>';
  if (f.city !== 'All Cities') filterHtml += '<span class="badge rounded-pill bg-success">' + f.city + '</span>';
  if (f.type !== 'All Types') filterHtml += '<span class="badge rounded-pill bg-info">' + f.type + '</span>';
  filterHtml += '<span class="badge rounded-pill bg-warning text-dark">' + f.budget + '</span>';
  if (f.bedrooms !== 'Any') filterHtml += '<span class="badge rounded-pill bg-secondary">' + f.bedrooms + '+ BHK</span>';
  if (f.lifestyle !== 'General') filterHtml += '<span class="badge rounded-pill bg-danger">' + f.lifestyle + '</span>';
  document.getElementById('aiFilterSummary').innerHTML = '<strong class="me-2" style="font-size:.82rem">Filters:</strong>' + filterHtml;

  // Property cards
  var html = '';
  data.properties.forEach(function(p, i) {
    var delay = i * 100;
    html += '<div style="animation:fadeIn .5s ease ' + delay + 'ms both">' +
      '<a href="property-detail.php?id=' + p.id + '" class="text-decoration-none">' +
      '<div class="ai-result-card">' +
      '<div style="overflow:hidden;height:200px;position:relative">' +
      '<img src="' + escH(p.image_url) + '" alt="' + escH(p.title) + '">' +
      '<span class="ai-match-badge"><i class="fas fa-brain me-1"></i>' + p.match_score + '% Match</span>';

    if (p.featured) {
      html += '<span class="ai-featured-badge">⭐ Featured</span>';
    }
    html += '</div>' +
      '<div class="ai-result-body">' +
      '<div class="d-flex justify-content-between align-items-start mb-1">' +
      '<h6 class="fw-bold mb-0" style="font-size:.92rem">' + escH(p.title) + '</h6>' +
      '<span class="badge rounded-pill" style="background:' + getTypeColor(p.listing_type) + ';font-size:.65rem;flex-shrink:0">' + p.listing_type.toUpperCase() + '</span>' +
      '</div>' +
      '<p class="mb-2" style="font-size:.8rem;color:var(--text-muted)"><i class="fas fa-map-marker-alt me-1 text-danger"></i>' + escH(p.location) + ', ' + escH(p.city) + '</p>' +
      '<div class="d-flex justify-content-between align-items-center">' +
      '<div class="property-price" style="font-size:1.15rem">' + escH(p.price_fmt) + ((['rent','pg'].indexOf(p.listing_type) > -1) ? '<span style="font-size:.75rem;color:var(--text-muted)">/mo</span>' : '') + '</div>' +
      '<span class="btn btn-accent btn-sm px-3 rounded-pill" style="font-size:.75rem">View Details</span>' +
      '</div>' +
      '<div class="ai-stat-mini">';

    if (p.bedrooms > 0) html += '<span><i class="fas fa-bed"></i>' + p.bedrooms + ' Bed</span>';
    if (p.bathrooms > 0) html += '<span><i class="fas fa-bath"></i>' + p.bathrooms + ' Bath</span>';
    if (p.area) html += '<span><i class="fas fa-ruler-combined"></i>' + escH(p.area) + '</span>';
    html += '<span><i class="fas fa-home"></i>' + ucfirst(p.type) + '</span>';

    html += '</div></div></div></a></div>';
  });

  document.getElementById('aiResultGrid').innerHTML = html;
  document.getElementById('aiResultActions').style.display = 'block';
}

function resetWizard() {
  currentStep = 1;
  for (var i = 1; i <= totalSteps; i++) {
    document.getElementById('step' + i).style.display = i === 1 ? 'block' : 'none';
    var cards = document.getElementById('step' + i).querySelectorAll('.ai-pref-card');
    cards.forEach(function(c) { c.classList.remove('selected'); });
  }
  document.querySelectorAll('.ai-amenity-chip').forEach(function(c) { c.classList.remove('on'); });
  aiPrefs = {listing:'',budget_max:5000000,city:'',state:'',property_type:'',bedrooms:0,lifestyle:'',amenities:[]};
  document.getElementById('budgetSlider').value = 5000000;
  updateBudget(5000000);
  document.getElementById('aiState').value = '';
  document.getElementById('aiCity').value = '';
  document.getElementById('aiPropType').value = '';
  updateStepUI();
  document.getElementById('aiResultsSection').style.display = 'none';
  var nextBtn = document.getElementById('nextBtn');
  nextBtn.innerHTML = 'Next <i class="fas fa-chevron-right ms-1"></i>';
  nextBtn.disabled = false;
  nextBtn.onclick = nextStep;
  window.scrollTo({top:0,behavior:'smooth'});
}

function getTypeColor(t) {
  var m = {buy:'#2d6a4f',rent:'#1a3c5e',pg:'#6f42c1',commercial:'#dc3545'};
  return m[t] || '#1a3c5e';
}

function escH(s) { if (!s) return ''; var d=document.createElement('div'); d.textContent=s; return d.innerHTML; }
function ucfirst(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }
</script>

<?php require_once 'includes/footer.php'; ?>
