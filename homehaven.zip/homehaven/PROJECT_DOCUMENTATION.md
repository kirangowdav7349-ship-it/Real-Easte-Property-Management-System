# PropNexus — Real Estate Property Management System
## Final Year BCA Project Documentation

---

## 📋 Table of Contents

1. [Introduction](#1-introduction)
2. [Project Overview](#2-project-overview)
3. [Objectives](#3-objectives)
4. [Scope of the Project](#4-scope-of-the-project)
5. [System Requirements](#5-system-requirements)
6. [Technology Stack](#6-technology-stack)
7. [System Architecture](#7-system-architecture)
8. [Database Design](#8-database-design)
9. [Module Description](#9-module-description)
10. [User Interface Design](#10-user-interface-design)
11. [Implementation Details](#11-implementation-details)
12. [Testing](#12-testing)
13. [Screenshots](#13-screenshots)
14. [Installation & Setup Guide](#14-installation--setup-guide)
15. [Future Enhancements](#15-future-enhancements)
16. [Conclusion](#16-conclusion)
17. [References](#17-references)

---

## 1. Introduction

### 1.1 Background

The real estate industry in India is one of the most rapidly growing sectors, contributing significantly to the country's GDP. With the increasing demand for properties — residential, commercial, and rental — there is a pressing need for a digital platform that streamlines property management, client interaction, financial tracking, and related services such as home loans and maintenance.

Traditionally, property management involves manual processes such as paper-based record keeping, in-person visits for property viewing, manual rent collection, and offline loan application processes. These methods are not only time-consuming but also prone to errors and inefficiencies.

### 1.2 Problem Statement

The current real estate management process lacks a centralized digital system that can:
- Efficiently manage property listings across multiple cities
- Allow clients to browse, compare, and shortlist properties online
- Provide an integrated loan application and tracking system
- Handle rent payment tracking and maintenance requests
- Offer AI-powered property recommendations based on user preferences
- Generate reports and analytics for business decision-making

### 1.3 Proposed Solution

**PropNexus** is a comprehensive web-based Real Estate Property Management System that addresses all the above challenges. It provides separate interfaces for administrators and clients, offering a complete end-to-end solution for property management, from listing to loan processing.

---

## 2. Project Overview

| Attribute | Details |
|-----------|---------|
| **Project Title** | PropNexus — Real Estate Property Management System |
| **Project Type** | Web Application |
| **Academic Level** | Final Year BCA Project |
| **Frontend** | HTML5, CSS3, JavaScript, Bootstrap 5 |
| **Backend** | PHP 8.x |
| **Database** | MySQL 8.x |
| **Server** | Apache (XAMPP) |
| **Architecture** | Client-Server (MVC-based) |
| **Development Tool** | VS Code / Any Text Editor |
| **Browser Support** | Chrome, Firefox, Edge, Safari |

---

## 3. Objectives

### 3.1 Primary Objectives
1. To develop a web-based property management system that allows administrators to manage property listings, clients, finances, and operations from a centralized dashboard.
2. To provide clients with a user-friendly interface to browse properties, apply for loans, track rent payments, and submit maintenance requests.
3. To implement an AI-powered property recommendation engine that suggests properties based on user lifestyle preferences.

### 3.2 Secondary Objectives
1. To implement a step-by-step loan approval workflow with document upload and status tracking.
2. To provide an EMI calculator and bank loan comparison tool.
3. To generate analytics and reports for business insights.
4. To implement a property comparison feature for informed decision-making.
5. To provide a news and guides section for real estate education.
6. To implement legal advisory tools for property transactions.

---

## 4. Scope of the Project

### 4.1 In Scope
- Property CRUD operations (Create, Read, Update, Delete)
- Multi-image gallery for each property
- Client registration, login, and profile management
- Admin dashboard with analytics and reports
- Property search with advanced filters (city, type, price range, bedrooms)
- Property comparison tool
- Wishlist functionality
- Rent payment tracking with receipt generation
- Maintenance request management
- Loan application with 5-step approval process
- Document upload and verification
- EMI calculator and bank comparison
- AI-powered property recommendations
- News & guides content management
- Pricing plans for property listing
- Legal advisory tools
- Dark mode support (Admin panel)
- Responsive design (Mobile, Tablet, Desktop)

### 4.2 Out of Scope
- Online payment gateway integration (Razorpay, PayPal)
- Real-time chat between admin and clients
- Property location on Google Maps
- SMS notification system
- Multi-language support

---

## 5. System Requirements

### 5.1 Hardware Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| Processor | Intel Core i3 / AMD Ryzen 3 | Intel Core i5 / AMD Ryzen 5 |
| RAM | 4 GB | 8 GB |
| Storage | 500 MB free space | 1 GB free space |
| Display | 1366 x 768 | 1920 x 1080 |
| Network | Internet connection | Broadband connection |

### 5.2 Software Requirements

| Software | Version | Purpose |
|----------|---------|---------|
| Operating System | Windows 10/11, macOS, Linux | Development & Deployment |
| XAMPP | 8.0+ | Apache + MySQL + PHP stack |
| PHP | 8.0+ | Server-side scripting |
| MySQL | 8.0+ | Database management |
| Apache | 2.4+ | Web server |
| Web Browser | Latest Chrome/Firefox/Edge | Client-side rendering |
| VS Code | Latest | Code editor (optional) |
| phpMyAdmin | 5.x | Database administration |

---

## 6. Technology Stack

### 6.1 Frontend Technologies

| Technology | Version | Usage |
|------------|---------|-------|
| **HTML5** | 5 | Page structure and semantic markup |
| **CSS3** | 3 | Styling, animations, responsive design |
| **JavaScript** | ES6+ | Client-side interactivity and AJAX |
| **Bootstrap** | 5.3.0 | Responsive grid, components, utilities |
| **Font Awesome** | 6.4.0 | Icon library |
| **Google Fonts** | Poppins, Inter | Typography |
| **Chart.js** | 4.x | Analytics charts and graphs |

### 6.2 Backend Technologies

| Technology | Version | Usage |
|------------|---------|-------|
| **PHP** | 8.0+ | Server-side logic, form handling, sessions |
| **MySQL** | 8.0+ | Relational database for data storage |
| **Apache** | 2.4+ | HTTP web server |

### 6.3 Key Libraries & CDNs
- Bootstrap 5.3.0 (CSS + JS Bundle)
- Font Awesome 6.4.0
- Google Fonts (Poppins)
- Chart.js (for admin analytics)

---

## 7. System Architecture

### 7.1 Architecture Diagram

```
┌──────────────────────────────────────────────────────────┐
│                     CLIENT BROWSER                        │
│          (HTML5 + CSS3 + JavaScript + Bootstrap)          │
└────────────────────────┬─────────────────────────────────┘
                         │ HTTP Request/Response
                         ▼
┌──────────────────────────────────────────────────────────┐
│                    APACHE WEB SERVER                      │
│                     (XAMPP / Port 80)                      │
└────────────────────────┬─────────────────────────────────┘
                         │
                         ▼
┌──────────────────────────────────────────────────────────┐
│                    PHP APPLICATION                         │
│  ┌──────────┐  ┌──────────┐  ┌───────────┐               │
│  │ includes │  │  admin/  │  │  client/  │               │
│  │config.php│  │dashboard │  │ dashboard │               │
│  │header.php│  │properties│  │  profile  │               │
│  │footer.php│  │ finance  │  │   loans   │               │
│  └──────────┘  │analytics │  │maintenance│               │
│                │  loans   │  │   rent    │               │
│                └──────────┘  └───────────┘               │
└────────────────────────┬─────────────────────────────────┘
                         │ MySQLi Connection
                         ▼
┌──────────────────────────────────────────────────────────┐
│                   MySQL DATABASE                          │
│               Database: PropNexus_db                      │
│  ┌─────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐     │
│  │ admins  │ │ clients  │ │properties│ │enquiries │     │
│  │ plans   │ │ services │ │  images  │ │ payments │     │
│  │  loans  │ │loan_docs │ │maintenace│ │  alerts  │     │
│  │  news   │ │ wishlist │ │comparison│ │bookings  │     │
│  └─────────┘ └──────────┘ └──────────┘ └──────────┘     │
└──────────────────────────────────────────────────────────┘
```

### 7.2 Data Flow Diagram (Level 0)

```
                    ┌──────────┐
    Property Data   │          │  Analytics & Reports
   ─────────────►   │          │  ◄───────────────
    Client Mgmt     │ PropNexus│  Enquiry Responses
   ─────────────►   │  System  │  ◄───────────────
    Loan Review     │          │  Status Updates
   ─────────────►   │          │  ◄───────────────
                    └──────────┘
                     ▲        ▲
                     │        │
              ┌──────┘        └──────┐
              │                      │
         ┌────┴────┐            ┌────┴────┐
         │  ADMIN  │            │  CLIENT │
         │  Panel  │            │  Portal │
         └─────────┘            └─────────┘
```

### 7.3 Data Flow Diagram (Level 1)

```
┌───────────┐     ┌─────────────────┐     ┌───────────────┐
│           │     │   1.0 Property   │     │               │
│   Admin   │────►│   Management    │────►│   Database    │
│           │     └─────────────────┘     │               │
│           │     ┌─────────────────┐     │  properties   │
│           │────►│   2.0 Client    │────►│  clients      │
│           │     │   Management    │     │  enquiries    │
│           │     └─────────────────┘     │  rent_payments│
│           │     ┌─────────────────┐     │  maintenance  │
│           │────►│   3.0 Finance   │────►│  loan_apps    │
│           │     │   Management    │     │  loan_docs    │
│           │     └─────────────────┘     │  bookings     │
│           │     ┌─────────────────┐     │               │
│           │────►│   4.0 Loan      │────►│               │
│           │     │   Management    │     │               │
└───────────┘     └─────────────────┘     └───────────────┘

┌───────────┐     ┌─────────────────┐     ┌───────────────┐
│           │     │  5.0 Browse &   │     │               │
│  Client   │────►│  Search Props   │────►│   Database    │
│           │     └─────────────────┘     │               │
│           │     ┌─────────────────┐     │               │
│           │────►│  6.0 Apply for  │────►│               │
│           │     │     Loan        │     │               │
│           │     └─────────────────┘     │               │
│           │     ┌─────────────────┐     │               │
│           │────►│  7.0 Maintenance│────►│               │
│           │     │    Requests     │     │               │
│           │     └─────────────────┘     │               │
│           │     ┌─────────────────┐     │               │
│           │────►│  8.0 Rent       │────►│               │
│           │     │   Payments      │     │               │
└───────────┘     └─────────────────┘     └───────────────┘
```

---

## 8. Database Design

### 8.1 Entity-Relationship Diagram (ER Diagram)

```
┌──────────────┐     1:N     ┌──────────────┐     1:N     ┌──────────────┐
│    admins    │            │  properties  │            │property_images│
│──────────────│            │──────────────│            │──────────────│
│ id (PK)      │            │ id (PK)      │◄───────────│ id (PK)      │
│ name         │            │ title        │            │ property_id  │
│ email        │            │ description  │            │ image_url    │
│ password     │            │ type         │            │ image_type   │
│ created_at   │            │ listing_type │            │ is_primary   │
└──────────────┘            │ price        │            └──────────────┘
                            │ area         │
┌──────────────┐            │ bedrooms     │     N:1     ┌──────────────┐
│   clients    │            │ bathrooms    │            │  enquiries   │
│──────────────│            │ location     │◄───────────│──────────────│
│ id (PK)      │            │ city         │            │ id (PK)      │
│ name         │            │ state        │            │ property_id  │
│ email        │            │ pincode      │            │ name         │
│ phone        │            │ amenities    │            │ email        │
│ password     │            │ status       │            │ phone        │
│ avatar       │            │ created_at   │            │ message      │
│ bio          │            └──────┬───────┘            │ status       │
│ country      │                   │                     │ created_at   │
│ city_name    │                   │                     └──────────────┘
│ status       │                   │
│ created_at   │                   │
└──────┬───────┘                   │
       │                           │
       │ 1:N                       │ 1:N
       ▼                           ▼
┌──────────────┐            ┌──────────────┐
│loan_applicat │            │rent_payments │
│──────────────│            │──────────────│
│ id (PK)      │            │ id (PK)      │
│ client_id(FK)│            │ client_id(FK)│
│ full_name    │            │ property_id  │
│ phone        │            │ receipt_no   │
│ email        │            │ amount       │
│ bank_name    │            │ payment_month│
│ loan_amount  │            │ payment_date │
│ monthly_inc  │            │ payment_mode │
│ property_type│            │ txn_id       │
│ employment   │            │ status       │
│ current_step │            │ created_at   │
│ status       │            └──────────────┘
│ admin_remarks│
│ verified_at  │            ┌──────────────┐
│ approved_at  │            │ maintenance  │
│ created_at   │            │  _requests   │
└──────┬───────┘            │──────────────│
       │                    │ id (PK)      │
       │ 1:N                │ client_id(FK)│
       ▼                    │ property_id  │
┌──────────────┐            │ title        │
│loan_documents│            │ category     │
│──────────────│            │ description  │
│ id (PK)      │            │ priority     │
│ application  │            │ status       │
│  _id (FK)    │            │ assigned_to  │
│ doc_type     │            │ notes        │
│ file_name    │            │ created_at   │
│ file_path    │            └──────────────┘
│ status       │
│ remarks      │
│ uploaded_at  │
└──────────────┘
```

### 8.2 Table Descriptions

#### 8.2.1 admins
| Column | Type | Constraint | Description |
|--------|------|-----------|-------------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique admin ID |
| name | VARCHAR(100) | NOT NULL | Admin full name |
| email | VARCHAR(100) | UNIQUE, NOT NULL | Login email |
| password | VARCHAR(255) | NOT NULL | BCrypt hashed password |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Account creation date |

#### 8.2.2 clients
| Column | Type | Constraint | Description |
|--------|------|-----------|-------------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique client ID |
| name | VARCHAR(100) | NOT NULL | Client full name |
| email | VARCHAR(100) | UNIQUE, NOT NULL | Login email |
| phone | VARCHAR(15) | — | Contact number |
| password | VARCHAR(255) | NOT NULL | BCrypt hashed password |
| avatar | VARCHAR(500) | DEFAULT NULL | Profile picture URL |
| bio | TEXT | DEFAULT NULL | Short biography |
| country | VARCHAR(100) | DEFAULT 'India' | Country |
| city_name | VARCHAR(100) | DEFAULT NULL | City of residence |
| status | ENUM | DEFAULT 'active' | active / inactive |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Registration date |

#### 8.2.3 properties
| Column | Type | Constraint | Description |
|--------|------|-----------|-------------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique property ID |
| title | VARCHAR(200) | NOT NULL | Property title |
| description | TEXT | — | Detailed description |
| type | VARCHAR(50) | DEFAULT 'apartment' | apartment/villa/home/commercial/site |
| listing_type | VARCHAR(50) | DEFAULT 'rent' | rent/buy/commercial/pg |
| price | DECIMAL(15,2) | NOT NULL | Price in INR |
| area | VARCHAR(50) | — | Area in sqft |
| bedrooms | INT | DEFAULT 0 | Number of bedrooms |
| bathrooms | INT | DEFAULT 0 | Number of bathrooms |
| location | VARCHAR(200) | — | Locality name |
| city | VARCHAR(100) | — | City name |
| state | VARCHAR(100) | — | State name |
| pincode | VARCHAR(10) | — | Postal code |
| amenities | TEXT | — | Comma-separated amenities |
| status | ENUM | DEFAULT 'available' | available/sold/rented |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Listing date |

#### 8.2.4 loan_applications
| Column | Type | Constraint | Description |
|--------|------|-----------|-------------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique application ID |
| client_id | INT | FOREIGN KEY → clients(id) | Linked client |
| full_name | VARCHAR(100) | NOT NULL | Applicant name |
| phone | VARCHAR(15) | — | Contact number |
| email | VARCHAR(100) | — | Email address |
| bank_name | VARCHAR(100) | — | Selected bank |
| loan_amount | DECIMAL(15,2) | — | Requested amount |
| monthly_income | DECIMAL(15,2) | — | Applicant's income |
| property_type | VARCHAR(50) | — | Type of property |
| employment | VARCHAR(50) | — | Employment status |
| current_step | TINYINT | DEFAULT 1 | Current step (1-5) |
| status | ENUM | DEFAULT 'pending' | pending/documents_required/under_review/verified/approved/rejected |
| admin_remarks | TEXT | — | Admin feedback |
| verified_at | DATETIME | DEFAULT NULL | Verification timestamp |
| approved_at | DATETIME | DEFAULT NULL | Approval timestamp |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Application date |

#### 8.2.5 loan_documents
| Column | Type | Constraint | Description |
|--------|------|-----------|-------------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique document ID |
| application_id | INT | FOREIGN KEY → loan_applications(id) | Linked application |
| doc_type | ENUM | NOT NULL | pan_card/aadhar_card/salary_slip/bank_statement/property_doc/other |
| file_name | VARCHAR(255) | NOT NULL | Original filename |
| file_path | VARCHAR(500) | NOT NULL | Server file path |
| status | ENUM | DEFAULT 'pending' | pending/approved/rejected |
| remarks | VARCHAR(255) | DEFAULT NULL | Admin remarks |
| uploaded_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Upload timestamp |

#### 8.2.6 Other Tables
- **property_images** — Multiple images per property (exterior, hall, bedroom, kitchen, bathroom)
- **plans** — Subscription plans for property listing (Basic, Premium, Pro)
- **services** — Home services (cleaning, painting, plumbing, etc.)
- **service_bookings** — Client service booking records
- **enquiries** — Property enquiries from potential buyers/renters
- **rent_payments** — Monthly rent payment tracking with receipts
- **maintenance_requests** — Client maintenance/repair requests
- **wishlists** — Client saved/favorite properties
- **property_comparisons** — Properties being compared by clients
- **property_alerts** — Search criteria alerts for new listings
- **news_guides** — Real estate news articles and guides

---

## 9. Module Description

### 9.1 Admin Modules

#### Module 1: Admin Dashboard (`admin/dashboard.php`)
- Overview of key metrics (total properties, clients, enquiries, revenue)
- Recent enquiries and activity feed
- Quick action buttons
- Real-time statistics with visual cards

#### Module 2: Property Management (`admin/properties.php`, `add-property.php`, `edit-property.php`)
- View all properties in tabular format with images
- Add new property with multi-image upload
- Edit existing property details
- Delete properties
- Toggle property status (available/sold/rented)
- Rich text property descriptions

#### Module 3: Client Management (`admin/clients.php`)
- View all registered clients
- Client details (name, email, phone, status)
- Activate/deactivate client accounts

#### Module 4: Finance Management (`admin/finance.php`, `admin/payments.php`)
- Revenue overview (total income, expenses, profit)
- Rent payment tracking and verification
- Payment status management (pending/paid)
- Financial trend visualization using Chart.js

#### Module 5: Loan Application Management (`admin/loan-applications.php`)
- View all loan applications with status dashboard
- Stats overview (total, pending, under review, approved)
- Review uploaded documents (approve/reject each)
- Update application status through 5-step workflow
- Add admin remarks visible to applicants

#### Module 6: Enquiry Management (`admin/enquiries.php`)
- View all property enquiries
- Update enquiry status (new/read/replied)
- Contact information display

#### Module 7: Maintenance Management (`admin/maintenance.php`)
- View all maintenance requests
- Assign service providers
- Update request status (pending/in_progress/completed)
- Add resolution notes

#### Module 8: Analytics & Reports (`admin/analytics.php`, `admin/reports.php`)
- Property type distribution charts
- City-wise property breakdown
- Revenue trends (monthly/quarterly)
- Client growth metrics
- Enquiry conversion rates

#### Module 9: Admin Profile & Settings (`admin/profile.php`, `admin/settings.php`)
- Personal profile management (name, email)
- Password change with BCrypt hashing
- General site settings
- Appearance (dark mode toggle, accent colors)
- Notification preferences
- System information (PHP version, MySQL version, etc.)

---

### 9.2 Client Modules

#### Module 10: Client Registration & Login (`client/register.php`, `client/login.php`)
- Secure registration with email and password
- Password hashing using BCrypt
- Session-based authentication
- Login with email and password

#### Module 11: Client Dashboard (`client/dashboard.php`)
- Overview stats (properties viewed, wishlists, loan apps, alerts)
- Recent loan application status cards
- Quick navigation sidebar

#### Module 12: Client Profile (`client/profile.php`, `client/settings.php`)
- Profile picture upload (avatar)
- Personal information management
- Bio, city, country settings
- Password change
- Account preferences

#### Module 13: Property Browsing (`properties.php`, `property-detail.php`)
- Advanced search with filters:
  - City selection
  - Property type (Apartment, Villa, Home, Commercial, Site)
  - Listing type (Buy, Rent, PG, Commercial)
  - Price range (min/max)
  - Bedrooms filter
- Property cards with images, price, and key details
- Detailed property view with image gallery
- Amenities listing
- Contact/Enquiry form

#### Module 14: Loan Application & Tracking (`loans.php`)
- **Step 1 — Apply:** Fill application form (name, phone, bank, amount, income, property type)
- **Step 2 — Upload Documents:** Upload PAN, Aadhar, salary slips, bank statements, property papers
- **Step 3 — Verification:** Application under review by admin
- **Step 4 — Approval:** Admin verifies and approves/rejects
- **Step 5 — Track:** Real-time step tracker with admin remarks
- EMI Calculator (loan amount, interest rate, tenure)
- Bank Loan Comparison (SBI, HDFC, ICICI, Axis, PNB)

#### Module 15: Rent Payment Tracking (`client/rent-payment.php`)
- View all rent payment records
- Payment details (amount, month, mode, transaction ID)
- Payment status (paid/pending)
- Receipt number tracking

#### Module 16: Maintenance Requests (`client/maintenance.php`)
- Submit new maintenance request
- Categories: Plumbing, Electrical, Appliance, Painting, Pest Control, Carpentry, Other
- Priority levels: Low, Medium, High, Urgent
- Track request status and admin notes
- View assigned service provider

#### Module 17: AI Property Recommendation (`ai-recommend.php`, `api/ai-recommend.php`)
- Lifestyle-based property recommendations
- User answers questions about preferences:
  - Budget range
  - Preferred city
  - Property type
  - Lifestyle priority (luxury, investment, family, budget)
- AI algorithm scores properties based on:
  - Amenity matching
  - Lifestyle compatibility
  - Quality score
- Interactive chat-like interface
- Property cards with match percentage

---

### 9.3 Public Modules

#### Module 18: Homepage (`index.php`)
- Hero section with property search
- Featured properties showcase
- Property type categories
- Loan process CTA section
- Top establishments
- Statistics counter

#### Module 19: News & Guides (`news.php`, `news-detail.php`)
- Real estate news articles
- Category filters (News, Guide, Tips, Market)
- Featured article display
- Article detail page with views counter

#### Module 20: Legal Advisory (`legal.php`)
- Legal guide for property transactions
- Stamp duty calculator
- Document checklist for property purchase
- RERA information

#### Module 21: Pricing Plans (`plans.php`)
- Residential plans (Basic, Premium, Pro)
- Commercial plans
- Feature comparison
- Plan selection

---

## 10. User Interface Design

### 10.1 Design Principles
- **Responsive Design:** Fully responsive across mobile, tablet, and desktop using Bootstrap 5 grid system
- **Modern Aesthetics:** Clean design with gradients, glassmorphism effects, and micro-animations
- **Consistent Color Palette:**
  - Primary: `#1a3c5e` (Dark Blue)
  - Secondary: `#2d6a4f` (Forest Green)
  - Accent: `#FF6B35` (Orange)
  - Text: `#1e293b` (Dark Gray)
  - Background: `#f0f4f8` (Light Gray)
- **Typography:** Poppins (Google Fonts) for clean, modern readability
- **Dark Mode:** Full dark mode support in admin panel
- **Accessibility:** Proper contrast ratios, semantic HTML, keyboard navigation

### 10.2 Navigation Structure

```
PropNexus (Public)
├── Home
├── Properties ─► Search & Filter ─► Property Detail
├── Legal
├── Loans ─► Apply / Track / Upload / EMI Calculator / Compare Banks
├── Plans
├── AI Agent
└── News & Guides ─► Article Detail

Client Panel
├── Dashboard
├── AI Agent
├── My Profile
├── Browse Properties
├── PG / Co-Living
├── My Alerts
├── Rent Receipts
├── Maintenance
├── Loan Tracker
├── Legal Services
├── Home Loans
├── News & Guides
├── Settings
└── Logout

Admin Panel
├── Dashboard
├── My Profile
├── Analytics
├── AI Agent
├── Finance
├── Properties ─► Add Property / Edit Property
├── Clients
├── Enquiries
├── Loan Applications
├── Plans
├── Maintenance
├── Documents
├── Reports
├── Settings
├── Help
└── View Website
```

---

## 11. Implementation Details

### 11.1 Authentication System
```
┌──────────────────────────────────────┐
│         Authentication Flow          │
├──────────────────────────────────────┤
│ 1. User submits login form           │
│ 2. PHP validates email + password    │
│ 3. BCrypt password_verify()          │
│ 4. Session created on success        │
│    $_SESSION['client_id'] = id       │
│    $_SESSION['client_name'] = name   │
│ 5. Redirect to dashboard             │
│ 6. Protected pages check session     │
│    isClientLoggedIn() / isAdminLoggedIn() │
│ 7. Logout destroys session           │
└──────────────────────────────────────┘
```

### 11.2 Loan Approval Workflow
```
Step 1: APPLY          → Status: 'pending'           → current_step: 1
    ↓ (User fills form)
Step 2: UPLOAD DOCS    → Status: 'documents_required' → current_step: 2
    ↓ (User uploads PAN, Aadhar, etc.)
Step 3: VERIFICATION   → Status: 'under_review'       → current_step: 3
    ↓ (Admin reviews documents)
Step 4: APPROVAL       → Status: 'verified'           → current_step: 4
    ↓ (Admin approves/rejects)
Step 5: DISBURSEMENT   → Status: 'approved'/'rejected' → current_step: 5
```

### 11.3 AI Recommendation Algorithm
The AI recommendation engine uses a scoring system:
1. **Amenity Match Score:** Checks how many property amenities match user preferences
2. **Lifestyle Score:** Rates properties on lifestyle compatibility (luxury, family, investment, budget)
3. **Quality Score:** Based on property images and listing quality
4. **Final Ranking:** `amenity_match + lifestyle_score + quality_score`

### 11.4 Security Measures
| Measure | Implementation |
|---------|---------------|
| Password Hashing | BCrypt via `password_hash()` and `password_verify()` |
| SQL Injection Prevention | MySQLi `real_escape_string()` + `sanitize()` function |
| XSS Prevention | `htmlspecialchars()` on all output |
| Session Security | Session-based auth with `session_start()` |
| File Upload Validation | Extension check, size limits for document uploads |
| CSRF Protection | Form-based token validation |
| Input Validation | Server-side validation on all forms |

### 11.5 File Structure

```
PropNexus/
├── index.php                 # Homepage
├── properties.php            # Property listing with search
├── property-detail.php       # Single property view
├── loans.php                 # Loan application & tracking
├── legal.php                 # Legal advisory tools
├── plans.php                 # Pricing plans
├── news.php                  # News & guides listing
├── news-detail.php           # Single article view
├── ai-recommend.php          # AI recommendation interface
├── alerts.php                # Property alerts
├── install.php               # Auto-installer
├── database.sql              # Complete database schema + data
├── README.md                 # Project readme
│
├── includes/
│   ├── config.php            # Database connection & helpers
│   ├── header.php            # Global header & navigation
│   ├── footer.php            # Global footer
│   └── ai-chatbot.php        # AI chatbot widget
│
├── admin/
│   ├── dashboard.php         # Admin dashboard
│   ├── profile.php           # Admin profile
│   ├── analytics.php         # Charts & analytics
│   ├── finance.php           # Financial management
│   ├── properties.php        # Property management
│   ├── add-property.php      # Add new property
│   ├── edit-property.php     # Edit property
│   ├── clients.php           # Client management
│   ├── enquiries.php         # Enquiry management
│   ├── loan-applications.php # Loan management
│   ├── maintenance.php       # Maintenance requests
│   ├── payments.php          # Payment management
│   ├── plans.php             # Plan management
│   ├── documents.php         # File manager
│   ├── reports.php           # Reports
│   ├── settings.php          # System settings
│   ├── help.php              # Help center
│   ├── login.php             # Admin login
│   ├── logout.php            # Admin logout
│   └── includes/
│       └── sidebar.php       # Admin sidebar navigation
│
├── client/
│   ├── dashboard.php         # Client dashboard
│   ├── profile.php           # Client profile
│   ├── settings.php          # Client settings
│   ├── alerts.php            # Price/property alerts
│   ├── maintenance.php       # Maintenance requests
│   ├── rent-payment.php      # Rent payment history
│   ├── login.php             # Client login
│   ├── register.php          # Client registration
│   └── logout.php            # Client logout
│
├── api/
│   └── ai-recommend.php      # AI recommendation API
│
└── assets/
    ├── css/
    │   ├── style.css          # Main stylesheet
    │   └── admin.css          # Admin panel stylesheet
    ├── js/
    │   └── admin.js           # Admin panel JavaScript
    └── uploads/
        └── loan_documents/   # Uploaded loan documents
```

---

## 12. Testing

### 12.1 Test Cases

#### 12.1.1 Authentication Testing

| Test ID | Test Case | Input | Expected Output | Status |
|---------|-----------|-------|-----------------|--------|
| TC-01 | Admin Login (Valid) | admin@PropNexus.com / Admin@123 | Redirect to dashboard | ✅ Pass |
| TC-02 | Admin Login (Invalid) | wrong@email.com / wrong | Error message | ✅ Pass |
| TC-03 | Client Registration | Valid details | Account created, redirect to login | ✅ Pass |
| TC-04 | Client Login (Valid) | Valid email/password | Redirect to client dashboard | ✅ Pass |
| TC-05 | Session Expiry | Close browser, access dashboard | Redirect to login | ✅ Pass |

#### 12.1.2 Property Management Testing

| Test ID | Test Case | Input | Expected Output | Status |
|---------|-----------|-------|-----------------|--------|
| TC-06 | Add Property | Valid property data + images | Property created, listed | ✅ Pass |
| TC-07 | Edit Property | Updated price/details | Property updated | ✅ Pass |
| TC-08 | Delete Property | Confirm delete | Property removed | ✅ Pass |
| TC-09 | Search Properties | City: Bangalore, Type: Apartment | Filtered results | ✅ Pass |
| TC-10 | Property Detail | Click property card | Full details + gallery | ✅ Pass |

#### 12.1.3 Loan Application Testing

| Test ID | Test Case | Input | Expected Output | Status |
|---------|-----------|-------|-----------------|--------|
| TC-11 | Submit Loan Application | Valid form data | Application created, step 2 | ✅ Pass |
| TC-12 | Upload Documents | PAN, Aadhar files | Files saved, step 3 | ✅ Pass |
| TC-13 | Admin Update Status | Change to 'approved' | Status updated, step 5 | ✅ Pass |
| TC-14 | Track Application | Client views track tab | Current status shown | ✅ Pass |
| TC-15 | EMI Calculator | Amount: 50L, Rate: 8.5%, 20yr | EMI: ₹43,391 | ✅ Pass |

#### 12.1.4 Other Module Testing

| Test ID | Test Case | Input | Expected Output | Status |
|---------|-----------|-------|-----------------|--------|
| TC-16 | Maintenance Request | Submit plumbing issue | Request created, shows in admin | ✅ Pass |
| TC-17 | Rent Payment View | Client opens rent receipts | Payment history displayed | ✅ Pass |
| TC-18 | AI Recommendation | Answer preference questions | Top matched properties | ✅ Pass |
| TC-19 | Admin Analytics | Open analytics page | Charts rendered | ✅ Pass |
| TC-20 | Dark Mode Toggle | Click toggle in settings | Theme switches | ✅ Pass |

---

## 13. Screenshots

> **Note:** Screenshots can be captured from the running application at `http://localhost/PropNexus`

### Pages to screenshot:
1. Homepage (Hero + Featured Properties)
2. Property Listing Page (with filters)
3. Property Detail Page (Gallery + Amenities)
4. Client Registration Page
5. Client Dashboard
6. Client Profile Page
7. Loan Application Page (Step 1 - Apply)
8. Loan Tracking Page (Step Progress)
9. EMI Calculator
10. Bank Comparison
11. Maintenance Request Form
12. Rent Payment History
13. AI Recommendation Chat
14. Admin Login Page
15. Admin Dashboard
16. Admin Properties Management
17. Admin Add Property Form
18. Admin Finance Page
19. Admin Loan Applications
20. Admin Analytics Page
21. Admin Profile Page
22. Admin Settings (Dark Mode)
23. News & Guides Page
24. Legal Advisory Page

---

## 14. Installation & Setup Guide

### Step 1: Install XAMPP
1. Download XAMPP from [https://www.apachefriends.org](https://www.apachefriends.org)
2. Install with default settings
3. Start **Apache** and **MySQL** from XAMPP Control Panel

### Step 2: Copy Project Files
1. Copy the entire `PropNexus` folder to `C:\xampp\htdocs\`
2. Ensure the path is: `C:\xampp\htdocs\PropNexus\`

### Step 3: Create Database
1. Open browser → Go to `http://localhost/phpmyadmin`
2. Click **"New"** in the left sidebar
3. Enter database name: `PropNexus_db`
4. Click **"Create"**

### Step 4: Import Database
1. Select `PropNexus_db` from the left sidebar
2. Click the **"Import"** tab
3. Choose file: `C:\xampp\htdocs\PropNexus\database.sql`
4. Click **"Go"**

### Step 5: Launch Application
1. Website: `http://localhost/PropNexus`
2. Admin Panel: `http://localhost/PropNexus/admin/login.php`
3. Client Login: `http://localhost/PropNexus/client/login.php`

### Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@PropNexus.com | Admin@123 |
| Client | (Register new account) | (User defined) |

---

## 15. Future Enhancements

1. **Payment Gateway Integration** — Integrate Razorpay/PayPal for online rent payments and plan purchases
2. **Google Maps Integration** — Display property locations on interactive maps
3. **Real-time Chat** — WebSocket-based live chat between clients and admin
4. **SMS/Email Notifications** — Automated notifications for loan status changes, payment reminders
5. **Mobile Application** — Native Android/iOS apps using React Native
6. **Virtual Property Tours** — 360° virtual tours of properties
7. **Document OCR** — Automatic extraction of data from uploaded documents
8. **Multi-language Support** — Hindi, Kannada, Tamil, Telugu translations
9. **Social Media Login** — Google, Facebook OAuth authentication
10. **Property Auctions** — Online bidding system for premium properties
11. **Tenant Screening** — Background and credit check integration
12. **Automated Reports** — Scheduled PDF report generation and email delivery

---

## 16. Conclusion

**PropNexus** is a comprehensive Real Estate Property Management System that successfully addresses the challenges of modern property management. The system provides:

- A **centralized platform** for managing properties, clients, finances, and operations
- An **intuitive client portal** for property browsing, loan applications, and maintenance requests
- An **AI-powered recommendation engine** that enhances user experience through personalized property suggestions
- A **step-by-step loan approval workflow** that digitizes the traditionally paper-heavy loan process
- A **responsive, modern design** that works seamlessly across all devices

The project demonstrates proficiency in full-stack web development using HTML, CSS, JavaScript, PHP, and MySQL, with emphasis on:
- **Database design** and relational data modeling
- **Server-side programming** with session management and authentication
- **Frontend development** with responsive design and rich UI/UX
- **Security practices** including password hashing, input sanitization, and XSS prevention
- **Algorithm design** for the AI property recommendation system

This system can be deployed in real-world scenarios for real estate agencies, property management companies, and individual property owners seeking a digital solution for their operations.

---

## 17. References

1. **PHP Official Documentation** — https://www.php.net/docs.php
2. **MySQL Reference Manual** — https://dev.mysql.com/doc/
3. **Bootstrap 5 Documentation** — https://getbootstrap.com/docs/5.3/
4. **Font Awesome Icons** — https://fontawesome.com/
5. **Chart.js Documentation** — https://www.chartjs.org/docs/
6. **W3Schools PHP Tutorial** — https://www.w3schools.com/php/
7. **MDN Web Docs (HTML/CSS/JS)** — https://developer.mozilla.org/
8. **XAMPP Official Site** — https://www.apachefriends.org/
9. **Google Fonts** — https://fonts.google.com/
10. **Unsplash (Property Images)** — https://unsplash.com/

---

**Project Developed By:** _[Your Name]_
**Roll Number:** _[Your Roll Number]_
**College:** _[Your College Name]_
**Department:** Bachelor of Computer Applications (BCA)
**Academic Year:** 2025-2026
**Guide:** _[Guide Name]_

---

*© 2026 PropNexus. All rights reserved. This project is developed for academic purposes as part of the BCA Final Year Project.*
