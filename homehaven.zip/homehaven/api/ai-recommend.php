<?php
/**
 * PropNexus AI Property Recommendation Engine
 * Processes user preferences and returns smart property matches
 */
header('Content-Type: application/json');
session_start();
require_once __DIR__ . '/../includes/config.php';

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? 'recommend';

switch ($action) {
    case 'recommend':
        echo json_encode(getRecommendations($conn, $input));
        break;
    case 'chat':
        echo json_encode(handleChat($conn, $input));
        break;
    case 'quick_match':
        echo json_encode(quickMatch($conn, $input));
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

/**
 * AI Recommendation Engine — matches properties based on user preferences
 */
function getRecommendations($conn, $input) {
    $budget_min  = (float)($input['budget_min'] ?? 0);
    $budget_max  = (float)($input['budget_max'] ?? 999999999);
    $city        = trim($input['city'] ?? '');
    $state       = trim($input['state'] ?? '');
    $type        = trim($input['property_type'] ?? '');
    $listing     = trim($input['listing_type'] ?? '');
    $bedrooms    = (int)($input['bedrooms'] ?? 0);
    $amenities   = $input['amenities'] ?? [];
    $lifestyle   = trim($input['lifestyle'] ?? '');

    // Build smart query
    $where = "WHERE p.status = 'available'";
    $params = [];
    $types_str = '';

    if ($budget_min > 0) {
        $where .= " AND p.price >= ?";
        $params[] = $budget_min;
        $types_str .= 'd';
    }
    if ($budget_max > 0 && $budget_max < 999999999) {
        $where .= " AND p.price <= ?";
        $params[] = $budget_max;
        $types_str .= 'd';
    }
    if ($city) {
        $where .= " AND p.city LIKE ?";
        $params[] = "%$city%";
        $types_str .= 's';
    }
    if ($state) {
        $where .= " AND p.state LIKE ?";
        $params[] = "%$state%";
        $types_str .= 's';
    }
    if ($type) {
        $where .= " AND p.type = ?";
        $params[] = $type;
        $types_str .= 's';
    }
    if ($listing) {
        $where .= " AND p.listing_type = ?";
        $params[] = $listing;
        $types_str .= 's';
    }
    if ($bedrooms > 0) {
        $where .= " AND p.bedrooms >= ?";
        $params[] = $bedrooms;
        $types_str .= 'i';
    }

    // Amenity matching
    $amenity_score = '';
    if (!empty($amenities)) {
        $parts = [];
        foreach ($amenities as $a) {
            $a = $conn->real_escape_string($a);
            $parts[] = "(CASE WHEN p.amenities LIKE '%$a%' THEN 1 ELSE 0 END)";
        }
        $amenity_score = ', (' . implode(' + ', $parts) . ') as amenity_match';
    } else {
        $amenity_score = ', 0 as amenity_match';
    }

    // Lifestyle preference scoring
    $lifestyle_score = '';
    switch (strtolower($lifestyle)) {
        case 'family':
            $lifestyle_score = ", (CASE WHEN p.bedrooms >= 2 THEN 2 ELSE 0 END + CASE WHEN p.amenities LIKE '%Garden%' THEN 1 ELSE 0 END + CASE WHEN p.amenities LIKE '%Security%' THEN 1 ELSE 0 END + CASE WHEN p.amenities LIKE '%Parking%' THEN 1 ELSE 0 END) as lifestyle_score";
            break;
        case 'bachelor':
            $lifestyle_score = ", (CASE WHEN p.listing_type IN ('rent','pg') THEN 2 ELSE 0 END + CASE WHEN p.amenities LIKE '%WiFi%' THEN 1 ELSE 0 END + CASE WHEN p.amenities LIKE '%Gym%' THEN 1 ELSE 0 END + CASE WHEN p.amenities LIKE '%Food%' THEN 1 ELSE 0 END) as lifestyle_score";
            break;
        case 'luxury':
            $lifestyle_score = ", (CASE WHEN p.amenities LIKE '%Pool%' THEN 2 ELSE 0 END + CASE WHEN p.amenities LIKE '%Gym%' THEN 1 ELSE 0 END + CASE WHEN p.amenities LIKE '%Valet%' THEN 1 ELSE 0 END + CASE WHEN p.amenities LIKE '%Club%' THEN 1 ELSE 0 END + CASE WHEN p.featured = 1 THEN 2 ELSE 0 END) as lifestyle_score";
            break;
        case 'investment':
            $lifestyle_score = ", (CASE WHEN p.listing_type = 'buy' THEN 2 ELSE 0 END + CASE WHEN p.featured = 1 THEN 1 ELSE 0 END + CASE WHEN p.type = 'site' THEN 2 ELSE 0 END) as lifestyle_score";
            break;
        case 'student':
            $lifestyle_score = ", (CASE WHEN p.listing_type = 'pg' THEN 3 ELSE 0 END + CASE WHEN p.amenities LIKE '%WiFi%' THEN 1 ELSE 0 END + CASE WHEN p.amenities LIKE '%Food%' THEN 2 ELSE 0 END + CASE WHEN p.price <= 15000 THEN 2 ELSE 0 END) as lifestyle_score";
            break;
        default:
            $lifestyle_score = ", 0 as lifestyle_score";
    }

    $sql = "SELECT p.*, pi.image_url $amenity_score $lifestyle_score,
            (p.featured * 2 + IFNULL((SELECT COUNT(*) FROM property_images WHERE property_id = p.id), 0)) as quality_score
            FROM properties p
            LEFT JOIN property_images pi ON p.id = pi.property_id AND pi.is_primary = 1
            $where
            ORDER BY (amenity_match + lifestyle_score + quality_score) DESC, p.featured DESC, p.created_at DESC
            LIMIT 6";

    $stmt = $conn->prepare($sql);
    if ($types_str && count($params) > 0) {
        $stmt->bind_param($types_str, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    $properties = [];
    while ($row = $result->fetch_assoc()) {
        $properties[] = [
            'id'           => $row['id'],
            'title'        => $row['title'],
            'price'        => (float)$row['price'],
            'price_fmt'    => formatPrice($row['price']),
            'type'         => $row['type'],
            'listing_type' => $row['listing_type'],
            'bedrooms'     => (int)$row['bedrooms'],
            'bathrooms'    => (int)$row['bathrooms'],
            'area'         => $row['area'],
            'location'     => $row['location'],
            'city'         => $row['city'],
            'amenities'    => $row['amenities'],
            'image_url'    => $row['image_url'] ?: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800',
            'featured'     => (bool)$row['featured'],
            'match_score'  => min(100, (int)(($row['amenity_match'] + $row['lifestyle_score'] + $row['quality_score']) * 8 + 40)),
        ];
    }

    // Generate AI insight message
    $insight = generateInsight($properties, $input);

    return [
        'success'    => true,
        'count'      => count($properties),
        'properties' => $properties,
        'insight'    => $insight,
        'filters'    => [
            'budget'    => ($budget_min > 0 ? formatPrice($budget_min) : '₹0') . ' - ' . ($budget_max < 999999999 ? formatPrice($budget_max) : 'Unlimited'),
            'city'      => $city ?: 'All Cities',
            'state'     => $state ?: 'All States',
            'type'      => $type ?: 'All Types',
            'listing'   => $listing ?: 'All',
            'bedrooms'  => $bedrooms ?: 'Any',
            'lifestyle' => $lifestyle ?: 'General',
        ]
    ];
}

/**
 * AI Chat Handler — processes natural language queries
 */
function handleChat($conn, $input) {
    $message = strtolower(trim($input['message'] ?? ''));
    if (empty($message)) {
        return ['success' => false, 'reply' => 'Please ask me something about properties! 🏠'];
    }

    // Intent detection
    $intent = detectIntent($message);
    $entities = extractEntities($conn, $message);

    switch ($intent) {
        case 'search':
            return handleSearchIntent($conn, $entities, $message);
        case 'budget':
            return handleBudgetIntent($conn, $entities, $message);
        case 'compare':
            return handleCompareIntent($conn, $message);
        case 'recommend':
            return handleRecommendIntent($conn, $entities, $message);
        case 'loan':
            return handleLoanIntent($message);
        case 'greeting':
            return ['success' => true, 'reply' => "Hello! 👋 I'm PropNexus's AI assistant. I can help you:\n\n🏠 **Find properties** — \"Show me 2BHK in Bangalore\"\n💰 **Explore by budget** — \"Properties under ₹50L\"\n🔍 **Smart recommendations** — \"Best homes for families\"\n🏦 **Loan guidance** — \"How much EMI for ₹80L?\"\n\nWhat are you looking for?", 'type' => 'greeting'];
        case 'help':
            return ['success' => true, 'reply' => "Here's what I can help you with:\n\n🔍 **Search** — \"3BHK villa in Pune\"\n💰 **Budget** — \"Flats under ₹1 Crore in Mumbai\"\n🏡 **Lifestyle** — \"Best properties for families\"\n🎓 **Student** — \"PG near Electronic City\"\n💼 **Investment** — \"Plots in Bangalore for investment\"\n📊 **Market Info** — \"How is Delhi real estate?\"\n🏦 **EMI** — \"What's the EMI for ₹50 Lakh loan?\"\n\nJust ask naturally — I understand! 🤖", 'type' => 'help'];
        default:
            return handleGeneralQuery($conn, $entities, $message);
    }
}

function detectIntent($msg) {
    $greetings = ['hello','hi','hey','good morning','good evening','good afternoon','greetings','namaste'];
    foreach ($greetings as $g) {
        if (strpos($msg, $g) !== false && strlen($msg) < 30) return 'greeting';
    }
    if (preg_match('/help|what can you|how to use/i', $msg)) return 'help';
    if (preg_match('/compare|versus|vs\b|which is better/i', $msg)) return 'compare';
    if (preg_match('/emi|loan|interest|eligib/i', $msg)) return 'loan';
    if (preg_match('/budget|under|below|less than|within|afford|cheap/i', $msg)) return 'budget';
    if (preg_match('/recommend|suggest|best|top|ideal|perfect|good/i', $msg)) return 'recommend';
    if (preg_match('/find|show|search|looking|want|need|get|list|available/i', $msg)) return 'search';
    return 'general';
}

function extractEntities($conn, $msg) {
    $entities = ['city'=>'','type'=>'','listing'=>'','bedrooms'=>0,'budget_max'=>0,'budget_min'=>0,'amenities'=>[],'lifestyle'=>''];

    // Cities
    $cities_result = $conn->query("SELECT DISTINCT city FROM properties");
    while ($row = $cities_result->fetch_assoc()) {
        if (stripos($msg, strtolower($row['city'])) !== false) {
            $entities['city'] = $row['city'];
            break;
        }
    }

    // Location
    if (empty($entities['city'])) {
        $loc_result = $conn->query("SELECT DISTINCT location FROM properties");
        while ($row = $loc_result->fetch_assoc()) {
            if (stripos($msg, strtolower($row['location'])) !== false) {
                $entities['location'] = $row['location'];
                break;
            }
        }
    }

    // Property type
    $typeMap = ['villa'=>'villa','apartment'=>'apartment','flat'=>'apartment','house'=>'home','home'=>'home','plot'=>'site','site'=>'site','land'=>'site','commercial'=>'commercial','office'=>'commercial','shop'=>'commercial','pg'=>'pg','paying guest'=>'pg'];
    foreach ($typeMap as $keyword => $val) {
        if (stripos($msg, $keyword) !== false) {
            $entities['type'] = $val;
            if (in_array($val, ['pg'])) $entities['listing'] = 'pg';
            break;
        }
    }

    // Listing type
    $listMap = ['buy'=>'buy','purchase'=>'buy','rent'=>'rent','rental'=>'rent','lease'=>'rent','pg'=>'pg','commercial'=>'commercial'];
    foreach ($listMap as $keyword => $val) {
        if (stripos($msg, $keyword) !== false) {
            $entities['listing'] = $val;
            break;
        }
    }

    // Bedrooms
    if (preg_match('/(\d)\s*bhk/i', $msg, $m)) $entities['bedrooms'] = (int)$m[1];
    if (preg_match('/(\d)\s*bed/i', $msg, $m)) $entities['bedrooms'] = (int)$m[1];

    // Budget parsing
    if (preg_match('/([\d.]+)\s*(?:cr|crore)/i', $msg, $m)) $entities['budget_max'] = (float)$m[1] * 10000000;
    elseif (preg_match('/([\d.]+)\s*(?:l|lakh|lac)/i', $msg, $m)) $entities['budget_max'] = (float)$m[1] * 100000;
    elseif (preg_match('/([\d.]+)\s*(?:k|thousand)/i', $msg, $m)) $entities['budget_max'] = (float)$m[1] * 1000;
    elseif (preg_match('/under\s*(?:₹|rs\.?)?\s*([\d,]+)/i', $msg, $m)) $entities['budget_max'] = (float)str_replace(',', '', $m[1]);
    elseif (preg_match('/(?:₹|rs\.?)\s*([\d,]+)/i', $msg, $m)) $entities['budget_max'] = (float)str_replace(',', '', $m[1]);

    // Amenities
    $amenityList = ['pool','gym','parking','garden','security','wifi','food','ac','lift','power backup'];
    foreach ($amenityList as $a) {
        if (stripos($msg, $a) !== false) $entities['amenities'][] = $a;
    }

    // Lifestyle
    $lifestyleMap = ['family'=>'family','bachelor'=>'bachelor','singles'=>'bachelor','luxury'=>'luxury','premium'=>'luxury','investment'=>'investment','invest'=>'investment','student'=>'student','college'=>'student'];
    foreach ($lifestyleMap as $keyword => $val) {
        if (stripos($msg, $keyword) !== false) { $entities['lifestyle'] = $val; break; }
    }

    return $entities;
}

function handleSearchIntent($conn, $entities, $msg) {
    $params = [
        'city'          => $entities['city'],
        'property_type' => $entities['type'],
        'listing_type'  => $entities['listing'],
        'bedrooms'      => $entities['bedrooms'],
        'budget_max'    => $entities['budget_max'],
        'amenities'     => $entities['amenities'],
        'lifestyle'     => $entities['lifestyle'],
    ];
    $result = getRecommendations($conn, $params);

    if ($result['count'] > 0) {
        $reply = "🔍 I found **{$result['count']} properties** matching your search!\n\n";
        foreach ($result['properties'] as $i => $p) {
            $num = $i + 1;
            $reply .= "**{$num}. {$p['title']}**\n";
            $reply .= "📍 {$p['location']}, {$p['city']} • 💰 {$p['price_fmt']}";
            if ($p['bedrooms'] > 0) $reply .= " • 🛏️ {$p['bedrooms']}BHK";
            $reply .= " • Match: {$p['match_score']}%\n\n";
        }
        $reply .= "Click on any property to view details. Want to refine your search?";
        return ['success' => true, 'reply' => $reply, 'properties' => $result['properties'], 'type' => 'results'];
    } else {
        return ['success' => true, 'reply' => "😔 I couldn't find exact matches. Try:\n• Different city or location\n• Adjusting your budget range\n• Fewer specific filters\n\nOr tell me what you're looking for in different words!", 'type' => 'no_results'];
    }
}

function handleBudgetIntent($conn, $entities, $msg) {
    $params = [
        'city'          => $entities['city'],
        'property_type' => $entities['type'],
        'listing_type'  => $entities['listing'],
        'bedrooms'      => $entities['bedrooms'],
        'budget_max'    => $entities['budget_max'] ?: 5000000,
        'amenities'     => $entities['amenities'],
        'lifestyle'     => $entities['lifestyle'],
    ];
    $result = getRecommendations($conn, $params);
    $budgetFmt = formatPrice($params['budget_max']);

    if ($result['count'] > 0) {
        $reply = "💰 **Properties within {$budgetFmt}**\n\n";
        foreach ($result['properties'] as $i => $p) {
            $num = $i + 1;
            $reply .= "**{$num}. {$p['title']}**\n";
            $reply .= "📍 {$p['location']}, {$p['city']} • 💰 {$p['price_fmt']}";
            if ($p['bedrooms'] > 0) $reply .= " • 🛏️ {$p['bedrooms']}BHK";
            $reply .= "\n\n";
        }
        $reply .= "Want me to filter further?";
        return ['success' => true, 'reply' => $reply, 'properties' => $result['properties'], 'type' => 'results'];
    }
    return ['success' => true, 'reply' => "No properties found within {$budgetFmt}. Try a higher budget range? We have great options starting from ₹7,000/month for PG and ₹45L for buying.", 'type' => 'no_results'];
}

function handleRecommendIntent($conn, $entities, $msg) {
    $params = [
        'city'          => $entities['city'],
        'property_type' => $entities['type'],
        'listing_type'  => $entities['listing'],
        'bedrooms'      => $entities['bedrooms'],
        'budget_max'    => $entities['budget_max'],
        'amenities'     => $entities['amenities'],
        'lifestyle'     => $entities['lifestyle'],
    ];
    $result = getRecommendations($conn, $params);

    if ($result['count'] > 0) {
        $label = $entities['lifestyle'] ? ucfirst($entities['lifestyle']) . ' Living' : 'Your Needs';
        $reply = "🤖 **AI Recommendations for {$label}**\n\n";
        foreach ($result['properties'] as $i => $p) {
            $num = $i + 1;
            $stars = str_repeat('⭐', min(5, intdiv($p['match_score'], 20)));
            $reply .= "**{$num}. {$p['title']}** {$stars}\n";
            $reply .= "📍 {$p['location']}, {$p['city']} • 💰 {$p['price_fmt']}";
            if ($p['bedrooms'] > 0) $reply .= " • 🛏️ {$p['bedrooms']}BHK";
            $reply .= " • AI Match: **{$p['match_score']}%**\n\n";
        }
        $reply .= "These are my top picks! Need more options or different criteria?";
        return ['success' => true, 'reply' => $reply, 'properties' => $result['properties'], 'type' => 'results'];
    }
    return ['success' => true, 'reply' => "I need more details to recommend. Tell me:\n• 🏙️ Which city?\n• 💰 Your budget range?\n• 🛏️ How many bedrooms?\n• 🏠 Buy, rent, or PG?", 'type' => 'ask'];
}

function handleCompareIntent($conn, $msg) {
    return ['success' => true, 'reply' => "📊 To compare properties, visit our **Properties** page and use filters to shortlist. You can compare:\n• **Price** per sq. ft.\n• **Amenities** offered\n• **Location** connectivity\n• **Configuration** (BHK/size)\n\nTell me two property types or areas to compare!", 'type' => 'info'];
}

function handleLoanIntent($msg) {
    $reply = "🏦 **Home Loan Assistant**\n\n";
    if (preg_match('/([\d.]+)\s*(?:l|lakh|cr|crore)/i', $msg, $m)) {
        $amt = (float)$m[1];
        if (stripos($msg, 'cr') !== false) $amt *= 10000000;
        else $amt *= 100000;

        $rate = 8.5;
        $years = 20;
        $monthly_rate = $rate / 12 / 100;
        $months = $years * 12;
        $emi = $amt * $monthly_rate * pow(1 + $monthly_rate, $months) / (pow(1 + $monthly_rate, $months) - 1);

        $reply .= "For a loan of **" . formatPrice($amt) . "**:\n";
        $reply .= "• 📊 EMI @ {$rate}%: **₹" . number_format(round($emi)) . "/month**\n";
        $reply .= "• ⏳ Tenure: {$years} years\n";
        $reply .= "• 💵 Total payable: **₹" . number_format(round($emi * $months)) . "**\n";
        $reply .= "• 📈 Total interest: **₹" . number_format(round($emi * $months - $amt)) . "**\n\n";
        $reply .= "Visit our **Loans** page for bank-wise rates and apply directly!";
    } else {
        $reply .= "Current home loan rates:\n";
        $reply .= "• 🏦 SBI: 8.40% p.a.\n";
        $reply .= "• 🏦 HDFC: 8.50% p.a.\n";
        $reply .= "• 🏦 ICICI: 8.75% p.a.\n\n";
        $reply .= "Ask me **\"EMI for ₹50 Lakh\"** for a quick calculation!";
    }
    return ['success' => true, 'reply' => $reply, 'type' => 'loan'];
}

function handleGeneralQuery($conn, $entities, $msg) {
    // Try search with extracted entities
    if ($entities['city'] || $entities['type'] || $entities['budget_max'] > 0) {
        return handleSearchIntent($conn, $entities, $msg);
    }

    // Market info
    if (preg_match('/market|trend|price|rate|growth/i', $msg)) {
        return ['success' => true, 'reply' => "📊 **Real Estate Market Insights 2026**\n\n• Bangalore: +15% YoY growth, IT hub driving demand\n• Mumbai: +12% growth, Bandra & Powai hotspots\n• Hyderabad: +18% growth, Gachibowli & Madhapur booming\n• Pune: +10% growth, Baner & Hinjewadi popular\n• Delhi NCR: +8% growth, Noida & Gurgaon preferred\n\nAsk about a specific city for detailed insights!", 'type' => 'info'];
    }

    return ['success' => true, 'reply' => "I'm not sure I understood that. Try asking me:\n\n🏠 **\"Show me 3BHK apartments in Bangalore\"**\n💰 **\"Properties under ₹50 Lakh in Pune\"**\n🎓 **\"PG near Electronic City\"**\n🏦 **\"EMI for ₹1 Crore loan\"**\n🤖 **\"Best properties for families\"**\n\nI'm here to help! 🙂", 'type' => 'help'];
}

function quickMatch($conn, $input) {
    $client_id = (int)($input['client_id'] ?? 0);

    // If logged in, check their alerts for preferences
    $preferences = [];
    if ($client_id > 0) {
        $alerts = $conn->query("SELECT * FROM property_alerts WHERE client_id = $client_id AND status = 'active' ORDER BY created_at DESC LIMIT 1");
        if ($alerts && $alerts->num_rows > 0) {
            $al = $alerts->fetch_assoc();
            $preferences['city'] = $al['city'] ?? '';
            $preferences['listing_type'] = $al['listing_type'] ?? '';
            $preferences['property_type'] = $al['property_type'] ?? '';
            $preferences['budget_min'] = $al['min_budget'] ?? 0;
            $preferences['budget_max'] = $al['max_budget'] ?? 0;
            $preferences['bedrooms'] = $al['min_bedrooms'] ?? 0;
        }
    }

    // Fall back to random featured properties
    if (empty($preferences)) {
        $preferences = ['listing_type' => '', 'property_type' => '', 'city' => '', 'bedrooms' => 0, 'budget_max' => 0];
    }

    return getRecommendations($conn, $preferences);
}

/**
 * Generate contextual AI insight
 */
function generateInsight($properties, $input) {
    if (empty($properties)) {
        return "I couldn't find exact matches. Try broadening your search criteria!";
    }
    $count = count($properties);
    $avgPrice = array_sum(array_column($properties, 'price')) / $count;
    $cities = array_unique(array_column($properties, 'city'));
    $city_text = count($cities) > 1 ? implode(', ', array_slice($cities, 0, 3)) : ($cities[0] ?? 'various locations');

    $insights = [
        "Found {$count} great options in {$city_text}! Average price is " . formatPrice($avgPrice) . ". Featured properties tend to offer better value.",
        "I've curated {$count} top matches for you! Properties in {$city_text} are showing strong demand. I recommend checking featured listings first.",
        "Here are {$count} handpicked properties! The {$city_text} market is thriving. Properties with higher amenity scores tend to appreciate better.",
        "{$count} properties matched your criteria. The average asking price is " . formatPrice($avgPrice) . ". Consider locations with good connectivity for better ROI.",
    ];
    return $insights[array_rand($insights)];
}
?>
