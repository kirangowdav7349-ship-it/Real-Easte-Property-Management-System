<?php
$pageTitle = 'Property Detail';
require_once 'includes/header.php';

$id = (int)($_GET['id'] ?? 0);
$prop = $conn->query("SELECT * FROM properties WHERE id=$id")->fetch_assoc();
if(!$prop) { header("Location: properties.php"); exit(); }
$pageTitle = $prop['title'];

$images = $conn->query("SELECT * FROM property_images WHERE property_id=$id");
$imgArr = [];
while($img = $images->fetch_assoc()) $imgArr[] = $img;

// Handle buy request (NO immediate status change — pending admin approval)
$buyMsg = '';
$txnSuccess = false;
$txnId = 0;
$txnType = '';
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['buy_property'])) {
  if(!empty($_SESSION['client_id'])) {
    $cid = (int)$_SESSION['client_id'];
    $fullName = $conn->real_escape_string(trim($_POST['buyer_name'] ?? ''));
    $email = $conn->real_escape_string(trim($_POST['buyer_email'] ?? ''));
    $phone = $conn->real_escape_string(trim($_POST['buyer_phone'] ?? ''));
    $address = $conn->real_escape_string(trim($_POST['buyer_address'] ?? ''));
    $message = $conn->real_escape_string(trim($_POST['buyer_message'] ?? ''));
    $amount = (float)$prop['price'];

    // Check if client already has a pending request for this property
    $existing = $conn->query("SELECT id FROM property_transactions WHERE client_id=$cid AND property_id=$id AND transaction_type='buy' AND status='pending'")->num_rows;
    if($existing > 0) {
      $buyMsg = '<div class="alert alert-info"><i class="fas fa-info-circle me-2"></i>You already have a pending purchase request for this property. Our team will contact you soon.</div>';
    } else {
      $conn->query("INSERT INTO property_transactions (client_id, property_id, transaction_type, full_name, email, phone, address, message, amount, status, admin_read)
        VALUES ($cid, $id, 'buy', '$fullName', '$email', '$phone', '$address', '$message', $amount, 'pending', 0)");
      $txnId = $conn->insert_id;
      $txnSuccess = true;
      $txnType = 'buy';
    }
  } else {
    $buyMsg = '<div class="alert alert-warning">Please <a href="client/login.php">login</a> to buy this property.</div>';
  }
}

// Handle rent request (NO immediate status change — pending admin approval)
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['rent_property'])) {
  if(!empty($_SESSION['client_id'])) {
    $cid = (int)$_SESSION['client_id'];
    $fullName = $conn->real_escape_string(trim($_POST['renter_name'] ?? ''));
    $email = $conn->real_escape_string(trim($_POST['renter_email'] ?? ''));
    $phone = $conn->real_escape_string(trim($_POST['renter_phone'] ?? ''));
    $address = $conn->real_escape_string(trim($_POST['renter_address'] ?? ''));
    $message = $conn->real_escape_string(trim($_POST['renter_message'] ?? ''));
    $rentPrice = (float)$prop['price'];

    // Check if client already has a pending request for this property
    $existing = $conn->query("SELECT id FROM property_transactions WHERE client_id=$cid AND property_id=$id AND transaction_type='rent' AND status='pending'")->num_rows;
    if($existing > 0) {
      $buyMsg = '<div class="alert alert-info"><i class="fas fa-info-circle me-2"></i>You already have a pending rental request for this property. Our team will contact you soon.</div>';
    } else {
      $conn->query("INSERT INTO property_transactions (client_id, property_id, transaction_type, full_name, email, phone, address, message, amount, status, admin_read)
        VALUES ($cid, $id, 'rent', '$fullName', '$email', '$phone', '$address', '$message', $rentPrice, 'pending', 0)");
      $txnId = $conn->insert_id;
      $txnSuccess = true;
      $txnType = 'rent';
    }
  } else {
    $buyMsg = '<div class="alert alert-warning">Please <a href="client/login.php">login</a> to rent this property.</div>';
  }
}

// Handle enquiry
$msg = '';
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['enquire'])) {
  $name = sanitize($_POST['name']);
  $email = sanitize($_POST['email']);
  $phone = sanitize($_POST['phone']);
  $message = sanitize($_POST['message']);
  $conn->query("INSERT INTO enquiries (name,email,phone,property_id,message) VALUES('$name','$email','$phone',$id,'$message')");
  $msg = '<div class="alert alert-success">Enquiry submitted! We will contact you soon.</div>';
}
?>

<div class="page-banner py-3">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-0">
        <li class="breadcrumb-item"><a href="index.php" class="text-white">Home</a></li>
        <li class="breadcrumb-item"><a href="properties.php" class="text-white">Properties</a></li>
        <li class="breadcrumb-item active text-white"><?= substr($prop['title'],0,30) ?></li>
      </ol>
    </nav>
  </div>
</div>

<section class="py-5">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-8">
        <!-- Main Image -->
        <?php $mainImg = $imgArr[0]['image_url'] ?? 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800'; ?>
        <img id="mainPropImg" src="<?= $mainImg ?>" alt="Property" class="detail-img-main mb-3 w-100">
        
        <!-- Thumbnails -->
        <div class="row g-2 mb-4">
          <?php 
          $roomTypes = ['hall','bedroom','bathroom','kitchen'];
          $roomImgs = [
            'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400',
            'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=400',
            'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=400',
            'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400',
          ];
          foreach($imgArr as $ti): ?>
          <div class="col-3">
            <img src="<?= $ti['image_url'] ?>" class="thumb-img w-100" alt="<?= $ti['image_type'] ?>">
            <small class="text-muted d-block text-center"><?= ucfirst($ti['image_type']) ?></small>
          </div>
          <?php endforeach;
          // Show room type images
          foreach($roomTypes as $ri => $rt): 
            if(!isset($imgArr[$ri])): ?>
          <div class="col-3">
            <img src="<?= $roomImgs[$ri] ?>" class="thumb-img w-100" alt="<?= $rt ?>">
            <small class="text-muted d-block text-center"><?= ucfirst($rt) ?></small>
          </div>
          <?php endif; endforeach; ?>
        </div>



        <!-- Details -->
        <div class="admin-card">
          <div class="d-flex justify-content-between align-items-start mb-3">
            <div>
              <span class="badge badge-<?= $prop['listing_type'] ?> me-2"><?= strtoupper($prop['listing_type']) ?></span>
              <span class="badge bg-secondary"><?= ucfirst($prop['type']) ?></span>
            </div>
            <div class="property-price"><?= formatPrice($prop['price']) ?><?= in_array($prop['listing_type'], ['rent','pg']) ? '/month' : '' ?></div>
          </div>
          
          <h3 class="fw-bold text-primary"><?= $prop['title'] ?></h3>
          <?php
            $verifyLevels = [
              ['Basic Verified','fa-check-circle','#4CAF50'],
              ['RERA Verified','fa-shield-alt','#2196F3'],
              ['Legal Verified','fa-gavel','#FF9800'],
              ['Premium Verified','fa-award','#9C27B0'],
              ['PropNexus Certified','fa-certificate','#FF6B35'],
            ];
            $vl = $verifyLevels[$id % 5];
          ?>
          <div class="mb-2">
            <span style="font-size:.78rem;font-weight:700;padding:4px 12px;border-radius:8px;background:<?=$vl[2]?>;color:white;display:inline-flex;align-items:center;gap:5px">
              <i class="fas <?=$vl[1]?>"></i> <?=$vl[0]?>
            </span>
          </div>
          <p class="text-muted"><i class="fas fa-map-marker-alt me-1 text-danger"></i><?= $prop['location'] ?>, <?= $prop['city'] ?>, <?= $prop['state'] ?> - <?= $prop['pincode'] ?></p>

          <div class="row g-3 my-3">
            <?php if($prop['bedrooms']): ?>
            <div class="col-3 text-center p-3" style="background:#f8f9fa;border-radius:12px">
              <i class="fas fa-bed fs-3 text-primary"></i>
              <div class="fw-bold"><?= $prop['bedrooms'] ?></div><small>Bedrooms</small>
            </div>
            <?php endif; ?>
            <?php if($prop['bathrooms']): ?>
            <div class="col-3 text-center p-3" style="background:#f8f9fa;border-radius:12px">
              <i class="fas fa-bath fs-3 text-info"></i>
              <div class="fw-bold"><?= $prop['bathrooms'] ?></div><small>Bathrooms</small>
            </div>
            <?php endif; ?>
            <div class="col-3 text-center p-3" style="background:#f8f9fa;border-radius:12px">
              <i class="fas fa-ruler-combined fs-3 text-success"></i>
              <div class="fw-bold"><?= $prop['area'] ?></div><small>Area</small>
            </div>
            <div class="col-3 text-center p-3" style="background:#f8f9fa;border-radius:12px">
              <i class="fas fa-circle fs-3 text-warning"></i>
              <div class="fw-bold"><?= ucfirst($prop['status']) ?></div><small>Status</small>
            </div>
          </div>

          <h5 class="fw-bold mt-4">Description</h5>
          <p class="text-muted"><?= nl2br($prop['description']) ?></p>

          <?php if($prop['amenities']): ?>
          <h5 class="fw-bold mt-4">Amenities</h5>
          <div class="d-flex flex-wrap gap-2">
            <?php foreach(explode(',', $prop['amenities']) as $a): ?>
            <span class="badge bg-success text-white px-3 py-2"><i class="fas fa-check me-1"></i><?= trim($a) ?></span>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        </div>


      </div>

      <!-- Sidebar -->
      <div class="col-lg-4">

        <?php if($txnSuccess): ?>
        <!-- STEP 3: Request Submitted Successfully -->
        <div class="admin-card mb-4" style="border:2px solid <?= $txnType==='buy'?'#10b981':'#3b82f6' ?>;overflow:hidden">
          <div class="text-center p-3 mb-3" style="background:<?= $txnType==='buy'?'linear-gradient(135deg,#10b981,#059669)':'linear-gradient(135deg,#3b82f6,#2563eb)' ?>;color:white;margin:-20px -20px 15px -20px;padding:20px !important">
            <div style="font-size:2.5rem">✅</div>
            <h5 class="fw-bold mb-1">Request Submitted!</h5>
            <small style="opacity:.85">Transaction #TXN<?= str_pad($txnId, 6, '0', STR_PAD_LEFT) ?></small>
          </div>
          <!-- Progress Steps -->
          <div class="d-flex justify-content-between align-items-center mb-4 px-2">
            <div class="text-center">
              <div style="width:36px;height:36px;border-radius:50%;background:#10b981;color:white;display:flex;align-items:center;justify-content:center;margin:0 auto;font-size:.85rem"><i class="fas fa-check"></i></div>
              <div style="font-size:.65rem;font-weight:600;margin-top:4px;color:#10b981">Details</div>
            </div>
            <div style="flex:1;height:3px;background:#10b981;margin:0 6px;border-radius:2px;margin-bottom:16px"></div>
            <div class="text-center">
              <div style="width:36px;height:36px;border-radius:50%;background:#10b981;color:white;display:flex;align-items:center;justify-content:center;margin:0 auto;font-size:.85rem"><i class="fas fa-check"></i></div>
              <div style="font-size:.65rem;font-weight:600;margin-top:4px;color:#10b981">Review</div>
            </div>
            <div style="flex:1;height:3px;background:#10b981;margin:0 6px;border-radius:2px;margin-bottom:16px"></div>
            <div class="text-center">
              <div style="width:36px;height:36px;border-radius:50%;background:#10b981;color:white;display:flex;align-items:center;justify-content:center;margin:0 auto;font-size:.85rem"><i class="fas fa-check"></i></div>
              <div style="font-size:.65rem;font-weight:600;margin-top:4px;color:#10b981">Submitted</div>
            </div>
          </div>
          <div class="text-center" style="font-size:.85rem;color:var(--text-muted)">
            <p class="mb-2">Your <strong><?= $txnType==='buy'?'purchase':'rental' ?></strong> request is now <span class="badge bg-warning text-dark">PENDING</span></p>
            <p class="mb-3" style="font-size:.78rem">Our team will review your details and <?= $txnType==='buy'?'process your purchase':'prepare the rental agreement' ?>. You will be notified once approved.</p>
            <a href="client/dashboard.php" class="btn btn-sm btn-accent rounded-pill px-4"><i class="fas fa-tachometer-alt me-1"></i>Go to Dashboard</a>
          </div>
        </div>
        <?php else: ?>
        <?php echo $buyMsg; ?>
        <?php endif; ?>

        <?php if($prop['status'] === 'sold'): ?>
        <div class="admin-card mb-4 text-center" style="background:linear-gradient(135deg,#dc3545,#c0392b);color:white;border:none">
          <div style="font-size:2.5rem">🏷️</div>
          <h4 class="fw-bold mb-1">SOLD</h4>
          <p class="mb-0" style="opacity:.85;font-size:.85rem">This property has been sold</p>
        </div>
        <?php elseif($prop['status'] === 'rented'): ?>
        <div class="admin-card mb-4 text-center" style="background:linear-gradient(135deg,#f59e0b,#d97706);color:white;border:none">
          <div style="font-size:2.5rem">🔑</div>
          <h4 class="fw-bold mb-1">RENTED</h4>
          <p class="mb-0" style="opacity:.85;font-size:.85rem">This property is currently rented</p>
        </div>
        <?php endif; ?>

        <?php if($prop['status'] === 'available' && $prop['listing_type'] === 'buy'): ?>
        <!-- Buy Property -->
        <div class="admin-card mb-4" style="border:2px solid #10b981">
          <div class="text-center">
            <div style="font-size:2rem">🏠</div>
            <h5 class="fw-bold mb-1">Interested in this property?</h5>
            <div class="fw-bold fs-4 mb-2" style="color:#FF6B35"><?= formatPrice($prop['price']) ?></div>
            <button type="button" class="btn w-100 fw-bold py-2" style="background:linear-gradient(135deg,#10b981,#059669);color:white;border-radius:25px;font-size:1rem" data-bs-toggle="modal" data-bs-target="#buyConfirmModal">
              <i class="fas fa-shopping-cart me-2"></i>Buy This Property
            </button>
            <small class="text-muted d-block mt-2" style="font-size:.72rem">Click to mark as purchased. Our team will contact you.</small>
          </div>
        </div>
        <?php endif; ?>

        <?php if($prop['status'] === 'available' && $prop['listing_type'] === 'rent'): ?>
        <!-- Rent Property -->
        <div class="admin-card mb-4" style="border:2px solid #3b82f6">
          <div class="text-center">
            <div style="font-size:2rem">🔑</div>
            <h5 class="fw-bold mb-1">Rent This Property</h5>
            <div class="fw-bold fs-4 mb-2" style="color:#FF6B35"><?= formatPrice($prop['price']) ?><small class="text-muted fw-normal" style="font-size:.55em">/month</small></div>
            <button type="button" class="btn w-100 fw-bold py-2" style="background:linear-gradient(135deg,#3b82f6,#2563eb);color:white;border-radius:25px;font-size:1rem" data-bs-toggle="modal" data-bs-target="#rentConfirmModal">
              <i class="fas fa-key me-2"></i>Rent This Property
            </button>
            <small class="text-muted d-block mt-2" style="font-size:.72rem">Click to rent. Monthly rent will be added to your dashboard.</small>
          </div>
        </div>
        <?php endif; ?>

        <!-- Enquiry Form -->
        <?php if($prop['status'] === 'available'): ?>
        <div class="admin-card mb-4">
          <h5 class="fw-bold mb-3">📩 Contact Owner</h5>
          <?= $msg ?>
          <form method="POST" action="property-detail.php?id=<?= $id ?>">
            <div class="mb-2">
              <input type="text" name="name" class="form-control" placeholder="Your Name" required value="<?= $_SESSION['client_name'] ?? '' ?>">
            </div>
            <div class="mb-2">
              <input type="email" name="email" class="form-control" placeholder="Email" required value="<?= $_SESSION['client_email'] ?? '' ?>">
            </div>
            <div class="mb-2">
              <input type="text" name="phone" class="form-control" placeholder="Phone Number" required>
            </div>
            <div class="mb-3">
              <textarea name="message" class="form-control" rows="4" placeholder="I'm interested in this property...">I am interested in this property. Please contact me.</textarea>
            </div>
            <button type="submit" name="enquire" class="btn btn-accent w-100">Send Enquiry</button>
          </form>
        </div>
        <?php endif; ?>

        <!-- Quick Info -->
        <div class="admin-card">
          <h5 class="fw-bold mb-3">Quick Info</h5>
          <table class="table table-borderless table-sm">
            <tr><td class="text-muted">Type</td><td class="fw-bold"><?= ucfirst($prop['type']) ?></td></tr>
            <tr><td class="text-muted">Listing</td><td class="fw-bold"><?= ucfirst($prop['listing_type']) ?></td></tr>
            <tr><td class="text-muted">City</td><td class="fw-bold"><?= $prop['city'] ?></td></tr>
            <tr><td class="text-muted">Area</td><td class="fw-bold"><?= $prop['area'] ?></td></tr>
            <tr><td class="text-muted">Price</td><td class="fw-bold text-accent"><?= formatPrice($prop['price']) ?></td></tr>
            <tr>
              <td class="text-muted">Status</td>
              <td>
                <?php if($prop['status'] === 'sold'): ?>
                  <span class="badge bg-danger px-3">SOLD</span>
                <?php elseif($prop['status'] === 'rented'): ?>
                  <span class="badge bg-warning text-dark px-3">RENTED</span>
                <?php else: ?>
                  <span class="badge bg-success px-3">AVAILABLE</span>
                <?php endif; ?>
              </td>
            </tr>
          </table>


          <a href="legal.php" class="btn btn-primary-custom w-100 mb-2">📄 Get Rental Agreement</a>
          <a href="loans.php" class="btn btn-outline-primary w-100">💰 Check Loan</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Buy 3-Step Wizard Modal -->
<?php if(isset($prop) && $prop['status'] === 'available' && $prop['listing_type'] === 'buy'): ?>
<div class="modal fade" id="buyConfirmModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow-lg" style="border-radius:16px;overflow:hidden">
      <div class="modal-header border-0" style="background:linear-gradient(135deg,#10b981,#059669);color:white">
        <h5 class="modal-title fw-bold"><i class="fas fa-shopping-cart me-2"></i>Purchase Property</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST" action="property-detail.php?id=<?= $id ?>" id="buyForm">
      <div class="modal-body p-4">
        <!-- Step Progress Bar -->
        <div class="d-flex align-items-center mb-4" id="buyProgress">
          <div class="text-center" style="flex-shrink:0">
            <div id="buyStep1Dot" style="width:32px;height:32px;border-radius:50%;background:#10b981;color:white;display:flex;align-items:center;justify-content:center;margin:0 auto;font-size:.75rem;font-weight:700">1</div>
            <div style="font-size:.62rem;font-weight:600;margin-top:3px;color:#10b981">Details</div>
          </div>
          <div id="buyLine1" style="flex:1;height:3px;background:#e5e7eb;margin:0 8px;border-radius:2px;margin-bottom:16px;transition:background .3s"></div>
          <div class="text-center" style="flex-shrink:0">
            <div id="buyStep2Dot" style="width:32px;height:32px;border-radius:50%;background:#e5e7eb;color:#9ca3af;display:flex;align-items:center;justify-content:center;margin:0 auto;font-size:.75rem;font-weight:700;transition:all .3s">2</div>
            <div id="buyStep2Lbl" style="font-size:.62rem;font-weight:600;margin-top:3px;color:#9ca3af;transition:color .3s">Review</div>
          </div>
          <div id="buyLine2" style="flex:1;height:3px;background:#e5e7eb;margin:0 8px;border-radius:2px;margin-bottom:16px;transition:background .3s"></div>
          <div class="text-center" style="flex-shrink:0">
            <div id="buyStep3Dot" style="width:32px;height:32px;border-radius:50%;background:#e5e7eb;color:#9ca3af;display:flex;align-items:center;justify-content:center;margin:0 auto;font-size:.75rem;font-weight:700;transition:all .3s">3</div>
            <div id="buyStep3Lbl" style="font-size:.62rem;font-weight:600;margin-top:3px;color:#9ca3af;transition:color .3s">Submit</div>
          </div>
        </div>

        <!-- STEP 1: Fill Details -->
        <div id="buyStep1">
          <div class="d-flex align-items-center gap-3 p-3 rounded-3 mb-3" style="background:#f0fdf4;border:1px solid #bbf7d0">
            <div style="font-size:2rem">🏠</div>
            <div style="flex:1">
              <h6 class="fw-bold mb-0" style="font-size:.9rem"><?= htmlspecialchars($prop['title']) ?></h6>
              <small class="text-muted"><i class="fas fa-map-marker-alt me-1"></i><?= htmlspecialchars($prop['location'] . ', ' . $prop['city']) ?></small>
            </div>
            <div class="fw-bold fs-5" style="color:#FF6B35"><?= formatPrice($prop['price']) ?></div>
          </div>
          <h6 class="fw-bold mb-3" style="color:#1a3c5e"><i class="fas fa-user-circle me-2"></i>Step 1: Fill Your Details</h6>
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label small fw-bold">Full Name <span class="text-danger">*</span></label>
              <input type="text" name="buyer_name" id="buyName" class="form-control" placeholder="Enter your full name" required value="<?= $_SESSION['client_name'] ?? '' ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Email Address <span class="text-danger">*</span></label>
              <input type="email" name="buyer_email" id="buyEmail" class="form-control" placeholder="your@email.com" required value="<?= $_SESSION['client_email'] ?? '' ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Phone Number <span class="text-danger">*</span></label>
              <input type="tel" name="buyer_phone" id="buyPhone" class="form-control" placeholder="10-digit mobile number" required pattern="[0-9]{10}">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Current Address</label>
              <input type="text" name="buyer_address" id="buyAddr" class="form-control" placeholder="Your current address">
            </div>
            <div class="col-12">
              <label class="form-label small fw-bold">Message / Notes</label>
              <textarea name="buyer_message" id="buyMsg" class="form-control" rows="2" placeholder="Any specific requirements or questions..."></textarea>
            </div>
          </div>
        </div>

        <!-- STEP 2: Review -->
        <div id="buyStep2" style="display:none">
          <h6 class="fw-bold mb-3" style="color:#1a3c5e"><i class="fas fa-clipboard-check me-2"></i>Step 2: Review Your Request</h6>
          <div class="p-3 rounded-3 mb-3" style="background:#f0fdf4;border:1px solid #bbf7d0">
            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted" style="font-size:.82rem">Property</span>
              <strong style="font-size:.85rem"><?= htmlspecialchars($prop['title']) ?></strong>
            </div>
            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted" style="font-size:.82rem">Location</span>
              <span style="font-size:.85rem"><?= htmlspecialchars($prop['location'] . ', ' . $prop['city']) ?></span>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted" style="font-size:.82rem">Price</span>
              <strong style="font-size:.85rem;color:#FF6B35"><?= formatPrice($prop['price']) ?></strong>
            </div>
          </div>
          <div class="p-3 rounded-3 mb-3" style="background:#f8fafc;border:1px solid var(--border-c,#e2e8f0)">
            <h6 class="fw-bold mb-2" style="font-size:.82rem;color:#1a3c5e">Your Details</h6>
            <table class="table table-sm table-borderless mb-0" style="font-size:.82rem">
              <tr><td class="text-muted" style="width:120px">Name</td><td class="fw-bold" id="buyRevName"></td></tr>
              <tr><td class="text-muted">Email</td><td id="buyRevEmail"></td></tr>
              <tr><td class="text-muted">Phone</td><td id="buyRevPhone"></td></tr>
              <tr><td class="text-muted">Address</td><td id="buyRevAddr"></td></tr>
              <tr><td class="text-muted">Message</td><td id="buyRevMsg"></td></tr>
            </table>
          </div>
          <div class="alert alert-warning mb-0" style="border-radius:12px;font-size:.8rem">
            <i class="fas fa-info-circle me-1"></i>
            Your request will be sent to our team for review. The property will <strong>NOT</strong> be marked as sold until admin approves your request.
          </div>
        </div>
      </div>

      <div class="modal-footer border-0 pt-0 px-4 pb-4 gap-2">
        <button type="button" class="btn btn-light px-4 rounded-pill" data-bs-dismiss="modal" id="buyCancelBtn">Cancel</button>
        <button type="button" id="buyBackBtn" class="btn btn-outline-secondary px-4 rounded-pill" style="display:none" onclick="buyGoStep(1)"><i class="fas fa-arrow-left me-1"></i>Back</button>
        <button type="button" id="buyNextBtn" class="btn px-5 rounded-pill fw-bold flex-fill" style="background:linear-gradient(135deg,#10b981,#059669);color:white;max-width:280px" onclick="buyGoStep(2)">
          Next: Review <i class="fas fa-arrow-right ms-1"></i>
        </button>
        <button type="submit" name="buy_property" value="1" id="buySubmitBtn" class="btn px-5 rounded-pill fw-bold flex-fill" style="display:none;background:linear-gradient(135deg,#10b981,#059669);color:white;max-width:280px">
          <i class="fas fa-paper-plane me-1"></i>Submit Request
        </button>
      </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Rent 3-Step Wizard Modal -->
<?php if(isset($prop) && $prop['status'] === 'available' && ($prop['listing_type'] === 'rent' || $prop['listing_type'] === 'pg')): ?>
<div class="modal fade" id="rentConfirmModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow-lg" style="border-radius:16px;overflow:hidden">
      <div class="modal-header border-0" style="background:linear-gradient(135deg,#3b82f6,#2563eb);color:white">
        <h5 class="modal-title fw-bold"><i class="fas fa-key me-2"></i>Rent Property</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST" action="property-detail.php?id=<?= $id ?>" id="rentForm">
      <div class="modal-body p-4">
        <!-- Step Progress Bar -->
        <div class="d-flex align-items-center mb-4">
          <div class="text-center" style="flex-shrink:0">
            <div id="rentStep1Dot" style="width:32px;height:32px;border-radius:50%;background:#3b82f6;color:white;display:flex;align-items:center;justify-content:center;margin:0 auto;font-size:.75rem;font-weight:700">1</div>
            <div style="font-size:.62rem;font-weight:600;margin-top:3px;color:#3b82f6">Details</div>
          </div>
          <div id="rentLine1" style="flex:1;height:3px;background:#e5e7eb;margin:0 8px;border-radius:2px;margin-bottom:16px;transition:background .3s"></div>
          <div class="text-center" style="flex-shrink:0">
            <div id="rentStep2Dot" style="width:32px;height:32px;border-radius:50%;background:#e5e7eb;color:#9ca3af;display:flex;align-items:center;justify-content:center;margin:0 auto;font-size:.75rem;font-weight:700;transition:all .3s">2</div>
            <div id="rentStep2Lbl" style="font-size:.62rem;font-weight:600;margin-top:3px;color:#9ca3af;transition:color .3s">Review</div>
          </div>
          <div id="rentLine2" style="flex:1;height:3px;background:#e5e7eb;margin:0 8px;border-radius:2px;margin-bottom:16px;transition:background .3s"></div>
          <div class="text-center" style="flex-shrink:0">
            <div id="rentStep3Dot" style="width:32px;height:32px;border-radius:50%;background:#e5e7eb;color:#9ca3af;display:flex;align-items:center;justify-content:center;margin:0 auto;font-size:.75rem;font-weight:700;transition:all .3s">3</div>
            <div id="rentStep3Lbl" style="font-size:.62rem;font-weight:600;margin-top:3px;color:#9ca3af;transition:color .3s">Submit</div>
          </div>
        </div>

        <!-- STEP 1: Fill Details -->
        <div id="rentStep1">
          <div class="d-flex align-items-center gap-3 p-3 rounded-3 mb-3" style="background:#eff6ff;border:1px solid #bfdbfe">
            <div style="font-size:2rem">🔑</div>
            <div style="flex:1">
              <h6 class="fw-bold mb-0" style="font-size:.9rem"><?= htmlspecialchars($prop['title']) ?></h6>
              <small class="text-muted"><i class="fas fa-map-marker-alt me-1"></i><?= htmlspecialchars($prop['location'] . ', ' . $prop['city']) ?></small>
            </div>
            <div>
              <div class="fw-bold fs-5" style="color:#FF6B35"><?= formatPrice($prop['price']) ?></div>
              <div class="text-muted text-end" style="font-size:.72rem">per month</div>
            </div>
          </div>
          <h6 class="fw-bold mb-3" style="color:#1a3c5e"><i class="fas fa-user-circle me-2"></i>Step 1: Fill Your Details</h6>
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label small fw-bold">Full Name <span class="text-danger">*</span></label>
              <input type="text" name="renter_name" id="rentName" class="form-control" placeholder="Enter your full name" required value="<?= $_SESSION['client_name'] ?? '' ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Email Address <span class="text-danger">*</span></label>
              <input type="email" name="renter_email" id="rentEmail" class="form-control" placeholder="your@email.com" required value="<?= $_SESSION['client_email'] ?? '' ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Phone Number <span class="text-danger">*</span></label>
              <input type="tel" name="renter_phone" id="rentPhone" class="form-control" placeholder="10-digit mobile number" required pattern="[0-9]{10}">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-bold">Current Address</label>
              <input type="text" name="renter_address" id="rentAddr" class="form-control" placeholder="Your current address">
            </div>
            <div class="col-12">
              <label class="form-label small fw-bold">Message / Notes</label>
              <textarea name="renter_message" id="rentMsg" class="form-control" rows="2" placeholder="Move-in date, number of occupants, etc..."></textarea>
            </div>
          </div>
        </div>

        <!-- STEP 2: Review -->
        <div id="rentStep2" style="display:none">
          <h6 class="fw-bold mb-3" style="color:#1a3c5e"><i class="fas fa-clipboard-check me-2"></i>Step 2: Review Your Request</h6>
          <div class="p-3 rounded-3 mb-3" style="background:#eff6ff;border:1px solid #bfdbfe">
            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted" style="font-size:.82rem">Property</span>
              <strong style="font-size:.85rem"><?= htmlspecialchars($prop['title']) ?></strong>
            </div>
            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted" style="font-size:.82rem">Location</span>
              <span style="font-size:.85rem"><?= htmlspecialchars($prop['location'] . ', ' . $prop['city']) ?></span>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted" style="font-size:.82rem">Monthly Rent</span>
              <strong style="font-size:.85rem;color:#FF6B35">₹<?= number_format($prop['price']) ?>/mo</strong>
            </div>
          </div>
          <div class="p-3 rounded-3 mb-3" style="background:#f8fafc;border:1px solid var(--border-c,#e2e8f0)">
            <h6 class="fw-bold mb-2" style="font-size:.82rem;color:#1a3c5e">Your Details</h6>
            <table class="table table-sm table-borderless mb-0" style="font-size:.82rem">
              <tr><td class="text-muted" style="width:120px">Name</td><td class="fw-bold" id="rentRevName"></td></tr>
              <tr><td class="text-muted">Email</td><td id="rentRevEmail"></td></tr>
              <tr><td class="text-muted">Phone</td><td id="rentRevPhone"></td></tr>
              <tr><td class="text-muted">Address</td><td id="rentRevAddr"></td></tr>
              <tr><td class="text-muted">Message</td><td id="rentRevMsg"></td></tr>
            </table>
          </div>
          <div class="alert alert-info mb-0" style="border-radius:12px;font-size:.8rem">
            <i class="fas fa-info-circle me-1"></i>
            Your rental request will be sent to our team. The property will remain <strong>available</strong> until admin approves your request and processes the rental agreement.
          </div>
        </div>
      </div>

      <div class="modal-footer border-0 pt-0 px-4 pb-4 gap-2">
        <button type="button" class="btn btn-light px-4 rounded-pill" data-bs-dismiss="modal" id="rentCancelBtn">Cancel</button>
        <button type="button" id="rentBackBtn" class="btn btn-outline-secondary px-4 rounded-pill" style="display:none" onclick="rentGoStep(1)"><i class="fas fa-arrow-left me-1"></i>Back</button>
        <button type="button" id="rentNextBtn" class="btn px-5 rounded-pill fw-bold flex-fill" style="background:linear-gradient(135deg,#3b82f6,#2563eb);color:white;max-width:280px" onclick="rentGoStep(2)">
          Next: Review <i class="fas fa-arrow-right ms-1"></i>
        </button>
        <button type="submit" name="rent_property" value="1" id="rentSubmitBtn" class="btn px-5 rounded-pill fw-bold flex-fill" style="display:none;background:linear-gradient(135deg,#3b82f6,#2563eb);color:white;max-width:280px">
          <i class="fas fa-paper-plane me-1"></i>Submit Request
        </button>
      </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
// Buy wizard step navigation
function buyGoStep(step) {
  if(step === 2) {
    // Validate step 1
    var name = document.getElementById('buyName').value.trim();
    var email = document.getElementById('buyEmail').value.trim();
    var phone = document.getElementById('buyPhone').value.trim();
    if(!name || !email || !phone || phone.length !== 10) {
      alert('Please fill all required fields (Name, Email, Phone) with valid data.');
      return;
    }
    // Populate review
    document.getElementById('buyRevName').textContent = name;
    document.getElementById('buyRevEmail').textContent = email;
    document.getElementById('buyRevPhone').textContent = phone;
    document.getElementById('buyRevAddr').textContent = document.getElementById('buyAddr').value.trim() || '—';
    document.getElementById('buyRevMsg').textContent = document.getElementById('buyMsg').value.trim() || '—';
    // Show step 2
    document.getElementById('buyStep1').style.display = 'none';
    document.getElementById('buyStep2').style.display = 'block';
    document.getElementById('buyNextBtn').style.display = 'none';
    document.getElementById('buySubmitBtn').style.display = '';
    document.getElementById('buyBackBtn').style.display = '';
    // Update progress
    document.getElementById('buyStep2Dot').style.background = '#10b981';
    document.getElementById('buyStep2Dot').style.color = 'white';
    document.getElementById('buyStep2Lbl').style.color = '#10b981';
    document.getElementById('buyLine1').style.background = '#10b981';
  } else {
    document.getElementById('buyStep1').style.display = 'block';
    document.getElementById('buyStep2').style.display = 'none';
    document.getElementById('buyNextBtn').style.display = '';
    document.getElementById('buySubmitBtn').style.display = 'none';
    document.getElementById('buyBackBtn').style.display = 'none';
    document.getElementById('buyStep2Dot').style.background = '#e5e7eb';
    document.getElementById('buyStep2Dot').style.color = '#9ca3af';
    document.getElementById('buyStep2Lbl').style.color = '#9ca3af';
    document.getElementById('buyLine1').style.background = '#e5e7eb';
  }
}

// Rent wizard step navigation
function rentGoStep(step) {
  if(step === 2) {
    var name = document.getElementById('rentName').value.trim();
    var email = document.getElementById('rentEmail').value.trim();
    var phone = document.getElementById('rentPhone').value.trim();
    if(!name || !email || !phone || phone.length !== 10) {
      alert('Please fill all required fields (Name, Email, Phone) with valid data.');
      return;
    }
    document.getElementById('rentRevName').textContent = name;
    document.getElementById('rentRevEmail').textContent = email;
    document.getElementById('rentRevPhone').textContent = phone;
    document.getElementById('rentRevAddr').textContent = document.getElementById('rentAddr').value.trim() || '—';
    document.getElementById('rentRevMsg').textContent = document.getElementById('rentMsg').value.trim() || '—';
    document.getElementById('rentStep1').style.display = 'none';
    document.getElementById('rentStep2').style.display = 'block';
    document.getElementById('rentNextBtn').style.display = 'none';
    document.getElementById('rentSubmitBtn').style.display = '';
    document.getElementById('rentBackBtn').style.display = '';
    document.getElementById('rentStep2Dot').style.background = '#3b82f6';
    document.getElementById('rentStep2Dot').style.color = 'white';
    document.getElementById('rentStep2Lbl').style.color = '#3b82f6';
    document.getElementById('rentLine1').style.background = '#3b82f6';
  } else {
    document.getElementById('rentStep1').style.display = 'block';
    document.getElementById('rentStep2').style.display = 'none';
    document.getElementById('rentNextBtn').style.display = '';
    document.getElementById('rentSubmitBtn').style.display = 'none';
    document.getElementById('rentBackBtn').style.display = 'none';
    document.getElementById('rentStep2Dot').style.background = '#e5e7eb';
    document.getElementById('rentStep2Dot').style.color = '#9ca3af';
    document.getElementById('rentStep2Lbl').style.color = '#9ca3af';
    document.getElementById('rentLine1').style.background = '#e5e7eb';
  }
}
</script>

<?php require_once 'includes/footer.php'; ?>
