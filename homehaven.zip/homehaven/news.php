<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/config.php';

$page    = max(1, intval($_GET['page'] ?? 1));
$rawCat  = isset($_GET['cat']) ? $_GET['cat'] : 'all';
$cat     = $conn->real_escape_string($rawCat);
$perPage = 9;
$offset  = ($page - 1) * $perPage;

$cats      = array('all'=>'All', 'news'=>'News', 'guide'=>'Guides', 'tips'=>'Tips', 'market'=>'Market');
$catEmoji  = array('all'=>'', 'news'=>'&#128240; ', 'guide'=>'&#128218; ', 'tips'=>'&#128161; ', 'market'=>'&#128202; ');
$catColors = array('all'=>'#1a3c5e', 'news'=>'#dc3545', 'guide'=>'#2d6a4f', 'tips'=>'#FF6B35', 'market'=>'#6f42c1');

$where = ($cat !== 'all') ? "AND category='" . $cat . "'" : '';

$totalRow   = $conn->query("SELECT COUNT(*) as c FROM news_guides WHERE status='published' " . $where);
$total      = 0;
if ($totalRow) {
    $totalRow = $totalRow->fetch_assoc();
    $total    = (int)$totalRow['c'];
}
$totalPages = ($total > 0) ? (int)ceil($total / $perPage) : 1;

$articles = $conn->query("SELECT * FROM news_guides WHERE status='published' " . $where . " ORDER BY created_at DESC LIMIT " . $perPage . " OFFSET " . $offset);
$featRes  = $conn->query("SELECT * FROM news_guides WHERE status='published' ORDER BY views DESC LIMIT 1");
$featured = ($featRes) ? $featRes->fetch_assoc() : null;
$popular  = $conn->query("SELECT * FROM news_guides WHERE status='published' ORDER BY views DESC LIMIT 5");

$pageTitle = 'News & Guides';
require_once 'includes/header.php';
?>
<style>
.art-card{background:var(--card-bg,#fff);border-radius:16px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.08);transition:.3s;height:100%;border:1px solid var(--border-color,#eee)}
.art-card:hover{transform:translateY(-6px);box-shadow:0 12px 40px rgba(0,0,0,.15)}
.art-img{height:200px;overflow:hidden}
.art-img img{width:100%;height:100%;object-fit:cover;transition:.4s}
.art-card:hover .art-img img{transform:scale(1.06)}
.cat-btn{padding:8px 20px;border-radius:25px;border:2px solid;font-weight:600;cursor:pointer;transition:.3s;font-size:.83rem;text-decoration:none;display:inline-block}
.hero-art{background:var(--card-bg,#fff);border-radius:20px;overflow:hidden;box-shadow:0 8px 30px rgba(0,0,0,.12)}
.sidebar-art{padding:12px 0;border-bottom:1px solid var(--border-color,#eee);display:flex;gap:12px;align-items:flex-start}
.sidebar-art:last-child{border-bottom:none}
.sidebar-art img{width:65px;height:55px;object-fit:cover;border-radius:8px;flex-shrink:0}
.news-hero{background:linear-gradient(135deg,#1a3c5e,#2d6a4f);padding:60px 0;color:white}
.sbox{background:var(--card-bg,#fff);border-radius:16px;padding:24px;box-shadow:0 4px 20px rgba(0,0,0,.08);border:1px solid var(--border-color,#eee);margin-bottom:20px}
body.dark-mode .art-card,body.dark-mode .hero-art,body.dark-mode .sbox{background:#1a2535 !important;border-color:#2d3748}
</style>

<section class="news-hero">
  <div class="container">
    <div class="text-center mb-4">
      <h1 class="fw-bold mb-2">&#128240; News &amp; Guides</h1>
      <p class="opacity-75 mb-0">Real estate insights, buyer guides, market reports &amp; expert tips</p>
    </div>
    <div class="d-flex justify-content-center flex-wrap gap-2">
      <?php
      foreach ($cats as $key => $label) {
          $color    = isset($catColors[$key]) ? $catColors[$key] : '#1a3c5e';
          $isActive = ($cat === $key);
          $emoji    = isset($catEmoji[$key]) ? $catEmoji[$key] : '';
          if ($isActive) {
              $btnStyle = 'border-color:' . $color . ';color:white;background:' . $color;
          } else {
              $btnStyle = 'border-color:rgba(255,255,255,.6);color:rgba(255,255,255,.9);background:transparent';
          }
          echo '<a href="news.php?cat=' . $key . '" class="cat-btn" style="' . $btnStyle . '">' . $emoji . $label . '</a>' . "\n";
      }
      ?>
    </div>
  </div>
</section>

<div class="container py-5">
  <div class="row g-4">

    <div class="col-lg-8">

      <?php
      if ($page === 1 && $featured && $cat === 'all') {
          $fColor = isset($catColors[$featured['category']]) ? $catColors[$featured['category']] : '#1a3c5e';
          $fImg   = !empty($featured['image_url']) ? $featured['image_url'] : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600';
          $fExc   = !empty($featured['excerpt']) ? htmlspecialchars(substr($featured['excerpt'], 0, 140)) . '...' : '';
      ?>
      <div class="hero-art mb-4">
        <div class="row g-0">
          <div class="col-md-6">
            <img src="<?php echo $fImg; ?>" style="width:100%;height:260px;object-fit:cover" alt="Featured">
          </div>
          <div class="col-md-6 p-4 d-flex flex-column justify-content-center">
            <div class="mb-2">
              <span class="badge px-3 py-1 me-1" style="background:<?php echo $fColor; ?>"><?php echo strtoupper($featured['category']); ?></span>
              <span class="badge bg-warning text-dark">&#128293; Most Read</span>
            </div>
            <h4 class="fw-bold mb-2"><?php echo htmlspecialchars($featured['title']); ?></h4>
            <p class="text-muted mb-3" style="font-size:.88rem"><?php echo $fExc; ?></p>
            <div class="d-flex justify-content-between align-items-center">
              <small class="text-muted"><i class="fas fa-eye me-1"></i><?php echo number_format((int)$featured['views']); ?> views</small>
              <a href="news-detail.php?slug=<?php echo htmlspecialchars($featured['slug']); ?>" class="btn btn-accent btn-sm px-4 rounded-pill">Read More</a>
            </div>
          </div>
        </div>
      </div>
      <?php } ?>

      <div class="row g-4">
        <?php
        if ($articles && $articles->num_rows > 0) {
            while ($a = $articles->fetch_assoc()) {
                $aColor = isset($catColors[$a['category']]) ? $catColors[$a['category']] : '#1a3c5e';
                $aImg   = !empty($a['image_url']) ? $a['image_url'] : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600';
                $aExc   = !empty($a['excerpt']) ? htmlspecialchars(substr($a['excerpt'], 0, 100)) . '...' : '';
        ?>
        <div class="col-md-6">
          <div class="art-card">
            <div class="art-img"><img src="<?php echo $aImg; ?>" alt="<?php echo htmlspecialchars($a['title']); ?>"></div>
            <div class="p-3">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="badge px-2 py-1" style="background:<?php echo $aColor; ?>;font-size:.7rem"><?php echo strtoupper($a['category']); ?></span>
                <small class="text-muted"><i class="fas fa-eye me-1"></i><?php echo number_format((int)$a['views']); ?></small>
              </div>
              <h6 class="fw-bold mb-2" style="line-height:1.4"><?php echo htmlspecialchars($a['title']); ?></h6>
              <p class="text-muted mb-3" style="font-size:.8rem;line-height:1.5"><?php echo $aExc; ?></p>
              <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted"><i class="fas fa-user me-1"></i><?php echo htmlspecialchars($a['author']); ?></small>
                <a href="news-detail.php?slug=<?php echo htmlspecialchars($a['slug']); ?>" class="btn btn-outline-primary btn-sm rounded-pill px-3">Read</a>
              </div>
            </div>
          </div>
        </div>
        <?php
            }
        } else {
        ?>
        <div class="col-12 text-center py-5">
          <i class="fas fa-newspaper fa-3x text-muted mb-3"></i>
          <p class="text-muted">No articles found.</p>
          <a href="news.php" class="btn btn-accent rounded-pill px-4">View All</a>
        </div>
        <?php } ?>
      </div>

      <?php if ($totalPages > 1) { ?>
      <nav class="mt-5">
        <ul class="pagination justify-content-center">
          <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
          <li class="page-item <?php echo ($i === $page) ? 'active' : ''; ?>">
            <a class="page-link rounded-circle mx-1" href="news.php?page=<?php echo $i; ?>&cat=<?php echo $cat; ?>" style="width:40px;height:40px;display:flex;align-items:center;justify-content:center"><?php echo $i; ?></a>
          </li>
          <?php } ?>
        </ul>
      </nav>
      <?php } ?>

    </div><!-- col-lg-8 -->

    <div class="col-lg-4">

      <div class="sbox">
        <h6 class="fw-bold mb-3">&#128293; Most Popular</h6>
        <?php
        if ($popular) {
            while ($pop = $popular->fetch_assoc()) {
                $popImg = !empty($pop['image_url']) ? $pop['image_url'] : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=200';
        ?>
        <div class="sidebar-art">
          <img src="<?php echo $popImg; ?>" alt="">
          <div>
            <a href="news-detail.php?slug=<?php echo htmlspecialchars($pop['slug']); ?>" class="fw-bold text-decoration-none" style="font-size:.82rem;color:var(--text-main,#222)"><?php echo htmlspecialchars($pop['title']); ?></a>
            <div class="text-muted mt-1" style="font-size:.72rem"><i class="fas fa-eye me-1"></i><?php echo number_format((int)$pop['views']); ?> views</div>
          </div>
        </div>
        <?php
            }
        }
        ?>
      </div>

      <div class="sbox">
        <h6 class="fw-bold mb-3">&#128194; Browse by Category</h6>
        <div class="d-flex flex-column gap-2">
          <?php
          foreach ($cats as $key => $label) {
              $color    = isset($catColors[$key]) ? $catColors[$key] : '#1a3c5e';
              $emoji    = isset($catEmoji[$key]) ? $catEmoji[$key] : '';
              $isActive = ($cat === $key);
              $bg       = $isActive ? $color : 'var(--section-bg,#f8f9fa)';
              $fg       = $isActive ? 'white' : 'var(--text-main,#333)';
              $cSql     = "SELECT COUNT(*) as c FROM news_guides WHERE status='published'";
              if ($key !== 'all') { $cSql .= " AND category='" . $key . "'"; }
              $cRes = $conn->query($cSql);
              $cnt  = ($cRes) ? (int)$cRes->fetch_assoc()['c'] : 0;
              echo '<a href="news.php?cat=' . $key . '" class="d-flex justify-content-between align-items-center py-2 px-3 rounded-3 text-decoration-none" style="background:' . $bg . ';color:' . $fg . ';font-weight:500;font-size:.85rem">' . $emoji . $label . '<span class="badge" style="background:' . $color . '">' . $cnt . '</span></a>' . "\n";
          }
          ?>
        </div>
      </div>

      <div class="sbox" style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f)!important">
        <h6 class="fw-bold mb-3 text-white">&#9889; Quick Links</h6>
        <div class="d-flex flex-column gap-2">
          <?php
          $quickLinks = array(
              array('&#127968; Buy Property',    'properties.php?type=buy'),
              array('&#128273; Rent Property',   'properties.php?type=rent'),
              array('&#128717; Find PG',         'properties.php?type=pg'),
              array('&#128176; Home Loan',        'loans.php'),
              array('&#9878; Legal Services',     'legal.php'),
              array('&#128196; Rent Receipt',     'client/rent-payment.php'),
          );
          foreach ($quickLinks as $ql) {
              echo '<a href="' . $ql[1] . '" class="text-white text-decoration-none py-2 px-3 rounded-3" style="background:rgba(255,255,255,.1);font-size:.83rem" onmouseover="this.style.background=\'rgba(255,255,255,.2)\'" onmouseout="this.style.background=\'rgba(255,255,255,.1)\'">' . $ql[0] . '</a>' . "\n";
          }
          ?>
        </div>
      </div>

    </div><!-- sidebar -->
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
