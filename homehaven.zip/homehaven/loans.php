<?php
$pageTitle = 'Property Loan Tracker';
require_once 'includes/header.php';

$clientId = !empty($_SESSION['client_id']) ? (int)$_SESSION['client_id'] : 0;
$msg = '';

// Handle Step 1: Loan Application
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['apply_loan'])) {
    $lname   = sanitize($_POST['full_name'] ?? '');
    $lphone  = sanitize($_POST['phone'] ?? '');
    $lemail  = sanitize($_POST['email'] ?? '');
    $lbank   = sanitize($_POST['bank_name'] ?? '');
    $lamount = sanitize($_POST['loan_amount'] ?? '');
    $lincome = sanitize($_POST['monthly_income'] ?? '');
    $lprop   = sanitize($_POST['property_type'] ?? '');
    $lemploy = sanitize($_POST['employment'] ?? 'Salaried');
    $propId  = (int)($_POST['property_id'] ?? 0);
    $propVal = $propId > 0 ? $propId : 'NULL';
    $cidVal  = $clientId > 0 ? $clientId : 'NULL';
    if ($lname && $lphone && $lbank) {
        $conn->query("INSERT INTO loan_applications (client_id,full_name,phone,email,bank_name,loan_amount,monthly_income,property_type,property_id,employment,current_step,status)
            VALUES($cidVal,'$lname','$lphone','$lemail','$lbank','$lamount','$lincome','$lprop',$propVal,'$lemploy',2,'documents_required')");
        $newAppId = $conn->insert_id;
        $msg = '<div class="alert alert-success alert-dismissible fade show rounded-3"><i class="fas fa-check-circle me-2"></i><strong>Application submitted!</strong> Please upload your documents below. Application ID: #' . $newAppId . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    }
}

// Handle Step 2: Document Information Submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['upload_docs'])) {
    $appId = (int)$_POST['application_id'];
    $docTypes = ['pan_card','aadhar_card','salary_slip','bank_statement','property_doc'];
    $docCount = 0;
    foreach ($docTypes as $dt) {
        $docValue = sanitize($_POST[$dt] ?? '');
        if (!empty($docValue)) {
            $conn->query("INSERT INTO loan_documents (application_id,doc_type,file_name,file_path) VALUES($appId,'$dt','$docValue','entered_manually')");
            $docCount++;
        }
    }
    if ($docCount > 0) {
        $conn->query("UPDATE loan_applications SET current_step=3, status='under_review' WHERE id=$appId");
        $msg = '<div class="alert alert-success alert-dismissible fade show rounded-3"><i class="fas fa-check-circle me-2"></i><strong>' . $docCount . ' document(s) submitted!</strong> Your application is now under review.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    } else {
        $msg = '<div class="alert alert-warning rounded-3"><i class="fas fa-exclamation-triangle me-2"></i>Please enter at least one document number.</div>';
    }
}

// Get user's loan applications
$myLoans = null;
if ($clientId > 0) {
    $myLoans = $conn->query("SELECT la.*, GROUP_CONCAT(ld.doc_type) as uploaded_docs
        FROM loan_applications la
        LEFT JOIN loan_documents ld ON la.id=ld.application_id
        WHERE la.client_id=$clientId
        GROUP BY la.id ORDER BY la.created_at DESC");
}

// Bank data
$loans = $conn->query("SELECT * FROM loan_services ORDER BY interest_rate ASC");
$homeLoans = []; $commLoans = [];
if ($loans && $loans->num_rows > 0) {
    while ($l = $loans->fetch_assoc()) {
        if (stripos($l['loan_type'], 'commercial') !== false) $commLoans[] = $l;
        else $homeLoans[] = $l;
    }
}

$bankColors = [
    'SBI'=>['#2d5be3','#1a3a8f'],'HDFC'=>['#e60026','#a00019'],'ICICI'=>['#F37021','#b04e0d'],
    'Axis'=>['#800000','#500000'],'Kotak'=>['#ed1c24','#a0121a'],'Bank of Baroda'=>['#f26522','#b04a15'],
    'PNB'=>['#003087','#001a5e'],'LIC'=>['#00843d','#005528'],'Bajaj'=>['#00439c','#002a6e'],
    'IDFC'=>['#0066b3','#003d6e'],'Tata'=>['#0f3e6e','#082340'],'Indiabulls'=>['#e31837','#9c0f23'],
];
function getBankColor2($name, $bc) {
    foreach ($bc as $key => $clr) { if (stripos($name, $key) !== false) return $clr; }
    return ['#1a3c5e','#0d2035'];
}

$stepMeta = [
    1 => ['📝','Application','Fill your details','#FF6B35'],
    2 => ['📄','Documents','Upload required docs','#1a3c5e'],
    3 => ['🔍','Verification','Under admin review','#2d6a4f'],
    4 => ['✅','Approval','Loan decision','#6f42c1'],
    5 => ['📊','Disbursement','Loan sanctioned','#dc3545'],
];
$statusColors = [
    'pending'=>'#f59e0b','documents_required'=>'#3b82f6','under_review'=>'#8b5cf6',
    'verified'=>'#10b981','approved'=>'#059669','rejected'=>'#ef4444'
];
$statusLabels = [
    'pending'=>'⏳ Pending','documents_required'=>'📄 Docs Required','under_review'=>'🔍 Under Review',
    'verified'=>'✅ Verified','approved'=>'🎉 Approved','rejected'=>'❌ Rejected'
];
?>

<div class="page-banner">
  <div class="container text-center">
    <h2 class="fw-bold mb-2">💰 Property Loan Tracker</h2>
    <p class="opacity-75 mb-0">Apply · Upload Documents · Track Approval — All in one place</p>
  </div>
</div>

<section class="py-5">
  <div class="container">
    <?= $msg ?>

    <!-- ═══════ STEP PROGRESS VISUAL ═══════ -->
    <div class="row justify-content-center mb-5">
      <div class="col-lg-10">
        <div class="step-progress-bar">
          <?php foreach($stepMeta as $i => $s): ?>
          <div class="step-item">
            <div class="step-circle" style="background:<?=$s[3]?>"><?=$s[0]?></div>
            <div class="step-label"><?=$s[1]?></div>
            <div class="step-sub"><?=$s[2]?></div>
          </div>
          <?php if($i < 5): ?><div class="step-line"></div><?php endif; ?>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- ═══════ NAVIGATION TABS ═══════ -->
    <div class="d-flex justify-content-center gap-2 mb-4 flex-wrap">
      <button class="loan-tab active" onclick="showSection('apply',this)">📝 Apply Now</button>
      <?php if($clientId > 0): ?>
      <button class="loan-tab" onclick="showSection('track',this)">📊 Track Application</button>
      <button class="loan-tab" onclick="showSection('upload',this)">📄 Upload Documents</button>
      <?php endif; ?>
      <button class="loan-tab" onclick="showSection('emi',this)">🧮 EMI Calculator</button>
      <button class="loan-tab" onclick="showSection('banks',this)">🏦 Compare Banks</button>
    </div>

    <!-- ═══════ SECTION: APPLY ═══════ -->
    <div id="sec-apply" class="loan-section-content">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="bg-white rounded-4 shadow-sm p-4 p-md-5" style="border:1px solid #e4e9f0">
            <h4 class="fw-bold mb-1"><i class="fas fa-file-invoice-dollar me-2 text-accent"></i>Step 1: Loan Application</h4>
            <p class="text-muted mb-4" style="font-size:.88rem">Fill in your details to start the loan approval process</p>
            <form method="POST">
              <input type="hidden" name="apply_loan" value="1">
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label fw-bold" style="font-size:.82rem">Full Name *</label>
                  <input type="text" name="full_name" class="form-control" required value="<?= $_SESSION['client_name'] ?? '' ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-bold" style="font-size:.82rem">Phone *</label>
                  <input type="tel" name="phone" class="form-control" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-bold" style="font-size:.82rem">Email</label>
                  <input type="email" name="email" class="form-control" value="<?= $_SESSION['client_email'] ?? '' ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-bold" style="font-size:.82rem">Select Bank *</label>
                  <select name="bank_name" class="form-select" required>
                    <option value="">Choose Bank</option>
                    <?php foreach(array_merge($homeLoans, $commLoans) as $b): ?>
                    <option value="<?= htmlspecialchars($b['bank_name']) ?>"><?= htmlspecialchars($b['bank_name']) ?> (<?= $b['interest_rate'] ?>% p.a.)</option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-bold" style="font-size:.82rem">Loan Amount (₹) *</label>
                  <input type="number" name="loan_amount" class="form-control" placeholder="e.g. 5000000" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-bold" style="font-size:.82rem">Monthly Income (₹)</label>
                  <input type="number" name="monthly_income" class="form-control" placeholder="e.g. 80000">
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-bold" style="font-size:.82rem">Property Type</label>
                  <select name="property_type" class="form-select">
                    <option>Apartment</option><option>Villa</option><option>Independent House</option><option>Plot/Site</option><option>Commercial</option>
                  </select>
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-bold" style="font-size:.82rem">Employment Type</label>
                  <select name="employment" class="form-select">
                    <option>Salaried</option><option>Self-Employed</option><option>Business Owner</option><option>NRI</option>
                  </select>
                </div>
                <div class="col-12">
                  <div class="p-3 rounded-3" style="background:#fff8f0;border:1px solid #fde8d0">
                    <div class="d-flex align-items-center gap-2"><i class="fas fa-info-circle text-warning"></i><small class="text-muted">After submitting, you'll need to upload your documents (PAN, Aadhar, Salary Slips, etc.) for verification.</small></div>
                  </div>
                </div>
                <div class="col-12">
                  <button type="submit" class="btn w-100" style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:#fff;border:none;border-radius:12px;padding:14px;font-weight:700;font-size:1rem">
                    <i class="fas fa-paper-plane me-2"></i>Submit Application
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- ═══════ SECTION: TRACK ═══════ -->
    <div id="sec-track" class="loan-section-content" style="display:none">
      <div class="row justify-content-center">
        <div class="col-lg-10">
          <h4 class="fw-bold mb-4"><i class="fas fa-chart-line me-2 text-accent"></i>My Loan Applications</h4>
          <?php if($myLoans && $myLoans->num_rows > 0): ?>
            <?php while($app = $myLoans->fetch_assoc()):
              $sColor = $statusColors[$app['status']] ?? '#888';
              $sLabel = $statusLabels[$app['status']] ?? $app['status'];
              $step   = (int)$app['current_step'];
            ?>
            <div class="bg-white rounded-4 shadow-sm p-4 mb-4" style="border:1px solid #e4e9f0">
              <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
                <div>
                  <h6 class="fw-bold mb-1"><?= htmlspecialchars($app['bank_name']) ?> — ₹<?= number_format((float)$app['loan_amount']) ?></h6>
                  <small class="text-muted"><i class="far fa-clock me-1"></i>Applied: <?= date('d M Y, h:i A', strtotime($app['created_at'])) ?></small>
                </div>
                <span class="badge rounded-pill px-3 py-2" style="background:<?=$sColor?>15;color:<?=$sColor?>;font-weight:600"><?=$sLabel?></span>
              </div>
              <!-- Step tracker -->
              <div class="step-tracker mb-3">
                <?php for($si=1; $si<=5; $si++): $sm=$stepMeta[$si]; ?>
                <div class="tracker-step <?= $si<=$step?'done':'' ?> <?= $si==$step?'current':'' ?>">
                  <div class="tracker-dot" style="<?=$si<=$step?'background:'.$sm[3]:''?>"><?=$si<=$step?'✓':$si?></div>
                  <div class="tracker-label"><?=$sm[1]?></div>
                </div>
                <?php if($si<5): ?><div class="tracker-line <?=$si<$step?'done':''?>"></div><?php endif; ?>
                <?php endfor; ?>
              </div>
              <div class="row g-2" style="font-size:.82rem">
                <div class="col-md-3"><strong>Name:</strong> <?= htmlspecialchars($app['full_name']) ?></div>
                <div class="col-md-3"><strong>Phone:</strong> <?= htmlspecialchars($app['phone']) ?></div>
                <div class="col-md-3"><strong>Type:</strong> <?= htmlspecialchars($app['property_type'] ?? '-') ?></div>
                <div class="col-md-3"><strong>Income:</strong> ₹<?= number_format((float)$app['monthly_income']) ?></div>
              </div>
              <?php if(!empty($app['admin_remarks'])): ?>
              <div class="mt-2 p-2 rounded-2" style="background:#f0f4f8;font-size:.8rem">
                <i class="fas fa-comment-dots me-1 text-accent"></i><strong>Admin Remarks:</strong> <?= htmlspecialchars($app['admin_remarks']) ?>
              </div>
              <?php endif; ?>
              <?php if($app['status'] === 'documents_required'): ?>
              <div class="mt-3"><a href="javascript:void(0)" onclick="showSection('upload',document.querySelectorAll('.loan-tab')[2])" class="btn btn-accent btn-sm px-4 rounded-pill"><i class="fas fa-upload me-1"></i>Upload Documents Now</a></div>
              <?php endif; ?>
            </div>
            <?php endwhile; ?>
          <?php else: ?>
            <div class="bg-white rounded-4 shadow-sm p-5 text-center" style="border:1px solid #e4e9f0">
              <i class="fas fa-folder-open mb-3" style="font-size:3rem;color:#ccc"></i>
              <h6 class="fw-bold">No Loan Applications Yet</h6>
              <p class="text-muted small mb-3">Apply for a property loan to start tracking</p>
              <a href="javascript:void(0)" onclick="showSection('apply',document.querySelectorAll('.loan-tab')[0])" class="btn btn-accent rounded-pill px-4">Apply Now</a>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- ═══════ SECTION: DOCUMENTS ═══════ -->
    <div id="sec-upload" class="loan-section-content" style="display:none">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="bg-white rounded-4 shadow-sm p-4 p-md-5" style="border:1px solid #e4e9f0">
            <h4 class="fw-bold mb-1"><i class="fas fa-file-alt me-2 text-accent"></i>Step 2: Document Details</h4>
            <p class="text-muted mb-4" style="font-size:.88rem">Enter your document numbers and details for verification</p>
            <?php
            $pendingApps = null;
            if($clientId > 0) $pendingApps = $conn->query("SELECT id,bank_name,loan_amount FROM loan_applications WHERE client_id=$clientId AND status IN ('documents_required','pending') ORDER BY created_at DESC");
            if($pendingApps && $pendingApps->num_rows > 0):
            ?>
            <form method="POST">
              <input type="hidden" name="upload_docs" value="1">
              <div class="mb-4">
                <label class="form-label fw-bold">Select Application</label>
                <select name="application_id" class="form-select" required>
                  <?php while($pa = $pendingApps->fetch_assoc()): ?>
                  <option value="<?=$pa['id']?>">#<?=$pa['id']?> — <?=htmlspecialchars($pa['bank_name'])?> (₹<?=number_format((float)$pa['loan_amount'])?>)</option>
                  <?php endwhile; ?>
                </select>
              </div>
              <div class="row g-4">
                <?php
                $docTypes = [
                    'pan_card' => ['PAN Card Number', 'fas fa-id-card', '#FF6B35', 'e.g. ABCDE1234F', 'Enter 10-digit PAN number'],
                    'aadhar_card' => ['Aadhar Card Number', 'fas fa-fingerprint', '#1a3c5e', 'e.g. 1234 5678 9012', 'Enter 12-digit Aadhar number'],
                    'salary_slip' => ['Monthly Salary Details', 'fas fa-file-invoice', '#2d6a4f', 'e.g. ₹80,000 per month', 'Enter salary or employer details'],
                    'bank_statement' => ['Bank Account Number', 'fas fa-university', '#6f42c1', 'e.g. 12345678901234', 'Enter bank account number'],
                    'property_doc' => ['Property Document No.', 'fas fa-file-contract', '#dc3545', 'e.g. Sale deed / Title no.', 'Enter property document reference'],
                ];
                foreach($docTypes as $key => $doc): ?>
                <div class="col-md-6">
                  <div class="doc-upload-card" id="card-<?=$key?>">
                    <div class="d-flex align-items-center gap-3 mb-2">
                      <div style="width:42px;height:42px;background:<?=$doc[2]?>12;border-radius:10px;display:flex;align-items:center;justify-content:center;color:<?=$doc[2]?>;font-size:1.1rem"><i class="<?=$doc[1]?>"></i></div>
                      <div>
                        <div class="fw-bold" style="font-size:.88rem"><?=$doc[0]?></div>
                        <div class="text-muted" style="font-size:.72rem"><?=$doc[4]?></div>
                      </div>
                    </div>
                    <input type="text" name="<?=$key?>" class="form-control form-control-sm" placeholder="<?=$doc[3]?>" oninput="markFilled(this,'<?=$key?>')">
                    <div id="status-<?=$key?>" class="mt-1" style="font-size:.72rem"></div>
                  </div>
                </div>
                <?php endforeach; ?>
              </div>
              <button type="submit" class="btn w-100 mt-4" style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:#fff;border:none;border-radius:12px;padding:14px;font-weight:700;font-size:1rem">
                <i class="fas fa-paper-plane me-2"></i>Submit Document Details
              </button>
            </form>
            <?php else: ?>
            <div class="text-center py-4">
              <i class="fas fa-file-alt mb-3" style="font-size:3rem;color:#ccc"></i>
              <h6 class="fw-bold">No Pending Applications</h6>
              <p class="text-muted small">Submit a loan application first to provide documents</p>
              <a href="javascript:void(0)" onclick="showSection('apply',document.querySelectorAll('.loan-tab')[0])" class="btn btn-accent rounded-pill px-4">Apply Now</a>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- ═══════ SECTION: EMI CALCULATOR ═══════ -->
    <div id="sec-emi" class="loan-section-content" style="display:none">
      <div class="row justify-content-center">
        <div class="col-lg-10">
          <div class="bg-white rounded-4 shadow-sm p-4 p-md-5" style="border:1px solid #e4e9f0">
            <h4 class="fw-bold text-center mb-4">🧮 EMI Calculator</h4>
            <div class="row g-3 mb-4">
              <div class="col-md-4">
                <label class="fw-bold small text-muted text-uppercase">Loan Amount (₹)</label>
                <input type="number" id="loanAmount" class="form-control form-control-lg fw-bold text-center" value="5000000" oninput="syncSlider('loanAmount','loanSlider');calcEMI()">
                <input type="range" id="loanSlider" min="500000" max="50000000" step="100000" value="5000000" class="form-range mt-2" oninput="syncInput('loanSlider','loanAmount');calcEMI()">
                <div class="d-flex justify-content-between" style="font-size:.72rem;color:#888"><span>₹5L</span><span>₹5Cr</span></div>
              </div>
              <div class="col-md-4">
                <label class="fw-bold small text-muted text-uppercase">Interest Rate (% p.a.)</label>
                <input type="number" id="interestRate" class="form-control form-control-lg fw-bold text-center" value="8.5" step="0.05" oninput="syncSlider('interestRate','rateSlider');calcEMI()">
                <input type="range" id="rateSlider" min="5" max="20" step="0.05" value="8.5" class="form-range mt-2" oninput="syncInput('rateSlider','interestRate');calcEMI()">
                <div class="d-flex justify-content-between" style="font-size:.72rem;color:#888"><span>5%</span><span>20%</span></div>
              </div>
              <div class="col-md-4">
                <label class="fw-bold small text-muted text-uppercase">Tenure (Years)</label>
                <input type="number" id="tenure" class="form-control form-control-lg fw-bold text-center" value="20" oninput="syncSlider('tenure','tenureSlider');calcEMI()">
                <input type="range" id="tenureSlider" min="1" max="30" step="1" value="20" class="form-range mt-2" oninput="syncInput('tenureSlider','tenure');calcEMI()">
                <div class="d-flex justify-content-between" style="font-size:.72rem;color:#888"><span>1 yr</span><span>30 yrs</span></div>
              </div>
            </div>
            <div class="row g-3 text-center">
              <div class="col-md-4">
                <div class="p-3 rounded-3" style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f)">
                  <div style="font-size:.75rem;color:rgba(255,255,255,.7);text-transform:uppercase">Monthly EMI</div>
                  <div id="emiResult" style="font-size:1.8rem;font-weight:800;color:#fff">₹0</div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="p-3 rounded-3" style="background:#f0f4f8;border:1px solid #e4e9f0">
                  <div style="font-size:.75rem;color:#888;text-transform:uppercase">Total Interest</div>
                  <div id="interestResult" style="font-size:1.8rem;font-weight:800;color:#FF6B35">₹0</div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="p-3 rounded-3" style="background:#f0f4f8;border:1px solid #e4e9f0">
                  <div style="font-size:.75rem;color:#888;text-transform:uppercase">Total Payable</div>
                  <div id="totalResult" style="font-size:1.8rem;font-weight:800;color:#2d6a4f">₹0</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ═══════ SECTION: BANKS ═══════ -->
    <div id="sec-banks" class="loan-section-content" style="display:none">
      <h4 class="fw-bold mb-4"><i class="fas fa-university me-2 text-accent"></i>Compare Bank Rates</h4>
      <div class="row g-4">
        <?php foreach(array_merge($homeLoans, $commLoans) as $l):
          $clr = getBankColor2($l['bank_name'], $bankColors);
          $sampleEMI = round(((float)$l['max_amount']/2) * ((float)$l['interest_rate']/1200) / (1 - pow(1 + (float)$l['interest_rate']/1200, -240)));
        ?>
        <div class="col-lg-4 col-md-6">
          <div class="loan-card-new h-100">
            <div class="loan-card-header" style="background:linear-gradient(135deg,<?=$clr[0]?>,<?=$clr[1]?>)">
              <div class="d-flex align-items-center gap-3">
                <div class="bank-logo-wrap"><span style="font-size:1.6rem">🏦</span></div>
                <div>
                  <div style="font-size:.95rem;font-weight:700;color:#fff"><?= htmlspecialchars($l['bank_name']) ?></div>
                  <div style="font-size:.75rem;color:rgba(255,255,255,.7)"><?= htmlspecialchars($l['loan_type']) ?></div>
                </div>
              </div>
              <div class="rate-badge"><?= number_format((float)$l['interest_rate'], 2) ?>% p.a.</div>
            </div>
            <div class="loan-card-body">
              <p style="font-size:.82rem;color:#6b7a8d;margin-bottom:14px"><?= htmlspecialchars($l['description'] ?? '') ?></p>
              <div class="loan-stats">
                <div class="loan-stat">
                  <div class="loan-stat-val">₹<?= $l['max_amount'] >= 10000000 ? number_format($l['max_amount']/10000000, 1).' Cr' : number_format($l['max_amount']/100000, 0).' L' ?></div>
                  <div class="loan-stat-lbl">Max Amount</div>
                </div>
                <div class="loan-stat">
                  <div class="loan-stat-val"><?= $l['tenure_years'] ?> Yrs</div>
                  <div class="loan-stat-lbl">Max Tenure</div>
                </div>
                <div class="loan-stat">
                  <div class="loan-stat-val">₹<?= number_format($sampleEMI) ?></div>
                  <div class="loan-stat-lbl">Sample EMI*</div>
                </div>
              </div>
              <button class="btn w-100 mt-3" style="background:linear-gradient(135deg,<?=$clr[0]?>,<?=$clr[1]?>);color:#fff;border:none;border-radius:10px;padding:10px;font-weight:600" onclick="selectBank('<?= htmlspecialchars(addslashes($l['bank_name'])) ?>')">
                Apply Now <i class="fas fa-arrow-right ms-2"></i>
              </button>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <p class="text-center text-muted mt-3" style="font-size:.78rem">* Sample EMI calculated on 50% of max loan for 20 years. Actual may vary.</p>
    </div>

  </div>
</section>

<style>
/* Step Progress */
.step-progress-bar{display:flex;align-items:center;justify-content:center;gap:0;padding:20px 0;flex-wrap:wrap}
.step-item{text-align:center;flex-shrink:0}
.step-circle{width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.5rem;margin:0 auto 8px;color:white;box-shadow:0 4px 14px rgba(0,0,0,.15)}
.step-label{font-weight:700;font-size:.82rem;color:#1e293b}
.step-sub{font-size:.7rem;color:#94a3b8}
.step-line{width:40px;height:3px;background:linear-gradient(90deg,#e4e9f0,#ccc);margin:0 4px;margin-bottom:30px;flex-shrink:0}
/* Loan Tabs */
.loan-tab{background:#f0f4f8;border:1px solid #e4e9f0;border-radius:25px;padding:8px 20px;font-size:.85rem;font-weight:600;cursor:pointer;transition:.2s;color:#1a3c5e}
.loan-tab.active{background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:#fff;border-color:transparent}
.loan-tab:hover:not(.active){background:#e2e8f0}
/* Loan Cards */
.loan-card-new{background:#fff;border-radius:16px;box-shadow:0 2px 16px rgba(0,0,0,.08);border:1px solid #e4e9f0;overflow:hidden;transition:.3s}
.loan-card-new:hover{transform:translateY(-5px);box-shadow:0 12px 36px rgba(0,0,0,.12)}
.loan-card-header{padding:20px;position:relative}
.bank-logo-wrap{width:56px;height:56px;background:rgba(255,255,255,.15);border-radius:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.rate-badge{position:absolute;top:14px;right:14px;background:rgba(255,255,255,.2);color:#fff;border:1px solid rgba(255,255,255,.35);border-radius:20px;padding:4px 12px;font-size:.78rem;font-weight:700;backdrop-filter:blur(4px)}
.loan-card-body{padding:20px}
.loan-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.loan-stat{text-align:center;background:#f8fafc;border-radius:10px;padding:10px 6px}
.loan-stat-val{font-size:.9rem;font-weight:800;color:#1e293b}
.loan-stat-lbl{font-size:.65rem;color:#94a3b8;margin-top:2px}
/* Step Tracker */
.step-tracker{display:flex;align-items:center;justify-content:center;gap:0;padding:10px 0}
.tracker-step{text-align:center;flex-shrink:0}
.tracker-dot{width:32px;height:32px;border-radius:50%;background:#e4e9f0;display:flex;align-items:center;justify-content:center;margin:0 auto 4px;font-size:.75rem;font-weight:700;color:#fff;transition:.3s}
.tracker-step.done .tracker-dot{box-shadow:0 2px 8px rgba(0,0,0,.15)}
.tracker-step:not(.done) .tracker-dot{color:#94a3b8}
.tracker-step.current .tracker-dot{animation:pulse-dot 2s infinite}
@keyframes pulse-dot{0%{box-shadow:0 0 0 0 rgba(255,107,53,.4)}70%{box-shadow:0 0 0 10px rgba(255,107,53,0)}100%{box-shadow:0 0 0 0 rgba(255,107,53,0)}}
.tracker-label{font-size:.68rem;font-weight:600;color:#64748b}
.tracker-line{width:30px;height:3px;background:#e4e9f0;margin:0 2px;margin-bottom:18px}
.tracker-line.done{background:linear-gradient(90deg,#2d6a4f,#1a3c5e)}
/* Doc Upload Cards */
.doc-upload-card{background:#f8fafc;border:2px dashed #e4e9f0;border-radius:14px;padding:16px;transition:.3s}
.doc-upload-card:hover{border-color:#FF6B35}
.doc-upload-card.uploaded{border-color:#10b981;border-style:solid;background:#f0fdf4}
</style>

<script>
// Section toggle
function showSection(id, btn) {
    document.querySelectorAll('.loan-section-content').forEach(s => s.style.display = 'none');
    document.getElementById('sec-' + id).style.display = 'block';
    document.querySelectorAll('.loan-tab').forEach(t => t.classList.remove('active'));
    if(btn) btn.classList.add('active');
}
// Auto-show track section if hash
if(window.location.hash === '#track') showSection('track', document.querySelectorAll('.loan-tab')[1]);
if(window.location.hash === '#upload') showSection('upload', document.querySelectorAll('.loan-tab')[2]);
if(window.location.hash === '#emi') showSection('emi', null);
if(window.location.hash === '#banks') showSection('banks', null);

// EMI calculator
function calcEMI() {
    var P = parseFloat(document.getElementById('loanAmount').value)||0;
    var r = (parseFloat(document.getElementById('interestRate').value)||8.5) / 1200;
    var n = (parseFloat(document.getElementById('tenure').value)||20) * 12;
    if (P > 0 && r > 0 && n > 0) {
        var emi = P * r * Math.pow(1+r,n) / (Math.pow(1+r,n)-1);
        var total = emi * n;
        var inter = total - P;
        document.getElementById('emiResult').textContent = '₹' + Math.round(emi).toLocaleString('en-IN');
        document.getElementById('interestResult').textContent = '₹' + Math.round(inter).toLocaleString('en-IN');
        document.getElementById('totalResult').textContent = '₹' + Math.round(total).toLocaleString('en-IN');
    }
}
function syncSlider(a,b){document.getElementById(b).value=document.getElementById(a).value}
function syncInput(a,b){document.getElementById(b).value=document.getElementById(a).value}
calcEMI();

// Select bank from comparison
function selectBank(name) {
    showSection('apply', document.querySelectorAll('.loan-tab')[0]);
    var sel = document.querySelector('select[name="bank_name"]');
    if(sel) { for(var i=0;i<sel.options.length;i++){if(sel.options[i].value===name){sel.selectedIndex=i;break;}} }
    window.scrollTo({top:400,behavior:'smooth'});
}

// Document info visual feedback
function markFilled(input, key) {
    var card = document.getElementById('card-' + key);
    var status = document.getElementById('status-' + key);
    if (input.value.trim().length > 0) {
        card.classList.add('uploaded');
        status.innerHTML = '<span style="color:#10b981"><i class="fas fa-check-circle me-1"></i>Entered</span>';
    } else {
        card.classList.remove('uploaded');
        status.innerHTML = '';
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>
