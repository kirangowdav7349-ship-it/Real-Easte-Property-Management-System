<?php
/**
 * Database Connection Test Page
 * This file verifies that PHP is successfully connected to the MySQL database.
 * Access via: http://localhost/homehaven/db_test.php
 */

// ── Attempt connection ──────────────────────────────────────────────
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'homehaven_db';

$conn = @new mysqli($db_host, $db_user, $db_pass, $db_name);

$is_connected  = !$conn->connect_error;
$error_message = $conn->connect_error ?? '';
$server_info   = $is_connected ? $conn->server_info : 'N/A';
$host_info     = $is_connected ? $conn->host_info   : 'N/A';
$charset       = '';
$tables        = [];

if ($is_connected) {
    $conn->set_charset('utf8mb4');
    $charset = $conn->character_set_name();

    // Fetch list of tables
    $result = $conn->query("SHOW TABLES");
    if ($result) {
        while ($row = $result->fetch_array()) {
            $tables[] = $row[0];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=1280">
    <title>Database Connection Test — PropNexus</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
            color: #e2e8f0;
            padding: 2rem;
        }

        .card {
            width: 100%;
            max-width: 640px;
            background: rgba(30, 41, 59, 0.7);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(148, 163, 184, 0.12);
            border-radius: 1.25rem;
            overflow: hidden;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            animation: fadeIn 0.6s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(24px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        /* ── Header ─────────────────────────────────── */
        .card-header {
            padding: 2rem 2rem 1.5rem;
            text-align: center;
            border-bottom: 1px solid rgba(148, 163, 184, 0.1);
        }

        .status-icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.25rem;
            font-size: 2rem;
        }

        .status-icon.success {
            background: rgba(34, 197, 94, 0.15);
            color: #4ade80;
            box-shadow: 0 0 40px rgba(34, 197, 94, 0.2);
            animation: pulse-green 2s infinite;
        }

        .status-icon.error {
            background: rgba(239, 68, 68, 0.15);
            color: #f87171;
            box-shadow: 0 0 40px rgba(239, 68, 68, 0.2);
            animation: pulse-red 2s infinite;
        }

        @keyframes pulse-green {
            0%, 100% { box-shadow: 0 0 20px rgba(34,197,94,0.2); }
            50%      { box-shadow: 0 0 40px rgba(34,197,94,0.35); }
        }

        @keyframes pulse-red {
            0%, 100% { box-shadow: 0 0 20px rgba(239,68,68,0.2); }
            50%      { box-shadow: 0 0 40px rgba(239,68,68,0.35); }
        }

        .card-header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0.35rem;
        }

        .card-header h1.success { color: #4ade80; }
        .card-header h1.error   { color: #f87171; }

        .card-header p {
            font-size: 0.9rem;
            color: #94a3b8;
        }

        /* ── Details ────────────────────────────────── */
        .details {
            padding: 1.5rem 2rem;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem 0;
            border-bottom: 1px solid rgba(148, 163, 184, 0.08);
        }

        .detail-row:last-child { border-bottom: none; }

        .detail-label {
            font-size: 0.85rem;
            color: #94a3b8;
            font-weight: 500;
        }

        .detail-value {
            font-size: 0.85rem;
            font-weight: 600;
            color: #e2e8f0;
            text-align: right;
            max-width: 60%;
            word-break: break-all;
        }

        .badge {
            display: inline-block;
            padding: 0.2rem 0.7rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            letter-spacing: 0.03em;
        }

        .badge-success {
            background: rgba(34, 197, 94, 0.15);
            color: #4ade80;
        }

        .badge-error {
            background: rgba(239, 68, 68, 0.15);
            color: #f87171;
        }

        /* ── Tables list ────────────────────────────── */
        .tables-section {
            padding: 0 2rem 1.5rem;
        }

        .tables-section h3 {
            font-size: 0.85rem;
            font-weight: 600;
            color: #94a3b8;
            margin-bottom: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
        }

        .table-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
            gap: 0.5rem;
        }

        .table-chip {
            background: rgba(99, 102, 241, 0.1);
            border: 1px solid rgba(99, 102, 241, 0.2);
            border-radius: 0.5rem;
            padding: 0.45rem 0.75rem;
            font-size: 0.78rem;
            font-weight: 500;
            color: #a5b4fc;
            transition: all 0.2s;
        }

        .table-chip:hover {
            background: rgba(99, 102, 241, 0.2);
            transform: translateY(-1px);
        }

        .table-count {
            text-align: center;
            margin-top: 0.75rem;
            font-size: 0.8rem;
            color: #64748b;
        }

        /* ── Error box ──────────────────────────────── */
        .error-box {
            margin: 0 2rem 1.5rem;
            background: rgba(239, 68, 68, 0.08);
            border: 1px solid rgba(239, 68, 68, 0.2);
            border-radius: 0.75rem;
            padding: 1rem 1.25rem;
            font-size: 0.85rem;
            color: #fca5a5;
            line-height: 1.5;
        }

        /* ── Footer ─────────────────────────────────── */
        .card-footer {
            padding: 1rem 2rem;
            text-align: center;
            border-top: 1px solid rgba(148, 163, 184, 0.08);
        }

        .card-footer a {
            color: #818cf8;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: color 0.2s;
        }

        .card-footer a:hover { color: #a5b4fc; }

        .timestamp {
            margin-top: 0.5rem;
            font-size: 0.75rem;
            color: #475569;
        }
    </style>
</head>
<body>

<div class="card">

    <!-- Header -->
    <div class="card-header">
        <div class="status-icon <?= $is_connected ? 'success' : 'error' ?>">
            <?= $is_connected ? '✓' : '✕' ?>
        </div>
        <h1 class="<?= $is_connected ? 'success' : 'error' ?>">
            <?= $is_connected ? 'Database Connected Successfully!' : 'Database Connection Failed' ?>
        </h1>
        <p><?= $is_connected
            ? 'PHP is communicating with MySQL without any issues.'
            : 'PHP could not establish a connection to MySQL.' ?>
        </p>
    </div>

    <!-- Connection details -->
    <div class="details">
        <div class="detail-row">
            <span class="detail-label">Status</span>
            <span class="detail-value">
                <span class="badge <?= $is_connected ? 'badge-success' : 'badge-error' ?>">
                    <?= $is_connected ? 'CONNECTED' : 'FAILED' ?>
                </span>
            </span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Host</span>
            <span class="detail-value"><?= htmlspecialchars($db_host) ?></span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Database</span>
            <span class="detail-value"><?= htmlspecialchars($db_name) ?></span>
        </div>
        <div class="detail-row">
            <span class="detail-label">User</span>
            <span class="detail-value"><?= htmlspecialchars($db_user) ?></span>
        </div>
        <?php if ($is_connected): ?>
        <div class="detail-row">
            <span class="detail-label">MySQL Version</span>
            <span class="detail-value"><?= htmlspecialchars($server_info) ?></span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Connection Type</span>
            <span class="detail-value"><?= htmlspecialchars($host_info) ?></span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Charset</span>
            <span class="detail-value"><?= htmlspecialchars($charset) ?></span>
        </div>
        <?php endif; ?>
        <div class="detail-row">
            <span class="detail-label">PHP Version</span>
            <span class="detail-value"><?= phpversion() ?></span>
        </div>
    </div>

    <?php if (!$is_connected): ?>
    <!-- Error message -->
    <div class="error-box">
        <strong>Error:</strong> <?= htmlspecialchars($error_message) ?><br>
        Make sure XAMPP MySQL service is running and the <code>homehaven_db</code> database has been created via
        <a href="/homehaven/install.php" style="color:#fca5a5;text-decoration:underline;">install.php</a>.
    </div>
    <?php endif; ?>

    <?php if ($is_connected && count($tables) > 0): ?>
    <!-- Tables found -->
    <div class="tables-section">
        <h3>Tables Found (<?= count($tables) ?>)</h3>
        <div class="table-grid">
            <?php foreach ($tables as $t): ?>
            <div class="table-chip"><?= htmlspecialchars($t) ?></div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Footer -->
    <div class="card-footer">
        <a href="/homehaven/">← Back to PropNexus</a>
        <div class="timestamp">Tested on <?= date('d M Y, h:i:s A') ?></div>
    </div>

</div>

</body>
</html>
<?php
if ($is_connected) $conn->close();
?>
