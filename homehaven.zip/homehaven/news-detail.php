<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/config.php';

$slug = isset($_GET['slug']) ? $conn->real_escape_string($_GET['slug']) : '';
$article = null;
if ($slug) {
    $res = $conn->query("SELECT * FROM news_guides WHERE slug='" . $slug . "' AND status='published'");
    if ($res) { $article = $res->fetch_assoc(); }
}
if (!$article) { header('Location: news.php'); exit; }

// Increment view count
$conn->query("UPDATE news_guides SET views = views + 1 WHERE id = " . (int)$article['id']);

$catColors = array('news' => '#dc3545', 'guide' => '#2d6a4f', 'tips' => '#FF6B35', 'market' => '#6f42c1');
$catColor  = isset($catColors[$article['category']]) ? $catColors[$article['category']] : '#1a3c5e';
$artImg    = !empty($article['image_url']) ? $article['image_url'] : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800';

$relRes = $conn->query("SELECT * FROM news_guides WHERE category='" . $conn->real_escape_string($article['category']) . "' AND id != " . (int)$article['id'] . " AND status='published' LIMIT 3");

// Build article content
$content = !empty($article['content']) ? $article['content'] : '';
if (empty($content)) {
    $exc = !empty($article['excerpt']) ? htmlspecialchars($article['excerpt']) : '';
    $content = '<p class="lead">' . $exc . '</p>
<p>India\'s real estate market continues to evolve rapidly, driven by urbanization, policy reforms, and changing buyer preferences. This article explores key trends every buyer, tenant, and investor needs to know in 2025.</p>
<h3>Market Overview</h3>
<p>Property markets in major Indian metros have seen consistent growth. Tier-2 cities like Pune, Hyderabad, and Ahmedabad are emerging as top investment destinations. Remote work culture has expanded buyer horizons beyond traditional metros.</p>
<ul>
<li>Home loan interest rates remain competitive at 8.4% to 9.5% per annum</li>
<li>New residential launches are up 15% year-over-year in major cities</li>
<li>Rental yields in IT corridors averaging 3.5% to 4.5%</li>
<li>RERA compliance has significantly improved buyer confidence</li>
</ul>
<h3>What Buyers Should Know</h3>
<p>For first-time homebuyers, current market conditions present both opportunities and challenges. Developers are offering attractive payment plans and banks are providing competitive interest rates. Due diligence remains critical — always verify RERA registration and check title documents.</p>
<h3>Rental Market Insights</h3>
<p>The rental market remains strong, particularly in IT corridors. PG accommodations near tech parks maintain near-zero vacancy rates, making them attractive investments. Platforms like PropNexus help tenants find verified properties with transparent pricing.</p>
<blockquote style="border-left:4px solid #FF6B35;padding:15px 20px;background:var(--section-bg,#fff8f5);border-radius:0 8px 8px 0;margin:20px 0">
<p style="margin:0;font-style:italic;color:var(--text-muted,#555)">The Indian real estate sector is projected to reach USD 1 trillion by 2030, contributing 13% to the national GDP.</p>
</blockquote>
<h3>Tips for Renters</h3>
<p>When renting, always insist on a proper rental agreement. PropNexus Legal Services provides legally binding rental agreements that protect your rights as a tenant. Check for key amenities like power backup, water supply, security, and parking before signing.</p>';
}

$pageTitle = $article['title'];
require_once 'includes/header.php';
?>
<style>
.art-content h3{color:var(--primary,#1a3c5e);margin-top:2rem;margin-bottom:1rem;font-size:1.25rem;font-weight:700}
.art-content p{line-height:1.85;margin-bottom:1.2rem;color:var(--text-main,#333)}
.art-content ul{margin-bottom:1.2rem}
.art-content ul li{padding:5px 0;line-height:1.7;color:var(--text-main,#333)}
.rel-card{background:var(--card-bg,#fff);border-radius:14px;overflow:hidden;border:1px solid var(--border-color,#eee);transition:.3s;text-decoration:none;display:block}
.rel-card:hover{transform:translateY(-4px);box-shadow:0 8px 25px rgba(0,0,0,.12)}
body.dark-mode .art-content p,body.dark-mode .art-content li{color:var(--text-main,#e8eaed)}
body.dark-mode .rel-card{background:#1a2535;border-color:#2d3748}
</style>

<!-- Article Header Banner -->
<section style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f);padding:60px 0;color:white">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-9 text-center">
        <span class="badge mb-3 px-3 py-2" style="background:<?php echo $catColor; ?>;font-size:.82rem"><?php echo strtoupper($article['category']); ?></span>
        <h1 class="fw-bold mb-3" style="font-size:2rem;line-height:1.3"><?php echo htmlspecialchars($article['title']); ?></h1>
        <div class="d-flex justify-content-center gap-4 opacity-75 flex-wrap" style="font-size:.85rem">
          <span><i class="fas fa-user me-1"></i><?php echo htmlspecialchars($article['author']); ?></span>
          <span><i class="fas fa-eye me-1"></i><?php echo number_format((int)$article['views']); ?> views</span>
          <span><i class="fas fa-calendar me-1"></i><?php echo date('d M Y', strtotime($article['created_at'])); ?></span>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="container py-5">
  <div class="row g-4">

    <!-- Article Content -->
    <div class="col-lg-8">
      <div style="background:var(--card-bg,#fff);border-radius:20px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.08);border:1px solid var(--border-color,#eee)">
        <img src="<?php echo $artImg; ?>" style="width:100%;height:380px;object-fit:cover" alt="<?php echo htmlspecialchars($article['title']); ?>">
        <div class="p-4 p-lg-5 art-content"><?php echo $content; ?></div>
      </div>

      <!-- Share Buttons -->
      <div class="mt-4 p-4 rounded-3" style="background:var(--card-bg,#fff);border:1px solid var(--border-color,#eee)">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
          <span class="fw-bold">Share this article:</span>
          <div class="d-flex gap-2">
            <?php
            $shareUrl   = SITE_URL . '/news-detail.php?slug=' . urlencode($article['slug']);
            $shareTitle = urlencode($article['title']);
            $shares = array(
              array('fab fa-whatsapp',   'bg-success',  'https://wa.me/?text=' . $shareTitle . ' ' . $shareUrl),
              array('fab fa-facebook-f', 'bg-primary',  'https://facebook.com/sharer/sharer.php?u=' . $shareUrl),
              array('fab fa-twitter',    'bg-info',     'https://twitter.com/intent/tweet?text=' . $shareTitle . '&url=' . $shareUrl),
              array('fab fa-linkedin-in','bg-primary',  'https://www.linkedin.com/shareArticle?url=' . $shareUrl),
            );
            foreach ($shares as $sh) {
                echo '<a href="' . $sh[2] . '" target="_blank" class="btn btn-sm ' . $sh[1] . ' text-white rounded-circle" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center"><i class="' . $sh[0] . '"></i></a>';
            }
            ?>
          </div>
        </div>
      </div>

      <!-- Related Articles -->
      <?php if ($relRes && $relRes->num_rows > 0): ?>
      <h5 class="fw-bold mt-5 mb-3">&#128218; Related Articles</h5>
      <div class="row g-3">
        <?php while ($r = $relRes->fetch_assoc()):
          $rColor = isset($catColors[$r['category']]) ? $catColors[$r['category']] : '#1a3c5e';
          $rImg   = !empty($r['image_url']) ? $r['image_url'] : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=400';
        ?>
        <div class="col-md-4">
          <a href="news-detail.php?slug=<?php echo htmlspecialchars($r['slug']); ?>" class="rel-card">
            <img src="<?php echo $rImg; ?>" style="width:100%;height:120px;object-fit:cover" alt="">
            <div class="p-3">
              <span class="badge mb-1" style="background:<?php echo $rColor; ?>;font-size:.68rem"><?php echo strtoupper($r['category']); ?></span>
              <p class="fw-bold mb-1" style="font-size:.82rem;line-height:1.3;color:var(--text-main,#222)"><?php echo htmlspecialchars($r['title']); ?></p>
              <span style="font-size:.78rem;color:#FF6B35;font-weight:600">Read More &rarr;</span>
            </div>
          </a>
        </div>
        <?php endwhile; ?>
      </div>
      <?php endif; ?>

      <div class="mt-4">
        <a href="news.php" class="btn btn-outline-primary rounded-pill px-4">
          <i class="fas fa-arrow-left me-2"></i>Back to All Articles
        </a>
      </div>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
      <div class="mb-4 p-4 rounded-3 text-white" style="background:linear-gradient(135deg,#FF6B35,#e85d28)">
        <h6 class="fw-bold text-white mb-2">&#127968; Looking for a Property?</h6>
        <p style="font-size:.83rem;opacity:.9;margin-bottom:12px">Search 50,000+ verified listings across India</p>
        <a href="properties.php" class="btn btn-light btn-sm fw-bold px-4 rounded-pill">Search Now</a>
      </div>

      <div class="mb-4 p-4 rounded-3 text-white" style="background:linear-gradient(135deg,#2d6a4f,#1a3c5e)">
        <h6 class="fw-bold text-white mb-2">&#128717; Find Perfect PG</h6>
        <p style="font-size:.83rem;opacity:.9;margin-bottom:12px">Verified PGs with food, WiFi &amp; AC</p>
        <a href="properties.php?type=pg" class="btn btn-light btn-sm fw-bold px-4 rounded-pill">Browse PG</a>
      </div>

      <div style="background:var(--card-bg,#fff);border-radius:16px;padding:24px;border:1px solid var(--border-color,#eee)">
        <h6 class="fw-bold mb-3">&#128194; Categories</h6>
        <?php
        $cats2 = array(
          'news'   => '&#128240; News',
          'guide'  => '&#128218; Guides',
          'tips'   => '&#128161; Tips',
          'market' => '&#128202; Market',
        );
        foreach ($cats2 as $k => $l) {
            $cc   = isset($catColors[$k]) ? $catColors[$k] : '#1a3c5e';
            $cRes = $conn->query("SELECT COUNT(*) as c FROM news_guides WHERE category='" . $k . "' AND status='published'");
            $cnt  = ($cRes) ? (int)$cRes->fetch_assoc()['c'] : 0;
            echo '<a href="news.php?cat=' . $k . '" class="d-flex justify-content-between py-2 text-decoration-none" style="border-bottom:1px solid var(--border-color,#eee);color:var(--text-main,#333);font-size:.85rem;font-weight:500">' . $l . '<span class="badge" style="background:' . $cc . '">' . $cnt . '</span></a>' . "\n";
        }
        ?>
      </div>
    </div>

  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
