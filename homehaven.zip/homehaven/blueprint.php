<?php
$pageTitle = 'AI Blueprint Generator — Design Your Dream Home';
require_once 'includes/header.php';
?>

<style>
/* ── Page Banner ── */
.bp-banner {
  background: linear-gradient(135deg, #0e1621 0%, #1a3c5e 50%, #2d6a4f 100%);
  padding: 40px 0 30px; text-align: center; color: white; position: relative; overflow: hidden;
}
.bp-banner::before {
  content: ''; position: absolute; top: -50%; right: -10%; width: 400px; height: 400px;
  background: radial-gradient(circle, rgba(255,107,53,.15) 0%, transparent 70%);
  border-radius: 50%;
}
.bp-banner h1 { font-size: 2rem; font-weight: 800; position: relative; }
.bp-banner p { font-size: .92rem; opacity: .7; position: relative; }
.bp-banner .ai-badge {
  display: inline-flex; align-items: center; gap: 8px; background: rgba(255,107,53,.2);
  border: 1px solid rgba(255,107,53,.4); padding: 6px 18px; border-radius: 50px;
  font-size: .78rem; font-weight: 700; color: #FF6B35; margin-bottom: 12px;
}

/* ── Main Layout ── */
.bp-layout { display: flex; min-height: calc(100vh - 200px); }
.bp-sidebar {
  width: 380px; min-width: 360px; background: var(--card-bg);
  border-right: 1px solid var(--border); padding: 24px; overflow-y: auto;
}
.bp-canvas-area {
  flex: 1; padding: 24px; background: var(--body-bg);
  display: flex; flex-direction: column; align-items: center;
}

/* ── Form Styling ── */
.bp-section { margin-bottom: 22px; }
.bp-section-title {
  font-size: .82rem; font-weight: 700; text-transform: uppercase; letter-spacing: .6px;
  color: var(--accent); margin-bottom: 10px; display: flex; align-items: center; gap: 8px;
}
.bp-section-title i { font-size: .9rem; }
.bp-label { font-size: .76rem; font-weight: 600; color: var(--text-muted); margin-bottom: 4px; display: block; }
.bp-input {
  width: 100%; padding: 9px 14px; border-radius: 10px; border: 1px solid var(--border);
  background: var(--body-bg); color: var(--text-main); font-size: .84rem; font-family: 'Poppins';
  transition: .3s;
}
.bp-input:focus { border-color: var(--accent); outline: none; box-shadow: 0 0 0 3px rgba(255,107,53,.12); }
.bp-input-group { display: flex; gap: 10px; }
.bp-input-group > div { flex: 1; }

/* ── Style Selector ── */
.style-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
.style-card {
  padding: 10px; border-radius: 12px; border: 2px solid var(--border);
  text-align: center; cursor: pointer; transition: .3s; background: var(--body-bg);
}
.style-card:hover { border-color: var(--accent); transform: translateY(-2px); }
.style-card.active { border-color: var(--accent); background: rgba(255,107,53,.08); box-shadow: 0 4px 16px rgba(255,107,53,.15); }
.style-card .style-icon { font-size: 1.4rem; margin-bottom: 4px; display: block; }
.style-card .style-name { font-size: .72rem; font-weight: 700; color: var(--text-main); }

/* ── Room Chips ── */
.room-config { margin-top: 4px; }
.room-row {
  display: flex; align-items: center; gap: 8px; padding: 8px 0;
  border-bottom: 1px solid var(--border); font-size: .82rem;
}
.room-row:last-child { border-bottom: none; }
.room-row .room-name { flex: 1; font-weight: 600; color: var(--text-main); display: flex; align-items: center; gap: 6px; }
.room-row .room-name i { color: var(--accent); font-size: .85rem; width: 18px; text-align: center; }
.room-stepper { display: flex; align-items: center; gap: 0; }
.room-stepper button {
  width: 28px; height: 28px; border-radius: 8px; border: 1px solid var(--border);
  background: var(--body-bg); color: var(--text-main); font-size: .85rem; font-weight: 700;
  cursor: pointer; transition: .2s; display: flex; align-items: center; justify-content: center;
}
.room-stepper button:hover { background: var(--accent); color: white; border-color: var(--accent); }
.room-stepper .room-count {
  width: 32px; text-align: center; font-weight: 700; font-size: .9rem; color: var(--accent);
}

/* ── Generate Button ── */
.bp-generate-btn {
  width: 100%; padding: 14px; border: none; border-radius: 14px; font-weight: 800;
  font-size: .95rem; cursor: pointer; transition: all .3s; font-family: 'Poppins';
  background: linear-gradient(135deg, #FF6B35, #ff8c42); color: white;
  box-shadow: 0 6px 24px rgba(255,107,53,.3); position: relative; overflow: hidden;
}
.bp-generate-btn:hover { transform: translateY(-3px); box-shadow: 0 10px 32px rgba(255,107,53,.4); }
.bp-generate-btn:active { transform: translateY(0); }
.bp-generate-btn.generating { pointer-events: none; }
.bp-generate-btn.generating::after {
  content: ''; position: absolute; top: 0; left: -100%; width: 200%; height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,.3), transparent);
  animation: shimmer 1.5s infinite;
}
@keyframes shimmer { to { left: 100%; } }

/* ── Canvas Container ── */
.bp-canvas-wrap {
  background: white; border-radius: 16px; box-shadow: 0 8px 40px rgba(0,0,0,.1);
  border: 1px solid var(--border); overflow: hidden; position: relative;
  width: 100%; max-width: 900px;
}
.bp-canvas-toolbar {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 18px; background: #f8f9fb; border-bottom: 1px solid #e5e7eb;
}
.bp-canvas-toolbar .toolbar-title { font-weight: 700; font-size: .88rem; color: #1a3c5e; display: flex; align-items: center; gap: 8px; }
.bp-canvas-toolbar .toolbar-actions { display: flex; gap: 6px; }
.toolbar-btn {
  padding: 6px 14px; border-radius: 8px; border: 1px solid #e5e7eb;
  background: white; color: #1a3c5e; font-size: .76rem; font-weight: 600;
  cursor: pointer; transition: .3s; display: flex; align-items: center; gap: 5px;
}
.toolbar-btn:hover { border-color: #FF6B35; color: #FF6B35; }
.toolbar-btn.primary { background: #1a3c5e; color: white; border-color: #1a3c5e; }
.toolbar-btn.primary:hover { background: #2d5a8e; }
#blueprintCanvas { display: block; width: 100%; }

/* ── Stats Bar ── */
.bp-stats {
  display: flex; gap: 16px; flex-wrap: wrap; margin-top: 16px; width: 100%; max-width: 900px;
}
.bp-stat-card {
  flex: 1; min-width: 130px; background: var(--card-bg); border: 1px solid var(--border);
  border-radius: 12px; padding: 14px 16px; text-align: center;
}
.bp-stat-card .stat-value { font-size: 1.2rem; font-weight: 800; color: var(--accent); }
.bp-stat-card .stat-label { font-size: .7rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase; letter-spacing: .3px; }

/* ── Empty State ── */
.bp-empty-state {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  padding: 60px 30px; text-align: center; color: var(--text-muted);
}
.bp-empty-state i { font-size: 4rem; margin-bottom: 16px; opacity: .25; }
.bp-empty-state h4 { font-weight: 700; font-size: 1.1rem; margin-bottom: 6px; color: var(--text-main); }
.bp-empty-state p { font-size: .84rem; max-width: 320px; line-height: 1.6; }

/* ── Legend ── */
.bp-legend {
  margin-top: 16px; width: 100%; max-width: 900px; background: var(--card-bg);
  border: 1px solid var(--border); border-radius: 12px; padding: 16px;
}
.bp-legend h6 { font-size: .82rem; font-weight: 700; color: var(--text-main); margin-bottom: 10px; }
.legend-grid { display: flex; flex-wrap: wrap; gap: 12px; }
.legend-item { display: flex; align-items: center; gap: 6px; font-size: .74rem; color: var(--text-muted); }
.legend-color { width: 16px; height: 16px; border-radius: 4px; border: 1px solid rgba(0,0,0,.1); }

/* ── Responsive ── */
@media(max-width: 992px) {
  .bp-layout { flex-direction: column; }
  .bp-sidebar { width: 100%; min-width: auto; max-height: none; }
}

/* ── Vastu Compass ── */
.vastu-indicator { 
  position: absolute; top: 16px; right: 16px; z-index: 5;
  width: 70px; height: 70px;
}
</style>

<!-- Banner -->
<div class="bp-banner">
  <div class="container">
    <div class="ai-badge"><i class="fas fa-microchip"></i> AI-Powered Tool</div>
    <h1>🏗️ AI Blueprint Generator</h1>
    <p>Design your dream floor plan in seconds. Customize rooms, choose a style, and generate.</p>
  </div>
</div>

<div class="bp-layout">
  <!-- ══════ SIDEBAR ══════ -->
  <div class="bp-sidebar">
    <!-- Property Type -->
    <div class="bp-section">
      <div class="bp-section-title"><i class="fas fa-building"></i> Property Type</div>
      <select class="bp-input" id="propType" onchange="updateUIFromType()">
        <option value="1bhk">1 BHK Apartment</option>
        <option value="2bhk" selected>2 BHK Apartment</option>
        <option value="3bhk">3 BHK Apartment</option>
        <option value="4bhk">4 BHK Villa</option>
        <option value="studio">Studio Apartment</option>
        <option value="penthouse">Penthouse</option>
        <option value="office">Office Space</option>
        <option value="custom">Custom Layout</option>
      </select>
    </div>

    <!-- Total Area -->
    <div class="bp-section">
      <div class="bp-section-title"><i class="fas fa-ruler-combined"></i> Total Area</div>
      <div class="bp-input-group">
        <div>
          <label class="bp-label">Area (sq ft)</label>
          <input type="number" class="bp-input" id="totalArea" value="1200" min="200" max="20000" step="50">
        </div>
        <div>
          <label class="bp-label">Floors</label>
          <select class="bp-input" id="numFloors">
            <option value="1" selected>Single Floor</option>
            <option value="2">2 Floors</option>
            <option value="3">3 Floors</option>
          </select>
        </div>
      </div>
    </div>

    <!-- Room Configuration -->
    <div class="bp-section">
      <div class="bp-section-title"><i class="fas fa-th-large"></i> Room Configuration</div>
      <div class="room-config" id="roomConfig">
        <!-- Filled by JS -->
      </div>
    </div>

    <!-- Architectural Style -->
    <div class="bp-section">
      <div class="bp-section-title"><i class="fas fa-palette"></i> Architectural Style</div>
      <div class="style-grid" id="styleGrid">
        <div class="style-card active" data-style="modern" onclick="selectStyle(this,'modern')">
          <span class="style-icon">🏢</span>
          <span class="style-name">Modern</span>
        </div>
        <div class="style-card" data-style="traditional" onclick="selectStyle(this,'traditional')">
          <span class="style-icon">🏛️</span>
          <span class="style-name">Traditional</span>
        </div>
        <div class="style-card" data-style="vastu" onclick="selectStyle(this,'vastu')">
          <span class="style-icon">🧭</span>
          <span class="style-name">Vastu</span>
        </div>
        <div class="style-card" data-style="minimalist" onclick="selectStyle(this,'minimalist')">
          <span class="style-icon">◻️</span>
          <span class="style-name">Minimalist</span>
        </div>
      </div>
    </div>

    <!-- Additional Options -->
    <div class="bp-section">
      <div class="bp-section-title"><i class="fas fa-sliders-h"></i> Options</div>
      <div style="display:flex;flex-direction:column;gap:8px">
        <label style="display:flex;align-items:center;gap:8px;font-size:.82rem;cursor:pointer;color:var(--text-main)">
          <input type="checkbox" id="optBalcony" checked style="accent-color:var(--accent)"> Include Balcony
        </label>
        <label style="display:flex;align-items:center;gap:8px;font-size:.82rem;cursor:pointer;color:var(--text-main)">
          <input type="checkbox" id="optPooja" style="accent-color:var(--accent)"> Pooja Room
        </label>
        <label style="display:flex;align-items:center;gap:8px;font-size:.82rem;cursor:pointer;color:var(--text-main)">
          <input type="checkbox" id="optServant" style="accent-color:var(--accent)"> Servant Room
        </label>
        <label style="display:flex;align-items:center;gap:8px;font-size:.82rem;cursor:pointer;color:var(--text-main)">
          <input type="checkbox" id="optParking" checked style="accent-color:var(--accent)"> Car Parking
        </label>
        <label style="display:flex;align-items:center;gap:8px;font-size:.82rem;cursor:pointer;color:var(--text-main)">
          <input type="checkbox" id="optDimensions" checked style="accent-color:var(--accent)"> Show Dimensions
        </label>
        <label style="display:flex;align-items:center;gap:8px;font-size:.82rem;cursor:pointer;color:var(--text-main)">
          <input type="checkbox" id="optFurniture" checked style="accent-color:var(--accent)"> Show Furniture
        </label>
      </div>
    </div>

    <!-- Generate Button -->
    <button class="bp-generate-btn" id="generateBtn" onclick="generateBlueprint()">
      <i class="fas fa-magic me-2"></i>Generate Blueprint
    </button>
    <p style="font-size:.68rem;color:var(--text-muted);text-align:center;margin-top:8px">
      AI analyzes room requirements & generates optimal floor plan
    </p>
  </div>

  <!-- ══════ CANVAS AREA ══════ -->
  <div class="bp-canvas-area">
    <div class="bp-canvas-wrap" id="canvasWrap">
      <div class="bp-canvas-toolbar">
        <div class="toolbar-title"><i class="fas fa-drafting-compass"></i> Floor Plan Preview</div>
        <div class="toolbar-actions">
          <button class="toolbar-btn" onclick="zoomCanvas(-1)"><i class="fas fa-search-minus"></i></button>
          <button class="toolbar-btn" onclick="zoomCanvas(1)"><i class="fas fa-search-plus"></i></button>
          <button class="toolbar-btn" onclick="downloadBlueprint('png')"><i class="fas fa-download"></i> PNG</button>
          <button class="toolbar-btn" onclick="downloadBlueprint('pdf')"><i class="fas fa-file-pdf"></i> PDF</button>
          <button class="toolbar-btn primary" onclick="generateBlueprint()"><i class="fas fa-sync-alt"></i> Regenerate</button>
        </div>
      </div>
      <div style="position:relative;overflow:hidden" id="canvasContainer">
        <canvas id="blueprintCanvas" width="860" height="640"></canvas>
        <div class="bp-empty-state" id="emptyState">
          <i class="fas fa-drafting-compass"></i>
          <h4>Your Blueprint Awaits</h4>
          <p>Configure your room requirements on the left and click <strong>"Generate Blueprint"</strong> to create your floor plan.</p>
        </div>
      </div>
    </div>

    <!-- Stats -->
    <div class="bp-stats" id="bpStats" style="display:none">
      <div class="bp-stat-card">
        <div class="stat-value" id="statArea">—</div>
        <div class="stat-label">Total Area</div>
      </div>
      <div class="bp-stat-card">
        <div class="stat-value" id="statRooms">—</div>
        <div class="stat-label">Total Rooms</div>
      </div>
      <div class="bp-stat-card">
        <div class="stat-value" id="statConfig">—</div>
        <div class="stat-label">Configuration</div>
      </div>
      <div class="bp-stat-card">
        <div class="stat-value" id="statStyle">—</div>
        <div class="stat-label">Style</div>
      </div>
      <div class="bp-stat-card">
        <div class="stat-value" id="statCost">—</div>
        <div class="stat-label">Est. Cost</div>
      </div>
    </div>

    <!-- Legend -->
    <div class="bp-legend" id="bpLegend" style="display:none">
      <h6><i class="fas fa-palette me-2"></i>Room Legend</h6>
      <div class="legend-grid" id="legendGrid">
        <!-- filled by JS -->
      </div>
    </div>
  </div>
</div>

<!-- ══════ FLOOR PLAN LAYOUT & FRONT ELEVATION DESIGN ══════ -->
<style>
.design-section{padding:50px 0}
.design-tabs{display:flex;gap:6px;padding:4px;background:var(--card-bg);border-radius:14px;border:1px solid var(--border);box-shadow:0 4px 20px rgba(0,0,0,.06);margin-bottom:24px;overflow-x:auto}
.design-tab{padding:10px 20px;border:2px solid transparent;border-radius:10px;background:transparent;color:var(--text-muted);font-size:.8rem;font-weight:600;cursor:pointer;transition:.3s;white-space:nowrap;display:flex;align-items:center;gap:6px;font-family:'Poppins'}
.design-tab:hover{background:rgba(255,107,53,.06);color:var(--accent);border-color:rgba(255,107,53,.15)}
.design-tab.active{background:linear-gradient(135deg,#FF6B35,#ff8c42);color:white;border-color:transparent;box-shadow:0 4px 16px rgba(255,107,53,.3)}
.design-tab i{font-size:.78rem}
.house-select-row{display:flex;gap:10px;margin-bottom:20px;overflow-x:auto;padding-bottom:6px}
.house-chip{padding:10px 18px;border-radius:12px;border:2px solid var(--border);background:var(--card-bg);cursor:pointer;transition:.3s;display:flex;align-items:center;gap:8px;white-space:nowrap;font-size:.78rem;font-weight:600;color:var(--text-main)}
.house-chip:hover{border-color:var(--accent);transform:translateY(-2px)}
.house-chip.active{border-color:var(--accent);background:rgba(255,107,53,.08);color:var(--accent);box-shadow:0 4px 16px rgba(255,107,53,.12)}
.house-chip .chip-icon{font-size:1.3rem}
.elev-viewer{background:var(--card-bg);border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.08);border:1px solid var(--border)}
.elev-header{display:flex;justify-content:space-between;align-items:center;padding:14px 20px;background:linear-gradient(135deg,#0e1621,#1a3c5e);color:white;font-size:.86rem;font-weight:700}
.elev-header .save-btn{padding:6px 14px;border-radius:8px;border:1px solid rgba(255,255,255,.3);background:transparent;color:white;font-size:.76rem;font-weight:600;cursor:pointer;transition:.3s}
.elev-header .save-btn:hover{background:rgba(255,255,255,.15);border-color:white}
.elev-img-wrap{position:relative;overflow:hidden;background:#111}
.elev-img-wrap img{width:100%;height:400px;object-fit:cover;transition:opacity .5s,transform .5s;display:block}
.elev-img-overlay{position:absolute;bottom:0;left:0;right:0;padding:20px 24px;background:linear-gradient(transparent,rgba(0,0,0,.75));color:white}
.elev-img-overlay .elev-tag{font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;opacity:.7;margin-bottom:4px}
.elev-img-overlay .elev-name{font-size:1.2rem;font-weight:800}
.elev-img-overlay .elev-detail{font-size:.76rem;opacity:.7;margin-top:3px}
.feat-strip{display:flex;background:var(--card-bg);border-top:1px solid var(--border)}
.feat-pill{flex:1;min-width:100px;display:flex;align-items:center;gap:8px;padding:13px 14px;font-size:.74rem;font-weight:600;color:var(--text-main);border-right:1px solid var(--border);justify-content:center;transition:.3s}
.feat-pill:last-child{border-right:none}
.feat-pill:hover{background:rgba(255,107,53,.05);color:var(--accent)}
.feat-pill i{font-size:.85rem}
.budget-card{background:var(--card-bg);border-radius:16px;padding:24px;border:1px solid var(--border);box-shadow:0 4px 20px rgba(0,0,0,.06);height:100%}
.budget-row-item{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px dashed var(--border);font-size:.84rem;color:var(--text-main)}
.budget-row-item:last-child{border-bottom:none}
.budget-row-item.total-row{border-bottom:none;border-top:2px solid var(--accent);padding-top:14px;margin-top:6px;font-weight:800}
.material-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;margin-top:20px}
.mat-item{background:var(--card-bg);border-radius:12px;padding:14px;border:1px solid var(--border);transition:.3s;text-align:center}
.mat-item:hover{transform:translateY(-3px);box-shadow:0 8px 24px rgba(0,0,0,.08);border-color:var(--accent)}
.mat-item .mat-emoji{font-size:1.6rem;margin-bottom:6px;display:block}
.mat-item .mat-title{font-size:.82rem;font-weight:700;color:var(--text-main)}
.mat-item .mat-info{font-size:.68rem;color:var(--text-muted);margin-top:2px}
.mat-item .mat-cost{font-size:.74rem;font-weight:700;color:var(--accent);margin-top:6px}
</style>

<section class="design-section" style="background:var(--body-bg)">
  <div class="container">
    <div class="text-center mb-4">
      <div style="display:inline-flex;align-items:center;gap:8px;background:rgba(255,107,53,.1);border:1px solid rgba(255,107,53,.3);padding:6px 18px;border-radius:50px;font-size:.76rem;font-weight:700;color:#FF6B35;margin-bottom:10px">
        <i class="fas fa-building"></i> Design Studio
      </div>
      <h2 style="font-weight:800;color:var(--text-main)">Floor Plan & Elevation Design</h2>
      <p style="color:var(--text-muted);font-size:.88rem;max-width:600px;margin:0 auto">Explore front elevation views, floor plan layouts, and architectural drawings for different house types</p>
    </div>

    <!-- House Type Chips -->
    <div class="house-select-row" id="houseChips">
      <div class="house-chip active" onclick="pickHouse(this,'modern')"><span class="chip-icon">🏢</span>Modern</div>
      <div class="house-chip" onclick="pickHouse(this,'simple')"><span class="chip-icon">🏡</span>Simple</div>
      <div class="house-chip" onclick="pickHouse(this,'premium')"><span class="chip-icon">🏰</span>Premium</div>
      <div class="house-chip" onclick="pickHouse(this,'luxury')"><span class="chip-icon">👑</span>Luxury Villa</div>
      <div class="house-chip" onclick="pickHouse(this,'duplex')"><span class="chip-icon">🏘️</span>Duplex</div>
    </div>

    <!-- Plan Type Tabs -->
    <div class="design-tabs" id="designTabs">
      <button class="design-tab active" onclick="pickTab(this,'front')"><i class="fas fa-home"></i>Front View</button>
      <button class="design-tab" onclick="pickTab(this,'floor')"><i class="fas fa-th-large"></i>Floor Plan</button>
      <button class="design-tab" onclick="pickTab(this,'elevation')"><i class="fas fa-building"></i>Elevation</button>
      <button class="design-tab" onclick="pickTab(this,'section')"><i class="fas fa-layer-group"></i>Section</button>
      <button class="design-tab" onclick="pickTab(this,'site')"><i class="fas fa-map"></i>Site Plan</button>
      <button class="design-tab" onclick="pickTab(this,'electrical')"><i class="fas fa-bolt"></i>Electrical</button>
      <button class="design-tab" onclick="pickTab(this,'plumbing')"><i class="fas fa-faucet"></i>Plumbing</button>
    </div>

    <div class="row g-4">
      <!-- Image Viewer -->
      <div class="col-lg-8">
        <div class="elev-viewer">
          <div class="elev-header">
            <span><i class="fas fa-drafting-compass me-2"></i><span id="dsLabel">Front View</span> — <span id="dsHouseType">Modern House</span></span>
            <button class="save-btn" onclick="savePlanImage()"><i class="fas fa-download me-1"></i>Save Image</button>
          </div>
          <div class="elev-img-wrap">
            <img id="dsImage" src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80" alt="Modern House Front View">
            <div class="elev-img-overlay">
              <div class="elev-tag" id="dsTag">Front Elevation Design</div>
              <div class="elev-name" id="dsTitle">Modern House</div>
              <div class="elev-detail" id="dsDesc">Contemporary flat-roof design with glass panels & minimalist facade</div>
            </div>
          </div>
          <div class="feat-strip" id="dsFeats">
            <div class="feat-pill"><i class="fas fa-ruler-combined text-warning"></i><span>Flat Roof</span></div>
            <div class="feat-pill"><i class="fas fa-window-maximize text-info"></i><span>Large Windows</span></div>
            <div class="feat-pill"><i class="fas fa-paint-roller text-success"></i><span>Minimal Finish</span></div>
            <div class="feat-pill"><i class="fas fa-car text-warning"></i><span>Parking</span></div>
          </div>
        </div>
      </div>

      <!-- Budget Estimator -->
      <div class="col-lg-4">
        <div class="budget-card">
          <h5 style="font-weight:800;margin-bottom:16px"><i class="fas fa-calculator me-2 text-accent"></i>Budget Estimator</h5>
          <div style="margin-bottom:14px">
            <label style="font-size:.76rem;font-weight:600;display:block;margin-bottom:4px">Plot Area (sq ft)</label>
            <input type="range" class="form-range" id="dsPlot" min="500" max="5000" value="1500" oninput="calcBudget()" style="accent-color:#FF6B35">
            <div style="display:flex;justify-content:space-between;font-size:.74rem;color:var(--text-muted)"><span>500</span><strong id="dsPlotVal" style="color:var(--accent)">1500 sqft</strong><span>5000</span></div>
          </div>
          <div style="margin-bottom:14px">
            <label style="font-size:.76rem;font-weight:600;display:block;margin-bottom:4px">Number of Floors</label>
            <select class="form-select form-select-sm" id="dsFloors" onchange="calcBudget()" style="border-radius:10px">
              <option value="1">Ground Floor</option>
              <option value="2" selected>G + 1 Floor</option>
              <option value="3">G + 2 Floors</option>
            </select>
          </div>
          <hr>
          <div id="dsBudgetResult">
            <div class="budget-row-item"><span>Built-up Area</span><strong id="dsBuilt">3000 sqft</strong></div>
            <div class="budget-row-item"><span>Structure Cost</span><strong id="dsStruct">—</strong></div>
            <div class="budget-row-item"><span>Finishing Cost</span><strong id="dsFinish">—</strong></div>
            <div class="budget-row-item"><span>Misc (10%)</span><strong id="dsMisc">—</strong></div>
            <div class="budget-row-item total-row"><span>Total Estimate</span><strong id="dsTotal" style="color:var(--accent);font-size:1.1rem">—</strong></div>
          </div>
        </div>
      </div>
    </div>

    <!-- Material Suggestions -->
    <div style="margin-top:40px">
      <h4 style="font-weight:800;text-center;margin-bottom:4px"><i class="fas fa-cubes me-2 text-accent"></i>Material Suggestions</h4>
      <p style="color:var(--text-muted);font-size:.82rem;text-align:center;margin-bottom:16px">Recommended for <strong id="dsMatType">Modern House</strong></p>
      <div class="material-grid" id="dsMaterialGrid"></div>
    </div>
  </div>
</section>

<script>
// ── ROOM COLORS ──
var ROOM_COLORS = {
  'Living Room':    { fill: '#E8F4FD', stroke: '#2196F3', label: '#1565C0', furniture: '#90CAF9' },
  'Master Bedroom': { fill: '#FFF3E0', stroke: '#FF9800', label: '#E65100', furniture: '#FFCC80' },
  'Bedroom':        { fill: '#F3E5F5', stroke: '#9C27B0', label: '#6A1B9A', furniture: '#CE93D8' },
  'Kitchen':        { fill: '#E8F5E9', stroke: '#4CAF50', label: '#2E7D32', furniture: '#A5D6A7' },
  'Bathroom':       { fill: '#E0F7FA', stroke: '#00BCD4', label: '#00838F', furniture: '#80DEEA' },
  'Dining':         { fill: '#FBE9E7', stroke: '#FF5722', label: '#BF360C', furniture: '#FFAB91' },
  'Balcony':        { fill: '#F1F8E9', stroke: '#8BC34A', label: '#558B2F', furniture: '#C5E1A5' },
  'Pooja':          { fill: '#FFF8E1', stroke: '#FFC107', label: '#F57F17', furniture: '#FFE082' },
  'Servant Room':   { fill: '#ECEFF1', stroke: '#607D8B', label: '#37474F', furniture: '#B0BEC5' },
  'Parking':        { fill: '#F5F5F5', stroke: '#9E9E9E', label: '#424242', furniture: '#E0E0E0' },
  'Entrance':       { fill: '#FCE4EC', stroke: '#E91E63', label: '#880E4F', furniture: '#F48FB1' },
  'Store':          { fill: '#EFEBE9', stroke: '#795548', label: '#3E2723', furniture: '#BCAAA4' },
  'Study':          { fill: '#E8EAF6', stroke: '#3F51B5', label: '#1A237E', furniture: '#9FA8DA' },
  'Lobby':          { fill: '#FAFAFA', stroke: '#BDBDBD', label: '#616161', furniture: '#E0E0E0' },
  'Conference':     { fill: '#E3F2FD', stroke: '#1976D2', label: '#0D47A1', furniture: '#90CAF9' },
  'Cabin':          { fill: '#FFF3E0', stroke: '#F57C00', label: '#E65100', furniture: '#FFCC80' },
  'Pantry':         { fill: '#E8F5E9', stroke: '#66BB6A', label: '#2E7D32', furniture: '#A5D6A7' },
  'Reception':      { fill: '#FCE4EC', stroke: '#EC407A', label: '#AD1457', furniture: '#F48FB1' }
};

// ── ROOM PRESETS PER TYPE ──
var ROOM_PRESETS = {
  'studio':    [{ name:'Living Room',1:true }, { name:'Kitchen',1:true }, { name:'Bathroom',1:true }],
  '1bhk':      [{ name:'Living Room' }, { name:'Master Bedroom' }, { name:'Kitchen' }, { name:'Bathroom' }, { name:'Dining' }],
  '2bhk':      [{ name:'Living Room' }, { name:'Master Bedroom' }, { name:'Bedroom' }, { name:'Kitchen' }, { name:'Bathroom',count:2 }, { name:'Dining' }],
  '3bhk':      [{ name:'Living Room' }, { name:'Master Bedroom' }, { name:'Bedroom',count:2 }, { name:'Kitchen' }, { name:'Bathroom',count:2 }, { name:'Dining' }],
  '4bhk':      [{ name:'Living Room' }, { name:'Master Bedroom' }, { name:'Bedroom',count:3 }, { name:'Kitchen' }, { name:'Bathroom',count:3 }, { name:'Dining' }, { name:'Study' }],
  'penthouse': [{ name:'Living Room' }, { name:'Master Bedroom' }, { name:'Bedroom',count:3 }, { name:'Kitchen' }, { name:'Bathroom',count:3 }, { name:'Dining' }, { name:'Study' }, { name:'Store' }],
  'office':    [{ name:'Reception' }, { name:'Conference' }, { name:'Cabin',count:3 }, { name:'Pantry' }, { name:'Bathroom',count:2 }, { name:'Lobby' }],
  'custom':    [{ name:'Living Room' }, { name:'Master Bedroom' }, { name:'Kitchen' }, { name:'Bathroom' }],
};

var AREA_PRESETS = { 'studio':450, '1bhk':650, '2bhk':1200, '3bhk':1600, '4bhk':2800, 'penthouse':4000, 'office':2000, 'custom':1200 };

var rooms = {};
var currentStyle = 'modern';
var canvasZoom = 1;

// ── INIT ROOM CONFIG UI ──
function initRoomConfig(type) {
  var preset = ROOM_PRESETS[type] || ROOM_PRESETS['2bhk'];
  rooms = {};
  preset.forEach(function(r) { rooms[r.name] = r.count || 1; });
  renderRoomConfig();
}

function renderRoomConfig() {
  var html = '';
  var icons = {
    'Living Room':'fa-couch','Master Bedroom':'fa-bed','Bedroom':'fa-bed',
    'Kitchen':'fa-utensils','Bathroom':'fa-bath','Dining':'fa-drumstick-bite',
    'Balcony':'fa-wind','Pooja':'fa-om','Servant Room':'fa-user',
    'Parking':'fa-car','Study':'fa-book','Store':'fa-box',
    'Reception':'fa-concierge-bell','Conference':'fa-users','Cabin':'fa-door-closed',
    'Pantry':'fa-coffee','Lobby':'fa-building','Entrance':'fa-door-open'
  };
  Object.keys(rooms).forEach(function(name) {
    var icon = icons[name] || 'fa-square';
    html += '<div class="room-row">' +
      '<div class="room-name"><i class="fas ' + icon + '"></i>' + name + '</div>' +
      '<div class="room-stepper">' +
        '<button onclick="changeRoom(\'' + name + '\',-1)">−</button>' +
        '<span class="room-count">' + rooms[name] + '</span>' +
        '<button onclick="changeRoom(\'' + name + '\',1)">+</button>' +
      '</div></div>';
  });
  document.getElementById('roomConfig').innerHTML = html;
}

function changeRoom(name, delta) {
  rooms[name] = Math.max(0, Math.min(8, (rooms[name] || 0) + delta));
  if (rooms[name] === 0) delete rooms[name];
  renderRoomConfig();
}

function selectStyle(el, style) {
  document.querySelectorAll('.style-card').forEach(function(c) { c.classList.remove('active'); });
  el.classList.add('active');
  currentStyle = style;
}

function updateUIFromType() {
  var type = document.getElementById('propType').value;
  document.getElementById('totalArea').value = AREA_PRESETS[type] || 1200;
  initRoomConfig(type);
}

// ── BLUEPRINT GENERATOR ENGINE ──
function generateBlueprint() {
  var btn = document.getElementById('generateBtn');
  btn.classList.add('generating');
  btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generating Blueprint...';

  setTimeout(function() {
    document.getElementById('emptyState').style.display = 'none';
    drawBlueprint();
    updateStats();
    document.getElementById('bpStats').style.display = 'flex';
    document.getElementById('bpLegend').style.display = 'block';
    btn.classList.remove('generating');
    btn.innerHTML = '<i class="fas fa-magic me-2"></i>Generate Blueprint';
  }, 1200);
}

function drawBlueprint() {
  var canvas = document.getElementById('blueprintCanvas');
  var ctx = canvas.getContext('2d');
  var totalArea = parseInt(document.getElementById('totalArea').value) || 1200;
  var showDimensions = document.getElementById('optDimensions').checked;
  var showFurniture = document.getElementById('optFurniture').checked;
  var hasBalcony = document.getElementById('optBalcony').checked;
  var hasPooja = document.getElementById('optPooja').checked;
  var hasServant = document.getElementById('optServant').checked;
  var hasParking = document.getElementById('optParking').checked;

  // Build room list
  var roomList = [];
  Object.keys(rooms).forEach(function(name) {
    for (var i = 0; i < rooms[name]; i++) {
      roomList.push({ name: name + (rooms[name] > 1 ? ' ' + (i+1) : ''), type: name });
    }
  });
  if (hasBalcony) roomList.push({ name: 'Balcony', type: 'Balcony' });
  if (hasPooja) roomList.push({ name: 'Pooja Room', type: 'Pooja' });
  if (hasServant) roomList.push({ name: 'Servant Room', type: 'Servant Room' });
  if (hasParking) roomList.push({ name: 'Car Parking', type: 'Parking' });
  roomList.unshift({ name: 'Entrance', type: 'Entrance' });

  // Canvas dimensions
  var W = 860, H = 640;
  canvas.width = W; canvas.height = H;

  // Margins
  var mx = 60, my = 60;
  var pw = W - mx * 2, ph = H - my * 2;

  // Clear
  ctx.fillStyle = '#FAFBFC';
  ctx.fillRect(0, 0, W, H);

  // Grid
  ctx.strokeStyle = '#E8ECF0';
  ctx.lineWidth = 0.5;
  for (var gx = mx; gx <= mx + pw; gx += 20) { ctx.beginPath(); ctx.moveTo(gx, my); ctx.lineTo(gx, my + ph); ctx.stroke(); }
  for (var gy = my; gy <= my + ph; gy += 20) { ctx.beginPath(); ctx.moveTo(mx, gy); ctx.lineTo(mx + pw, gy); ctx.stroke(); }

  // Title
  ctx.fillStyle = '#1a3c5e';
  ctx.font = 'bold 16px Poppins, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('FLOOR PLAN — ' + document.getElementById('propType').selectedOptions[0].text.toUpperCase(), W/2, 28);
  ctx.font = '11px Poppins, sans-serif';
  ctx.fillStyle = '#6B7280';
  ctx.fillText('Total Area: ' + totalArea + ' sq ft  |  Style: ' + currentStyle.charAt(0).toUpperCase() + currentStyle.slice(1) + '  |  Generated by PropNexus AI', W/2, 46);

  // ── ROOM LAYOUT ALGORITHM ──
  var n = roomList.length;
  // Simple treemap-like packing
  var rects = packRooms(roomList, mx, my, pw, ph, totalArea);

  // ── DRAW ROOMS ──
  rects.forEach(function(r, i) {
    var colors = ROOM_COLORS[r.type] || { fill: '#F5F5F5', stroke: '#9E9E9E', label: '#424242', furniture: '#E0E0E0' };

    // Room fill
    ctx.fillStyle = colors.fill;
    ctx.fillRect(r.x, r.y, r.w, r.h);

    // Wall pattern for style
    if (currentStyle === 'traditional') {
      ctx.strokeStyle = colors.stroke + '40';
      ctx.lineWidth = 1;
      for (var p = r.x + 15; p < r.x + r.w; p += 15) {
        ctx.beginPath(); ctx.moveTo(p, r.y); ctx.lineTo(p, r.y + r.h); ctx.stroke();
      }
    }

    // Room border (walls)
    ctx.strokeStyle = colors.stroke;
    ctx.lineWidth = 3;
    ctx.strokeRect(r.x, r.y, r.w, r.h);

    // Door
    if (r.type !== 'Parking' && r.type !== 'Balcony') {
      drawDoor(ctx, r);
    }

    // Furniture
    if (showFurniture) {
      drawFurniture(ctx, r, colors);
    }

    // Room label
    ctx.fillStyle = colors.label;
    ctx.font = 'bold 12px Poppins, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(r.name, r.x + r.w/2, r.y + r.h/2 - (showDimensions ? 8 : 0));

    // Dimensions
    if (showDimensions) {
      var roomAreaSqft = Math.round(r.areaSqft || (r.w * r.h / (pw * ph) * totalArea));
      var dimW = Math.round(Math.sqrt(roomAreaSqft * (r.w / r.h)) );
      var dimH = Math.round(roomAreaSqft / dimW);
      ctx.font = '10px Poppins, sans-serif';
      ctx.fillStyle = '#9CA3AF';
      ctx.fillText(dimW + "' × " + dimH + "'  (" + roomAreaSqft + " sqft)", r.x + r.w/2, r.y + r.h/2 + 10);
    }
  });

  // Outer wall
  ctx.strokeStyle = '#1a3c5e';
  ctx.lineWidth = 5;
  ctx.strokeRect(mx, my, pw, ph);

  // Vastu North indicator
  if (currentStyle === 'vastu') {
    drawVastuCompass(ctx, W - 55, my + 50);
  }

  // Scale bar
  ctx.fillStyle = '#1a3c5e';
  ctx.fillRect(mx, H - 22, 80, 3);
  ctx.font = '9px Poppins, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('Scale: 1px ≈ ' + (totalArea / (pw * ph) * 400).toFixed(1) + ' sqft', mx, H - 8);

  // Copyright
  ctx.textAlign = 'right';
  ctx.fillStyle = '#9CA3AF';
  ctx.font = '9px Poppins, sans-serif';
  ctx.fillText('© PropNexus AI Blueprint Generator', W - mx, H - 8);

  // Update legend
  updateLegend(rects);
}

// ── ROOM PACKING (TREEMAP-STYLE) ──
function packRooms(roomList, ox, oy, W, H, totalArea) {
  var rects = [];
  var n = roomList.length;
  if (n === 0) return rects;

  // Weight assignment
  var weights = {
    'Living Room': 20, 'Master Bedroom': 16, 'Bedroom': 13, 'Kitchen': 12,
    'Bathroom': 6, 'Dining': 10, 'Balcony': 5, 'Pooja': 4, 'Servant Room': 6,
    'Parking': 8, 'Entrance': 3, 'Store': 5, 'Study': 8,
    'Reception': 12, 'Conference': 14, 'Cabin': 8, 'Pantry': 6, 'Lobby': 6
  };

  var totalWeight = 0;
  roomList.forEach(function(r) { r.weight = weights[r.type] || 8; totalWeight += r.weight; });

  // Squarified treemap layout
  squarify(roomList, ox, oy, W, H, totalWeight, rects, totalArea);
  return rects;
}

function squarify(items, x, y, w, h, totalW, rects, totalArea) {
  if (items.length === 0) return;
  if (items.length === 1) {
    var item = items[0];
    var pad = 1;
    rects.push({
      x: x + pad, y: y + pad, w: w - pad*2, h: h - pad*2,
      name: item.name, type: item.type,
      areaSqft: Math.round(item.weight / totalW * totalArea)
    });
    return;
  }

  // Split horizontally or vertically
  var horizontal = w >= h;
  var half = 0, idx = 0, sum = 0;
  var target = totalW / 2;
  for (var i = 0; i < items.length; i++) {
    sum += items[i].weight;
    if (sum >= target) { idx = i; half = sum; break; }
  }
  idx = Math.max(0, Math.min(items.length - 2, idx));
  half = 0;
  for (var j = 0; j <= idx; j++) half += items[j].weight;

  var ratio = half / totalW;
  var group1 = items.slice(0, idx + 1);
  var group2 = items.slice(idx + 1);

  if (horizontal) {
    var splitX = Math.round(w * ratio);
    squarify(group1, x, y, splitX, h, half, rects, totalArea);
    squarify(group2, x + splitX, y, w - splitX, h, totalW - half, rects, totalArea);
  } else {
    var splitY = Math.round(h * ratio);
    squarify(group1, x, y, w, splitY, half, rects, totalArea);
    squarify(group2, x, y + splitY, w, h - splitY, totalW - half, rects, totalArea);
  }
}

// ── DRAW DOOR ──
function drawDoor(ctx, r) {
  var doorW = Math.min(24, r.w * 0.3);
  var doorX, doorY;

  // Place door on the largest wall
  if (r.w > r.h) {
    doorX = r.x + r.w * 0.35;
    doorY = r.y + r.h - 1;
    // Door arc
    ctx.fillStyle = r.type === 'Entrance' ? '#FF6B35' : '#FFFFFF';
    ctx.fillRect(doorX, doorY - 2, doorW, 4);
    ctx.strokeStyle = '#555';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(doorX, doorY, doorW, -Math.PI/2, 0, false);
    ctx.stroke();
  } else {
    doorX = r.x + r.w - 1;
    doorY = r.y + r.h * 0.35;
    ctx.fillStyle = r.type === 'Entrance' ? '#FF6B35' : '#FFFFFF';
    ctx.fillRect(doorX - 2, doorY, 4, doorW);
    ctx.strokeStyle = '#555';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(doorX, doorY, doorW, 0, Math.PI/2, false);
    ctx.stroke();
  }
}

// ── DRAW FURNITURE ──
function drawFurniture(ctx, r, colors) {
  ctx.fillStyle = colors.furniture;
  ctx.strokeStyle = colors.stroke + '60';
  ctx.lineWidth = 1;
  var cx = r.x + r.w / 2, cy = r.y + r.h / 2;
  var fw = Math.min(r.w * 0.4, 50), fh = Math.min(r.h * 0.3, 35);

  switch(r.type) {
    case 'Living Room':
      // Sofa
      roundRect(ctx, cx - fw, cy + fh - 10, fw * 2, 14, 4, true);
      // Coffee Table
      ctx.fillStyle = colors.stroke + '30';
      roundRect(ctx, cx - fw/3, cy + 2, fw*0.66, fh*0.5, 3, true);
      // TV unit
      ctx.fillStyle = colors.furniture;
      ctx.fillRect(cx - fw*0.6, r.y + 12, fw*1.2, 6);
      break;
    case 'Master Bedroom': case 'Bedroom':
      // Bed
      roundRect(ctx, cx - fw*0.7, cy - fh*0.3, fw*1.4, fh*1.2, 4, true);
      // Pillow
      ctx.fillStyle = '#fff';
      roundRect(ctx, cx - fw*0.5, cy - fh*0.2, fw*0.4, fh*0.3, 3, true);
      roundRect(ctx, cx + fw*0.1, cy - fh*0.2, fw*0.4, fh*0.3, 3, true);
      // Nightstand
      ctx.fillStyle = colors.furniture;
      ctx.fillRect(r.x + 8, cy, 10, 10);
      break;
    case 'Kitchen':
      // Counter L-shape
      ctx.fillStyle = colors.furniture;
      ctx.fillRect(r.x + 6, r.y + 6, r.w - 12, 12);
      ctx.fillRect(r.x + 6, r.y + 6, 12, r.h * 0.6);
      // Sink circle
      ctx.beginPath();
      ctx.arc(r.x + r.w * 0.6, r.y + 12, 5, 0, Math.PI*2);
      ctx.fillStyle = '#fff';
      ctx.fill();
      ctx.stroke();
      break;
    case 'Bathroom':
      // Toilet
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.ellipse(r.x + r.w * 0.3, r.y + r.h * 0.7, 8, 10, 0, 0, Math.PI*2);
      ctx.fill(); ctx.stroke();
      // Shower
      ctx.strokeStyle = colors.stroke + '80';
      ctx.setLineDash([3,3]);
      ctx.strokeRect(r.x + r.w * 0.55, r.y + 8, r.w * 0.35, r.h * 0.5);
      ctx.setLineDash([]);
      break;
    case 'Dining':
      // Table
      ctx.fillStyle = colors.furniture;
      roundRect(ctx, cx - fw*0.5, cy - fh*0.3, fw, fh*0.6, 4, true);
      // Chairs
      ctx.fillStyle = colors.stroke + '40';
      for (var ci = 0; ci < 4; ci++) {
        var angle = (ci / 4) * Math.PI * 2;
        var chairX = cx + Math.cos(angle) * fw * 0.7 - 5;
        var chairY = cy + Math.sin(angle) * fh * 0.5 - 5;
        roundRect(ctx, chairX, chairY, 10, 10, 3, true);
      }
      break;
    case 'Parking':
      // Car outline
      ctx.strokeStyle = colors.stroke;
      ctx.lineWidth = 1.5;
      roundRect(ctx, cx - 20, cy - 10, 40, 20, 6, false, true);
      ctx.fillStyle = colors.label;
      ctx.font = '9px Poppins';
      ctx.textAlign = 'center';
      ctx.fillText('🚗', cx, cy + 4);
      break;
    case 'Study':
      // Desk
      ctx.fillStyle = colors.furniture;
      ctx.fillRect(r.x + r.w * 0.15, r.y + r.h * 0.55, r.w * 0.7, 10);
      // Chair
      ctx.beginPath();
      ctx.arc(r.x + r.w * 0.5, r.y + r.h * 0.75, 8, 0, Math.PI*2);
      ctx.fillStyle = colors.stroke + '40';
      ctx.fill();
      break;
  }
}

function roundRect(ctx, x, y, w, h, r, fill, strokeOnly) {
  ctx.beginPath();
  ctx.moveTo(x+r, y);
  ctx.arcTo(x+w,y, x+w,y+h, r);
  ctx.arcTo(x+w,y+h, x,y+h, r);
  ctx.arcTo(x,y+h, x,y, r);
  ctx.arcTo(x,y, x+w,y, r);
  ctx.closePath();
  if (strokeOnly) { ctx.stroke(); return; }
  if (fill !== false) ctx.fill();
  ctx.stroke();
}

// ── VASTU COMPASS ──
function drawVastuCompass(ctx, cx, cy) {
  var r = 25;
  ctx.save();
  // Circle
  ctx.fillStyle = 'rgba(255,255,255,.9)';
  ctx.strokeStyle = '#FF6B35';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI*2);
  ctx.fill(); ctx.stroke();
  // N pointer
  ctx.fillStyle = '#E53935';
  ctx.beginPath();
  ctx.moveTo(cx, cy - r + 4);
  ctx.lineTo(cx - 6, cy);
  ctx.lineTo(cx + 6, cy);
  ctx.fill();
  // S pointer
  ctx.fillStyle = '#1a3c5e';
  ctx.beginPath();
  ctx.moveTo(cx, cy + r - 4);
  ctx.lineTo(cx - 6, cy);
  ctx.lineTo(cx + 6, cy);
  ctx.fill();
  // Labels
  ctx.fillStyle = '#E53935';
  ctx.font = 'bold 10px Poppins';
  ctx.textAlign = 'center';
  ctx.fillText('N', cx, cy - r - 4);
  ctx.fillStyle = '#1a3c5e';
  ctx.fillText('S', cx, cy + r + 12);
  ctx.fillText('E', cx + r + 8, cy + 4);
  ctx.fillText('W', cx - r - 8, cy + 4);
  ctx.restore();
}

// ── UPDATE STATS ──
function updateStats() {
  var totalArea = parseInt(document.getElementById('totalArea').value) || 1200;
  var type = document.getElementById('propType').selectedOptions[0].text;
  var totalRooms = 0;
  Object.keys(rooms).forEach(function(k) { totalRooms += rooms[k]; });
  var bedrooms = (rooms['Master Bedroom'] || 0) + (rooms['Bedroom'] || 0);
  var costPerSqft = currentStyle === 'modern' ? 2200 : currentStyle === 'traditional' ? 1800 : currentStyle === 'vastu' ? 2000 : 2400;
  var cost = totalArea * costPerSqft;
  var costStr = cost >= 10000000 ? '₹' + (cost/10000000).toFixed(1) + ' Cr' : cost >= 100000 ? '₹' + (cost/100000).toFixed(1) + ' L' : '₹' + cost.toLocaleString('en-IN');

  document.getElementById('statArea').textContent = totalArea + ' sqft';
  document.getElementById('statRooms').textContent = totalRooms;
  document.getElementById('statConfig').textContent = bedrooms + ' BHK';
  document.getElementById('statStyle').textContent = currentStyle.charAt(0).toUpperCase() + currentStyle.slice(1);
  document.getElementById('statCost').textContent = costStr;
}

function updateLegend(rects) {
  var seen = {};
  var html = '';
  rects.forEach(function(r) {
    if (seen[r.type]) return;
    seen[r.type] = true;
    var c = ROOM_COLORS[r.type] || { fill: '#F5F5F5', stroke: '#9E9E9E' };
    html += '<div class="legend-item"><div class="legend-color" style="background:' + c.fill + ';border-color:' + c.stroke + '"></div>' + r.type + '</div>';
  });
  document.getElementById('legendGrid').innerHTML = html;
}

// ── ZOOM ──
function zoomCanvas(dir) {
  canvasZoom = Math.max(0.5, Math.min(2, canvasZoom + dir * 0.25));
  var canvas = document.getElementById('blueprintCanvas');
  canvas.style.transform = 'scale(' + canvasZoom + ')';
  canvas.style.transformOrigin = 'top left';
  var container = document.getElementById('canvasContainer');
  container.style.height = (640 * canvasZoom) + 'px';
}

// ── DOWNLOAD ──
function downloadBlueprint(format) {
  var canvas = document.getElementById('blueprintCanvas');
  if (format === 'png') {
    var link = document.createElement('a');
    link.download = 'PropNexus_Blueprint_' + Date.now() + '.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  } else if (format === 'pdf') {
    // Simple approach: create an image and open in new window for printing
    var win = window.open('', '_blank');
    win.document.write('<html><head><title>PropNexus Blueprint</title><style>body{margin:0;display:flex;justify-content:center;align-items:center;min-height:100vh;background:#fff;}img{max-width:100%;height:auto;}</style></head><body>');
    win.document.write('<img src="' + canvas.toDataURL('image/png') + '">');
    win.document.write('</body></html>');
    win.document.close();
    setTimeout(function() { win.print(); }, 500);
  }
}

// ── INIT ──
document.addEventListener('DOMContentLoaded', function() {
  initRoomConfig('2bhk');
  // Design Studio init
  updateDesignView();
  renderDsMaterials();
  calcBudget();
});

// ══════════════════════════════════════════════════════════
// DESIGN STUDIO — Floor Plan & Elevation
// ══════════════════════════════════════════════════════════
var dsHouse = 'modern';
var dsPlan = 'front';

var DS_PLANS = {
  front:{
    simple:{img:'https://images.unsplash.com/photo-1518780664697-55e3ad937233?w=800&q=80',t:'Simple House — Front View',d:'Budget-friendly facade with sloped roof, painted walls and basic landscaping',f:[{i:'fa-home',c:'text-success',l:'Single Story'},{i:'fa-layer-group',c:'text-danger',l:'Sloped Roof'},{i:'fa-th-large',c:'text-warning',l:'Clay Tiles'},{i:'fa-leaf',c:'text-success',l:'Garden'}]},
    modern:{img:'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80',t:'Modern House — Front View',d:'Contemporary flat-roof design with glass panels & minimalist facade',f:[{i:'fa-ruler-combined',c:'text-warning',l:'Flat Roof'},{i:'fa-window-maximize',c:'text-info',l:'Large Windows'},{i:'fa-paint-roller',c:'text-success',l:'Minimal Finish'},{i:'fa-car',c:'text-warning',l:'Parking'}]},
    premium:{img:'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80',t:'Premium House — Front View',d:'Grand bungalow with stone cladding, pillars and premium finishes',f:[{i:'fa-columns',c:'text-primary',l:'Grand Pillars'},{i:'fa-gem',c:'text-danger',l:'Stone Cladding'},{i:'fa-wifi',c:'text-info',l:'Smart Home'},{i:'fa-hot-tub',c:'text-warning',l:'Luxury Bath'}]},
    luxury:{img:'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&q=80',t:'Luxury Villa — Front View',d:'Ultra-premium villa with marble facade, landscaped gardens & pool',f:[{i:'fa-crown',c:'text-warning',l:'Premium Marble'},{i:'fa-swimming-pool',c:'text-info',l:'Pool Area'},{i:'fa-shield-alt',c:'text-danger',l:'Security'},{i:'fa-tree',c:'text-success',l:'Landscape'}]},
    duplex:{img:'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=800&q=80',t:'Duplex House — Front View',d:'Two-floor home with modern balcony, staircase & separate entrances',f:[{i:'fa-building',c:'text-primary',l:'Two Floors'},{i:'fa-stairs',c:'text-warning',l:'Staircase'},{i:'fa-door-open',c:'text-success',l:'Balcony'},{i:'fa-expand-arrows-alt',c:'text-info',l:'Spacious'}]}
  },
  floor:{
    simple:{img:'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&q=80',t:'Simple House — Floor Plan',d:'Open layout with 2BHK arrangement: living, kitchen, bedrooms & bath',f:[{i:'fa-bed',c:'text-primary',l:'2 Bedrooms'},{i:'fa-utensils',c:'text-danger',l:'Kitchen'},{i:'fa-couch',c:'text-info',l:'Living Room'},{i:'fa-bath',c:'text-warning',l:'1 Bathroom'}]},
    modern:{img:'https://images.unsplash.com/photo-1574362848149-11496d93a7c7?w=800&q=80',t:'Modern House — Floor Plan',d:'Open-concept with island kitchen, master suite & utility room',f:[{i:'fa-bed',c:'text-primary',l:'3 Bedrooms'},{i:'fa-utensils',c:'text-danger',l:'Modular Kitchen'},{i:'fa-couch',c:'text-info',l:'Open Living'},{i:'fa-car',c:'text-warning',l:'Garage'}]},
    premium:{img:'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&q=80',t:'Premium House — Floor Plan',d:'Spacious with home office, walk-in closets & pooja room',f:[{i:'fa-bed',c:'text-primary',l:'4 Bedrooms'},{i:'fa-laptop-house',c:'text-success',l:'Home Office'},{i:'fa-praying-hands',c:'text-warning',l:'Pooja Room'},{i:'fa-bath',c:'text-info',l:'3 Bathrooms'}]},
    luxury:{img:'https://images.unsplash.com/photo-1574362848149-11496d93a7c7?w=800&q=80',t:'Luxury Villa — Floor Plan',d:'Expansive with home theater, gym, guest suite & servant quarters',f:[{i:'fa-bed',c:'text-primary',l:'5+ Bedrooms'},{i:'fa-film',c:'text-danger',l:'Home Theater'},{i:'fa-dumbbell',c:'text-info',l:'Gym'},{i:'fa-swimming-pool',c:'text-warning',l:'Pool'}]},
    duplex:{img:'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800&q=80',t:'Duplex — Floor Plan (Both Floors)',d:'Ground: living, kitchen. First floor: bedrooms, study',f:[{i:'fa-bed',c:'text-primary',l:'3 Bedrooms'},{i:'fa-utensils',c:'text-danger',l:'Kitchen'},{i:'fa-book',c:'text-info',l:'Study'},{i:'fa-bath',c:'text-warning',l:'2 Bathrooms'}]}
  },
  elevation:{
    simple:{img:'https://images.unsplash.com/photo-1449844908441-8829872d2607?w=800&q=80',t:'Simple House — Elevation',d:'Side elevation showing roof pitch, window placement & floor heights',f:[{i:'fa-arrows-alt-v',c:'text-primary',l:'10ft Height'},{i:'fa-window-maximize',c:'text-info',l:'Standard Windows'},{i:'fa-ruler-vertical',c:'text-danger',l:'Plinth Level'},{i:'fa-cloud-rain',c:'text-success',l:'Rain Gutters'}]},
    modern:{img:'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',t:'Modern House — Elevation',d:'All-side elevation with material annotations & cladding details',f:[{i:'fa-arrows-alt-v',c:'text-primary',l:'12ft Height'},{i:'fa-window-maximize',c:'text-info',l:'Floor-to-Ceiling'},{i:'fa-th',c:'text-warning',l:'ACP Cladding'},{i:'fa-lightbulb',c:'text-success',l:'Facade Lighting'}]},
    premium:{img:'https://images.unsplash.com/photo-1600607687644-aac4c3eac7f4?w=800&q=80',t:'Premium House — Elevation',d:'Detailed elevation with stone texture, pillar sections & ornaments',f:[{i:'fa-arrows-alt-v',c:'text-primary',l:'14ft Height'},{i:'fa-columns',c:'text-warning',l:'Columns'},{i:'fa-gem',c:'text-danger',l:'Stone Work'},{i:'fa-border-style',c:'text-info',l:'Cornices'}]},
    luxury:{img:'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',t:'Luxury Villa — Elevation',d:'Grand elevation with double-height spaces, terrace gardens & canopy',f:[{i:'fa-arrows-alt-v',c:'text-primary',l:'18ft Double'},{i:'fa-tree',c:'text-success',l:'Terrace Garden'},{i:'fa-glass-martini',c:'text-danger',l:'Entertainment'},{i:'fa-sun',c:'text-warning',l:'Pergola'}]},
    duplex:{img:'https://images.unsplash.com/photo-1600607687644-aac4c3eac7f4?w=800&q=80',t:'Duplex — Elevation',d:'Two-floor elevation with staircase profile & balcony railing details',f:[{i:'fa-arrows-alt-v',c:'text-primary',l:'22ft Total'},{i:'fa-stairs',c:'text-warning',l:'Staircase'},{i:'fa-border-all',c:'text-info',l:'Railings'},{i:'fa-grip-horizontal',c:'text-warning',l:'Parapet'}]}
  },
  section:{
    simple:{img:'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800&q=80',t:'Simple House — Section',d:'Cross-section showing foundation depth, wall thickness & roof structure',f:[{i:'fa-expand-arrows-alt',c:'text-primary',l:'Wall 9" Thick'},{i:'fa-level-down-alt',c:'text-danger',l:'3ft Foundation'},{i:'fa-angle-double-up',c:'text-info',l:'Truss Roof'},{i:'fa-ruler-vertical',c:'text-success',l:'10ft Clearance'}]},
    modern:{img:'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&q=80',t:'Modern House — Section',d:'Section through living room showing slab levels & sunken areas',f:[{i:'fa-expand-arrows-alt',c:'text-primary',l:'RCC 6" Slab'},{i:'fa-level-down-alt',c:'text-danger',l:'Sunken Floor'},{i:'fa-grip-lines',c:'text-info',l:'False Ceiling'},{i:'fa-lightbulb',c:'text-warning',l:'Cove Lights'}]},
    premium:{img:'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800&q=80',t:'Premium House — Section',d:'Section with insulation layers, waterproofing & HVAC ducts',f:[{i:'fa-shield-alt',c:'text-primary',l:'Insulation'},{i:'fa-water',c:'text-info',l:'Waterproofing'},{i:'fa-wind',c:'text-success',l:'HVAC Ducts'},{i:'fa-download',c:'text-warning',l:'Drainage'}]},
    luxury:{img:'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&q=80',t:'Luxury Villa — Section',d:'Complex section with basement, double-height foyer & pool pit',f:[{i:'fa-level-down-alt',c:'text-danger',l:'Basement'},{i:'fa-arrows-alt-v',c:'text-primary',l:'Double Height'},{i:'fa-swimming-pool',c:'text-info',l:'Pool Pit'},{i:'fa-leaf',c:'text-success',l:'Green Roof'}]},
    duplex:{img:'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800&q=80',t:'Duplex — Section',d:'Section showing staircase construction & inter-floor slab',f:[{i:'fa-stairs',c:'text-warning',l:'Staircase RCC'},{i:'fa-grip-lines',c:'text-primary',l:'Inter Slab'},{i:'fa-columns',c:'text-warning',l:'Utility Shaft'},{i:'fa-border-all',c:'text-info',l:'Parapet Wall'}]}
  },
  site:{
    simple:{img:'https://images.unsplash.com/photo-1494526585095-c41746248156?w=800&q=80',t:'Simple House — Site Plan',d:'Plot layout showing setbacks, driveway, garden & boundary walls',f:[{i:'fa-border-all',c:'text-primary',l:'Boundary Wall'},{i:'fa-road',c:'text-warning',l:'Driveway'},{i:'fa-seedling',c:'text-success',l:'Garden'},{i:'fa-arrows-alt',c:'text-info',l:'Setbacks'}]},
    modern:{img:'https://images.unsplash.com/photo-1448630360428-65456885c650?w=800&q=80',t:'Modern House — Site Plan',d:'Site plan with parking, landscape zones & utility connections',f:[{i:'fa-car',c:'text-warning',l:'2-Car Parking'},{i:'fa-tree',c:'text-success',l:'Landscape'},{i:'fa-tint',c:'text-info',l:'Water Tank'},{i:'fa-plug',c:'text-danger',l:'Utilities'}]},
    premium:{img:'https://images.unsplash.com/photo-1494526585095-c41746248156?w=800&q=80',t:'Premium House — Site Plan',d:'Site plan with pool placement, generator room & security cabin',f:[{i:'fa-swimming-pool',c:'text-info',l:'Pool Area'},{i:'fa-bolt',c:'text-warning',l:'Generator'},{i:'fa-shield-alt',c:'text-danger',l:'Guard Room'},{i:'fa-tree',c:'text-success',l:'Lawn'}]},
    luxury:{img:'https://images.unsplash.com/photo-1448630360428-65456885c650?w=800&q=80',t:'Luxury Villa — Site Plan',d:'Estate plan with guest house, pool, tennis court & multi-car parking',f:[{i:'fa-home',c:'text-primary',l:'Guest House'},{i:'fa-table-tennis',c:'text-warning',l:'Tennis Court'},{i:'fa-parking',c:'text-warning',l:'Multi Parking'},{i:'fa-water',c:'text-info',l:'Water Feature'}]},
    duplex:{img:'https://images.unsplash.com/photo-1494526585095-c41746248156?w=800&q=80',t:'Duplex — Site Plan',d:'Twin-unit plan with separate entrances & shared driveway',f:[{i:'fa-door-open',c:'text-success',l:'2 Entrances'},{i:'fa-road',c:'text-warning',l:'Shared Drive'},{i:'fa-grip-vertical',c:'text-primary',l:'Partition'},{i:'fa-seedling',c:'text-info',l:'Gardens'}]}
  },
  electrical:{
    simple:{img:'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=800&q=80',t:'Simple House — Electrical',d:'Basic wiring layout with switch points, sockets, DB board & earthing',f:[{i:'fa-plug',c:'text-warning',l:'15A Sockets'},{i:'fa-toggle-on',c:'text-info',l:'Switches'},{i:'fa-server',c:'text-primary',l:'DB Board'},{i:'fa-bolt',c:'text-danger',l:'Earthing'}]},
    modern:{img:'https://images.unsplash.com/photo-1555664424-778a1e5e1b48?w=800&q=80',t:'Modern House — Electrical',d:'Smart wiring with RCBO, USB outlets, cove lighting & sensors',f:[{i:'fa-microchip',c:'text-info',l:'Smart Switches'},{i:'fa-lightbulb',c:'text-warning',l:'Cove Lights'},{i:'fa-usb',c:'text-primary',l:'USB Outlets'},{i:'fa-shield-alt',c:'text-danger',l:'RCBO'}]},
    premium:{img:'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=800&q=80',t:'Premium House — Electrical',d:'Home automation wiring, UPS circuit & solar panel interface',f:[{i:'fa-robot',c:'text-info',l:'Automation'},{i:'fa-battery-full',c:'text-success',l:'UPS Circuit'},{i:'fa-solar-panel',c:'text-warning',l:'Solar Ready'},{i:'fa-wifi',c:'text-primary',l:'Data Points'}]},
    luxury:{img:'https://images.unsplash.com/photo-1555664424-778a1e5e1b48?w=800&q=80',t:'Luxury Villa — Electrical',d:'Full KNX automation, landscape lighting, pool electric & AV wiring',f:[{i:'fa-microchip',c:'text-primary',l:'KNX System'},{i:'fa-film',c:'text-danger',l:'AV Wiring'},{i:'fa-elevator',c:'text-warning',l:'Elevator'},{i:'fa-swimming-pool',c:'text-info',l:'Pool Electric'}]},
    duplex:{img:'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=800&q=80',t:'Duplex — Electrical',d:'Dual-floor wiring with separate meters & staircase lighting',f:[{i:'fa-tachometer-alt',c:'text-warning',l:'2 Meters'},{i:'fa-lightbulb',c:'text-info',l:'Stair Lights'},{i:'fa-code-branch',c:'text-primary',l:'Distribution'},{i:'fa-bell',c:'text-danger',l:'Intercom'}]}
  },
  plumbing:{
    simple:{img:'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=800&q=80',t:'Simple House — Plumbing',d:'Cold & hot water supply, drainage layout & septic connection',f:[{i:'fa-tint',c:'text-info',l:'Water Supply'},{i:'fa-arrow-down',c:'text-danger',l:'Drainage'},{i:'fa-toilet',c:'text-primary',l:'Fixtures'},{i:'fa-warehouse',c:'text-warning',l:'Septic Tank'}]},
    modern:{img:'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=800&q=80',t:'Modern House — Plumbing',d:'CPVC lines, concealed drainage, rain water harvesting & STP',f:[{i:'fa-tint',c:'text-info',l:'CPVC Lines'},{i:'fa-cloud-rain',c:'text-primary',l:'Rain Harvest'},{i:'fa-recycle',c:'text-success',l:'STP Ready'},{i:'fa-fire',c:'text-danger',l:'Hot Water'}]},
    premium:{img:'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=800&q=80',t:'Premium House — Plumbing',d:'Multi-point geyser, floor drains, water softener & pressure pump',f:[{i:'fa-fire',c:'text-danger',l:'Multi Geyser'},{i:'fa-tachometer-alt',c:'text-warning',l:'Pressure Pump'},{i:'fa-filter',c:'text-info',l:'Water Softener'},{i:'fa-arrow-down',c:'text-primary',l:'Floor Drains'}]},
    luxury:{img:'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=800&q=80',t:'Luxury Villa — Plumbing',d:'Central heating, pool plumbing, fountain supply & grey water recycling',f:[{i:'fa-swimming-pool',c:'text-info',l:'Pool Plumbing'},{i:'fa-spa',c:'text-danger',l:'Spa Lines'},{i:'fa-recycle',c:'text-success',l:'Grey Water'},{i:'fa-fountain',c:'text-primary',l:'Fountain'}]},
    duplex:{img:'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=800&q=80',t:'Duplex — Plumbing',d:'Vertical stack system, overhead tank & separate bathroom risers',f:[{i:'fa-arrows-alt-v',c:'text-primary',l:'Vertical Stack'},{i:'fa-database',c:'text-info',l:'OH Tank'},{i:'fa-code-branch',c:'text-warning',l:'Risers'},{i:'fa-toilet',c:'text-danger',l:'Dual Bath'}]}
  }
};

var DS_MATERIALS = {
  simple:[{e:'\uD83E\uDDF1',n:'Bricks',d:'Standard clay red bricks',b:'Local kiln bricks',p:'\u20B95-8/brick'},{e:'\uD83E\uDEA8',n:'Cement',d:'OPC 43 grade',b:'UltraTech / ACC',p:'\u20B9350-400/bag'},{e:'\uD83C\uDFD7\uFE0F',n:'TMT Steel',d:'Fe500 grade bars',b:'TATA Tiscon',p:'\u20B955-65/kg'},{e:'\uD83E\uDEB5',n:'Wood',d:'Sal wood doors',b:'Local timber',p:'\u20B91500-2500/cft'},{e:'\uD83D\uDD32',n:'Tiles',d:'Ceramic 2x2',b:'Johnson / Kajaria',p:'\u20B925-40/sqft'},{e:'\uD83C\uDFA8',n:'Paint',d:'Interior emulsion',b:'Asian Paints',p:'\u20B9150-250/ltr'}],
  modern:[{e:'\uD83E\uDDF1',n:'AAC Blocks',d:'Lightweight concrete',b:'Magicrete',p:'\u20B945-60/block'},{e:'\uD83E\uDEA8',n:'Cement',d:'PPC eco-friendly',b:'UltraTech',p:'\u20B9380-420/bag'},{e:'\uD83E\uDE9F',n:'UPVC Windows',d:'Double-glazed',b:'Fenesta',p:'\u20B9450-700/sqft'},{e:'\uD83C\uDFD7\uFE0F',n:'TMT Steel',d:'Fe550 bars',b:'TATA / Jindal',p:'\u20B965-75/kg'},{e:'\uD83D\uDD32',n:'Vitrified Tiles',d:'600x600 anti-skid',b:'Somany',p:'\u20B945-80/sqft'},{e:'\uD83C\uDFA8',n:'Premium Paint',d:'Weatherproof',b:'Asian Royale',p:'\u20B9350-550/ltr'}],
  premium:[{e:'\uD83E\uDDF1',n:'Fly Ash Bricks',d:'High-strength',b:'Premium mfr',p:'\u20B98-12/brick'},{e:'\uD83E\uDE9F',n:'Aluminium Windows',d:'Powder-coated',b:'Hindalco',p:'\u20B9600-1000/sqft'},{e:'\uD83D\uDEBF',n:'Premium Bath',d:'Wall-hung WC',b:'Kohler',p:'\u20B950K-1.5L'},{e:'\uD83C\uDFD7\uFE0F',n:'Steel Fe600',d:'Earthquake-safe',b:'TATA Tiscon',p:'\u20B970-85/kg'},{e:'\uD83D\uDD32',n:'Italian Marble',d:'Statuario/Carrara',b:'Italian imports',p:'\u20B9200-800/sqft'},{e:'\uD83C\uDFE0',n:'Smart Home Kit',d:'Automated lights',b:'Schneider',p:'\u20B91-3L/home'}],
  luxury:[{e:'\uD83E\uDEA8',n:'Imported Marble',d:'Calacatta Gold',b:'Italy/Spain',p:'\u20B9500-2000/sqft'},{e:'\uD83E\uDE9F',n:'Designer Glass',d:'Low-E tempered',b:'Saint-Gobain',p:'\u20B9800-1500/sqft'},{e:'\uD83C\uDFE0',n:'Home Automation',d:'KNX/Crestron',b:'Control4',p:'\u20B95-15L'},{e:'\uD83D\uDEBF',n:'Luxury Fixtures',d:'Designer faucets',b:'Grohe',p:'\u20B92-8L/bath'},{e:'\uD83D\uDD10',n:'Security System',d:'Biometric CCTV',b:'Honeywell',p:'\u20B92-5L'},{e:'\uD83C\uDF3F',n:'Landscaping',d:'Designer garden',b:'Professional',p:'\u20B93-10L'}],
  duplex:[{e:'\uD83E\uDDF1',n:'AAC Blocks',d:'Upper floor blocks',b:'Magicrete',p:'\u20B945-60/block'},{e:'\uD83C\uDFD7\uFE0F',n:'Staircase Steel',d:'MS + glass railing',b:'Custom fab',p:'\u20B9800-1500/rft'},{e:'\uD83E\uDE9F',n:'Sliding Windows',d:'Aluminium mesh',b:'Fenesta',p:'\u20B9500-800/sqft'},{e:'\uD83D\uDD32',n:'Wood Flooring',d:'Oak/teak planks',b:'Pergo',p:'\u20B9150-350/sqft'},{e:'\uD83C\uDFA8',n:'Texture Paint',d:'Exterior texture',b:'Asian Apex',p:'\u20B9400-600/ltr'},{e:'\uD83D\uDCA1',n:'LED Lighting',d:'Recessed & cove',b:'Philips',p:'\u20B950K-1.5L'}]
};

function pickHouse(el, type) {
  document.querySelectorAll('.house-chip').forEach(function(c){c.classList.remove('active')});
  el.classList.add('active');
  dsHouse = type;
  var names = {simple:'Simple House',modern:'Modern House',premium:'Premium House',luxury:'Luxury Villa',duplex:'Duplex House'};
  document.getElementById('dsHouseType').textContent = names[type]||type;
  document.getElementById('dsMatType').textContent = names[type]||type;
  updateDesignView();
  renderDsMaterials();
  calcBudget();
}

function pickTab(el, plan) {
  document.querySelectorAll('.design-tab').forEach(function(t){t.classList.remove('active')});
  el.classList.add('active');
  dsPlan = plan;
  var labels = {front:'Front View',floor:'Floor Plan',elevation:'Elevation Drawing',section:'Section Drawing',site:'Site Plan',electrical:'Electrical Plan',plumbing:'Plumbing Plan'};
  document.getElementById('dsLabel').textContent = labels[plan]||plan;
  updateDesignView();
}

function updateDesignView() {
  var planSet = DS_PLANS[dsPlan] || DS_PLANS.front;
  var data = planSet[dsHouse] || planSet.modern;
  var img = document.getElementById('dsImage');
  img.style.opacity = '0';
  img.style.transform = 'scale(1.03)';
  setTimeout(function() {
    img.src = data.img;
    img.alt = data.t;
    document.getElementById('dsTitle').textContent = data.t;
    document.getElementById('dsDesc').textContent = data.d;
    var tagLabels = {front:'Front Elevation Design',floor:'Floor Plan Layout',elevation:'Elevation Drawing',section:'Section Drawing Detail',site:'Site Plan Layout',electrical:'Electrical Wiring Layout',plumbing:'Plumbing & Drainage Plan'};
    document.getElementById('dsTag').textContent = tagLabels[dsPlan]||'Design';
    var fh = '';
    data.f.forEach(function(feat){fh+='<div class="feat-pill"><i class="fas '+feat.i+' '+feat.c+'"></i><span>'+feat.l+'</span></div>';});
    document.getElementById('dsFeats').innerHTML = fh;
    img.style.opacity = '1';
    img.style.transform = 'scale(1)';
  },300);
}

function savePlanImage() {
  var img = document.getElementById('dsImage');
  var a = document.createElement('a');
  a.href = img.src;
  a.download = 'PropNexus_'+dsPlan+'_'+dsHouse+'.jpg';
  a.target = '_blank';
  a.click();
}

function calcBudget() {
  var area = parseInt(document.getElementById('dsPlot').value)||1500;
  var floors = parseFloat(document.getElementById('dsFloors').value)||2;
  document.getElementById('dsPlotVal').textContent = area+' sqft';
  var builtUp = Math.round(area*floors);
  var rates = {simple:1000,modern:2000,premium:3200,luxury:6000,duplex:2600};
  var rate = rates[dsHouse]||2000;
  var struct = Math.round(builtUp*rate*0.6);
  var finish = Math.round(builtUp*rate*0.3);
  var misc = Math.round((struct+finish)*0.1);
  var total = struct+finish+misc;
  function fmtCost(v){if(v>=10000000)return'\u20B9'+(v/10000000).toFixed(1)+' Cr';if(v>=100000)return'\u20B9'+(v/100000).toFixed(1)+' L';return'\u20B9'+v.toLocaleString('en-IN');}
  document.getElementById('dsBuilt').textContent = builtUp+' sqft';
  document.getElementById('dsStruct').textContent = fmtCost(struct);
  document.getElementById('dsFinish').textContent = fmtCost(finish);
  document.getElementById('dsMisc').textContent = fmtCost(misc);
  document.getElementById('dsTotal').textContent = fmtCost(total);
}

function renderDsMaterials() {
  var mats = DS_MATERIALS[dsHouse] || DS_MATERIALS.modern;
  var html = '';
  mats.forEach(function(m){
    html+='<div class="mat-item"><span class="mat-emoji">'+m.e+'</span><div class="mat-title">'+m.n+'</div><div class="mat-info">'+m.d+' — '+m.b+'</div><div class="mat-cost">'+m.p+'</div></div>';
  });
  document.getElementById('dsMaterialGrid').innerHTML = html;
}
</script>

<?php require_once 'includes/footer.php'; ?>
