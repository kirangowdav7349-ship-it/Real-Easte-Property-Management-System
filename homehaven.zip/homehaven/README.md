# 🏠 HomeHaven – Real Estate Property Management System

A full-featured real estate platform built with PHP, MySQL, Bootstrap & JavaScript.
Inspired by NoBroker-style design with zero-brokerage concept.

---

## 🔐 Admin Login Credentials (Pre-configured)

| Field    | Value                  |
|----------|------------------------|
| Email    | admin@homehaven.com    |
| Password | Admin@123               |
| URL      | /admin/login.php       |

---

## ⚙️ Installation & Setup

### Requirements
- XAMPP (Apache + MySQL + PHP 7.4+)
- Browser (Chrome / Firefox)

### Steps

1. **Download & Extract**
   - Unzip `HomeHaven_PropertyManagement.zip`
   - Copy the `homehaven` folder to:
     ```
     C:\xampp\htdocs\homehaven
     ```

2. **Start XAMPP**
   - Open XAMPP Control Panel
   - Start **Apache** and **MySQL**

3. **Import Database**
   - Open browser → go to `http://localhost/phpmyadmin`
   - Click **New** → Create database named: `homehaven_db`
   - Click the database → go to **Import** tab
   - Choose file: `homehaven/database.sql`
   - Click **Go**

4. **Launch the Project**
   - Website: `http://localhost/homehaven `
   - Admin Panel: `http://localhost/homehaven/admin/login.php`

---

## 📁 Project Structure

```
homehaven/
│
├── index.php                   → Homepage
├── properties.php              → Property Listings (Buy/Rent/Commercial)
├── property-detail.php         → Property Detail with Room Images
├── services.php                → Home Services (Cleaning, Painting, etc.)
├── legal.php                   → Legal Services
├── loans.php                   → Loan Services + EMI Calculator
├── plans.php                   → Subscription Plans
├── alerts.php                  → Property Alerts
├── database.sql                → Full Database Schema + Sample Data
│
├── includes/
│   ├── config.php              → DB Config + Helper Functions
│   ├── header.php              → Navbar Header
│   └── footer.php              → Footer
│
├── assets/
│   ├── css/style.css           → Main Stylesheet
│   └── js/main.js              → JavaScript
│
├── client/
│   ├── register.php            → Client Registration
│   ├── login.php               → Client Login
│   ├── logout.php              → Client Logout
│   ├── dashboard.php           → Client Dashboard
│   ├── rent-payment.php        → Online Rent Payment
│   └── alerts.php              → My Property Alerts
│
└── admin/
    ├── login.php               → Admin Login
    ├── logout.php              → Admin Logout
    ├── dashboard.php           → Admin Dashboard (Stats)
    ├── properties.php          → Manage Properties
    ├── add-property.php        → Add New Property
    ├── edit-property.php       → Edit Property + Room Images
    ├── clients.php             → Manage Clients
    ├── enquiries.php           → View Enquiries
    ├── bookings.php            → Service Bookings
    ├── payments.php            → Rent Payment Records
    ├── alerts.php              → Property Alert Records
    ├── plans.php               → Subscription Plans
    ├── services.php            → Manage Services
    └── includes/
        └── sidebar.php         → Admin Sidebar Layout
```

---

## 🌐 15 Pages Overview

| # | Page | Description |
|---|------|-------------|
| 1 | Homepage | Hero search, featured properties, stats, services |
| 2 | Properties | Buy / Rent / Commercial with filters |
| 3 | Property Detail | Full detail with room image gallery |
| 4 | Services | Home Cleaning, Painting, Movers, Plumbing, Carpentry |
| 5 | Legal | Rental Agreement, Tenant Verification, Sale Agreement |
| 6 | Loans | SBI, HDFC, ICICI + EMI Calculator |
| 7 | Plans | Residential & Commercial subscription plans |
| 8 | Property Alerts | Set custom property alert notifications |
| 9 | Client Register | New user registration |
| 10 | Client Login | Client sign in |
| 11 | Client Dashboard | Bookings, alerts, quick actions |
| 12 | Rent Payment | Online rent payment + history |
| 13 | Admin Login | Secure admin portal |
| 14 | Admin Dashboard | Stats, recent properties & enquiries |
| 15 | Admin CRUD | Properties, Clients, Bookings, Payments |

---

## 🏘️ Property Types Supported

- 🏠 Home
- 🏢 Apartment
- 🏰 Villa
- 🌿 Site / Plot
- 🏬 Commercial

## 🔖 Listing Types

- **Buy** – Properties for sale
- **Rent** – Properties for rent
- **Commercial** – Office/shop spaces

---

## 🔧 Home Services

| Service | Description |
|---------|-------------|
| Home Cleaning | Professional cleaning services |
| Home Painting | Interior & exterior painting |
| Packers & Movers | Safe relocation services |
| Commercial Interiors | Office interior design |
| Plumbing | Expert plumbing solutions |
| Carpentry | Custom woodwork & furniture |

---

## ⚖️ Legal Services

- Rental Agreement
- Tenant Verification
- Sale Agreement
- Property Legal Service

---

## 💰 Loan Services

- SBI Home Loan (8.40%)
- HDFC Home Loan (8.50%)
- ICICI Home Loan (8.75%)
- Built-in EMI Calculator

---

## 📋 Subscription Plans

**Residential:** Basic / Premium / Pro  
**Commercial:** Basic / Premium

---

## 🗄️ Database Tables

| Table | Purpose |
|-------|---------|
| admins | Admin credentials |
| clients | Client accounts |
| properties | Property listings |
| property_images | Room images (hall, bedroom, bathroom, kitchen, exterior) |
| services | Home services |
| legal_services | Legal service offerings |
| loan_services | Bank loan options |
| plans | Subscription plans |
| property_alerts | Client alert preferences |
| rent_payments | Rent payment records |
| service_bookings | Service booking records |
| enquiries | Property enquiries |

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, JavaScript, Bootstrap 5.3 |
| Backend | PHP 7.4+ |
| Database | MySQL |
| Server | XAMPP (Apache) |
| Icons | Font Awesome 6 |
| Fonts | Google Fonts – Poppins |
| Images | Unsplash (real property photos) |

---

## 📸 Real Images Used

All property, service, and legal images are sourced from **Unsplash** (free to use).
Categories: Homes, Villas, Apartments, Sites, Commercial spaces, Cleaning, Painting, Movers, Legal, Banks.

---

## 👤 Client Features

- Register / Login / Logout
- Browse all property types
- View property with room gallery
- Submit property enquiry
- Book home services
- Pay rent online (with receipt)
- Set property alerts
- Personal dashboard

---

## 🛡️ Admin Features

- Secure login with hashed password
- Dashboard with live stats
- Add / Edit / Delete properties
- Upload room images via URL (auto-filled)
- Manage clients (enable/disable)
- View & update enquiries
- Manage service bookings
- View all rent payments
- Property alert management
- Subscription plan overview

---

## 📞 Default Contact Info

- **Email:** admin@homehaven.com
- **Phone:** +91 98765 43210
- **Location:** MG Road, Bangalore – 560001

---

## 📝 Notes

- All admin credentials are pre-filled in the login page for easy access
- Images use Unsplash URLs — no local image uploads required
- Password stored using PHP `password_hash()` (bcrypt) for security
- All inputs are sanitized to prevent SQL injection

---

*Built for educational/demo purposes. HomeHaven © 2026*
