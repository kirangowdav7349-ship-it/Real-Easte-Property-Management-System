<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once '../includes/config.php';
if(!isClientLoggedIn()) redirect(SITE_URL.'/client/login.php');
require_once 'includes/rent-gate.php';
$cid = $_SESSION['client_id'];
$res = $conn->query("SELECT * FROM clients WHERE id=$cid");
$client = ($res && $res->num_rows > 0) ? $res->fetch_assoc() : array(
    'id'=>$cid,'name'=>'User','email'=>'','phone'=>'','password'=>'',
    'avatar'=>'','bio'=>'','country'=>'India','city_name'=>'India'
);

$msg = ''; $msgType = 'success';

// Handle profile update
if($_SERVER['REQUEST_METHOD']==='POST'){

  // Update profile info
  if(isset($_POST['save_profile'])){
    $name    = $conn->real_escape_string(trim($_POST['name']??''));
    $phone   = $conn->real_escape_string(trim($_POST['phone']??''));
    $bio     = $conn->real_escape_string(trim($_POST['bio']??''));
    $country = $conn->real_escape_string(trim($_POST['country']??''));
    $city    = $conn->real_escape_string(trim($_POST['city']??''));

    // Handle avatar upload
    $avatarField = '';
    if(!empty($_FILES['avatar']['name'])){
      $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
      $allowed = ['jpg','jpeg','png','gif','webp'];
      if(!in_array($ext,$allowed)){
        $msg = 'Invalid file type. Only JPG, PNG, GIF, WEBP allowed.'; $msgType='danger';
      } else {
        $uploadDir = '../assets/uploads/avatars/';
        if(!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        $newName = 'avatar_'.$cid.'_'.time().'.'.$ext;
        if(move_uploaded_file($_FILES['avatar']['tmp_name'], $uploadDir.$newName)){
          $avatarField = ", avatar='".SITE_URL."/assets/uploads/avatars/$newName'";
        }
      }
    }
    // Avatar URL option
    if(!empty($_POST['avatar_url']) && empty($_FILES['avatar']['name'])){
      $avUrl = $conn->real_escape_string(trim($_POST['avatar_url']));
      $avatarField = ", avatar='$avUrl'";
    }

    if(!$msg){
      // Try with new columns first, fallback to basic
      $sql = "UPDATE clients SET name='$name',phone='$phone'$avatarField WHERE id=$cid";
      $conn->query($sql);
      // Try update bio/country/city if columns exist
      @$conn->query("UPDATE clients SET bio='$bio',country='$country',city_name='$city' WHERE id=$cid");
      $_SESSION['client_name'] = $name;
      $msg = 'Profile updated successfully!'; $msgType='success';
      $client = $conn->query("SELECT * FROM clients WHERE id=$cid")->fetch_assoc();
    }
  }

  // Change password
  if(isset($_POST['change_password'])){
    $cur  = $_POST['current_password']??'';
    $new  = $_POST['new_password']??'';
    $cnew = $_POST['confirm_new']??'';
    if(!password_verify($cur,$client['password']))      { $msg='Current password incorrect.'; $msgType='danger'; }
    elseif(strlen($new)<6)                              { $msg='New password must be 6+ characters.'; $msgType='danger'; }
    elseif($new!==$cnew)                                { $msg='New passwords do not match.'; $msgType='danger'; }
    else {
      $hash=password_hash($new,PASSWORD_BCRYPT);
      $conn->query("UPDATE clients SET password='$hash' WHERE id=$cid");
      $msg='Password changed successfully!'; $msgType='success';
    }
  }
}

$countries=['Afghanistan','Albania','Algeria','Argentina','Australia','Austria','Bangladesh','Belgium','Brazil','Canada','Chile','China','Colombia','Czech Republic','Denmark','Egypt','Ethiopia','Finland','France','Germany','Ghana','Greece','Hungary','India','Indonesia','Iran','Iraq','Ireland','Israel','Italy','Japan','Jordan','Kenya','Malaysia','Mexico','Morocco','Nepal','Netherlands','New Zealand','Nigeria','Norway','Pakistan','Philippines','Poland','Portugal','Romania','Russia','Saudi Arabia','Singapore','South Africa','South Korea','Spain','Sri Lanka','Sweden','Switzerland','Thailand','Turkey','UAE','UK','Ukraine','USA','Vietnam'];
$indianCities=['Ahmedabad','Bangalore','Bhopal','Chandigarh','Chennai','Coimbatore','Delhi','Faridabad','Gurgaon','Hyderabad','Indore','Jaipur','Kochi','Kolkata','Lucknow','Mumbai','Mysore','Nagpur','Noida','Patna','Pune','Surat','Visakhapatnam'];
$clientName  = !empty($client['name'])  ? $client['name']  : 'User';
$clientEmail = !empty($client['email']) ? $client['email'] : '';
$avatarUrl   = !empty($client['avatar']) ? $client['avatar'] : 'https://ui-avatars.com/api/?name='.urlencode($clientName).'&background=FF6B35&color=fff&size=128&bold=true';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280">
<title>My Profile - PropNexus</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="<?=SITE_URL?>/assets/css/style.css" rel="stylesheet">
<style>
.profile-sidebar{background:linear-gradient(160deg,#1a3c5e,#2d6a4f);border-radius:20px;padding:30px;color:white;text-align:center;position:sticky;top:20px}
.avatar-wrap{position:relative;display:inline-block;margin-bottom:15px}
.avatar-img{width:110px;height:110px;border-radius:50%;object-fit:cover;border:4px solid rgba(255,255,255,.4);box-shadow:0 8px 25px rgba(0,0,0,.3)}
.avatar-edit{position:absolute;bottom:4px;right:4px;background:#FF6B35;border:none;border-radius:50%;width:32px;height:32px;color:white;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:.8rem;transition:.2s}
.avatar-edit:hover{transform:scale(1.15)}
.tab-pane-section{background:var(--card-bg,#fff);border-radius:16px;padding:28px;box-shadow:0 4px 20px rgba(0,0,0,.07);border:1px solid var(--border-color,#e5e9ef);margin-bottom:20px}
.section-h{font-size:.9rem;font-weight:700;color:#1a3c5e;border-bottom:2px solid var(--border-color,#eee);padding-bottom:10px;margin-bottom:20px;display:flex;align-items:center;gap:8px}
.avatar-preset{width:52px;height:52px;border-radius:50%;object-fit:cover;cursor:pointer;border:3px solid transparent;transition:.2s}
.avatar-preset:hover,.avatar-preset.picked{border-color:#FF6B35;transform:scale(1.1)}
.nav-profile .nav-link{color:#555;padding:10px 18px;border-radius:10px;font-weight:500;border:none;background:transparent;transition:.2s}
.nav-profile .nav-link.active{background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:white}
.nav-profile .nav-link:hover:not(.active){background:#f0f4f8}
body.dark-mode .tab-pane-section{background:#1a2535;border-color:#2d3748}
body.dark-mode .section-h{color:#c9d1d9;border-color:#2d3748}
body.dark-mode .nav-profile .nav-link{color:#9aa0a6}
body.dark-mode .nav-profile .nav-link:hover:not(.active){background:#1e2d40}
.strength-bar{height:4px;border-radius:2px;flex:1;background:#eee;transition:.3s}
</style>
</head>
<body>
<script>if(localStorage.getItem('hh_dark')==='1')document.body.classList.add('dark-mode')</script>

<!-- Top Nav -->
<div style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f);padding:12px 0;position:sticky;top:0;z-index:999">
  <div class="container d-flex justify-content-between align-items-center">
    <a href="<?=SITE_URL?>" class="text-white text-decoration-none fw-bold fs-5">
      <i class="fas fa-home me-2" style="color:#FF6B35"></i>PropNexus
    </a>
    <div class="d-flex gap-3 align-items-center">
      <button onclick="toggleDark()" id="darkBtn" class="dark-toggle"><i class="fas fa-moon" id="darkIco"></i></button>
      <a href="dashboard.php" class="text-white text-decoration-none small"><i class="fas fa-arrow-left me-1"></i>Dashboard</a>
      <a href="logout.php" class="btn btn-outline-light btn-sm rounded-pill">Logout</a>
    </div>
  </div>
</div>

<div class="container py-4">
  <?php if($msg): ?>
  <div class="alert alert-<?=$msgType?> alert-dismissible fade show">
    <i class="fas fa-<?=$msgType==='success'?'check-circle':'exclamation-circle'?> me-2"></i><?=$msg?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
  <?php endif; ?>

  <div class="row g-4">
    <!-- Left sidebar -->
    <div class="col-lg-3">
      <div class="profile-sidebar">
        <div class="avatar-wrap">
          <img src="<?=$avatarUrl?>" alt="Avatar" class="avatar-img" id="avatarPreview">
          <button class="avatar-edit" onclick="document.getElementById('avatarFileInput').click()" title="Change photo">
            <i class="fas fa-camera"></i>
          </button>
        </div>
        <h5 class="fw-bold mb-1"><?=htmlspecialchars($clientName)?></h5>
        <p class="opacity-75 mb-1" style="font-size:.82rem"><?=htmlspecialchars($clientEmail)?></p>
        <p class="opacity-60 mb-3" style="font-size:.78rem"><i class="fas fa-map-marker-alt me-1"></i><?=$client['city_name']??'India'?></p>
        <div class="d-flex justify-content-center gap-3 mb-3" style="font-size:.75rem;opacity:.8">
          <div><strong>0</strong><br>Saved</div>
          <div style="border-left:1px solid rgba(255,255,255,.3);padding-left:12px"><strong>0</strong><br>Alerts</div>
          <div style="border-left:1px solid rgba(255,255,255,.3);padding-left:12px"><strong>0</strong><br>Bookings</div>
        </div>
        <hr style="border-color:rgba(255,255,255,.2)">
        <nav class="d-flex flex-column gap-1">
          <a href="dashboard.php"    class="text-white text-decoration-none py-2 px-3 rounded-3 text-start" style="background:rgba(255,255,255,.1);font-size:.85rem"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
          <a href="profile.php"      class="text-white text-decoration-none py-2 px-3 rounded-3 text-start" style="background:rgba(255,107,53,.3);font-size:.85rem"><i class="fas fa-user me-2"></i>My Profile</a>
          <a href="settings.php"     class="text-white text-decoration-none py-2 px-3 rounded-3 text-start" style="font-size:.85rem"><i class="fas fa-cog me-2"></i>Settings</a>
          <a href="rent-payment.php" class="text-white text-decoration-none py-2 px-3 rounded-3 text-start" style="font-size:.85rem"><i class="fas fa-receipt me-2"></i>Rent Receipts</a>
          <a href="alerts.php"       class="text-white text-decoration-none py-2 px-3 rounded-3 text-start" style="font-size:.85rem"><i class="fas fa-bell me-2"></i>My Alerts</a>
          <a href="logout.php"       class="text-white text-decoration-none py-2 px-3 rounded-3 text-start" style="font-size:.85rem;color:#ffaaaa!important"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
        </nav>
      </div>
    </div>

    <!-- Right content -->
    <div class="col-lg-9">
      <!-- Tab nav -->
      <div class="d-flex gap-2 mb-4 flex-wrap nav-profile">
        <button class="nav-link active" onclick="showTab(this,'tab-profile')"  id="btn-profile">  <i class="fas fa-user me-1"></i>Profile</button>
        <button class="nav-link"        onclick="showTab(this,'tab-avatar')"   id="btn-avatar">   <i class="fas fa-image me-1"></i>Avatar</button>
        <button class="nav-link"        onclick="showTab(this,'tab-password')" id="btn-password"> <i class="fas fa-lock me-1"></i>Password</button>
        <button class="nav-link"        onclick="showTab(this,'tab-privacy')"  id="btn-privacy">  <i class="fas fa-shield-alt me-1"></i>Privacy</button>
      </div>

      <!-- Tab: Profile -->
      <div id="tab-profile">
        <form method="POST" enctype="multipart/form-data">
          <div class="tab-pane-section">
            <div class="section-h"><i class="fas fa-user text-accent"></i>Personal Information</div>
            <div class="row g-3">
              <div class="col-md-6">
                <label class="fw-bold small">Full Name <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" value="<?=htmlspecialchars($clientName)?>" required>
              </div>
              <div class="col-md-6">
                <label class="fw-bold small">Email (read-only)</label>
                <input type="email" class="form-control" value="<?=htmlspecialchars($clientEmail)?>" disabled style="opacity:.6">
              </div>
              <div class="col-md-6">
                <label class="fw-bold small">Phone Number</label>
                <div class="input-group">
                  <span class="input-group-text" id="pflag">📞</span>
                  <input type="text" name="phone" class="form-control" value="<?=htmlspecialchars($client['phone'])?>">
                </div>
              </div>
              <div class="col-md-6">
                <label class="fw-bold small">Country</label>
                <select name="country" class="form-select" id="countrySelP" onchange="onCountry(this.value)">
                  <option value="">-- Select Country --</option>
                  <?php foreach($countries as $c): ?>
                  <option value="<?=$c?>" <?=(($client['country']??'India')===$c)?'selected':''?>><?=$c==='India'?'🇮🇳 ':''?><?=$c?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-6" id="cityRowP">
                <label class="fw-bold small">City</label>
                <select name="city" class="form-select">
                  <option value="">-- Select City --</option>
                  <?php foreach($indianCities as $ic): ?>
                  <option value="<?=$ic?>" <?=(($client['city_name']??'')===$ic)?'selected':''?>><?=$ic?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-12">
                <label class="fw-bold small">Bio / About Me</label>
                <textarea name="bio" class="form-control" rows="3" placeholder="Tell others about yourself, your preferences, what you're looking for..."><?=htmlspecialchars($client['bio']??'')?></textarea>
              </div>
            </div>
            <!-- hidden avatar from profile tab -->
            <input type="hidden" name="avatar_url" id="hiddenAvatarUrl" value="">
            <input type="file" name="avatar" id="avatarFileInput" accept="image/*" style="display:none" onchange="previewAvatar(this)">
          </div>
          <button type="submit" name="save_profile" class="btn btn-accent fw-bold px-5 py-2">
            <i class="fas fa-save me-2"></i>Save Profile
          </button>
        </form>
      </div>

      <!-- Tab: Avatar -->
      <div id="tab-avatar" style="display:none">
        <form method="POST" enctype="multipart/form-data">
          <div class="tab-pane-section">
            <div class="section-h"><i class="fas fa-user-circle" style="color:#6f42c1"></i>Change Avatar / Profile Photo</div>

            <!-- Current avatar -->
            <div class="text-center mb-4">
              <img src="<?=$avatarUrl?>" id="bigAvatarPreview" class="rounded-circle mb-2" style="width:100px;height:100px;object-fit:cover;border:4px solid #FF6B35;box-shadow:0 8px 25px rgba(255,107,53,.3)">
              <p class="text-muted small mb-0">Current profile photo</p>
            </div>

            <!-- Upload file -->
            <div class="mb-4 p-4 rounded-3" style="background:var(--section-bg,#f8f9fa);border:2px dashed var(--border-color,#ddd)">
              <div class="text-center">
                <i class="fas fa-cloud-upload-alt fs-1 text-accent mb-2"></i>
                <p class="fw-bold mb-1">Upload a Photo</p>
                <p class="text-muted small mb-3">JPG, PNG, GIF or WEBP • Max 5MB</p>
                <label for="avatarUpload" class="btn btn-primary-custom px-4" style="cursor:pointer">
                  <i class="fas fa-folder-open me-2"></i>Browse Files
                </label>
                <input type="file" name="avatar" id="avatarUpload" accept="image/*" style="display:none" onchange="prevBig(this)">
              </div>
            </div>

            <!-- OR paste URL -->
            <div class="mb-4">
              <label class="fw-bold small">Or paste an image URL</label>
              <div class="input-group">
                <span class="input-group-text"><i class="fas fa-link"></i></span>
                <input type="text" name="avatar_url" id="avatarUrlIn" class="form-control" placeholder="https://... any image URL" oninput="prevUrl(this.value)">
                <button type="button" class="btn btn-outline-secondary" onclick="prevUrl(document.getElementById('avatarUrlIn').value)">Preview</button>
              </div>
            </div>

            <!-- Preset avatars -->
            <div class="mb-2">
              <label class="fw-bold small d-block mb-2">Or pick a preset avatar</label>
              <div class="d-flex flex-wrap gap-2">
                <?php
                $presets=[
                  'https://api.dicebear.com/7.x/avataaars/svg?seed=PropNexus1&backgroundColor=FF6B35',
                  'https://api.dicebear.com/7.x/avataaars/svg?seed=PropNexus2&backgroundColor=1a3c5e',
                  'https://api.dicebear.com/7.x/avataaars/svg?seed=PropNexus3&backgroundColor=2d6a4f',
                  'https://api.dicebear.com/7.x/avataaars/svg?seed=PropNexus4&backgroundColor=6f42c1',
                  'https://api.dicebear.com/7.x/avataaars/svg?seed=PropNexus5&backgroundColor=dc3545',
                  'https://api.dicebear.com/7.x/avataaars/svg?seed=PropNexus6&backgroundColor=fd7e14',
                  'https://ui-avatars.com/api/?name='.urlencode($clientName).'&background=FF6B35&color=fff&size=128&bold=true',
                  'https://ui-avatars.com/api/?name='.urlencode($clientName).'&background=1a3c5e&color=fff&size=128&bold=true',
                ];
                foreach($presets as $i=>$ps):
                ?>
                <img src="<?=$ps?>" class="avatar-preset" onclick="pickPreset('<?=$ps?>',this)" title="Preset <?=($i+1)?>">
                <?php endforeach; ?>
              </div>
            </div>
            <input type="hidden" name="avatar_url" id="hiddenPresetUrl" value="">
          </div>
          <button type="submit" name="save_profile" class="btn btn-accent fw-bold px-5 py-2">
            <i class="fas fa-check me-2"></i>Save Avatar
          </button>
        </form>
      </div>

      <!-- Tab: Password -->
      <div id="tab-password" style="display:none">
        <form method="POST">
          <div class="tab-pane-section">
            <div class="section-h"><i class="fas fa-lock" style="color:#6f42c1"></i>Change Password</div>
            <div class="row g-3">
              <div class="col-12">
                <label class="fw-bold small">Current Password</label>
                <div class="input-group">
                  <span class="input-group-text"><i class="fas fa-lock"></i></span>
                  <input type="password" name="current_password" id="cp" class="form-control" placeholder="Enter current password" required>
                  <button type="button" class="btn btn-outline-secondary" onclick="tp('cp')"><i class="fas fa-eye"></i></button>
                </div>
              </div>
              <div class="col-md-6">
                <label class="fw-bold small">New Password</label>
                <div class="input-group">
                  <span class="input-group-text"><i class="fas fa-lock"></i></span>
                  <input type="password" name="new_password" id="np" class="form-control" placeholder="Min 6 characters" oninput="checkStr(this.value)" required>
                  <button type="button" class="btn btn-outline-secondary" onclick="tp('np')"><i class="fas fa-eye"></i></button>
                </div>
                <div class="d-flex gap-1 mt-2">
                  <?php for($i=1;$i<=4;$i++): ?><div class="strength-bar" id="sb<?=$i?>"></div><?php endfor; ?>
                </div>
                <small id="strTxt" class="text-muted"></small>
              </div>
              <div class="col-md-6">
                <label class="fw-bold small">Confirm New Password</label>
                <div class="input-group">
                  <span class="input-group-text"><i class="fas fa-lock"></i></span>
                  <input type="password" name="confirm_new" id="cnp" class="form-control" placeholder="Repeat new password" required>
                  <button type="button" class="btn btn-outline-secondary" onclick="tp('cnp')"><i class="fas fa-eye"></i></button>
                </div>
              </div>

              <!-- Security tips -->
              <div class="col-12">
                <div class="p-3 rounded-3" style="background:#f0fff4;border:1px solid #c6f6d5">
                  <p class="fw-bold small mb-1 text-success"><i class="fas fa-shield-alt me-2"></i>Password Tips</p>
                  <ul class="mb-0 small text-muted">
                    <li>Use at least 8 characters</li>
                    <li>Mix uppercase, lowercase, numbers & symbols</li>
                    <li>Don't reuse passwords from other sites</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <button type="submit" name="change_password" class="btn btn-primary-custom fw-bold px-5 py-2">
            <i class="fas fa-key me-2"></i>Change Password
          </button>
        </form>
      </div>

      <!-- Tab: Privacy -->
      <div id="tab-privacy" style="display:none">
        <div class="tab-pane-section">
          <div class="section-h"><i class="fas fa-shield-alt text-success"></i>Privacy & Security</div>
          <?php foreach([
            ['Show my profile to property owners','priv_profile',true,'Allow owners to see your name & contact'],
            ['Allow contact messages','priv_contact',true,'Let owners message you about their properties'],
            ['Share search history for recommendations','priv_search',false,'Improves suggestions based on your browsing'],
            ['Two-factor authentication','priv_2fa',false,'Extra security layer (coming soon)'],
          ] as $pv): ?>
          <div class="d-flex align-items-center justify-content-between py-3" style="border-bottom:1px solid var(--border-color,#eee)">
            <div>
              <div class="fw-bold small"><?=$pv[0]?></div>
              <div class="text-muted" style="font-size:.77rem"><?=$pv[3]?></div>
            </div>
            <div class="form-check form-switch mb-0">
              <input class="form-check-input" type="checkbox" <?=$pv[2]?'checked':''?> role="switch" style="width:44px;height:22px">
            </div>
          </div>
          <?php endforeach; ?>
          <div class="mt-4 p-3 rounded-3" style="background:#fff5f5;border:1px solid #ffcccc">
            <p class="fw-bold small text-danger mb-1"><i class="fas fa-exclamation-triangle me-2"></i>Danger Zone</p>
            <p class="text-muted small mb-2">Deleting your account is permanent. All data will be lost.</p>
            <button class="btn btn-outline-danger btn-sm" onclick="confirmDel()">
              <i class="fas fa-trash me-2"></i>Delete Account
            </button>
          </div>
        </div>
      </div>

    </div><!-- end right -->
  </div><!-- end row -->
</div><!-- end container -->

<script>
function showTab(btn,id){
  document.querySelectorAll('.nav-profile .nav-link').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  ['tab-profile','tab-avatar','tab-password','tab-privacy'].forEach(t=>{ document.getElementById(t).style.display='none'; });
  document.getElementById(id).style.display='';
}

function previewAvatar(inp){
  if(inp.files&&inp.files[0]){
    const r=new FileReader();
    r.onload=e=>{ document.getElementById('avatarPreview').src=e.target.result; };
    r.readAsDataURL(inp.files[0]);
  }
}

function prevBig(inp){
  if(inp.files&&inp.files[0]){
    const r=new FileReader();
    r.onload=e=>{ document.getElementById('bigAvatarPreview').src=e.target.result; document.getElementById('avatarPreview').src=e.target.result; };
    r.readAsDataURL(inp.files[0]);
  }
}

function prevUrl(u){ if(u){ document.getElementById('bigAvatarPreview').src=u; document.getElementById('avatarPreview').src=u; } }

function pickPreset(url,el){
  document.querySelectorAll('.avatar-preset').forEach(a=>a.classList.remove('picked'));
  el.classList.add('picked');
  document.getElementById('hiddenPresetUrl').value=url;
  document.getElementById('bigAvatarPreview').src=url;
  document.getElementById('avatarPreview').src=url;
}

function tp(id){ const el=document.getElementById(id); el.type=el.type==='password'?'text':'password'; }

function checkStr(v){
  let s=0;
  if(v.length>=6)s++; if(v.length>=10)s++; if(/[A-Z]/.test(v)&&/[0-9]/.test(v))s++; if(/[^A-Za-z0-9]/.test(v))s++;
  const c=['','#dc3545','#fd7e14','#ffc107','#28a745'];
  const l=['','Weak','Fair','Good','Strong'];
  for(let i=1;i<=4;i++) document.getElementById('sb'+i).style.background=i<=s?c[s]:'#eee';
  const t=document.getElementById('strTxt');
  t.textContent=s?'Strength: '+l[s]:'';
  t.style.color=c[s]||'#999';
}

function onCountry(v){
  document.getElementById('cityRowP').style.display=v==='India'?'':'none';
  const flags={'India':'🇮🇳','USA':'🇺🇸','UK':'🇬🇧','UAE':'🇦🇪','Australia':'🇦🇺','Canada':'🇨🇦'};
  document.getElementById('pflag').textContent=flags[v]||'📞';
}

function confirmDel(){ if(confirm('This will permanently delete your account. Continue?')) alert('Please contact support at admin@PropNexus.com to delete your account.'); }

function toggleDark(){ const on=document.body.classList.toggle('dark-mode'); localStorage.setItem('hh_dark',on?'1':'0'); document.getElementById('darkIco').className=on?'fas fa-sun':'fas fa-moon'; }

// Init
document.addEventListener('DOMContentLoaded',()=>{
  onCountry(document.getElementById('countrySelP').value||'India');
  if(localStorage.getItem('hh_dark')==='1') document.getElementById('darkIco').className='fas fa-sun';
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
