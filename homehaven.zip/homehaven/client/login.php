<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once '../includes/config.php';
if(isClientLoggedIn()) redirect(SITE_URL . '/client/dashboard.php');

$error = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
  $email = sanitize($_POST['email']);
  $pass = $_POST['password'];
  $result = $conn->query("SELECT * FROM clients WHERE email='$email' AND status='active'");
  if($row = $result->fetch_assoc()) {
    if(password_verify($pass, $row['password'])) {
      $_SESSION['client_id'] = $row['id'];
      $_SESSION['client_name'] = $row['name'];
      $_SESSION['client_email'] = $row['email'];
      redirect(SITE_URL . '/client/dashboard.php');
    } else { $error = 'Invalid password!'; }
  } else { $error = 'Email not found or account inactive!'; }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280">
<title>Client Login - PropNexus</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="<?= SITE_URL ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="auth-wrapper" style="background:linear-gradient(rgba(26,60,94,0.85),rgba(26,60,94,0.85)),url('https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1600') center/cover">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-4 col-md-5 col-sm-7">
        <div class="auth-card" style="padding:28px;border-radius:16px">
          <div class="text-center mb-3">
            <a href="<?= SITE_URL ?>" class="text-decoration-none">
              <div style="font-size:1.3rem;font-weight:800;color:var(--primary)"><i class="fas fa-home me-2" style="color:#FF6B35"></i>PropNexus</div>
            </a>
            <p class="text-muted mt-1" style="font-size:.85rem">Sign in to your account</p>
          </div>
          
          <?php if($error): ?><div class="alert alert-danger py-2" style="font-size:.82rem"><?= $error ?></div><?php endif; ?>
          
          <form method="POST">
            <div class="mb-2">
              <label class="form-label fw-bold" style="font-size:.82rem;margin-bottom:4px">Email Address</label>
              <div class="input-group input-group-sm">
                <span class="input-group-text"><i class="fas fa-envelope" style="font-size:.78rem"></i></span>
                <input type="email" name="email" class="form-control" placeholder="your@email.com" required>
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label fw-bold" style="font-size:.82rem;margin-bottom:4px">Password</label>
              <div class="input-group input-group-sm">
                <span class="input-group-text"><i class="fas fa-lock" style="font-size:.78rem"></i></span>
                <input type="password" name="password" class="form-control" placeholder="Your password" required>
              </div>
            </div>
            <button type="submit" class="btn btn-accent w-100 py-2 fw-bold" style="font-size:.9rem;border-radius:10px">Login</button>
          </form>
          <hr class="my-2">
          <p class="text-center text-muted mb-1" style="font-size:.82rem">Don't have an account? <a href="register.php" class="text-accent fw-bold">Register Free</a></p>
          <p class="text-center mb-1"><a href="<?= SITE_URL ?>/admin/login.php" class="text-muted" style="font-size:.75rem">Admin Login</a></p>
          <p class="text-center mb-0"><a href="<?= SITE_URL ?>" class="text-muted" style="font-size:.75rem">← Back to Home</a></p>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
