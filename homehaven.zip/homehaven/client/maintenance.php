<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once '../includes/config.php';
if (!isClientLoggedIn()) { redirect(SITE_URL . '/client/login.php'); }
require_once 'includes/rent-gate.php';
$cid = (int)$_SESSION['client_id'];
$res = $conn->query("SELECT * FROM clients WHERE id=" . $cid);
$client = ($res && $res->num_rows > 0) ? $res->fetch_assoc() : array('name'=>'User','email'=>'');
$clientName  = !empty($client['name']) ? $client['name'] : 'User';
$clientEmail = !empty($client['email']) ? $client['email'] : '';
$avatarUrl = !empty($client['avatar'])
    ? $client['avatar']
    : 'https://ui-avatars.com/api/?name=' . urlencode($clientName) . '&background=FF6B35&color=fff&size=128&bold=true';

$msg = ''; $msgType = 'success';

// Handle new request submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_request'])) {
    $title    = $conn->real_escape_string(trim($_POST['title'] ?? ''));
    $category = $conn->real_escape_string($_POST['category'] ?? 'other');
    $desc     = $conn->real_escape_string(trim($_POST['description'] ?? ''));
    $priority = $conn->real_escape_string($_POST['priority'] ?? 'medium');
    $propId   = (int)($_POST['property_id'] ?? 0);
    $propVal  = $propId > 0 ? $propId : 'NULL';

    if (empty($title)) {
        $msg = 'Please enter a title for your request.'; $msgType = 'danger';
    } else {
        $conn->query("INSERT INTO maintenance_requests (client_id, property_id, title, category, description, priority, status, created_at)
            VALUES ($cid, $propVal, '$title', '$category', '$desc', '$priority', 'pending', NOW())");
        $msg = 'Maintenance request submitted successfully! We will get back to you soon.'; $msgType = 'success';
    }
}

// Stats
$totalReq   = (int)$conn->query("SELECT COUNT(*) as c FROM maintenance_requests WHERE client_id=$cid")->fetch_assoc()['c'];
$pendingReq = (int)$conn->query("SELECT COUNT(*) as c FROM maintenance_requests WHERE client_id=$cid AND status='pending'")->fetch_assoc()['c'];
$progressReq= (int)$conn->query("SELECT COUNT(*) as c FROM maintenance_requests WHERE client_id=$cid AND status='in_progress'")->fetch_assoc()['c'];
$doneReq    = (int)$conn->query("SELECT COUNT(*) as c FROM maintenance_requests WHERE client_id=$cid AND status='completed'")->fetch_assoc()['c'];

// Get user's requests
$requests = $conn->query("SELECT mr.*, p.title as property_title
    FROM maintenance_requests mr
    LEFT JOIN properties p ON mr.property_id=p.id
    WHERE mr.client_id=$cid
    ORDER BY mr.created_at DESC");

// Get user's properties for dropdown
$properties = $conn->query("SELECT DISTINCT p.id, p.title FROM properties p
    INNER JOIN service_bookings sb ON sb.client_id=$cid
    UNION
    SELECT DISTINCT p.id, p.title FROM properties p
    INNER JOIN rent_payments rp ON rp.client_id=$cid AND rp.property_id=p.id
    ORDER BY title ASC");
// If no properties linked, show all available
if (!$properties || $properties->num_rows == 0) {
    $properties = $conn->query("SELECT id, title FROM properties WHERE status='available' ORDER BY title ASC LIMIT 20");
}

$catIcons = [
    'plumbing'     => ['fas fa-faucet', '#3b82f6', 'Plumbing'],
    'electrical'   => ['fas fa-bolt', '#f59e0b', 'Electrical'],
    'carpentry'    => ['fas fa-hammer', '#8b5cf6', 'Carpentry'],
    'painting'     => ['fas fa-paint-roller', '#ec4899', 'Painting'],
    'cleaning'     => ['fas fa-broom', '#10b981', 'Cleaning'],
    'pest_control' => ['fas fa-bug', '#ef4444', 'Pest Control'],
    'appliance'    => ['fas fa-blender', '#6366f1', 'Appliance'],
    'other'        => ['fas fa-wrench', '#64748b', 'Other'],
];
$prioColors = ['low' => '#10b981', 'medium' => '#f59e0b', 'high' => '#FF6B35', 'urgent' => '#ef4444'];
$statusColors = ['pending' => '#f59e0b', 'in_progress' => '#3b82f6', 'completed' => '#10b981', 'cancelled' => '#94a3b8'];
$statusLabels = ['pending' => '⏳ Pending', 'in_progress' => '🔧 In Progress', 'completed' => '✅ Completed', 'cancelled' => '❌ Cancelled'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280">
<title>Maintenance Requests - PropNexus</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="<?php echo SITE_URL; ?>/assets/css/style.css" rel="stylesheet">
<style>
html,body{margin:0;padding:0;height:100%;overflow:hidden}
.db-wrapper{display:flex;height:100vh;overflow:hidden}
.db-sidebar{background:linear-gradient(180deg,#1a3c5e,#0d2438);width:260px;flex-shrink:0;overflow-y:auto}
.db-sidebar .nav-link{color:rgba(255,255,255,.75);padding:11px 20px;border-radius:10px;margin:2px 10px;font-size:.88rem;font-weight:500;display:flex;align-items:center;gap:10px;transition:.2s}
.db-sidebar .nav-link:hover,.db-sidebar .nav-link.active{background:rgba(255,255,255,.14);color:white}
.db-sidebar .nav-link.active{background:rgba(255,107,53,.3);border-left:3px solid #FF6B35}
.db-main{flex:1;overflow-y:auto;background:var(--body-bg,#f5f7ff)}
.db-topbar{background:var(--card-bg,#fff);border-bottom:1px solid var(--border-color,#e5e9ef);padding:14px 28px;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;z-index:99}
.m-card{background:var(--card-bg,#fff);border-radius:16px;padding:22px;box-shadow:0 4px 18px rgba(0,0,0,.07);border:1px solid var(--border-color,#eee)}
.m-stat{border-radius:14px;padding:18px;color:white;text-align:center;transition:.3s}
.m-stat:hover{transform:translateY(-3px);box-shadow:0 8px 25px rgba(0,0,0,.2)}
.req-item{background:var(--card-bg,#fff);border-radius:14px;padding:18px;border:1px solid var(--border-color,#eee);box-shadow:0 2px 10px rgba(0,0,0,.04);transition:.3s;margin-bottom:12px}
.req-item:hover{box-shadow:0 6px 22px rgba(0,0,0,.1);transform:translateY(-2px)}
.cat-badge{display:inline-flex;align-items:center;gap:6px;padding:4px 12px;border-radius:20px;font-size:.74rem;font-weight:600}
.prio-badge{padding:3px 10px;border-radius:20px;font-size:.7rem;font-weight:700;text-transform:uppercase}
.status-badge{padding:4px 12px;border-radius:20px;font-size:.72rem;font-weight:600}
.form-section{background:var(--card-bg,#fff);border-radius:16px;padding:28px;box-shadow:0 4px 18px rgba(0,0,0,.07);border:1px solid var(--border-color,#eee);margin-bottom:24px}
.form-section .section-title{font-weight:700;font-size:1rem;color:var(--primary,#1a3c5e);border-bottom:2px solid var(--border-color,#eee);padding-bottom:12px;margin-bottom:20px;display:flex;align-items:center;gap:10px}
.cat-select{display:flex;flex-wrap:wrap;gap:8px}
.cat-option{display:flex;align-items:center;gap:6px;padding:8px 14px;border-radius:10px;border:2px solid var(--border-color,#eee);cursor:pointer;font-size:.82rem;font-weight:500;transition:.2s;background:var(--card-bg,#fff)}
.cat-option:hover{border-color:var(--accent,#FF6B35)}
.cat-option.selected{border-color:var(--accent,#FF6B35);background:rgba(255,107,53,.08)}
.cat-option input{display:none}
.timeline-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0;margin-top:4px}
.db-sidebar::-webkit-scrollbar{width:5px}
.db-sidebar::-webkit-scrollbar-thumb{background:rgba(255,255,255,.25);border-radius:4px}
.db-main::-webkit-scrollbar{width:8px}
.db-main::-webkit-scrollbar-thumb{background:rgba(26,60,94,.3);border-radius:4px}
@media(max-width:768px){.db-sidebar{position:fixed;top:0;left:0;height:100vh;z-index:100;transform:translateX(-100%);transition:transform .3s}.db-sidebar.open{transform:translateX(0)}.db-main{width:100%}}
body.dark-mode .db-topbar{background:#1a2535;border-color:#2d3748}
body.dark-mode .m-card,body.dark-mode .form-section,body.dark-mode .req-item{background:#1a2535;border-color:#2d3748}
body.dark-mode .form-section .section-title{color:#c9d1d9;border-color:#2d3748}
</style>
</head>
<body>
<script>if(localStorage.getItem('hh_dark')==='1')document.body.classList.add('dark-mode');</script>

<div class="db-wrapper">
<!-- Sidebar -->
<div class="db-sidebar" id="sidebar">
  <div class="p-4 pb-2">
    <a href="<?php echo SITE_URL; ?>" class="text-decoration-none d-flex align-items-center gap-2 mb-4">
      <i class="fas fa-building text-accent" style="font-size:1.4rem"></i>
      <span class="text-white fw-bold fs-5">PropNexus</span>
    </a>
    <a href="profile.php" class="text-decoration-none d-flex align-items-center gap-3 mb-4 p-3 rounded-3" style="background:rgba(255,255,255,.08)">
      <img src="<?php echo $avatarUrl; ?>" class="rounded-circle" style="width:44px;height:44px;object-fit:cover;border:2px solid #FF6B35" alt="Avatar">
      <div>
        <div class="text-white fw-bold" style="font-size:.88rem"><?php echo htmlspecialchars($clientName); ?></div>
        <div class="text-muted" style="font-size:.72rem"><?php echo htmlspecialchars($clientEmail); ?></div>
      </div>
    </a>
    <nav class="nav flex-column gap-1">
      <a href="dashboard.php"     class="nav-link"><i class="fas fa-home"></i>Dashboard</a>
      <a href="../ai-recommend.php" class="nav-link" style="color:#FF6B35"><i class="fas fa-robot"></i>AI Agent</a>
      <a href="profile.php"       class="nav-link"><i class="fas fa-user-circle"></i>My Profile</a>
      <a href="../properties.php" class="nav-link"><i class="fas fa-building"></i>Browse Properties</a>
      <a href="alerts.php"        class="nav-link"><i class="fas fa-bell"></i>My Alerts</a>
      <a href="rent-payment.php"  class="nav-link"><i class="fas fa-receipt"></i>Rent Receipts</a>
      <a href="maintenance.php"   class="nav-link active"><i class="fas fa-wrench"></i>Maintenance</a>
      <a href="../loans.php"      class="nav-link"><i class="fas fa-file-invoice-dollar"></i>Loan Tracker</a>
      <a href="../legal.php"      class="nav-link"><i class="fas fa-gavel"></i>Legal Services</a>
      <a href="../loans.php"      class="nav-link"><i class="fas fa-piggy-bank"></i>Home Loans</a>
      <a href="../news.php"       class="nav-link"><i class="fas fa-newspaper"></i>News &amp; Guides</a>
      <hr style="border-color:rgba(255,255,255,.1);margin:8px 10px">
      <a href="settings.php"     class="nav-link"><i class="fas fa-cog"></i>Settings</a>
      <a href="logout.php"       class="nav-link" style="color:#ff8888"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </nav>
  </div>
</div>

<!-- Main Content -->
<div class="db-main">

  <!-- Top Bar -->
  <div class="db-topbar">
    <div class="d-flex align-items-center gap-3">
      <button class="btn btn-sm btn-outline-secondary d-md-none" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
      <div>
        <h5 class="fw-bold mb-0">🔧 Maintenance Requests</h5>
        <small class="text-muted">Submit and track maintenance requests for your property</small>
      </div>
    </div>
    <div class="d-flex align-items-center gap-2">
      <button class="dark-toggle" onclick="toggleDark()" id="darkBtn"><i class="fas fa-moon" id="darkIco"></i></button>
      <a href="dashboard.php" class="btn btn-outline-secondary btn-sm px-3 rounded-pill"><i class="fas fa-arrow-left me-1"></i>Dashboard</a>
      <a href="profile.php">
        <img src="<?php echo $avatarUrl; ?>" class="rounded-circle" style="width:38px;height:38px;object-fit:cover;border:2px solid #FF6B35" alt="Profile">
      </a>
    </div>
  </div>

  <div class="p-4">

    <?php if($msg): ?>
    <div class="alert alert-<?php echo $msgType; ?> alert-dismissible fade show" style="border-radius:12px">
      <i class="fas fa-<?php echo $msgType==='success'?'check-circle':'exclamation-circle'; ?> me-2"></i><?php echo $msg; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Stats Row -->
    <div class="row g-3 mb-4">
      <?php foreach([
        ['Total Requests', $totalReq, 'fas fa-clipboard-list', 'linear-gradient(135deg,#1a3c5e,#2d6a4f)'],
        ['Pending', $pendingReq, 'fas fa-clock', 'linear-gradient(135deg,#f59e0b,#d97706)'],
        ['In Progress', $progressReq, 'fas fa-spinner', 'linear-gradient(135deg,#3b82f6,#1d4ed8)'],
        ['Completed', $doneReq, 'fas fa-check-circle', 'linear-gradient(135deg,#10b981,#059669)'],
      ] as $s): ?>
      <div class="col-md-3 col-6">
        <div class="m-stat" style="background:<?php echo $s[3]; ?>">
          <i class="<?php echo $s[2]; ?> mb-2" style="font-size:1.5rem;opacity:.8"></i>
          <div class="fw-bold" style="font-size:1.8rem"><?php echo $s[1]; ?></div>
          <div style="font-size:.78rem;opacity:.85"><?php echo $s[0]; ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <div class="row g-4">
      <!-- New Request Form -->
      <div class="col-lg-5">
        <div class="form-section">
          <div class="section-title"><i class="fas fa-plus-circle text-accent"></i>Submit New Request</div>
          <form method="POST">
            <input type="hidden" name="submit_request" value="1">

            <div class="mb-3">
              <label class="fw-bold small mb-2">Category</label>
              <div class="cat-select">
                <?php foreach($catIcons as $key => $cat): ?>
                <label class="cat-option" onclick="selectCat(this)">
                  <input type="radio" name="category" value="<?php echo $key; ?>" <?php echo $key==='other'?'checked':''; ?>>
                  <i class="<?php echo $cat[0]; ?>" style="color:<?php echo $cat[1]; ?>"></i>
                  <span><?php echo $cat[2]; ?></span>
                </label>
                <?php endforeach; ?>
              </div>
            </div>

            <div class="mb-3">
              <label class="fw-bold small">Title <span class="text-danger">*</span></label>
              <input type="text" name="title" class="form-control" placeholder="e.g. Leaking faucet in kitchen" required>
            </div>

            <div class="mb-3">
              <label class="fw-bold small">Description</label>
              <textarea name="description" class="form-control" rows="3" placeholder="Describe the issue in detail..."></textarea>
            </div>

            <div class="row g-3 mb-3">
              <div class="col-6">
                <label class="fw-bold small">Priority</label>
                <select name="priority" class="form-select">
                  <option value="low">🟢 Low</option>
                  <option value="medium" selected>🟡 Medium</option>
                  <option value="high">🟠 High</option>
                  <option value="urgent">🔴 Urgent</option>
                </select>
              </div>
              <div class="col-6">
                <label class="fw-bold small">Property</label>
                <select name="property_id" class="form-select">
                  <option value="0">-- Optional --</option>
                  <?php if($properties && $properties->num_rows > 0): while($p = $properties->fetch_assoc()): ?>
                  <option value="<?php echo (int)$p['id']; ?>"><?php echo htmlspecialchars($p['title']); ?></option>
                  <?php endwhile; endif; ?>
                </select>
              </div>
            </div>

            <button type="submit" class="btn btn-accent fw-bold px-4 w-100">
              <i class="fas fa-paper-plane me-2"></i>Submit Request
            </button>
          </form>
        </div>
      </div>

      <!-- Requests List -->
      <div class="col-lg-7">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h6 class="fw-bold mb-0"><i class="fas fa-list-ul me-2 text-accent"></i>My Requests</h6>
          <span class="text-muted" style="font-size:.8rem"><?php echo $totalReq; ?> total</span>
        </div>

        <?php if($requests && $requests->num_rows > 0): while($r = $requests->fetch_assoc()):
          $cat = $catIcons[$r['category']] ?? $catIcons['other'];
          $pColor = $prioColors[$r['priority']] ?? '#64748b';
          $sColor = $statusColors[$r['status']] ?? '#64748b';
          $sLabel = $statusLabels[$r['status']] ?? $r['status'];
        ?>
        <div class="req-item">
          <div class="d-flex justify-content-between align-items-start mb-2">
            <div class="d-flex align-items-center gap-2">
              <div style="width:36px;height:36px;background:<?php echo $cat[1]; ?>15;border-radius:10px;display:flex;align-items:center;justify-content:center;color:<?php echo $cat[1]; ?>;font-size:.9rem">
                <i class="<?php echo $cat[0]; ?>"></i>
              </div>
              <div>
                <div class="fw-bold" style="font-size:.9rem"><?php echo htmlspecialchars($r['title']); ?></div>
                <div class="text-muted" style="font-size:.73rem">
                  <i class="fas fa-tag me-1"></i><?php echo $cat[2]; ?>
                  <?php if(!empty($r['property_title'])): ?>
                   · <i class="fas fa-building me-1"></i><?php echo htmlspecialchars($r['property_title']); ?>
                  <?php endif; ?>
                </div>
              </div>
            </div>
            <span class="status-badge" style="background:<?php echo $sColor; ?>15;color:<?php echo $sColor; ?>"><?php echo $sLabel; ?></span>
          </div>

          <?php if(!empty($r['description'])): ?>
          <p class="text-muted mb-2" style="font-size:.82rem;line-height:1.5"><?php echo htmlspecialchars(substr($r['description'], 0, 150)); ?><?php echo strlen($r['description']) > 150 ? '...' : ''; ?></p>
          <?php endif; ?>

          <div class="d-flex justify-content-between align-items-center">
            <div class="d-flex gap-2 align-items-center">
              <span class="prio-badge" style="background:<?php echo $pColor; ?>15;color:<?php echo $pColor; ?>"><?php echo $r['priority']; ?></span>
              <span class="text-muted" style="font-size:.72rem"><i class="far fa-clock me-1"></i><?php echo date('d M Y, h:i A', strtotime($r['created_at'])); ?></span>
            </div>
            <?php if(!empty($r['assigned_to'])): ?>
            <span class="text-muted" style="font-size:.72rem"><i class="fas fa-user-cog me-1"></i><?php echo htmlspecialchars($r['assigned_to']); ?></span>
            <?php endif; ?>
          </div>

          <?php if(!empty($r['notes'])): ?>
          <div class="mt-2 p-2 rounded-2" style="background:var(--body-bg,#f5f7ff);font-size:.78rem">
            <i class="fas fa-comment-dots me-1 text-accent"></i><strong>Admin Note:</strong> <?php echo htmlspecialchars($r['notes']); ?>
          </div>
          <?php endif; ?>

          <?php if(!empty($r['completed_at'])): ?>
          <div class="mt-1 text-success" style="font-size:.72rem"><i class="fas fa-check-double me-1"></i>Completed on <?php echo date('d M Y', strtotime($r['completed_at'])); ?></div>
          <?php endif; ?>
        </div>
        <?php endwhile; else: ?>
        <div class="m-card text-center py-5">
          <i class="fas fa-clipboard-check mb-3" style="font-size:3rem;color:var(--accent,#FF6B35);opacity:.5"></i>
          <h6 class="fw-bold">No Maintenance Requests Yet</h6>
          <p class="text-muted small">Use the form on the left to submit your first maintenance request.</p>
        </div>
        <?php endif; ?>
      </div>
    </div>

  </div>
</div><!-- db-main -->
</div><!-- db-wrapper -->

<script>
function toggleDark() {
  var on = document.body.classList.toggle('dark-mode');
  localStorage.setItem('hh_dark', on ? '1' : '0');
  document.getElementById('darkIco').className = on ? 'fas fa-sun' : 'fas fa-moon';
}
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}
function selectCat(el) {
  document.querySelectorAll('.cat-option').forEach(function(c){ c.classList.remove('selected'); });
  el.classList.add('selected');
  el.querySelector('input').checked = true;
}
// Init
if (localStorage.getItem('hh_dark') === '1') {
  document.getElementById('darkIco').className = 'fas fa-sun';
}
// Auto-select the "other" category
document.querySelector('.cat-option:last-child').classList.add('selected');
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
