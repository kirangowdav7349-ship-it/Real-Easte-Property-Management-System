<?php
$pageTitle = 'My Properties';
require_once '../includes/header.php';
if(!isClientLoggedIn()) redirect(SITE_URL . '/client/login.php');
$cid = (int)$_SESSION['client_id'];
$clientName = $_SESSION['client_name'] ?? '';
$clientEmail = $_SESSION['client_email'] ?? '';

// Ensure client_id column exists in properties table
$conn->query("ALTER TABLE properties ADD COLUMN IF NOT EXISTS `client_id` INT DEFAULT NULL");

$msg = '';

// Handle Add Property
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_property'])) {
    $title       = sanitize($_POST['title']);
    $description = sanitize($_POST['description']);
    $type        = sanitize($_POST['type']);
    $listing_type = sanitize($_POST['listing_type']);
    $price       = (float)$_POST['price'];
    $area        = sanitize($_POST['area']);
    $bedrooms    = (int)$_POST['bedrooms'];
    $bathrooms   = (int)$_POST['bathrooms'];
    $location    = sanitize($_POST['location']);
    $city        = sanitize($_POST['city']);
    $state       = sanitize($_POST['state']);
    $pincode     = sanitize($_POST['pincode']);
    $amenities   = sanitize($_POST['amenities']);

    $stmt = $conn->prepare("INSERT INTO properties (title, description, type, listing_type, price, area, bedrooms, bathrooms, location, city, state, pincode, amenities, status, client_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'available', ?)");
    $stmt->bind_param("ssssdsiisssssi", $title, $description, $type, $listing_type, $price, $area, $bedrooms, $bathrooms, $location, $city, $state, $pincode, $amenities, $cid);
    
    if($stmt->execute()) {
        $newPropId = $conn->insert_id;
        // Handle image upload
        if(isset($_FILES['property_image']) && $_FILES['property_image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = '../uploads/properties/';
            if(!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
            $ext = pathinfo($_FILES['property_image']['name'], PATHINFO_EXTENSION);
            $fileName = 'prop_' . $newPropId . '_' . time() . '.' . $ext;
            $uploadPath = $uploadDir . $fileName;
            if(move_uploaded_file($_FILES['property_image']['tmp_name'], $uploadPath)) {
                $imgUrl = 'uploads/properties/' . $fileName;
                $conn->query("INSERT INTO property_images (property_id, image_url, is_primary) VALUES ($newPropId, '$imgUrl', 1)");
            }
        }
        $msg = '<div class="alert alert-success"><strong>✅ Property Listed Successfully!</strong> Your property "<strong>' . htmlspecialchars($title) . '</strong>" is now live.</div>';
    } else {
        $msg = '<div class="alert alert-danger"><strong>❌ Error!</strong> Could not add property. Please try again.</div>';
    }
}

// Handle Delete Property (only own)
if(isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    $conn->query("DELETE FROM properties WHERE id=$delId AND client_id=$cid");
    if($conn->affected_rows > 0) {
        $msg = '<div class="alert alert-warning">🗑️ Property removed successfully.</div>';
    }
}

// Fetch my listed properties
$myProps = $conn->query("SELECT p.*, pi.image_url FROM properties p LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 WHERE p.client_id=$cid ORDER BY p.created_at DESC");
$myPropsCount = $myProps ? $myProps->num_rows : 0;

// Fetch bought properties (complete transactions of type 'buy')
$boughtProps = $conn->query("SELECT pt.*, p.title, p.price as prop_price, p.type, p.listing_type, p.location, p.city, p.state, p.bedrooms, p.bathrooms, p.area, pi.image_url 
    FROM property_transactions pt 
    LEFT JOIN properties p ON pt.property_id = p.id 
    LEFT JOIN property_images pi ON p.id = pi.property_id AND pi.is_primary = 1 
    WHERE pt.client_id = $cid AND pt.transaction_type = 'buy'
    ORDER BY pt.created_at DESC");
$boughtCount = $boughtProps ? $boughtProps->num_rows : 0;

// Fetch enquired/rented properties
$rentedProps = $conn->query("SELECT pt.*, p.title, p.price as prop_price, p.type, p.listing_type, p.location, p.city, p.state, p.bedrooms, p.bathrooms, p.area, pi.image_url 
    FROM property_transactions pt 
    LEFT JOIN properties p ON pt.property_id = p.id 
    LEFT JOIN property_images pi ON p.id = pi.property_id AND pi.is_primary = 1 
    WHERE pt.client_id = $cid AND pt.transaction_type = 'rent'
    ORDER BY pt.created_at DESC");
$rentedCount = $rentedProps ? $rentedProps->num_rows : 0;
?>

<style>
.prop-hero{background:linear-gradient(135deg,#1a3c5e 0%,#2d6a4f 100%);color:white;padding:50px 0 30px;position:relative;overflow:hidden}
.prop-hero::before{content:'';position:absolute;top:-60%;right:-15%;width:50%;height:200%;background:radial-gradient(circle,rgba(45,106,79,.3) 0%,transparent 60%);z-index:0;pointer-events:none}
.prop-hero .container{position:relative;z-index:1}
.prop-card{background:var(--card-bg,#fff);border-radius:16px;overflow:hidden;border:1px solid var(--border-color,#eee);box-shadow:0 4px 18px rgba(0,0,0,.06);transition:.3s}
.prop-card:hover{transform:translateY(-4px);box-shadow:0 10px 30px rgba(0,0,0,.13)}
.prop-card .prop-img{height:180px;object-fit:cover;width:100%}
.prop-card .prop-body{padding:16px}
.prop-card .prop-price{font-size:1.15rem;font-weight:800;color:var(--primary,#1a3c5e)}
.prop-status-badge{padding:4px 12px;border-radius:16px;font-size:.7rem;font-weight:700}
.tab-section{border-radius:16px;background:var(--card-bg,#fff);border:1px solid var(--border-color,#eee);box-shadow:0 4px 18px rgba(0,0,0,.06);overflow:hidden;margin-bottom:24px}
.tab-section .nav-tabs{border-bottom:2px solid var(--border-color,#eee);padding:0 20px}
.tab-section .nav-tabs .nav-link{border:none;padding:14px 20px;font-weight:600;color:var(--text-muted,#666);position:relative}
.tab-section .nav-tabs .nav-link.active{color:var(--primary,#1a3c5e);background:transparent}
.tab-section .nav-tabs .nav-link.active::after{content:'';position:absolute;bottom:-2px;left:0;right:0;height:3px;background:var(--accent,#FF6B35);border-radius:3px 3px 0 0}
.tab-section .tab-content{padding:20px}
.txn-status-pending{background:#fff3cd;color:#856404}
.txn-status-approved{background:#cce5ff;color:#004085}
.txn-status-completed{background:#d4edda;color:#155724}
.txn-status-rejected{background:#f8d7da;color:#721c24}
.form-section{background:var(--card-bg,#fff);border-radius:16px;border:1px solid var(--border-color,#eee);box-shadow:0 4px 18px rgba(0,0,0,.06);padding:28px}
</style>

<!-- Hero -->
<div class="prop-hero">
  <div class="container">
    <nav aria-label="breadcrumb" class="mb-3">
      <ol class="breadcrumb mb-0">
        <li class="breadcrumb-item"><a href="<?= SITE_URL ?>" class="text-white-50">Home</a></li>
        <li class="breadcrumb-item"><a href="dashboard.php" class="text-white-50">Dashboard</a></li>
        <li class="breadcrumb-item active text-white">My Properties</li>
      </ol>
    </nav>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
      <div>
        <h3 class="fw-bold mb-1"><i class="fas fa-home me-2"></i>My Properties</h3>
        <p class="mb-0" style="opacity:.8;font-size:.9rem">Manage your listings & view bought/rented properties</p>
      </div>
      <button class="btn btn-light fw-bold px-4 rounded-pill" data-bs-toggle="modal" data-bs-target="#addPropertyModal">
        <i class="fas fa-plus me-1"></i>Add My Property
      </button>
    </div>
  </div>
</div>

<div class="container py-5">
  <?= $msg ?>

  <!-- Stats Row -->
  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <div class="p-4 rounded-4 text-white" style="background:linear-gradient(135deg,#2d6a4f,#1a3c5e);box-shadow:0 8px 24px rgba(26,60,94,.3)">
        <div style="font-size:.85rem;opacity:.85"><i class="fas fa-building me-1"></i>My Listings</div>
        <div class="fw-bold mt-1" style="font-size:1.6rem"><?= $myPropsCount ?></div>
        <div style="font-size:.75rem;opacity:.75;margin-top:4px">Properties you've listed</div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="p-4 rounded-4 text-white" style="background:linear-gradient(135deg,#FF6B35,#e55a2b);box-shadow:0 8px 24px rgba(255,107,53,.3)">
        <div style="font-size:.85rem;opacity:.85"><i class="fas fa-shopping-cart me-1"></i>Bought Properties</div>
        <div class="fw-bold mt-1" style="font-size:1.6rem"><?= $boughtCount ?></div>
        <div style="font-size:.75rem;opacity:.75;margin-top:4px">Purchase transactions</div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="p-4 rounded-4 text-white" style="background:linear-gradient(135deg,#6f42c1,#5a32a3);box-shadow:0 8px 24px rgba(111,66,193,.3)">
        <div style="font-size:.85rem;opacity:.85"><i class="fas fa-key me-1"></i>Rented Properties</div>
        <div class="fw-bold mt-1" style="font-size:1.6rem"><?= $rentedCount ?></div>
        <div style="font-size:.75rem;opacity:.75;margin-top:4px">Rental transactions</div>
      </div>
    </div>
  </div>

  <!-- Tabs Section -->
  <div class="tab-section">
    <ul class="nav nav-tabs" role="tablist">
      <li class="nav-item">
        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#myListings" type="button">
          <i class="fas fa-building me-1"></i>My Listings <span class="badge bg-primary ms-1"><?= $myPropsCount ?></span>
        </button>
      </li>
      <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#boughtTab" type="button">
          <i class="fas fa-shopping-cart me-1"></i>Bought <span class="badge bg-warning text-dark ms-1"><?= $boughtCount ?></span>
        </button>
      </li>
      <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#rentedTab" type="button">
          <i class="fas fa-key me-1"></i>Rented <span class="badge bg-info ms-1"><?= $rentedCount ?></span>
        </button>
      </li>
    </ul>

    <div class="tab-content">
      <!-- Tab 1: My Listings -->
      <div class="tab-pane fade show active" id="myListings">
        <?php if($myPropsCount == 0): ?>
        <div class="text-center py-5">
          <div style="font-size:4rem;margin-bottom:12px">🏠</div>
          <h5 class="fw-bold">No Listed Properties</h5>
          <p class="text-muted" style="font-size:.88rem">You haven't listed any properties yet. Click "Add My Property" to get started.</p>
          <button class="btn btn-accent rounded-pill px-4 fw-bold" data-bs-toggle="modal" data-bs-target="#addPropertyModal">
            <i class="fas fa-plus me-1"></i>Add Property
          </button>
        </div>
        <?php else: ?>
        <div class="row g-4">
          <?php while($p = $myProps->fetch_assoc()): 
            $imgSrc = !empty($p['image_url']) ? (strpos($p['image_url'],'http')===0 ? $p['image_url'] : SITE_URL.'/'.$p['image_url']) : 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800';
            $statusBg = ['available'=>'#10b981','sold'=>'#ef4444','rented'=>'#6f42c1'][$p['status']] ?? '#6b7280';
          ?>
          <div class="col-md-6 col-lg-4">
            <div class="prop-card">
              <div style="position:relative">
                <img src="<?= $imgSrc ?>" class="prop-img" alt="<?= htmlspecialchars($p['title']) ?>">
                <span class="prop-status-badge" style="position:absolute;top:10px;left:10px;background:<?= $statusBg ?>;color:white"><?= ucfirst($p['status']) ?></span>
                <span class="prop-status-badge" style="position:absolute;top:10px;right:10px;background:rgba(0,0,0,.6);color:white"><?= ucfirst($p['listing_type']) ?></span>
              </div>
              <div class="prop-body">
                <h6 class="fw-bold mb-1" style="font-size:.92rem"><?= htmlspecialchars($p['title']) ?></h6>
                <p class="text-muted mb-2" style="font-size:.8rem"><i class="fas fa-map-marker-alt text-danger me-1"></i><?= htmlspecialchars($p['location']) ?>, <?= htmlspecialchars($p['city']) ?></p>
                <div class="d-flex justify-content-between align-items-center">
                  <span class="prop-price">₹<?= number_format((float)$p['price']) ?></span>
                  <div class="d-flex gap-1">
                    <a href="<?= SITE_URL ?>/property-detail.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3" style="font-size:.75rem"><i class="fas fa-eye me-1"></i>View</a>
                    <a href="?delete=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger rounded-pill px-2" style="font-size:.75rem" onclick="return confirm('Are you sure?')"><i class="fas fa-trash"></i></a>
                  </div>
                </div>
                <?php if($p['bedrooms'] > 0 || $p['bathrooms'] > 0 || !empty($p['area'])): ?>
                <div class="d-flex gap-3 mt-2 pt-2 border-top" style="font-size:.78rem;color:var(--text-muted,#666)">
                  <?php if($p['bedrooms'] > 0): ?><span><i class="fas fa-bed me-1"></i><?= $p['bedrooms'] ?> Bed</span><?php endif; ?>
                  <?php if($p['bathrooms'] > 0): ?><span><i class="fas fa-bath me-1"></i><?= $p['bathrooms'] ?> Bath</span><?php endif; ?>
                  <?php if(!empty($p['area'])): ?><span><i class="fas fa-ruler-combined me-1"></i><?= htmlspecialchars($p['area']) ?></span><?php endif; ?>
                </div>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <?php endwhile; ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- Tab 2: Bought Properties -->
      <div class="tab-pane fade" id="boughtTab">
        <?php if($boughtCount == 0): ?>
        <div class="text-center py-5">
          <div style="font-size:4rem;margin-bottom:12px">🛒</div>
          <h5 class="fw-bold">No Purchased Properties</h5>
          <p class="text-muted" style="font-size:.88rem">Properties you buy will appear here with transaction details.</p>
          <a href="<?= SITE_URL ?>/properties.php?type=buy" class="btn btn-accent rounded-pill px-4 fw-bold">
            <i class="fas fa-search me-1"></i>Browse Properties to Buy
          </a>
        </div>
        <?php else: ?>
        <div class="row g-4">
          <?php while($bp = $boughtProps->fetch_assoc()):
            $bImg = !empty($bp['image_url']) ? (strpos($bp['image_url'],'http')===0 ? $bp['image_url'] : SITE_URL.'/'.$bp['image_url']) : 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800';
            $txnStatus = $bp['status'];
            $txnBadge = 'txn-status-' . $txnStatus;
          ?>
          <div class="col-md-6">
            <div class="prop-card">
              <div class="row g-0">
                <div class="col-4">
                  <img src="<?= $bImg ?>" style="width:100%;height:100%;object-fit:cover;min-height:160px" alt="">
                </div>
                <div class="col-8">
                  <div class="prop-body">
                    <div class="d-flex justify-content-between mb-1">
                      <h6 class="fw-bold mb-0" style="font-size:.9rem"><?= htmlspecialchars($bp['title'] ?? 'Property') ?></h6>
                      <span class="prop-status-badge <?= $txnBadge ?>"><?= ucfirst($txnStatus) ?></span>
                    </div>
                    <p class="text-muted mb-2" style="font-size:.78rem"><i class="fas fa-map-marker-alt text-danger me-1"></i><?= htmlspecialchars(($bp['location'] ?? '') . ', ' . ($bp['city'] ?? '')) ?></p>
                    <div class="prop-price mb-2">₹<?= number_format((float)($bp['amount'] ?: $bp['prop_price'])) ?></div>
                    <div class="d-flex gap-3" style="font-size:.75rem;color:var(--text-muted,#666)">
                      <?php if($bp['bedrooms'] > 0): ?><span><i class="fas fa-bed me-1"></i><?= $bp['bedrooms'] ?>BHK</span><?php endif; ?>
                      <?php if(!empty($bp['area'])): ?><span><i class="fas fa-ruler-combined me-1"></i><?= $bp['area'] ?></span><?php endif; ?>
                      <span><i class="fas fa-tag me-1"></i><?= ucfirst($bp['type'] ?? 'property') ?></span>
                    </div>
                    <div class="mt-2 pt-2 border-top">
                      <small class="text-muted"><i class="fas fa-calendar me-1"></i><?= date('d M Y', strtotime($bp['created_at'])) ?></small>
                      <a href="<?= SITE_URL ?>/property-detail.php?id=<?= $bp['property_id'] ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 float-end" style="font-size:.7rem">View Details</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php endwhile; ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- Tab 3: Rented Properties -->
      <div class="tab-pane fade" id="rentedTab">
        <?php if($rentedCount == 0): ?>
        <div class="text-center py-5">
          <div style="font-size:4rem;margin-bottom:12px">🔑</div>
          <h5 class="fw-bold">No Rented Properties</h5>
          <p class="text-muted" style="font-size:.88rem">Properties you rent will appear here.</p>
          <a href="<?= SITE_URL ?>/properties.php?type=rent" class="btn btn-accent rounded-pill px-4 fw-bold">
            <i class="fas fa-search me-1"></i>Browse Rental Properties
          </a>
        </div>
        <?php else: ?>
        <div class="row g-4">
          <?php while($rp = $rentedProps->fetch_assoc()):
            $rImg = !empty($rp['image_url']) ? (strpos($rp['image_url'],'http')===0 ? $rp['image_url'] : SITE_URL.'/'.$rp['image_url']) : 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800';
            $rTxnBadge = 'txn-status-' . $rp['status'];
          ?>
          <div class="col-md-6">
            <div class="prop-card">
              <div class="row g-0">
                <div class="col-4">
                  <img src="<?= $rImg ?>" style="width:100%;height:100%;object-fit:cover;min-height:160px" alt="">
                </div>
                <div class="col-8">
                  <div class="prop-body">
                    <div class="d-flex justify-content-between mb-1">
                      <h6 class="fw-bold mb-0" style="font-size:.9rem"><?= htmlspecialchars($rp['title'] ?? 'Property') ?></h6>
                      <span class="prop-status-badge <?= $rTxnBadge ?>"><?= ucfirst($rp['status']) ?></span>
                    </div>
                    <p class="text-muted mb-2" style="font-size:.78rem"><i class="fas fa-map-marker-alt text-danger me-1"></i><?= htmlspecialchars(($rp['location'] ?? '') . ', ' . ($rp['city'] ?? '')) ?></p>
                    <div class="prop-price mb-2">₹<?= number_format((float)($rp['amount'] ?: $rp['prop_price'])) ?><span style="font-size:.75rem;color:var(--text-muted)">/mo</span></div>
                    <div class="mt-2 pt-2 border-top">
                      <small class="text-muted"><i class="fas fa-calendar me-1"></i><?= date('d M Y', strtotime($rp['created_at'])) ?></small>
                      <a href="<?= SITE_URL ?>/property-detail.php?id=<?= $rp['property_id'] ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 float-end" style="font-size:.7rem">View Details</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php endwhile; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- Add Property Modal -->
<div class="modal fade" id="addPropertyModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content border-0 shadow-lg" style="border-radius:16px">
      <div class="modal-header border-0" style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:white;border-radius:16px 16px 0 0;padding:20px 24px">
        <h5 class="modal-title fw-bold"><i class="fas fa-plus-circle me-2"></i>List Your Property</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST" enctype="multipart/form-data">
        <div class="modal-body p-4">
          <div class="row g-3">
            <div class="col-12">
              <label class="fw-bold small">Property Title *</label>
              <input type="text" name="title" class="form-control" placeholder="e.g., Spacious 3BHK in Koramangala" required>
            </div>
            <div class="col-12">
              <label class="fw-bold small">Description</label>
              <textarea name="description" class="form-control" rows="3" placeholder="Describe your property..."></textarea>
            </div>
            <div class="col-md-4">
              <label class="fw-bold small">Property Type *</label>
              <select name="type" class="form-select" required>
                <option value="apartment">Apartment</option>
                <option value="home">House</option>
                <option value="villa">Villa</option>
                <option value="site">Plot / Land</option>
                <option value="commercial">Commercial</option>
                <option value="pg">PG</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="fw-bold small">Listing Type *</label>
              <select name="listing_type" class="form-select" required>
                <option value="rent">For Rent</option>
                <option value="buy">For Sale</option>
                <option value="pg">PG / Co-Living</option>
                <option value="commercial">Commercial</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="fw-bold small">Price (₹) *</label>
              <input type="number" name="price" class="form-control" placeholder="e.g., 2500000" required>
            </div>
            <div class="col-md-4">
              <label class="fw-bold small">Area (sq ft)</label>
              <input type="text" name="area" class="form-control" placeholder="e.g., 1200 sq ft">
            </div>
            <div class="col-md-4">
              <label class="fw-bold small">Bedrooms</label>
              <select name="bedrooms" class="form-select">
                <option value="0">N/A</option>
                <option value="1">1 BHK</option>
                <option value="2">2 BHK</option>
                <option value="3">3 BHK</option>
                <option value="4">4 BHK</option>
                <option value="5">5+ BHK</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="fw-bold small">Bathrooms</label>
              <select name="bathrooms" class="form-select">
                <option value="0">N/A</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4+</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="fw-bold small">Location / Area *</label>
              <input type="text" name="location" class="form-control" placeholder="e.g., Koramangala, HSR Layout" required>
            </div>
            <div class="col-md-6">
              <label class="fw-bold small">City *</label>
              <input type="text" name="city" class="form-control" placeholder="e.g., Bangalore" required>
            </div>
            <div class="col-md-6">
              <label class="fw-bold small">State</label>
              <input type="text" name="state" class="form-control" placeholder="e.g., Karnataka">
            </div>
            <div class="col-md-6">
              <label class="fw-bold small">Pincode</label>
              <input type="text" name="pincode" class="form-control" placeholder="e.g., 560034">
            </div>
            <div class="col-12">
              <label class="fw-bold small">Amenities</label>
              <input type="text" name="amenities" class="form-control" placeholder="e.g., WiFi, Parking, Gym, Pool (comma separated)">
            </div>
            <div class="col-12">
              <label class="fw-bold small">Property Image</label>
              <input type="file" name="property_image" class="form-control" accept="image/*">
              <small class="text-muted">Upload a primary image (JPG, PNG)</small>
            </div>
          </div>
        </div>
        <div class="modal-footer border-0 pt-0 px-4 pb-4">
          <button type="button" class="btn btn-light px-4 rounded-pill" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" name="add_property" value="1" class="btn fw-bold px-5 rounded-pill" style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:white">
            <i class="fas fa-check me-1"></i>List Property
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
