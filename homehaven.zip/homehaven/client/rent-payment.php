<?php
$pageTitle = 'Rent Payment';
require_once '../includes/header.php';
if(!isClientLoggedIn()) redirect(SITE_URL . '/client/login.php');
$cid = $_SESSION['client_id'];
$clientEmail = $_SESSION['client_email'] ?? '';
$msg = '';

// Handle paying a pending payment
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['pay_pending_id'])) {
  $payId = (int)$_POST['pay_pending_id'];
  $mode = sanitize($_POST['payment_mode']);
  $txn = 'TXN' . date('YmdHis') . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 6));
  $date = date('Y-m-d');
  $conn->query("UPDATE rent_payments SET status='paid', payment_mode='$mode', transaction_id='$txn', payment_date='$date' WHERE id=$payId AND client_id=$cid AND status='pending'");
  if($conn->affected_rows > 0) {
    $paidRow = $conn->query("SELECT receipt_number, amount FROM rent_payments WHERE id=$payId")->fetch_assoc();
    $msg = "<div class='alert alert-success'><strong>✅ Payment Successful!</strong><br>Receipt No: <strong>" . htmlspecialchars($paidRow['receipt_number']) . "</strong><br>Amount: <strong>₹" . number_format((float)$paidRow['amount']) . "</strong><br>Date: $date</div>";
  }
}
// Handle new payment
elseif($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['amount'])) {
  $amount = (float)$_POST['amount'];
  $pid = (int)$_POST['property_id'];
  $mode = sanitize($_POST['payment_mode']);
  $txn = 'TXN' . date('YmdHis') . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 6));
  $date = date('Y-m-d');
  $receipt = 'RCP' . strtoupper(uniqid());
  $month   = date('F Y');
  $conn->query("INSERT INTO rent_payments (client_id,property_id,receipt_number,amount,payment_month,payment_date,payment_mode,transaction_id,status) VALUES($cid,$pid,'$receipt',$amount,'$month','$date','$mode','$txn','paid')");
  $msg = "<div class='alert alert-success'><strong>✅ Payment Successful!</strong><br>Receipt No: <strong>$receipt</strong><br>Transaction ID: <strong>$txn</strong><br>Amount: <strong>₹" . number_format($amount) . "</strong><br>Date: $date</div>";
}

// Only show properties that the client has enquired about (matched by client email)
$safeEmail = $conn->real_escape_string($clientEmail);
$props = $conn->query("SELECT DISTINCT p.* FROM properties p 
  INNER JOIN enquiries e ON e.property_id = p.id 
  WHERE e.email = '$safeEmail' 
  AND p.listing_type IN ('rent','pg')
  ORDER BY p.title ASC");

$payments = $conn->query("SELECT rp.*, p.title as ptitle FROM rent_payments rp LEFT JOIN properties p ON rp.property_id=p.id WHERE rp.client_id=$cid ORDER BY rp.created_at DESC LIMIT 15");

// Pending payments
$pendingPayments = $conn->query("SELECT rp.*, p.title as ptitle FROM rent_payments rp LEFT JOIN properties p ON rp.property_id=p.id WHERE rp.client_id=$cid AND rp.status='pending' ORDER BY rp.created_at DESC");
$totalPending = (float)$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE client_id=$cid AND status='pending'")->fetch_assoc()['s'];
$totalPaid = (float)$conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE client_id=$cid AND status='paid'")->fetch_assoc()['s'];
?>

<div class="page-banner py-3">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-0">
        <li class="breadcrumb-item"><a href="<?= SITE_URL ?>" class="text-white">Home</a></li>
        <li class="breadcrumb-item"><a href="dashboard.php" class="text-white">Dashboard</a></li>
        <li class="breadcrumb-item active text-white">Rent Payment</li>
      </ol>
    </nav>
  </div>
</div>

<div class="container py-5">
  <h3 class="fw-bold mb-4">💳 Rent Payment</h3>

  <?php if(isset($_GET['pay_first']) && $_GET['pay_first'] == '1'): ?>
  <div class="alert mb-4" style="background:linear-gradient(135deg,#dc3545,#c0392b);color:white;border:none;border-radius:16px;padding:24px;box-shadow:0 8px 24px rgba(220,53,69,.3)">
    <div class="d-flex align-items-center gap-3">
      <div style="font-size:2.5rem">🔐</div>
      <div>
        <h5 class="fw-bold mb-1" style="color:white">First Rent Payment Required</h5>
        <p class="mb-0" style="opacity:.9;font-size:.88rem">Your dashboard and all other features are <strong>locked</strong> until you pay your first month's rent below. Once paid, you'll have full access to everything.</p>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <?= $msg ?>

  <!-- Summary Cards -->
  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <div class="p-4 rounded-4 text-white" style="background:linear-gradient(135deg,#dc3545,#c0392b);box-shadow:0 8px 24px rgba(220,53,69,.3)">
        <div style="font-size:.85rem;opacity:.85"><i class="fas fa-clock me-1"></i>Pending Amount</div>
        <div class="fw-bold mt-1" style="font-size:1.6rem">₹<?= number_format($totalPending) ?></div>
        <div style="font-size:.75rem;opacity:.75;margin-top:4px"><?= $pendingPayments->num_rows ?> payment(s) pending</div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="p-4 rounded-4 text-white" style="background:linear-gradient(135deg,#10b981,#059669);box-shadow:0 8px 24px rgba(16,185,129,.3)">
        <div style="font-size:.85rem;opacity:.85"><i class="fas fa-check-circle me-1"></i>Total Paid</div>
        <div class="fw-bold mt-1" style="font-size:1.6rem">₹<?= number_format($totalPaid) ?></div>
        <div style="font-size:.75rem;opacity:.75;margin-top:4px">All time payments</div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="p-4 rounded-4 text-white" style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f);box-shadow:0 8px 24px rgba(26,60,94,.3)">
        <div style="font-size:.85rem;opacity:.85"><i class="fas fa-receipt me-1"></i>Total Transactions</div>
        <div class="fw-bold mt-1" style="font-size:1.6rem"><?= $pendingPayments->num_rows + $pcount = (int)$conn->query("SELECT COUNT(*) as c FROM rent_payments WHERE client_id=$cid AND status='paid'")->fetch_assoc()['c'] ?></div>
        <div style="font-size:.75rem;opacity:.75;margin-top:4px">Paid + Pending</div>
      </div>
    </div>
  </div>

  <?php
  // Reset pending payments cursor
  $pendingPayments->data_seek(0);
  if($pendingPayments->num_rows > 0):
  ?>
  <!-- Pending Payments Section -->
  <div class="receipt-card mb-4" style="border-left:4px solid #dc3545">
    <h5 class="fw-bold mb-3" style="color:#dc3545"><i class="fas fa-exclamation-triangle me-2"></i>Pending Payments</h5>
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead style="background:#fff5f5">
          <tr><th>Property</th><th>Amount</th><th>Month</th><th>Receipt</th><th>Action</th></tr>
        </thead>
        <tbody>
          <?php while($pp = $pendingPayments->fetch_assoc()): ?>
          <tr>
            <td class="fw-bold" style="font-size:.85rem"><?= htmlspecialchars($pp['ptitle'] ?? 'N/A') ?></td>
            <td class="fw-bold" style="color:#dc3545;font-size:1rem">₹<?= number_format((float)$pp['amount']) ?></td>
            <td style="font-size:.83rem"><?= htmlspecialchars($pp['payment_month'] ?? '-') ?></td>
            <td><code style="font-size:.75rem"><?= htmlspecialchars($pp['receipt_number'] ?? '-') ?></code></td>
            <td>
              <button class="btn btn-sm btn-danger rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#payModal<?= $pp['id'] ?>">
                <i class="fas fa-credit-card me-1"></i>Pay Now
              </button>
            </td>
          </tr>
          <!-- Pay Modal -->
          <div class="modal fade" id="payModal<?= $pp['id'] ?>" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content rounded-4">
                <div class="modal-header border-0" style="background:linear-gradient(135deg,#dc3545,#c0392b)">
                  <h6 class="modal-title text-white fw-bold"><i class="fas fa-credit-card me-2"></i>Pay ₹<?= number_format((float)$pp['amount']) ?></h6>
                  <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                  <div class="modal-body p-4">
                    <input type="hidden" name="pay_pending_id" value="<?= $pp['id'] ?>">
                    <div class="mb-3 p-3 rounded-3" style="background:#fff5f5">
                      <div style="font-size:.8rem;color:#666">Property</div>
                      <div class="fw-bold"><?= htmlspecialchars($pp['ptitle'] ?? 'N/A') ?></div>
                      <div class="fw-bold mt-1" style="color:#dc3545;font-size:1.2rem">₹<?= number_format((float)$pp['amount']) ?></div>
                    </div>
                    <div class="mb-3">
                      <label class="fw-bold" style="font-size:.85rem">Payment Mode</label>
                      <select name="payment_mode" class="form-select" required>
                        <option>UPI</option><option>Net Banking</option><option>Debit Card</option><option>Credit Card</option><option>NEFT/RTGS</option>
                      </select>
                    </div>

                  </div>
                  <div class="modal-footer border-0">
                    <button type="submit" class="btn btn-danger w-100 py-2 fw-bold rounded-pill"><i class="fas fa-check me-1"></i>Confirm Payment</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>

  <div class="row g-4">
    <div class="col-lg-6">
      <div class="receipt-card">
        <h5 class="fw-bold mb-4">Pay Rent</h5>
        <?php if($props && $props->num_rows > 0): ?>
        <form method="POST">
          <div class="mb-3">
            <label class="fw-bold">Select Property <small class="text-muted fw-normal">(Enquired properties only)</small></label>
            <select name="property_id" class="form-select" required>
              <option value="">Choose Property</option>
              <?php while($p = $props->fetch_assoc()): ?>
              <option value="<?= $p['id'] ?>"><?= $p['title'] ?> - <?= $p['city'] ?> (₹<?= number_format($p['price']) ?>/mo)</option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="fw-bold">Amount (₹)</label>
            <input type="number" name="amount" class="form-control form-control-lg" placeholder="Enter rent amount" required>
          </div>
          <div class="mb-3">
            <label class="fw-bold">Payment Mode</label>
            <select name="payment_mode" class="form-select" required>
              <option>UPI</option>
              <option>Net Banking</option>
              <option>Debit Card</option>
              <option>Credit Card</option>
              <option>NEFT/RTGS</option>
            </select>
          </div>
          <div class="mb-4">
            <div class="p-3 rounded-3" style="background:#f0fdf4;border:1px solid #bbf7d0">
              <div class="d-flex align-items-center gap-2">
                <i class="fas fa-shield-alt text-success"></i>
                <small class="text-muted">Transaction ID will be auto-generated upon payment</small>
              </div>
            </div>
          </div>
          <button type="submit" class="btn btn-accent w-100 py-3 fw-bold">Pay Now</button>
        </form>
        <?php else: ?>
        <div class="text-center py-4">
          <div style="font-size:3rem;margin-bottom:12px">📩</div>
          <h6 class="fw-bold text-muted">No Enquired Properties</h6>
          <p class="text-muted" style="font-size:.85rem">You haven't enquired about any rental properties yet.<br>Browse properties and send an enquiry first.</p>
          <a href="<?= SITE_URL ?>/properties.php?type=rent" class="btn btn-accent rounded-pill px-4"><i class="fas fa-search me-1"></i>Browse Rental Properties</a>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="receipt-card">
        <h5 class="fw-bold mb-4">Payment History</h5>
        <?php if($payments->num_rows == 0): ?>
        <p class="text-muted text-center py-4">No payment history</p>
        <?php else: while($pay = $payments->fetch_assoc()): ?>
        <div class="d-flex justify-content-between p-3 mb-2 border rounded">
          <div>
            <div class="fw-bold">₹<?= number_format($pay['amount']) ?></div>
            <small class="text-muted"><?= $pay['payment_mode'] ?> • <?= $pay['receipt_number'] ?></small><br>
            <small class="text-muted"><?= $pay['ptitle'] ?? '' ?> • <?= $pay['payment_date'] ?></small>
          </div>
          <?php if($pay['status'] === 'pending'): ?>
          <span class="badge bg-warning text-dark align-self-center px-3 py-2">⏳ Pending</span>
          <?php elseif($pay['status'] === 'failed'): ?>
          <span class="badge bg-danger align-self-center px-3 py-2">❌ Failed</span>
          <?php else: ?>
          <span class="badge bg-success align-self-center px-3 py-2">✅ Paid</span>
          <?php endif; ?>
        </div>
        <?php endwhile; endif; ?>
      </div>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
