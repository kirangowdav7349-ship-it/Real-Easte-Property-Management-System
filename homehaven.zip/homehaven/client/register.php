<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once '../includes/config.php';
if (isClientLoggedIn()) { redirect(SITE_URL . '/client/dashboard.php'); }

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = $conn->real_escape_string(trim(isset($_POST['name'])    ? $_POST['name']    : ''));
    $email   = $conn->real_escape_string(trim(isset($_POST['email'])   ? $_POST['email']   : ''));
    $phone   = $conn->real_escape_string(trim(isset($_POST['phone'])   ? $_POST['phone']   : ''));
    $country = $conn->real_escape_string(trim(isset($_POST['country']) ? $_POST['country'] : ''));
    $city    = $conn->real_escape_string(trim(isset($_POST['city'])    ? $_POST['city']    : ''));
    $pass    = isset($_POST['password'])         ? $_POST['password']         : '';
    $cpass   = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    if (!$name) {
        $error = 'Full name is required.';
    } elseif (!$email) {
        $error = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid email address.';
    } elseif (!$phone) {
        $error = 'Phone number is required.';
    } elseif ($pass !== $cpass) {
        $error = 'Passwords do not match!';
    } elseif (strlen($pass) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        $chk = $conn->query("SELECT id FROM clients WHERE email='" . $email . "'");
        if ($chk && $chk->num_rows > 0) {
            $error = 'This email is already registered!';
        } else {
            $hash    = password_hash($pass, PASSWORD_BCRYPT);
            $phoneDb = $phone . ($country ? ' (' . $country . ')' : '');
            $conn->query("INSERT INTO clients (name, email, phone, password) VALUES('" . $name . "', '" . $email . "', '" . $conn->real_escape_string($phoneDb) . "', '" . $hash . "')");
            $success = 'Account created successfully! Please login.';
        }
    }
}

$countries    = array('Afghanistan','Albania','Algeria','Argentina','Australia','Austria','Bangladesh','Belgium','Brazil','Canada','Chile','China','Colombia','Czech Republic','Denmark','Egypt','Ethiopia','Finland','France','Germany','Ghana','Greece','Hungary','India','Indonesia','Iran','Iraq','Ireland','Israel','Italy','Japan','Jordan','Kenya','Malaysia','Mexico','Morocco','Nepal','Netherlands','New Zealand','Nigeria','Norway','Pakistan','Philippines','Poland','Portugal','Romania','Russia','Saudi Arabia','Singapore','South Africa','South Korea','Spain','Sri Lanka','Sweden','Switzerland','Thailand','Turkey','UAE','UK','Ukraine','USA','Vietnam');
$indianCities = array('Ahmedabad','Bangalore','Bhopal','Chandigarh','Chennai','Coimbatore','Delhi','Faridabad','Gurgaon','Hyderabad','Indore','Jaipur','Kochi','Kolkata','Lucknow','Mumbai','Mysore','Nagpur','Noida','Patna','Pune','Surat','Visakhapatnam');

$postName    = isset($_POST['name'])    ? htmlspecialchars($_POST['name'])    : '';
$postEmail   = isset($_POST['email'])   ? htmlspecialchars($_POST['email'])   : '';
$postPhone   = isset($_POST['phone'])   ? htmlspecialchars($_POST['phone'])   : '';
$postCountry = isset($_POST['country']) ? $_POST['country']                   : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280">
<title>Register - PropNexus</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="<?php echo SITE_URL; ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
<script>if(localStorage.getItem('hh_dark')==='1')document.body.classList.add('dark-mode');</script>

<div class="auth-wrapper">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-6 col-md-8">
        <div class="auth-card">

          <div class="text-center mb-4">
            <a href="<?php echo SITE_URL; ?>" class="text-decoration-none">
              <div class="auth-logo"><i class="fas fa-home me-2" style="color:#FF6B35"></i>PropNexus</div>
            </a>
            <p class="text-muted mt-1 mb-0">Create your free account</p>
          </div>

          <?php if ($error): ?>
          <div class="alert alert-danger py-2"><i class="fas fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?></div>
          <?php endif; ?>
          <?php if ($success): ?>
          <div class="alert alert-success py-2">
            <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
            <a href="login.php" class="fw-bold ms-2">Login Now</a>
          </div>
          <?php endif; ?>

          <form method="POST">
            <div class="row g-3">

              <div class="col-12">
                <label class="fw-bold small">Full Name <span class="text-danger">*</span></label>
                <div class="input-group">
                  <span class="input-group-text"><i class="fas fa-user"></i></span>
                  <input type="text" name="name" class="form-control" placeholder="Your full name" required value="<?php echo $postName; ?>">
                </div>
              </div>

              <div class="col-12">
                <label class="fw-bold small">Email Address <span class="text-danger">*</span></label>
                <div class="input-group">
                  <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                  <input type="email" name="email" class="form-control" placeholder="your@email.com" required value="<?php echo $postEmail; ?>">
                </div>
              </div>

              <div class="col-md-6">
                <label class="fw-bold small">Country <span class="text-danger">*</span></label>
                <div class="input-group">
                  <span class="input-group-text"><i class="fas fa-globe"></i></span>
                  <select name="country" id="countrySelect" class="form-select" required onchange="onCountryChange(this.value)">
                    <option value="">-- Select Country --</option>
                    <?php
                    foreach ($countries as $c) {
                        $sel = ($postCountry === $c) ? ' selected' : '';
                        $fw  = ($c === 'India') ? ' style="font-weight:700"' : '';
                        echo '<option value="' . htmlspecialchars($c) . '"' . $sel . $fw . '>' . htmlspecialchars($c) . '</option>' . "\n";
                    }
                    ?>
                  </select>
                </div>
              </div>

              <div class="col-md-6" id="cityRow" style="display:none">
                <label class="fw-bold small">City</label>
                <div class="input-group">
                  <span class="input-group-text"><i class="fas fa-city"></i></span>
                  <select name="city" id="indiaCity" class="form-select">
                    <option value="">-- Select City --</option>
                    <?php foreach ($indianCities as $ic): ?>
                    <option value="<?php echo htmlspecialchars($ic); ?>"><?php echo htmlspecialchars($ic); ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>

              <div class="col-12">
                <label class="fw-bold small">Phone Number <span class="text-danger">*</span></label>
                <div class="input-group">
                  <span class="input-group-text" id="phoneFlag">&#128222;</span>
                  <input type="text" name="phone" id="phoneIn" class="form-control" placeholder="+91 XXXXX XXXXX" required value="<?php echo $postPhone; ?>">
                </div>
              </div>

              <div class="col-md-6">
                <label class="fw-bold small">Password <span class="text-danger">*</span></label>
                <div class="input-group">
                  <span class="input-group-text"><i class="fas fa-lock"></i></span>
                  <input type="password" name="password" id="passIn" class="form-control" placeholder="Min 6 characters" required>
                  <button type="button" class="btn btn-outline-secondary" onclick="togglePass('passIn')"><i class="fas fa-eye"></i></button>
                </div>
              </div>

              <div class="col-md-6">
                <label class="fw-bold small">Confirm Password <span class="text-danger">*</span></label>
                <div class="input-group">
                  <span class="input-group-text"><i class="fas fa-lock"></i></span>
                  <input type="password" name="confirm_password" id="cpassIn" class="form-control" placeholder="Repeat password" required>
                  <button type="button" class="btn btn-outline-secondary" onclick="togglePass('cpassIn')"><i class="fas fa-eye"></i></button>
                </div>
              </div>

              <!-- Password strength bars -->
              <div class="col-12">
                <div class="d-flex gap-1">
                  <div class="flex-grow-1 rounded" style="height:4px;background:#eee" id="sb1"></div>
                  <div class="flex-grow-1 rounded" style="height:4px;background:#eee" id="sb2"></div>
                  <div class="flex-grow-1 rounded" style="height:4px;background:#eee" id="sb3"></div>
                  <div class="flex-grow-1 rounded" style="height:4px;background:#eee" id="sb4"></div>
                </div>
                <small id="strengthTxt" class="text-muted"></small>
              </div>

              <div class="col-12">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="agreeCheck" required>
                  <label class="form-check-label small" for="agreeCheck">
                    I agree to the <a href="#" class="text-accent">Terms of Service</a> and <a href="#" class="text-accent">Privacy Policy</a>
                  </label>
                </div>
              </div>

              <div class="col-12">
                <button type="submit" class="btn btn-accent w-100 py-2 fw-bold">
                  <i class="fas fa-user-plus me-2"></i>Create Account
                </button>
              </div>

            </div>
          </form>

          <p class="text-center mt-3 text-muted small">Already have an account? <a href="login.php" class="text-accent fw-bold">Login</a></p>
          <p class="text-center"><a href="<?php echo SITE_URL; ?>" class="text-muted small">Back to PropNexus</a></p>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
var phonePrefixes = {
  'India': '+91', 'USA': '+1', 'UK': '+44', 'UAE': '+971',
  'Australia': '+61', 'Canada': '+1', 'Singapore': '+65',
  'Germany': '+49', 'France': '+33', 'Japan': '+81'
};

function onCountryChange(val) {
  var cityRow = document.getElementById('cityRow');
  cityRow.style.display = (val === 'India') ? '' : 'none';

  var pfx  = phonePrefixes[val] || '';
  var ph   = document.getElementById('phoneIn');
  if (pfx && !ph.value) { ph.value = pfx + ' '; }

  var flag = document.getElementById('phoneFlag');
  if (val === 'India')     { flag.innerHTML = '&#127470;&#127475;'; }
  else if (val === 'USA')  { flag.innerHTML = '&#127482;&#127480;'; }
  else if (val === 'UK')   { flag.innerHTML = '&#127468;&#127463;'; }
  else if (val === 'UAE')  { flag.innerHTML = '&#127462;&#127466;'; }
  else                     { flag.innerHTML = '&#128222;'; }
}

function togglePass(id) {
  var el = document.getElementById(id);
  el.type = (el.type === 'password') ? 'text' : 'password';
}

document.getElementById('passIn').addEventListener('input', function() {
  var v = this.value;
  var score = 0;
  if (v.length >= 6)  score++;
  if (v.length >= 10) score++;
  if (/[A-Z]/.test(v) && /[0-9]/.test(v)) score++;
  if (/[^A-Za-z0-9]/.test(v)) score++;

  var colors = ['', '#dc3545', '#fd7e14', '#ffc107', '#28a745'];
  var labels = ['', 'Weak', 'Fair', 'Good', 'Strong'];
  for (var i = 1; i <= 4; i++) {
    document.getElementById('sb' + i).style.background = (i <= score) ? colors[score] : '#eee';
  }
  var st = document.getElementById('strengthTxt');
  st.textContent = score ? ('Password strength: ' + labels[score]) : '';
  st.style.color = colors[score] || '#999';
});

// If country was pre-selected from POST, init city row
var savedCountry = document.getElementById('countrySelect').value;
if (savedCountry) { onCountryChange(savedCountry); }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
