<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once '../includes/config.php';
if(!isClientLoggedIn()) redirect(SITE_URL.'/client/login.php');
require_once 'includes/rent-gate.php';

$cid    = $_SESSION['client_id'];
$client = $conn->query("SELECT * FROM clients WHERE id=$cid")->fetch_assoc();

// ── Helpers ──────────────────────────────────────────────────
function toast($msg, $type='ok'){ return "<div class='hh-toast $type' id='hhToast'>$msg</div>"; }
$flash = '';

// ── Save Avatar ───────────────────────────────────────────────
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_avatar'])){
  $data = $_POST['avatar_data'] ?? '';
  if($data && strpos($data,'data:image/')===0){
    $safe = $conn->real_escape_string($data);
    $conn->query("UPDATE clients SET profile_pic='$safe' WHERE id=$cid");
    $_SESSION['client_pic'] = $data;
    $flash = toast('✅ Avatar saved!');
    $client['profile_pic'] = $data;
  }
}

// ── Save Profile ──────────────────────────────────────────────
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_profile'])){
  $name  = $conn->real_escape_string(trim($_POST['name']??''));
  $phone = $conn->real_escape_string(trim($_POST['phone']??''));
  $city  = $conn->real_escape_string(trim($_POST['city']??''));
  if(!$name){ $flash = toast('❌ Name is required','err'); }
  else {
    $conn->query("UPDATE clients SET name='$name', phone='$phone' WHERE id=$cid");
    $_SESSION['client_name'] = $name;
    $flash = toast('✅ Profile updated!');
    $client = $conn->query("SELECT * FROM clients WHERE id=$cid")->fetch_assoc();
  }
}

// ── Change Password ───────────────────────────────────────────
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['change_pwd'])){
  $cur  = $_POST['cur_pwd']??'';
  $new  = $_POST['new_pwd']??'';
  $cnew = $_POST['cnew_pwd']??'';
  if(!password_verify($cur,$client['password']))   $flash = toast('❌ Current password is wrong','err');
  elseif(strlen($new)<6)                            $flash = toast('❌ Min 6 characters required','err');
  elseif($new!==$cnew)                              $flash = toast('❌ Passwords do not match','err');
  else {
    $conn->query("UPDATE clients SET password='".password_hash($new,PASSWORD_BCRYPT)."' WHERE id=$cid");
    $flash = toast('✅ Password changed!');
  }
}

$init     = strtoupper(substr($client['name'],0,1));
$hasAvatar= !empty($client['profile_pic']) && strpos($client['profile_pic'],'data:image')===0;
$cities   = ['Ahmedabad','Bangalore','Bhopal','Chandigarh','Chennai','Coimbatore','Delhi','Faridabad','Gurgaon','Hyderabad','Indore','Jaipur','Kochi','Kolkata','Lucknow','Mumbai','Mysore','Nagpur','Noida','Patna','Pune','Surat','Visakhapatnam'];
$activeTab= $_GET['tab'] ?? 'profile';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=1280">
<title>Settings — PropNexus</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="<?=SITE_URL?>/assets/css/style.css" rel="stylesheet">
<style>
html,body{height:auto;overflow-x:hidden}
.settings-page{display:flex;min-height:100vh}
.settings-sidebar-inner{width:255px;background:linear-gradient(160deg,#1a3c5e 0%,#2d6a4f 100%);color:white;height:100vh;position:sticky;top:0;overflow-y:auto;flex-shrink:0}
.settings-content{flex:1;padding:32px 36px;background:var(--body-bg)}
.s-logo{padding:22px 20px 14px;font-size:1.25rem;font-weight:800;border-bottom:1px solid rgba(255,255,255,.14);display:flex;align-items:center;gap:10px}
.s-avatar-box{padding:20px;text-align:center;border-bottom:1px solid rgba(255,255,255,.12)}
.s-av{width:70px;height:70px;border-radius:50%;border:3px solid var(--accent);margin:0 auto 10px;overflow:hidden;display:flex;align-items:center;justify-content:center;font-size:1.8rem;font-weight:800;color:white;background:linear-gradient(135deg,#FF6B35,#1a3c5e)}
.s-av img{width:100%;height:100%;object-fit:cover}
.s-nav{padding:10px 8px}
.s-nav a{display:flex;align-items:center;gap:10px;padding:10px 13px;border-radius:9px;color:rgba(255,255,255,.78);text-decoration:none;font-size:.84rem;font-weight:500;transition:.2s;margin-bottom:1px}
.s-nav a:hover,.s-nav a.active{background:rgba(255,255,255,.17);color:white}
.s-sec{font-size:.66rem;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:rgba(255,255,255,.38);padding:12px 13px 5px}
/* Tabs */
.s-tabs{display:flex;gap:0;border-bottom:2px solid var(--border);margin-bottom:24px}
.s-tab-btn{padding:10px 22px;border:none;background:none;font-size:.85rem;font-weight:600;color:var(--text-muted);cursor:pointer;border-bottom:3px solid transparent;margin-bottom:-2px;transition:.2s;border-radius:8px 8px 0 0}
.s-tab-btn.active{color:var(--accent);border-bottom-color:var(--accent);background:rgba(255,107,53,.06)}
.tab-panel{display:none}.tab-panel.show{display:block}
/* Cards inside settings */
.s-card{background:var(--card-bg);border-radius:14px;border:1px solid var(--border);padding:22px;margin-bottom:18px;box-shadow:var(--card-shadow)}
.s-card-head{font-size:.87rem;font-weight:700;color:var(--primary);border-bottom:2px solid var(--border);padding-bottom:10px;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.s-row{display:flex;align-items:center;justify-content:space-between;padding:11px 0;border-bottom:1px solid var(--border)}
.s-row:last-child{border-bottom:none}
.s-row .t{font-weight:600;font-size:.84rem;color:var(--text-main)}
.s-row .s{font-size:.74rem;color:var(--text-muted);margin-top:1px}
/* Avatar */
.av-big{width:110px;height:110px;border-radius:50%;border:4px solid var(--accent);margin:0 auto;overflow:hidden;cursor:pointer;position:relative;display:flex;align-items:center;justify-content:center;transition:.3s}
.av-big:hover{opacity:.8;border-color:#e55a25}
.av-big img{width:100%;height:100%;object-fit:cover}
.av-big .av-init{font-size:3rem;font-weight:800;color:white;background:linear-gradient(135deg,#FF6B35,#1a3c5e);width:100%;height:100%;display:flex;align-items:center;justify-content:center}
.av-cam{position:absolute;bottom:4px;right:4px;width:30px;height:30px;background:var(--accent);border:none;border-radius:50%;color:white;font-size:.7rem;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.3)}
.upload-zone{border:2px dashed var(--border);border-radius:12px;padding:24px;text-align:center;cursor:pointer;transition:.3s}
.upload-zone:hover{border-color:var(--accent);background:rgba(255,107,53,.04)}
.color-av{width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.4rem;font-weight:800;cursor:pointer;border:3px solid transparent;transition:.3s}
.color-av:hover{border-color:var(--accent);transform:scale(1.1)}
/* Pass strength */
.ps-bar{height:4px;border-radius:2px;background:var(--border);flex:1;transition:.4s}
/* Dark mode overrides for this page */
body.dark .s-card{background:var(--card-bg);border-color:var(--border)}
body.dark .s-card-head{color:#b8d0e8;border-color:var(--border)}
body.dark .s-row{border-color:var(--border)}
body.dark .s-row .t{color:var(--text-main)}
body.dark .s-tab-btn{color:var(--text-muted)}
body.dark .upload-zone{border-color:var(--border)}
body.dark .settings-page{background:var(--body-bg)}
@media(max-width:767px){.settings-page{flex-direction:column}.settings-sidebar-inner{width:100%;height:auto;position:static}.settings-content{padding:18px 14px}}
</style>
</head>
<body>
<script>if(localStorage.getItem('hh_dark')==='1')document.body.classList.add('dark')</script>

<?= $flash ?>

<div class="settings-page">

<!-- ═══ SIDEBAR ═══ -->
<div class="settings-sidebar-inner">
  <div class="s-logo">
    <div style="width:30px;height:30px;background:var(--accent);border-radius:7px;display:flex;align-items:center;justify-content:center"><i class="fas fa-building text-white" style="font-size:.8rem"></i></div>
    PropNexus
  </div>

  <div class="s-avatar-box">
    <div class="s-av">
      <?php if($hasAvatar): ?>
      <img src="<?=$client['profile_pic']?>" alt="avatar">
      <?php else: ?>
      <?=$init?>
      <?php endif; ?>
    </div>
    <div class="fw-bold" style="font-size:.9rem"><?=$client['name']?></div>
    <div style="font-size:.72rem;color:rgba(255,255,255,.5)"><?=$client['email']?></div>
  </div>

  <div class="s-nav">
    <div class="s-sec">Account</div>
    <a href="?tab=profile"     class="<?=$activeTab==='profile'   ?'active':''?>"><i class="fas fa-user fa-fw"></i>Profile</a>
    <a href="?tab=password"    class="<?=$activeTab==='password'  ?'active':''?>"><i class="fas fa-lock fa-fw"></i>Password</a>
    <a href="?tab=avatar"      class="<?=$activeTab==='avatar'    ?'active':''?>"><i class="fas fa-camera fa-fw"></i>Profile Avatar</a>
    <div class="s-sec">Preferences</div>
    <a href="?tab=appearance"  class="<?=$activeTab==='appearance'?'active':''?>"><i class="fas fa-palette fa-fw"></i>Appearance</a>
    <a href="?tab=notifs"      class="<?=$activeTab==='notifs'    ?'active':''?>"><i class="fas fa-bell fa-fw"></i>Notifications</a>
    <a href="?tab=privacy"     class="<?=$activeTab==='privacy'   ?'active':''?>"><i class="fas fa-shield-alt fa-fw"></i>Privacy</a>
    <div class="s-sec">Navigate</div>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt fa-fw"></i>Dashboard</a>
    <a href="rent-payment.php"><i class="fas fa-receipt fa-fw"></i>Rent Receipts</a>
    <a href="alerts.php"><i class="fas fa-bell fa-fw"></i>My Alerts</a>
    <a href="<?=SITE_URL?>/news.php"><i class="fas fa-newspaper fa-fw"></i>News & Guides</a>
    <a href="<?=SITE_URL?>"><i class="fas fa-home fa-fw"></i>Back to Site</a>
    <a href="logout.php" style="color:#ff8585"><i class="fas fa-sign-out-alt fa-fw"></i>Logout</a>
  </div>
</div>

<!-- ═══ CONTENT ═══ -->
<div class="settings-content">

  <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
    <div>
      <h4 class="fw-bold mb-0">⚙️ Account Settings</h4>
      <p style="color:var(--text-muted);font-size:.84rem;margin:0">Manage your profile, security & preferences</p>
    </div>
    <button onclick="toggleDark()" class="btn btn-outline-secondary btn-sm px-3" id="darkBtn">
      <i class="fas fa-moon me-1" id="darkIco"></i><span id="darkTxt">Dark Mode</span>
    </button>
  </div>

  <!-- ── PROFILE ── -->
  <?php if($activeTab==='profile'): ?>
  <div class="s-card">
    <div class="s-card-head"><i class="fas fa-user text-accent"></i>Profile Information</div>
    <form method="POST">
      <div class="row g-3">
        <div class="col-md-6">
          <label class="fw-bold small">Full Name <span class="text-danger">*</span></label>
          <div class="input-group">
            <span class="input-group-text"><i class="fas fa-user"></i></span>
            <input type="text" name="name" class="form-control" value="<?=htmlspecialchars($client['name'])?>" required>
          </div>
        </div>
        <div class="col-md-6">
          <label class="fw-bold small">Email (cannot change)</label>
          <div class="input-group">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            <input type="email" class="form-control" value="<?=htmlspecialchars($client['email'])?>" disabled style="opacity:.7">
          </div>
        </div>
        <div class="col-md-6">
          <label class="fw-bold small">Phone Number</label>
          <div class="input-group">
            <span class="input-group-text"><i class="fas fa-phone"></i></span>
            <input type="text" name="phone" class="form-control" value="<?=htmlspecialchars($client['phone'])?>">
          </div>
        </div>
        <div class="col-md-6">
          <label class="fw-bold small">City</label>
          <div class="input-group">
            <span class="input-group-text"><i class="fas fa-city"></i></span>
            <select name="city" class="form-select">
              <option value="">-- Select City --</option>
              <?php foreach($cities as $ct): ?><option value="<?=$ct?>"><?=$ct?></option><?php endforeach; ?>
            </select>
          </div>
        </div>
      </div>
      <button type="submit" name="save_profile" class="btn btn-accent mt-3 px-5 fw-bold">
        <i class="fas fa-save me-2"></i>Save Changes
      </button>
    </form>
  </div>

  <!-- Stats -->
  <div class="row g-3">
    <?php
    $bc=$conn->query("SELECT COUNT(*) c FROM service_bookings WHERE client_id=$cid")->fetch_assoc()['c'];
    $ac=$conn->query("SELECT COUNT(*) c FROM property_alerts WHERE client_id=$cid")->fetch_assoc()['c'];
    $pc=$conn->query("SELECT COUNT(*) c FROM rent_payments WHERE client_id=$cid")->fetch_assoc()['c'];
    foreach([['fa-calendar','Member Since',date('M Y',strtotime($client['created_at'])),'#1a3c5e'],['fa-tools','Services Booked',$bc,'#2d6a4f'],['fa-bell','Alerts',$ac,'#6f42c1'],['fa-receipt','Receipts',$pc,'#FF6B35']] as $st):?>
    <div class="col-6 col-md-3">
      <div class="s-card text-center p-3">
        <i class="fas <?=$st[0]?> fa-2x mb-2" style="color:<?=$st[3]?>"></i>
        <div class="fw-bold"><?=$st[2]?></div>
        <div style="font-size:.74rem;color:var(--text-muted)"><?=$st[1]?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- ── PASSWORD ── -->
  <?php elseif($activeTab==='password'): ?>
  <div class="s-card">
    <div class="s-card-head"><i class="fas fa-lock" style="color:#6f42c1"></i>Change Password</div>
    <form method="POST" style="max-width:460px">
      <div class="mb-3">
        <label class="fw-bold small">Current Password</label>
        <div class="input-group">
          <input type="password" name="cur_pwd" id="cp" class="form-control" placeholder="Enter current password" required>
          <button type="button" class="btn btn-outline-secondary" onclick="eyeToggle('cp')"><i class="fas fa-eye"></i></button>
        </div>
      </div>
      <div class="mb-3">
        <label class="fw-bold small">New Password</label>
        <div class="input-group">
          <input type="password" name="new_pwd" id="np" class="form-control" placeholder="Min 6 characters" required oninput="checkStrength(this.value)">
          <button type="button" class="btn btn-outline-secondary" onclick="eyeToggle('np')"><i class="fas fa-eye"></i></button>
        </div>
        <div class="d-flex gap-1 mt-2">
          <div class="ps-bar" id="ps1"></div><div class="ps-bar" id="ps2"></div>
          <div class="ps-bar" id="ps3"></div><div class="ps-bar" id="ps4"></div>
        </div>
        <small id="psLbl" class="text-muted"></small>
      </div>
      <div class="mb-4">
        <label class="fw-bold small">Confirm New Password</label>
        <div class="input-group">
          <input type="password" name="cnew_pwd" id="cnp" class="form-control" placeholder="Repeat new password" required oninput="checkMatch()">
          <button type="button" class="btn btn-outline-secondary" onclick="eyeToggle('cnp')"><i class="fas fa-eye"></i></button>
        </div>
        <small id="matchLbl" class="mt-1 d-block"></small>
      </div>
      <button type="submit" name="change_pwd" class="btn btn-primary-custom px-5 fw-bold">
        <i class="fas fa-key me-2"></i>Update Password
      </button>
    </form>

    <hr class="my-4">
    <h6 class="fw-bold mb-3">🔐 Password Security Tips</h6>
    <div class="row g-2">
      <?php foreach(['Use at least 8 characters','Mix uppercase & lowercase','Include numbers and symbols','Never reuse old passwords'] as $tip): ?>
      <div class="col-md-6"><div style="font-size:.82rem;display:flex;gap:8px"><i class="fas fa-check-circle text-success mt-1"></i><?=$tip?></div></div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- ── AVATAR ── -->
  <?php elseif($activeTab==='avatar'): ?>
  <div class="s-card">
    <div class="s-card-head"><i class="fas fa-camera text-accent"></i>Profile Avatar</div>

    <div class="row g-4 align-items-start">
      <div class="col-md-3 text-center">
        <div class="av-big" onclick="document.getElementById('avFile').click()" id="avRing">
          <?php if($hasAvatar): ?>
          <img src="<?=$client['profile_pic']?>" id="avPreviewImg">
          <?php else: ?>
          <div class="av-init" id="avInitDiv"><?=$init?></div>
          <img src="" id="avPreviewImg" style="display:none">
          <?php endif; ?>
        </div>
        <button class="av-cam mt-2" type="button" onclick="document.getElementById('avFile').click()" style="position:static;margin:8px auto 0;display:flex">
          <i class="fas fa-camera"></i>
        </button>
        <div class="mt-2 fw-bold small"><?=$client['name']?></div>
        <div style="font-size:.72rem;color:var(--text-muted)"><?=$client['email']?></div>
      </div>

      <div class="col-md-9">
        <h6 class="fw-bold mb-3">Upload a Photo</h6>
        <div class="upload-zone mb-3" onclick="document.getElementById('avFile').click()" ondragover="event.preventDefault();this.style.borderColor='var(--accent)'" ondragleave="this.style.borderColor=''" ondrop="handleFileDrop(event)">
          <i class="fas fa-cloud-upload-alt fa-2x mb-2 text-accent"></i>
          <div class="fw-bold">Click to upload or drag & drop</div>
          <small style="color:var(--text-muted)">JPG, PNG, GIF · Max 5MB · Square recommended</small>
        </div>
        <input type="file" id="avFile" accept="image/*" class="d-none" onchange="previewAv(this)">

        <form method="POST" id="avForm">
          <input type="hidden" name="avatar_data" id="avData">
          <div class="d-none" id="avSaveRow">
            <button type="submit" name="save_avatar" class="btn btn-accent px-4 fw-bold me-2">
              <i class="fas fa-save me-2"></i>Save Avatar
            </button>
            <button type="button" class="btn btn-outline-secondary px-4" onclick="cancelAv()">Cancel</button>
          </div>
        </form>

        <hr class="my-3">
        <h6 class="fw-bold mb-2">🎨 Pick a Color Style</h6>
        <div class="d-flex flex-wrap gap-2">
          <?php foreach([['#FF6B35','white'],['#1a3c5e','white'],['#2d6a4f','white'],['#6f42c1','white'],['#dc3545','white'],['#17a2b8','white'],['#000000','#FF6B35'],['#f5f5f5','#1a3c5e']] as $cs): ?>
          <div class="color-av" style="background:<?=$cs[0]?>;color:<?=$cs[1]?>" onclick="makeColorAv('<?=$cs[0]?>','<?=$cs[1]?>')"><?=$init?></div>
          <?php endforeach; ?>
        </div>
        <p class="text-muted small mt-2">Click any color to instantly set it as your avatar</p>
      </div>
    </div>
  </div>

  <!-- ── APPEARANCE ── -->
  <?php elseif($activeTab==='appearance'): ?>
  <div class="s-card">
    <div class="s-card-head"><i class="fas fa-palette" style="color:#FF6B35"></i>Appearance & Theme</div>

    <div class="s-row">
      <div><div class="t">🌙 Dark Mode</div><div class="s">Comfortable night browsing</div></div>
      <div class="form-check form-switch mb-0">
        <input class="form-check-input" type="checkbox" id="darkSw" role="switch" onchange="toggleDark()" style="width:46px;height:22px">
      </div>
    </div>

    <div class="s-row">
      <div><div class="t">🎨 Accent Color</div><div class="s">Your preferred highlight color</div></div>
      <div class="d-flex gap-2">
        <?php foreach(['#FF6B35','#1a3c5e','#6f42c1','#2d6a4f','#dc3545','#0d9488'] as $ac): ?>
        <div style="width:26px;height:26px;border-radius:50%;background:<?=$ac?>;cursor:pointer;border:3px solid transparent;transition:.2s" onclick="setAccent('<?=$ac?>')" title="<?=$ac?>"></div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="s-row">
      <div><div class="t">📏 Text Size</div><div class="s">Adjust for readability</div></div>
      <select class="form-select form-select-sm" style="width:auto" onchange="document.body.style.fontSize=this.value+'px';localStorage.setItem('hh_fs',this.value)">
        <option value="13">Small</option><option value="15" selected>Normal</option><option value="17">Large</option><option value="19">X-Large</option>
      </select>
    </div>

    <div class="s-row">
      <div><div class="t">🌐 Language</div><div class="s">Display language</div></div>
      <select class="form-select form-select-sm" style="width:auto">
        <option selected>English</option><option>Hindi</option><option>Telugu</option><option>Tamil</option><option>Kannada</option><option>Marathi</option>
      </select>
    </div>

    <div class="s-row">
      <div><div class="t">💰 Currency</div><div class="s">Price display format</div></div>
      <select class="form-select form-select-sm" style="width:auto">
        <option selected>₹ INR</option><option>$ USD</option><option>£ GBP</option><option>€ EUR</option>
      </select>
    </div>
  </div>

  <!-- ── NOTIFICATIONS ── -->
  <?php elseif($activeTab==='notifs'): ?>
  <div class="s-card">
    <div class="s-card-head"><i class="fas fa-bell text-warning"></i>Notification Preferences</div>
    <?php foreach([
      ['📧 Property Match Email','New matching properties emailed to you','notif_email_p',true],
      ['📧 Booking Confirmation','Email when service is confirmed','notif_email_b',true],
      ['📧 Rent Reminders','Monthly due-date reminders','notif_email_r',true],
      ['📱 SMS Alerts','Property match via SMS','notif_sms',false],
      ['💬 WhatsApp','Property alerts on WhatsApp','notif_wa',false],
      ['🔔 Browser Push','Instant browser notifications','notif_push',false],
      ['🎯 Promo Offers','Deals and special offers','notif_promo',false],
      ['📰 Weekly News','Real estate market digest','notif_news',true],
    ] as $n): ?>
    <div class="s-row">
      <div><div class="t"><?=$n[0]?></div><div class="s"><?=$n[1]?></div></div>
      <div class="form-check form-switch mb-0">
        <input class="form-check-input" type="checkbox" role="switch" <?=$n[3]?'checked':''?> onchange="localStorage.setItem('hh_<?=$n[2]?>',this.checked?'1':'0')" style="width:44px;height:22px">
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- ── PRIVACY ── -->
  <?php elseif($activeTab==='privacy'): ?>
  <div class="s-card">
    <div class="s-card-head"><i class="fas fa-shield-alt text-success"></i>Privacy Settings</div>
    <?php foreach([
      ['👁️ Show Profile to Owners','Owners can see your basic profile','priv_p',true],
      ['📞 Allow Direct Contact','Owners can contact you via platform','priv_c',true],
      ['📊 Share Search History','Improve recommendations','priv_sh',false],
      ['📍 Location Access','Nearby property suggestions','priv_loc',false],
      ['🎯 Personalized Content','Ads based on your activity','priv_ad',false],
    ] as $pv): ?>
    <div class="s-row">
      <div><div class="t"><?=$pv[0]?></div><div class="s"><?=$pv[1]?></div></div>
      <div class="form-check form-switch mb-0">
        <input class="form-check-input" type="checkbox" role="switch" <?=$pv[3]?'checked':''?> style="width:44px;height:22px">
      </div>
    </div>
    <?php endforeach; ?>
    <hr class="mt-3 mb-3">
    <div class="d-flex gap-3 flex-wrap">
      <button class="btn btn-outline-secondary btn-sm"><i class="fas fa-download me-2"></i>Download My Data</button>
      <button class="btn btn-outline-danger btn-sm" onclick="if(confirm('Permanently delete your account?'))alert('Contact support@PropNexus.com')"><i class="fas fa-trash me-2"></i>Delete Account</button>
    </div>
  </div>
  <?php endif; ?>

</div><!-- settings-content -->
</div><!-- settings-page -->

<script>
// Dark mode
function toggleDark(){
  var on=document.body.classList.toggle('dark');
  localStorage.setItem('hh_dark',on?'1':'0');
  _upDark();
}
function _upDark(){
  var on=document.body.classList.contains('dark');
  document.getElementById('darkIco').className=on?'fas fa-sun me-1':'fas fa-moon me-1';
  document.getElementById('darkTxt').textContent=on?'Light Mode':'Dark Mode';
  var sw=document.getElementById('darkSw'); if(sw) sw.checked=on;
}
document.addEventListener('DOMContentLoaded',_upDark);

// Password eye toggle
function eyeToggle(id){var el=document.getElementById(id);el.type=el.type==='password'?'text':'password'}

// Password strength
function checkStrength(v){
  var s=0;
  if(v.length>=6)s++; if(v.length>=10)s++; if(/[A-Z]/.test(v)&&/[0-9]/.test(v))s++; if(/[^A-Za-z0-9]/.test(v))s++;
  var c=['','#dc3545','#fd7e14','#ffc107','#28a745'],l=['','Weak','Fair','Good','Strong'];
  for(var i=1;i<=4;i++) document.getElementById('ps'+i).style.background=i<=s?c[s]:'var(--border)';
  var el=document.getElementById('psLbl'); el.textContent=s?'Strength: '+l[s]:''; el.style.color=c[s];
}

// Password match
function checkMatch(){
  var np=document.getElementById('np').value, cnp=document.getElementById('cnp').value;
  var el=document.getElementById('matchLbl');
  if(!cnp){el.textContent='';return;}
  el.textContent=np===cnp?'✅ Passwords match':'❌ Does not match';
  el.style.color=np===cnp?'#28a745':'#dc3545';
}

// Avatar file input
function previewAv(inp){
  var f=inp.files[0]; if(!f) return;
  if(f.size>5*1024*1024){alert('Max 5MB');return;}
  var r=new FileReader();
  r.onload=function(e){
    setAvPreview(e.target.result);
    document.getElementById('avData').value=e.target.result;
    document.getElementById('avSaveRow').classList.remove('d-none');
  };
  r.readAsDataURL(f);
}
function setAvPreview(src){
  var img=document.getElementById('avPreviewImg');
  var init=document.getElementById('avInitDiv');
  if(img){img.src=src;img.style.display='block';}
  if(init) init.style.display='none';
}
function cancelAv(){
  document.getElementById('avSaveRow').classList.add('d-none');
  document.getElementById('avData').value='';
  var img=document.getElementById('avPreviewImg');
  var init=document.getElementById('avInitDiv');
  if(img){img.src='';img.style.display='none';}
  if(init) init.style.display='flex';
}
function handleFileDrop(e){
  e.preventDefault(); e.currentTarget.style.borderColor='';
  var f=e.dataTransfer.files[0];
  if(f){var dt=new DataTransfer();dt.items.add(f);document.getElementById('avFile').files=dt.files;previewAv(document.getElementById('avFile'));}
}

// Color avatar using canvas
function makeColorAv(bg,color){
  var c=document.createElement('canvas'); c.width=200; c.height=200;
  var ctx=c.getContext('2d');
  ctx.fillStyle=bg; ctx.fillRect(0,0,200,200);
  ctx.fillStyle=color; ctx.font='bold 88px Poppins,Arial';
  ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillText('<?=$init?>',100,108);
  var data=c.toDataURL('image/png');
  setAvPreview(data);
  document.getElementById('avData').value=data;
  document.getElementById('avSaveRow').classList.remove('d-none');
}

// Accent
function setAccent(col){
  document.documentElement.style.setProperty('--accent',col);
  localStorage.setItem('hh_accent',col);
  // Mark active
  document.querySelectorAll('[onclick^="setAccent"]').forEach(el=>{
    el.style.borderColor=el.getAttribute('onclick').includes(col)?'rgba(0,0,0,.5)':'transparent';
  });
}
var _ac=localStorage.getItem('hh_accent'); if(_ac) document.documentElement.style.setProperty('--accent',_ac);

// Auto dismiss toast
setTimeout(function(){var t=document.getElementById('hhToast');if(t){t.style.transition='opacity .6s';t.style.opacity='0';}},3500);
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
