<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once '../includes/config.php';
if (!isClientLoggedIn()) { redirect(SITE_URL . '/client/login.php'); }
require_once 'includes/rent-gate.php';
$cid    = (int)$_SESSION['client_id'];
$res    = $conn->query("SELECT * FROM clients WHERE id=" . $cid);
$client = ($res && $res->num_rows > 0) ? $res->fetch_assoc() : array('name'=>'User','email'=>'','avatar'=>'','phone'=>'');

$loanRes = $conn->query("SELECT COUNT(*) as c FROM loan_applications WHERE client_id=" . $cid);
$loanCount = ($loanRes) ? (int)$loanRes->fetch_assoc()['c'] : 0;

$aRes   = $conn->query("SELECT COUNT(*) as c FROM property_alerts WHERE client_id=" . $cid);
$acount = ($aRes) ? (int)$aRes->fetch_assoc()['c'] : 0;

$pRes   = $conn->query("SELECT COUNT(*) as c FROM rent_payments WHERE client_id=" . $cid);
$pcount = ($pRes) ? (int)$pRes->fetch_assoc()['c'] : 0;

$pendAmtRes = $conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE client_id=" . $cid . " AND status='pending'");
$pendingAmount = ($pendAmtRes) ? (float)$pendAmtRes->fetch_assoc()['s'] : 0;

$pendCountRes = $conn->query("SELECT COUNT(*) as c FROM rent_payments WHERE client_id=" . $cid . " AND status='pending'");
$pendingCount = ($pendCountRes) ? (int)$pendCountRes->fetch_assoc()['c'] : 0;

$loanApps = $conn->query("SELECT * FROM loan_applications WHERE client_id=" . $cid . " ORDER BY created_at DESC LIMIT 5");
$alerts   = $conn->query("SELECT * FROM property_alerts WHERE client_id=" . $cid . " ORDER BY created_at DESC LIMIT 5");
$featProp = $conn->query("SELECT p.*, pi.image_url FROM properties p LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 WHERE p.status='available' ORDER BY RAND() LIMIT 3");
$news     = $conn->query("SELECT * FROM news_guides WHERE status='published' ORDER BY views DESC LIMIT 3");

// Service bookings by this client
$svcBookings = $conn->query("SELECT sb.*, s.name as sname FROM service_bookings sb LEFT JOIN services s ON sb.service_id=s.id WHERE sb.client_id=" . $cid . " ORDER BY sb.created_at DESC LIMIT 5");
$svcCount    = ($svcBookings) ? $svcBookings->num_rows : 0;

// Legal bookings by this client
$legalBookings = $conn->query("SELECT lb.*, ls.name as lsname FROM legal_bookings lb LEFT JOIN legal_services ls ON lb.service_id=ls.id WHERE lb.client_id=" . $cid . " ORDER BY lb.created_at DESC LIMIT 5");
$legalCount    = ($legalBookings) ? $legalBookings->num_rows : 0;

// Total rent paid by this client
$totalPaidRes = $conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE client_id=" . $cid . " AND status='paid'");
$totalPaid = ($totalPaidRes) ? (float)$totalPaidRes->fetch_assoc()['s'] : 0;

// Rent rates by property type (for available rental properties)
$rentByType = $conn->query("SELECT p.type, COUNT(*) as cnt, MIN(p.price) as min_price, MAX(p.price) as max_price, AVG(p.price) as avg_price FROM properties p WHERE p.listing_type='rent' AND p.status='available' GROUP BY p.type ORDER BY avg_price DESC");

// Available rental properties for the client
$rentalProps = $conn->query("SELECT p.*, pi.image_url FROM properties p LEFT JOIN property_images pi ON p.id=pi.property_id AND pi.is_primary=1 WHERE p.listing_type='rent' AND p.status='available' ORDER BY p.price ASC LIMIT 6");

// ──── AUTO MONTHLY RENT NOTIFICATION ────
// Find properties client has rented (paid rent at least once)
$rentedPropsRes = $conn->query("SELECT DISTINCT rp.property_id, p.title, p.price, p.type
    FROM rent_payments rp
    JOIN properties p ON rp.property_id = p.id
    WHERE rp.client_id = $cid");

$currentMonth = date('F Y');
if($rentedPropsRes && $rentedPropsRes->num_rows > 0) {
    while($rp = $rentedPropsRes->fetch_assoc()) {
        // Check if a rent entry already exists for this month
        $pid = (int)$rp['property_id'];
        $price = (float)$rp['price'];
        $existsRes = $conn->query("SELECT id FROM rent_payments WHERE client_id=$cid AND property_id=$pid AND payment_month='$currentMonth'");
        if($existsRes && $existsRes->num_rows == 0 && $price > 0) {
            // Auto-create pending rent notification for this month
            $receipt = 'RCP' . strtoupper(uniqid());
            $conn->query("INSERT INTO rent_payments (client_id,property_id,receipt_number,amount,payment_month,status)
                VALUES($cid,$pid,'$receipt',$price,'$currentMonth','pending')");
        }
    }
    // Refresh counts after auto-generation
    $pendAmtRes = $conn->query("SELECT COALESCE(SUM(amount),0) as s FROM rent_payments WHERE client_id=" . $cid . " AND status='pending'");
    $pendingAmount = ($pendAmtRes) ? (float)$pendAmtRes->fetch_assoc()['s'] : 0;
    $pendCountRes = $conn->query("SELECT COUNT(*) as c FROM rent_payments WHERE client_id=" . $cid . " AND status='pending'");
    $pendingCount = ($pendCountRes) ? (int)$pendCountRes->fetch_assoc()['c'] : 0;
    $pRes = $conn->query("SELECT COUNT(*) as c FROM rent_payments WHERE client_id=" . $cid);
    $pcount = ($pRes) ? (int)$pRes->fetch_assoc()['c'] : 0;
}

// Client's rented properties (for rental agreement section)
$myRentals = $conn->query("SELECT DISTINCT rp.property_id, p.title, p.price, p.type, p.location, p.city,
    (SELECT lb.status FROM legal_bookings lb WHERE lb.client_id=$cid AND lb.service_id=1 ORDER BY lb.created_at DESC LIMIT 1) as agreement_status
    FROM rent_payments rp
    JOIN properties p ON rp.property_id = p.id
    WHERE rp.client_id = $cid");

// Pending rent notifications for alert display
$pendingRentAlerts = $conn->query("SELECT rp.*, p.title as ptitle, p.type as ptype
    FROM rent_payments rp
    JOIN properties p ON rp.property_id = p.id
    WHERE rp.client_id = $cid AND rp.status = 'pending'
    ORDER BY rp.created_at DESC");

$clientName  = !empty($client['name'])  ? $client['name']  : 'User';
$clientEmail = !empty($client['email']) ? $client['email'] : '';
$avatarUrl   = !empty($client['avatar'])
    ? $client['avatar']
    : 'https://ui-avatars.com/api/?name=' . urlencode($clientName) . '&background=FF6B35&color=fff&size=128&bold=true';

$hour = (int)date('H');
if ($hour < 12) {
    $greet = 'Good Morning';
} elseif ($hour < 17) {
    $greet = 'Good Afternoon';
} else {
    $greet = 'Good Evening';
}

$catColors = array('news' => '#dc3545', 'guide' => '#2d6a4f', 'tips' => '#FF6B35', 'market' => '#6f42c1');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280">
<title>Dashboard - PropNexus</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="<?php echo SITE_URL; ?>/assets/css/style.css" rel="stylesheet">
<style>
html,body{margin:0;padding:0;height:100%;overflow:hidden}
.db-wrapper{display:flex;height:100vh;overflow:hidden}
.db-sidebar{background:linear-gradient(180deg,#1a3c5e,#0d2438);width:260px;flex-shrink:0;overflow-y:auto}
.db-sidebar .nav-link{color:rgba(255,255,255,.75);padding:11px 20px;border-radius:10px;margin:2px 10px;font-size:.88rem;font-weight:500;display:flex;align-items:center;gap:10px;transition:.2s}
.db-sidebar .nav-link:hover,.db-sidebar .nav-link.active{background:rgba(255,255,255,.14);color:white}
.db-sidebar .nav-link.active{background:rgba(255,107,53,.3);border-left:3px solid #FF6B35}
.db-main{flex:1;overflow-y:auto;background:var(--body-bg,#f5f7ff)}
.db-topbar{background:var(--card-bg,#fff);border-bottom:1px solid var(--border-color,#e5e9ef);padding:14px 28px;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;z-index:99}
.stat-tile{background:var(--card-bg,#fff);border-radius:16px;padding:22px;box-shadow:0 4px 18px rgba(0,0,0,.07);border:1px solid var(--border-color,#eee);transition:.3s;cursor:pointer}
.stat-tile:hover{transform:translateY(-4px);box-shadow:0 10px 30px rgba(0,0,0,.13)}
.db-card{background:var(--card-bg,#fff);border-radius:16px;padding:22px;box-shadow:0 4px 18px rgba(0,0,0,.07);border:1px solid var(--border-color,#eee)}
.db-card h6{font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.prop-mini{border-radius:10px;overflow:hidden;border:1px solid var(--border-color,#eee);transition:.3s}
.prop-mini:hover{transform:translateY(-3px);box-shadow:0 6px 20px rgba(0,0,0,.12)}
.prop-mini img{width:100%;height:100px;object-fit:cover}
.bstatus-confirmed{background:#d4edda;color:#155724;padding:2px 8px;border-radius:20px;font-size:.7rem;font-weight:600}
.bstatus-pending{background:#fff3cd;color:#856404;padding:2px 8px;border-radius:20px;font-size:.7rem;font-weight:600}
.bstatus-completed{background:#d1ecf1;color:#0c5460;padding:2px 8px;border-radius:20px;font-size:.7rem;font-weight:600}
.db-sidebar::-webkit-scrollbar{width:5px}
.db-sidebar::-webkit-scrollbar-thumb{background:rgba(255,255,255,.25);border-radius:4px}
.db-main::-webkit-scrollbar{width:8px}
.db-main::-webkit-scrollbar-thumb{background:rgba(26,60,94,.3);border-radius:4px}
@media(max-width:768px){.db-sidebar{position:fixed;top:0;left:0;height:100vh;z-index:100;transform:translateX(-100%);transition:transform .3s}.db-sidebar.open{transform:translateX(0)}.db-main{width:100%}}
body.dark-mode .db-topbar,.db-topbar{transition:.3s}
body.dark-mode .db-topbar{background:#1a2535;border-color:#2d3748}
body.dark-mode .stat-tile,body.dark-mode .db-card{background:#1a2535;border-color:#2d3748}
</style>
</head>
<body>
<script>if(localStorage.getItem('hh_dark')==='1')document.body.classList.add('dark-mode');</script>

<div class="db-wrapper">
<!-- Sidebar -->
<div class="db-sidebar" id="sidebar">
  <div class="p-4 pb-2">
    <a href="<?php echo SITE_URL; ?>" class="text-decoration-none d-flex align-items-center gap-2 mb-4">
      <i class="fas fa-building text-accent" style="font-size:1.4rem"></i>
      <span class="text-white fw-bold fs-5">PropNexus</span>
    </a>
    <a href="profile.php" class="text-decoration-none d-flex align-items-center gap-3 mb-4 p-3 rounded-3" style="background:rgba(255,255,255,.08)">
      <img src="<?php echo $avatarUrl; ?>" class="rounded-circle" style="width:44px;height:44px;object-fit:cover;border:2px solid #FF6B35" alt="Avatar">
      <div>
        <div class="text-white fw-bold" style="font-size:.88rem"><?php echo htmlspecialchars($clientName); ?></div>
        <div class="text-muted" style="font-size:.72rem"><?php echo htmlspecialchars($clientEmail); ?></div>
      </div>
    </a>
    <nav class="nav flex-column gap-1">
      <a href="dashboard.php"     class="nav-link active"><i class="fas fa-home"></i>Dashboard</a>
      <a href="../ai-recommend.php" class="nav-link" style="color:#FF6B35"><i class="fas fa-robot"></i>AI Agent</a>

      <a href="../properties.php" class="nav-link"><i class="fas fa-building"></i>Browse Properties</a>
      <a href="my-properties.php" class="nav-link"><i class="fas fa-home"></i>My Properties</a>
      <a href="../properties.php?type=pg" class="nav-link"><i class="fas fa-door-open"></i>PG / Co-Living</a>
      <a href="alerts.php"        class="nav-link"><i class="fas fa-bell"></i>My Alerts <span class="badge bg-warning ms-auto" style="font-size:.65rem"><?php echo $acount; ?></span></a>
      <a href="rent-payment.php"  class="nav-link"><i class="fas fa-receipt"></i>Rent Receipts</a>
      <a href="maintenance.php"   class="nav-link"><i class="fas fa-wrench"></i>Maintenance</a>
      <a href="../loans.php"      class="nav-link"><i class="fas fa-file-invoice-dollar"></i>Loan Tracker</a>
      <a href="legal-tracking.php" class="nav-link"><i class="fas fa-gavel"></i>Legal Tracking <span class="badge bg-info ms-auto" style="font-size:.65rem"><?php echo $legalCount; ?></span></a>
      <a href="../loans.php"      class="nav-link"><i class="fas fa-piggy-bank"></i>Home Loans</a>
      <a href="../news.php"       class="nav-link"><i class="fas fa-newspaper"></i>News &amp; Guides</a>
      <a href="profile.php"       class="nav-link"><i class="fas fa-user-circle"></i>My Profile</a>
      <hr style="border-color:rgba(255,255,255,.1);margin:8px 10px">
      <a href="settings.php"     class="nav-link"><i class="fas fa-cog"></i>Settings</a>
      <a href="logout.php"       class="nav-link" style="color:#ff8888"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </nav>
  </div>
</div>

<!-- Main Content -->
<div class="db-main">

  <!-- Top Bar -->
  <div class="db-topbar">
    <div class="d-flex align-items-center gap-3">
      <button class="btn btn-sm btn-outline-secondary d-md-none" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
      <div>
        <h5 class="fw-bold mb-0"><?php echo $greet; ?>, <?php echo htmlspecialchars(explode(' ', $clientName)[0]); ?>! &#128075;</h5>
        <small class="text-muted" id="liveTime"></small>
      </div>
    </div>
    <div class="d-flex align-items-center gap-2">
      <button class="dark-toggle" onclick="toggleDark()" id="darkBtn"><i class="fas fa-moon" id="darkIco"></i></button>
      <a href="../index.php" class="btn btn-accent btn-sm px-3 rounded-pill">&#127968; Website</a>
      <a href="profile.php">
        <img src="<?php echo $avatarUrl; ?>" class="rounded-circle" style="width:38px;height:38px;object-fit:cover;border:2px solid #FF6B35" alt="Profile">
      </a>
    </div>
  </div>

  <?php
  // Check for unpaid first-month rent — block dashboard if pending
  $firstRentDue = $conn->query("SELECT rp.*, p.title as ptitle, p.location, p.city, p.price 
    FROM rent_payments rp 
    JOIN properties p ON rp.property_id = p.id
    WHERE rp.client_id = $cid AND rp.status = 'pending' 
    AND rp.id = (SELECT MIN(r2.id) FROM rent_payments r2 WHERE r2.client_id = $cid AND r2.property_id = rp.property_id)
    LIMIT 1");
  $hasUnpaidFirstRent = ($firstRentDue && $firstRentDue->num_rows > 0);
  $firstRent = $hasUnpaidFirstRent ? $firstRentDue->fetch_assoc() : null;
  ?>

  <?php if($hasUnpaidFirstRent && $firstRent): ?>
  <!-- FIRST RENT PAYMENT BLOCKER -->
  <div style="position:relative;flex:1;display:flex;align-items:center;justify-content:center;min-height:calc(100vh - 70px)">
    <!-- Blurred background -->
    <div style="position:absolute;top:0;left:0;right:0;bottom:0;background:url('data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22><rect fill=%22%23f5f7ff%22 width=%22100%22 height=%22100%22/><circle fill=%22%23FF6B3512%22 cx=%2250%22 cy=%2250%22 r=%2240%22/></svg>');filter:blur(3px);opacity:.5"></div>
    
    <div style="position:relative;max-width:520px;width:100%;margin:0 20px">
      <div class="db-card text-center" style="border:2px solid #dc3545;box-shadow:0 20px 60px rgba(220,53,69,.15)">
        <!-- Header -->
        <div style="background:linear-gradient(135deg,#dc3545,#c0392b);color:white;margin:-22px -22px 24px -22px;padding:30px 20px;border-radius:14px 14px 0 0">
          <div style="font-size:3rem;margin-bottom:8px">🔐</div>
          <h4 class="fw-bold mb-1">First Rent Payment Required</h4>
          <p style="opacity:.85;font-size:.85rem;margin-bottom:0">Please pay your first month's rent to unlock your dashboard</p>
        </div>

        <!-- Property Details -->
        <div class="p-3 rounded-3 mb-3 text-start" style="background:#fff5f5;border:1px solid #fecaca">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <span class="text-muted" style="font-size:.82rem">Property</span>
            <strong style="font-size:.85rem"><?= htmlspecialchars($firstRent['ptitle']) ?></strong>
          </div>
          <div class="d-flex justify-content-between align-items-center mb-2">
            <span class="text-muted" style="font-size:.82rem">Location</span>
            <span style="font-size:.85rem"><?= htmlspecialchars($firstRent['location'] . ', ' . $firstRent['city']) ?></span>
          </div>
          <div class="d-flex justify-content-between align-items-center mb-2">
            <span class="text-muted" style="font-size:.82rem">Rent Period</span>
            <span style="font-size:.85rem"><?= htmlspecialchars($firstRent['payment_month']) ?></span>
          </div>
          <div class="d-flex justify-content-between align-items-center">
            <span class="text-muted" style="font-size:.82rem">Amount Due</span>
            <strong style="font-size:1.1rem;color:#dc3545">₹<?= number_format($firstRent['amount']) ?></strong>
          </div>
        </div>

        <!-- Warning -->
        <div class="alert alert-warning mb-3" style="border-radius:12px;font-size:.8rem;text-align:left">
          <i class="fas fa-exclamation-triangle me-1"></i>
          Your dashboard features are <strong>locked</strong> until you complete your first rent payment. After payment, you'll have full access to all features.
        </div>

        <!-- CTA Button -->
        <a href="rent-payment.php" class="btn btn-lg fw-bold rounded-pill px-5 w-100" style="background:linear-gradient(135deg,#dc3545,#c0392b);color:white;font-size:1rem;padding:14px">
          <i class="fas fa-credit-card me-2"></i>Pay ₹<?= number_format($firstRent['amount']) ?> Now
        </a>
        <p class="text-muted mt-3 mb-0" style="font-size:.75rem">
          Receipt #<?= htmlspecialchars($firstRent['receipt_number']) ?> • Secure payment
        </p>
      </div>
    </div>
  </div>
  <?php else: ?>

  <div class="p-4">

    <!-- Stats Row -->
    <div class="row g-3 mb-4">
      <?php
      $tiles = array(
        array('&#128276;', 'My Alerts',      $acount, 'alerts.php',         '#FF6B35', 'Set property alerts'),
        array('&#128176;', 'Loan Apps',      $loanCount, '../loans.php',    '#2d6a4f', 'Track loan status'),
        array('&#128736;', 'Service Bookings', $svcCount, '../services.php', '#3b82f6', 'Home services booked'),
        array('&#9878;',   'Legal Requests',   $legalCount, '../legal.php', '#6f42c1', 'Legal services applied'),
        array('&#128176;', 'Rent Records',   $pcount, 'rent-payment.php',   '#1a3c5e', 'Generate receipts'),
        array('&#9888;',   'Pending Amount', '₹'.number_format($pendingAmount), 'rent-payment.php', '#dc3545', $pendingCount.' payment(s) pending'),
      );
      foreach ($tiles as $t) {
      ?>
      <div class="col-md-4 col-6">
        <a href="<?php echo $t[3]; ?>" class="text-decoration-none">
          <div class="stat-tile">
            <div class="d-flex justify-content-between align-items-start mb-2">
              <span style="font-size:1.8rem"><?php echo $t[0]; ?></span>
              <span class="fw-bold" style="font-size:1.6rem;color:<?php echo $t[4]; ?>"><?php echo $t[2]; ?></span>
            </div>
            <div class="fw-bold mb-0" style="font-size:.88rem"><?php echo $t[1]; ?></div>
            <div class="text-muted" style="font-size:.73rem"><?php echo $t[5]; ?></div>
          </div>
        </a>
      </div>
      <?php } ?>
    </div>

    <div class="row g-4">

      <!-- Quick Actions -->
      <div class="col-12">
        <div class="db-card">
          <h6><i class="fas fa-bolt text-warning"></i>Quick Actions</h6>
          <div class="row g-2">
            <?php
            $actions = array(
              array('../properties.php?type=buy',  '&#127968;', 'Buy Property',   'Browse sale listings', '#FF6B35'),
              array('../ai-recommend.php',           '&#129302;', 'AI Agent',       'Smart recommendations','#9333ea'),
              array('../properties.php?type=rent', '&#128273;', 'Rent Property',  'Find rental homes',    '#1a3c5e'),
              array('../properties.php?type=pg',   '&#128717;', 'Find PG',        'PG &amp; co-living',   '#6f42c1'),
              array('rent-payment.php',            '&#128196;', 'Rent Receipt',   'Generate PDF receipt', '#2d6a4f'),
              array('../legal.php',                '&#9878;',   'Legal Help',     'Agreements &amp; docs','#dc3545'),
              array('../loans.php',                '&#128176;', 'EMI Calculator', 'Check loan eligibility','#fd7e14'),
              array('../news.php',                 '&#128240;', 'News &amp; Guides','Market insights',    '#17a2b8'),
              array('profile.php',                 '&#128100;', 'My Profile',     'Update your info',     '#495057'),
            );
            foreach ($actions as $l) {
            ?>
            <div class="col-md-3 col-6">
              <a href="<?php echo $l[0]; ?>" class="text-decoration-none">
                <div class="d-flex align-items-center gap-2 p-3 rounded-3 h-100" style="background:var(--section-bg,#f5f7ff);border:1px solid var(--border-color,#eee);transition:.2s"
                     onmouseover="this.style.background='<?php echo $l[4]; ?>22';this.style.borderColor='<?php echo $l[4]; ?>'"
                     onmouseout="this.style.background='var(--section-bg,#f5f7ff)';this.style.borderColor='var(--border-color,#eee)'">
                  <span style="font-size:1.4rem"><?php echo $l[1]; ?></span>
                  <div>
                    <div class="fw-bold" style="font-size:.83rem;color:<?php echo $l[4]; ?>"><?php echo $l[2]; ?></div>
                    <div class="text-muted" style="font-size:.72rem"><?php echo $l[3]; ?></div>
                  </div>
                </div>
              </a>
            </div>
            <?php } ?>
          </div>
        </div>
      </div>

      <!-- Rent Overview Section -->
      <div class="col-12">
        <div class="db-card">
          <h6>
            <i class="fas fa-money-bill-wave text-success"></i>Rent Overview
            <a href="rent-payment.php" class="btn btn-outline-success btn-sm ms-auto rounded-pill px-3" style="font-size:.75rem">Pay Rent</a>
          </h6>

          <!-- Rent Summary Cards -->
          <div class="row g-3 mb-4">
            <div class="col-md-4">
              <div class="p-3 rounded-4 text-white text-center" style="background:linear-gradient(135deg,#dc3545,#c0392b)">
                <div style="font-size:2rem">⚠️</div>
                <div style="font-size:.78rem;opacity:.85">Pending Rent</div>
                <div class="fw-bold" style="font-size:1.4rem">₹<?= number_format($pendingAmount) ?></div>
                <div style="font-size:.7rem;opacity:.7"><?= $pendingCount ?> payment(s) due</div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="p-3 rounded-4 text-white text-center" style="background:linear-gradient(135deg,#10b981,#059669)">
                <div style="font-size:2rem">✅</div>
                <div style="font-size:.78rem;opacity:.85">Total Paid</div>
                <div class="fw-bold" style="font-size:1.4rem">₹<?= number_format($totalPaid) ?></div>
                <div style="font-size:.7rem;opacity:.7">All time rent paid</div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="p-3 rounded-4 text-white text-center" style="background:linear-gradient(135deg,#3b82f6,#2563eb)">
                <div style="font-size:2rem">💳</div>
                <div style="font-size:.78rem;opacity:.85">Total Records</div>
                <div class="fw-bold" style="font-size:1.4rem"><?= $pcount ?></div>
                <div style="font-size:.7rem;opacity:.7">Rent transactions</div>
              </div>
            </div>
          </div>

          <!-- Rent Rates by Property Type -->
          <h6 class="fw-bold mb-3" style="font-size:.88rem">🏠 Monthly Rent by Property Type</h6>
          <div class="table-responsive mb-3">
            <table class="table table-sm align-middle mb-0" style="font-size:.83rem">
              <thead style="background:var(--section-bg,#f5f7ff)">
                <tr>
                  <th>Property Type</th>
                  <th class="text-center">Available</th>
                  <th class="text-end">Min Rent/mo</th>
                  <th class="text-end">Avg Rent/mo</th>
                  <th class="text-end">Max Rent/mo</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $typeIcons = ['apartment'=>'🏢','villa'=>'🏰','home'=>'🏠','commercial'=>'🏬','site'=>'🌿'];
                $typeColors = ['apartment'=>'#3b82f6','villa'=>'#10b981','home'=>'#FF6B35','commercial'=>'#6f42c1','site'=>'#f59e0b'];
                if($rentByType && $rentByType->num_rows > 0):
                  while($rt = $rentByType->fetch_assoc()):
                    $icon = $typeIcons[$rt['type']] ?? '🏠';
                    $color = $typeColors[$rt['type']] ?? '#1a3c5e';
                ?>
                <tr>
                  <td>
                    <span style="font-size:1.1rem"><?= $icon ?></span>
                    <span class="fw-bold ms-1" style="color:<?= $color ?>"><?= ucfirst($rt['type']) ?></span>
                  </td>
                  <td class="text-center">
                    <span class="badge rounded-pill" style="background:<?= $color ?>18;color:<?= $color ?>;font-weight:600"><?= $rt['cnt'] ?> listings</span>
                  </td>
                  <td class="text-end fw-bold" style="color:#10b981">₹<?= number_format((float)$rt['min_price']) ?></td>
                  <td class="text-end fw-bold" style="color:#3b82f6">₹<?= number_format((float)$rt['avg_price']) ?></td>
                  <td class="text-end fw-bold" style="color:#dc3545">₹<?= number_format((float)$rt['max_price']) ?></td>
                </tr>
                <?php endwhile; else: ?>
                <tr><td colspan="5" class="text-center text-muted py-3">No rental properties available</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>

          <!-- Available Rental Properties -->
          <h6 class="fw-bold mb-3" style="font-size:.88rem">🔑 Available Rentals</h6>
          <div class="row g-3">
            <?php if($rentalProps && $rentalProps->num_rows > 0): while($rp = $rentalProps->fetch_assoc()):
              $rpImg = !empty($rp['image_url']) ? $rp['image_url'] : 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=400';
              $rpIcon = $typeIcons[$rp['type']] ?? '🏠';
              $rpColor = $typeColors[$rp['type']] ?? '#1a3c5e';
            ?>
            <div class="col-md-4 col-6">
              <a href="../property-detail.php?id=<?= $rp['id'] ?>" class="text-decoration-none">
                <div class="prop-mini">
                  <img src="<?= $rpImg ?>" alt="Rental">
                  <div class="p-2">
                    <div class="d-flex align-items-center gap-1 mb-1">
                      <span class="badge" style="background:<?= $rpColor ?>;font-size:.6rem"><?= $rpIcon ?> <?= ucfirst($rp['type']) ?></span>
                      <span class="badge bg-primary" style="font-size:.6rem">🔑 Rent</span>
                    </div>
                    <div class="fw-bold" style="font-size:.78rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($rp['title']) ?></div>
                    <div class="text-muted" style="font-size:.7rem"><i class="fas fa-map-marker-alt me-1 text-danger"></i><?= htmlspecialchars($rp['city']) ?></div>
                    <div class="fw-bold" style="font-size:.9rem;color:#FF6B35">₹<?= number_format($rp['price']) ?><small class="text-muted fw-normal">/mo</small></div>
                  </div>
                </div>
              </a>
            </div>
            <?php endwhile; else: ?>
            <div class="col-12 text-center py-3">
              <p class="text-muted small">No rental properties at the moment</p>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Featured Properties -->
      <div class="col-lg-8">
        <div class="db-card">
          <h6>
            <i class="fas fa-star text-warning"></i>Properties For You
            <a href="../properties.php" class="btn btn-outline-primary btn-sm ms-auto rounded-pill px-3" style="font-size:.75rem">View All</a>
          </h6>
          <div class="row g-3">
            <?php
            if ($featProp && $featProp->num_rows > 0) {
                while ($p = $featProp->fetch_assoc()) {
                    $pImg = !empty($p['image_url']) ? $p['image_url'] : 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=400';
            ?>
            <div class="col-md-4">
              <a href="../property-detail.php?id=<?php echo (int)$p['id']; ?>" class="text-decoration-none">
                <div class="prop-mini">
                  <img src="<?php echo $pImg; ?>" alt="Property">
                  <div class="p-2">
                    <div class="fw-bold" style="font-size:.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo htmlspecialchars($p['title']); ?></div>
                    <div class="text-muted" style="font-size:.73rem"><i class="fas fa-map-marker-alt me-1 text-danger"></i><?php echo htmlspecialchars($p['city']); ?></div>
                    <div class="fw-bold text-accent" style="font-size:.88rem"><?php echo formatPrice($p['price']); ?></div>
                  </div>
                </div>
              </a>
            </div>
            <?php
                }
            } else {
            ?>
            <div class="col-12 text-center py-3">
              <p class="text-muted small">No properties available</p>
              <a href="../properties.php" class="btn btn-sm btn-outline-primary rounded-pill">Browse All</a>
            </div>
            <?php } ?>
          </div>
        </div>
      </div>

      <!-- Alerts & Bookings -->
      <div class="col-lg-4">
        <div class="db-card mb-3">
          <h6>
            <i class="fas fa-bell text-warning"></i>My Alerts
            <a href="alerts.php" class="btn btn-accent btn-sm ms-auto rounded-pill px-2" style="font-size:.7rem">+ Add</a>
          </h6>
          <?php
          if ($alerts && $alerts->num_rows > 0) {
              while ($al = $alerts->fetch_assoc()) {
                  $alCity = !empty($al['city']) ? htmlspecialchars($al['city']) : 'Any';
                  $alType = !empty($al['listing_type']) ? htmlspecialchars($al['listing_type']) : 'Any';
          ?>
          <div class="d-flex justify-content-between align-items-center py-2" style="border-bottom:1px solid var(--border-color,#eee)">
            <div style="font-size:.82rem"><i class="fas fa-map-marker-alt me-1 text-danger"></i><?php echo $alCity; ?></div>
            <span class="badge rounded-pill" style="background:#eef;color:#1a3c5e;font-size:.7rem"><?php echo $alType; ?></span>
          </div>
          <?php
              }
          } else {
          ?>
          <div class="text-center py-3">
            <p class="text-muted small mb-2">No alerts set yet</p>
            <a href="alerts.php" class="btn btn-sm btn-outline-primary rounded-pill">Create Alert</a>
          </div>
          <?php } ?>
        </div>

        <div class="db-card">
          <h6><i class="fas fa-file-invoice-dollar text-accent"></i>Loan Applications</h6>
          <?php
          if ($loanApps && $loanApps->num_rows > 0) {
              while ($la = $loanApps->fetch_assoc()) {
                  $laStatus = htmlspecialchars($la['status']);
                  $laClass  = $laStatus==='approved'?'bstatus-completed':($laStatus==='rejected'?'bstatus-confirmed':'bstatus-pending');
          ?>
          <div class="d-flex justify-content-between py-2" style="border-bottom:1px solid var(--border-color,#eee);font-size:.82rem">
            <span><?php echo htmlspecialchars($la['bank_name']); ?> - ₹<?php echo number_format((float)$la['loan_amount']); ?></span>
            <span class="<?php echo $laClass; ?>"><?php echo $laStatus; ?></span>
          </div>
          <?php
              }
          } else {
          ?>
          <div class="text-center py-2">
            <p class="text-muted small mb-1">No loan applications yet</p>
            <a href="../loans.php" class="btn btn-sm btn-outline-success rounded-pill">Apply for Loan</a>
          </div>
          <?php } ?>
        </div>
      </div>

      <!-- Service Bookings -->
      <div class="col-lg-6">
        <div class="db-card">
          <h6>
            <i class="fas fa-tools text-primary"></i>My Service Bookings
            <a href="../services.php" class="btn btn-outline-primary btn-sm ms-auto rounded-pill px-2" style="font-size:.7rem">Book New</a>
          </h6>
          <?php
          if ($svcBookings && $svcBookings->num_rows > 0) {
              while ($sb = $svcBookings->fetch_assoc()) {
                  $sbStatus = htmlspecialchars($sb['status']);
                  $sbColor  = ['pending'=>'#f59e0b','confirmed'=>'#3b82f6','completed'=>'#10b981','cancelled'=>'#ef4444'][$sbStatus] ?? '#6b7280';
                  $sbIcon   = ['pending'=>'⏳','confirmed'=>'✅','completed'=>'🎉','cancelled'=>'❌'][$sbStatus] ?? '📋';
          ?>
          <div class="d-flex justify-content-between align-items-center py-2" style="border-bottom:1px solid var(--border-color,#eee)">
            <div>
              <div class="fw-bold" style="font-size:.83rem"><?php echo htmlspecialchars($sb['sname'] ?? 'Service'); ?></div>
              <div class="text-muted" style="font-size:.72rem"><?php echo $sb['booking_date'] ? date('d M Y', strtotime($sb['booking_date'])) : 'TBD'; ?> · <?php echo htmlspecialchars($sb['time_slot'] ?? ''); ?></div>
            </div>
            <span style="background:<?php echo $sbColor; ?>18;color:<?php echo $sbColor; ?>;padding:3px 10px;border-radius:15px;font-size:.72rem;font-weight:600"><?php echo $sbIcon.' '.ucfirst($sbStatus); ?></span>
          </div>
          <?php
              }
          } else {
          ?>
          <div class="text-center py-3">
            <p class="text-muted small mb-2">No service bookings yet</p>
            <a href="../services.php" class="btn btn-sm btn-outline-primary rounded-pill">Book a Service</a>
          </div>
          <?php } ?>
        </div>
      </div>

      <!-- Legal Bookings -->
      <div class="col-lg-6">
        <div class="db-card">
          <h6>
            <i class="fas fa-gavel" style="color:#6f42c1"></i>My Legal Requests
            <a href="legal-tracking.php" class="btn btn-sm ms-auto rounded-pill px-2" style="font-size:.7rem;background:#6f42c120;color:#6f42c1">Track All</a>
          </h6>
          <?php
          if ($legalBookings && $legalBookings->num_rows > 0) {
              while ($lb = $legalBookings->fetch_assoc()) {
                  $lbStatus = htmlspecialchars($lb['status']);
                  $lbColor  = ['pending'=>'#f59e0b','processing'=>'#3b82f6','completed'=>'#10b981','cancelled'=>'#ef4444'][$lbStatus] ?? '#6b7280';
                  $lbIcon   = ['pending'=>'⏳','processing'=>'🔄','completed'=>'✅','cancelled'=>'❌'][$lbStatus] ?? '📋';
          ?>
          <div class="d-flex justify-content-between align-items-center py-2" style="border-bottom:1px solid var(--border-color,#eee)">
            <div>
              <div class="fw-bold" style="font-size:.83rem"><?php echo htmlspecialchars($lb['lsname'] ?? 'Legal Service'); ?></div>
              <div class="text-muted" style="font-size:.72rem"><?php echo date('d M Y', strtotime($lb['created_at'])); ?></div>
            </div>
            <span style="background:<?php echo $lbColor; ?>18;color:<?php echo $lbColor; ?>;padding:3px 10px;border-radius:15px;font-size:.72rem;font-weight:600"><?php echo $lbIcon.' '.ucfirst($lbStatus); ?></span>
          </div>
          <?php
              }
          } else {
          ?>
          <div class="text-center py-3">
            <p class="text-muted small mb-2">No legal requests yet</p>
            <a href="../legal.php" class="btn btn-sm btn-outline-primary rounded-pill">Get Legal Help</a>
          </div>
          <?php } ?>
        </div>
      </div>

      <!-- News & Guides -->
      <div class="col-12">
        <div class="db-card">
          <h6>
            <i class="fas fa-newspaper text-primary"></i>Latest News &amp; Guides
            <a href="../news.php" class="btn btn-outline-primary btn-sm ms-auto rounded-pill px-3" style="font-size:.75rem">View All</a>
          </h6>
          <div class="row g-3">
            <?php
            if ($news && $news->num_rows > 0) {
                while ($nw = $news->fetch_assoc()) {
                    $nwColor = isset($catColors[$nw['category']]) ? $catColors[$nw['category']] : '#1a3c5e';
                    $nwImg   = !empty($nw['image_url']) ? $nw['image_url'] : 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=400';
            ?>
            <div class="col-md-4">
              <a href="../news-detail.php?slug=<?php echo htmlspecialchars($nw['slug']); ?>" class="text-decoration-none">
                <div class="prop-mini">
                  <img src="<?php echo $nwImg; ?>" style="height:110px" alt="News">
                  <div class="p-2">
                    <span class="badge mb-1" style="background:<?php echo $nwColor; ?>;font-size:.65rem"><?php echo strtoupper($nw['category']); ?></span>
                    <div class="fw-bold" style="font-size:.79rem;line-height:1.3"><?php echo htmlspecialchars(substr($nw['title'], 0, 55)); ?>...</div>
                    <div class="text-muted" style="font-size:.72rem;margin-top:3px"><i class="fas fa-eye me-1"></i><?php echo number_format((int)$nw['views']); ?></div>
                  </div>
                </div>
              </a>
            </div>
            <?php
                }
            } else {
            ?>
            <div class="col-12 text-center py-3">
              <p class="text-muted small">No news articles yet</p>
            </div>
            <?php } ?>
          </div>
        </div>
      </div>

    </div>
  </div>
  <?php endif; ?>
</div><!-- db-main -->
</div><!-- db-wrapper -->

<script>
function toggleDark() {
  var on = document.body.classList.toggle('dark-mode');
  localStorage.setItem('hh_dark', on ? '1' : '0');
  document.getElementById('darkIco').className = on ? 'fas fa-sun' : 'fas fa-moon';
}
function toggleSidebar() {
  var s = document.getElementById('sidebar');
  s.classList.toggle('open');
}
function tick() {
  var now = new Date();
  var el = document.getElementById('liveTime');
  if (el) el.textContent = now.toLocaleDateString('en-IN', {weekday:'long',day:'numeric',month:'long',year:'numeric'}) + ' ' + now.toLocaleTimeString('en-IN', {hour:'2-digit',minute:'2-digit'});
}
tick();
setInterval(tick, 1000);
if (localStorage.getItem('hh_dark') === '1') {
  document.getElementById('darkIco').className = 'fas fa-sun';
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
