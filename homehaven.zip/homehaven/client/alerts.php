<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once '../includes/config.php';
if(!isClientLoggedIn()) redirect(SITE_URL . '/client/login.php');
require_once 'includes/rent-gate.php';
$cid = $_SESSION['client_id'];
$alerts = $conn->query("SELECT * FROM property_alerts WHERE client_id=$cid ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>My Alerts - PropNexus</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="<?= SITE_URL ?>/assets/css/style.css" rel="stylesheet">
</head>
<body style="background:#f5f5f5">
<nav class="navbar navbar-dark sticky-top" id="mainNav" style="background:linear-gradient(135deg,#1a3c5e,#2d6a4f)">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?= SITE_URL ?>"><i class="fas fa-home me-2"></i>PropNexus</a>
    <div>
      <a href="dashboard.php" class="btn btn-outline-light btn-sm me-2">Dashboard</a>
      <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>
  </div>
</nav>
<div class="container py-5">
  <div class="d-flex justify-content-between mb-4">
    <h3 class="fw-bold">🔔 My Property Alerts</h3>
    <a href="<?= SITE_URL ?>/alerts.php" class="btn btn-accent">+ New Alert</a>
  </div>
  <?php if($alerts->num_rows == 0): ?>
  <div class="text-center py-5 admin-card">
    <i class="fas fa-bell fa-4x text-muted mb-3"></i>
    <h5 class="text-muted">No alerts set yet</h5>
    <a href="<?= SITE_URL ?>/alerts.php" class="btn btn-accent mt-3">Set Your First Alert</a>
  </div>
  <?php else: ?>
  <div class="row g-3">
    <?php while($a = $alerts->fetch_assoc()): ?>
    <div class="col-md-6">
      <div class="admin-card">
        <div class="d-flex justify-content-between">
          <span class="fw-bold"><?= $a['property_type'] ?: 'Any Type' ?> - <?= ucfirst($a['listing_type'] ?: 'Any') ?></span>
          <span class="badge bg-success">Active</span>
        </div>
        <p class="mb-1"><i class="fas fa-map-marker-alt me-1 text-danger"></i><?= $a['city'] ?: 'Any City' ?></p>
        <p class="mb-1 text-muted">Budget: ₹<?= number_format($a['min_budget']) ?> - ₹<?= number_format($a['max_budget']) ?></p>
        <?php if($a['min_bedrooms']): ?><p class="mb-1 text-muted">Min <?= $a['min_bedrooms'] ?> Bedrooms</p><?php endif; ?>
        <small class="text-muted">Set on: <?= date('d M Y', strtotime($a['created_at'])) ?></small>
      </div>
    </div>
    <?php endwhile; ?>
  </div>
  <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
