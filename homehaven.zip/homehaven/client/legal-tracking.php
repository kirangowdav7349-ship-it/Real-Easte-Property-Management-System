<?php
$pageTitle = 'Legal Service Tracking';
require_once '../includes/header.php';
if(!isClientLoggedIn()) redirect(SITE_URL . '/client/login.php');
$cid = (int)$_SESSION['client_id'];

// Fetch all legal bookings for this client
$bookings = $conn->query("SELECT lb.*, ls.name as service_name, ls.price as service_price, ls.description as service_desc 
  FROM legal_bookings lb 
  LEFT JOIN legal_services ls ON lb.service_id = ls.id 
  WHERE lb.client_id = $cid 
  ORDER BY lb.created_at DESC");

$totalBookings = $bookings ? $bookings->num_rows : 0;

// Stats
$pendingCount    = (int)$conn->query("SELECT COUNT(*) as c FROM legal_bookings WHERE client_id=$cid AND status='pending'")->fetch_assoc()['c'];
$reviewCount     = (int)$conn->query("SELECT COUNT(*) as c FROM legal_bookings WHERE client_id=$cid AND status='under_review'")->fetch_assoc()['c'];
$verifiedCount   = (int)$conn->query("SELECT COUNT(*) as c FROM legal_bookings WHERE client_id=$cid AND status='verified'")->fetch_assoc()['c'];
$completedCount  = (int)$conn->query("SELECT COUNT(*) as c FROM legal_bookings WHERE client_id=$cid AND status='completed'")->fetch_assoc()['c'];
$cancelledCount  = (int)$conn->query("SELECT COUNT(*) as c FROM legal_bookings WHERE client_id=$cid AND status='cancelled'")->fetch_assoc()['c'];
$processingTotal = $reviewCount + $verifiedCount;
?>

<style>
.legal-hero{background:linear-gradient(135deg,#1a3c5e 0%,#6f42c1 100%);color:white;padding:50px 0 30px;position:relative;overflow:hidden}
.legal-hero::before{content:'';position:absolute;top:-60%;right:-20%;width:60%;height:200%;background:radial-gradient(circle,rgba(111,66,193,.25) 0%,transparent 60%);animation:legalOrb 10s ease-in-out infinite alternate;z-index:0;pointer-events:none}
.legal-hero .container{position:relative;z-index:1}
@keyframes legalOrb{0%{transform:translate(0,0)}100%{transform:translate(20px,-15px)}}
.legal-stat-card{background:var(--card-bg,#fff);border-radius:16px;padding:20px;box-shadow:0 4px 18px rgba(0,0,0,.07);border:1px solid var(--border-color,#eee);transition:.3s;text-align:center}
.legal-stat-card:hover{transform:translateY(-4px);box-shadow:0 10px 30px rgba(0,0,0,.13)}
.legal-stat-card .stat-num{font-size:2rem;font-weight:800;line-height:1}
.legal-stat-card .stat-label{font-size:.78rem;color:var(--text-muted,#666);margin-top:4px}
.booking-card{background:var(--card-bg,#fff);border-radius:16px;border:1px solid var(--border-color,#eee);overflow:hidden;box-shadow:0 4px 18px rgba(0,0,0,.06);transition:.3s;margin-bottom:16px}
.booking-card:hover{box-shadow:0 8px 30px rgba(0,0,0,.12);transform:translateY(-2px)}
.booking-header{padding:18px 22px;border-bottom:1px solid var(--border-color,#eee);display:flex;justify-content:space-between;align-items:center}
.booking-body{padding:18px 22px}
.booking-footer{padding:14px 22px;border-top:1px solid var(--border-color,#eee);background:var(--section-bg,#f9fafb);display:flex;justify-content:space-between;align-items:center}
.status-badge{padding:5px 14px;border-radius:20px;font-size:.72rem;font-weight:700;display:inline-flex;align-items:center;gap:5px}
.status-pending{background:#fff3cd;color:#856404}
.status-under_review{background:#cce5ff;color:#004085}
.status-verified{background:#e8daef;color:#6f42c1}
.status-completed{background:#d4edda;color:#155724}
.status-cancelled{background:#f8d7da;color:#721c24}
.booking-id{font-family:monospace;font-size:.75rem;background:var(--section-bg,#f0f2f5);padding:3px 10px;border-radius:6px;color:var(--text-muted,#666)}

/* 3-Step Progress Bar */
.client-step-bar{display:flex;align-items:flex-start;gap:0;padding:16px 8px;background:var(--section-bg,#f8fafc);border-radius:12px;border:1px solid var(--border-color,#eee)}
.cs-item{display:flex;flex-direction:column;align-items:center;position:relative;flex:1;min-width:80px}
.cs-dot{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.75rem;font-weight:700;z-index:2;transition:all .3s;border:3px solid var(--border-color,#ddd);background:var(--card-bg,#fff);color:var(--text-muted,#999)}
.cs-item.done .cs-dot{background:var(--sc,#10b981);border-color:var(--sc,#10b981);color:#fff}
.cs-item.active .cs-dot{background:#fff;border-color:var(--sc,#3b82f6);color:var(--sc,#3b82f6);box-shadow:0 0 0 4px rgba(59,130,246,.2);animation:csPulse 2s infinite}
.cs-item.cancelled .cs-dot{background:#ef4444;border-color:#ef4444;color:#fff}
@keyframes csPulse{0%,100%{box-shadow:0 0 0 4px rgba(59,130,246,.2)}50%{box-shadow:0 0 0 8px rgba(59,130,246,.1)}}
.cs-line{position:absolute;top:18px;left:calc(50% + 18px);right:calc(-50% + 18px);height:3px;background:var(--border-color,#ddd);z-index:1}
.cs-line.done{background:linear-gradient(90deg,#10b981,#3b82f6)}
.cs-label{text-align:center;margin-top:8px}
.cs-title{font-size:.72rem;font-weight:700;color:var(--text-main,#333)}
.cs-item.waiting .cs-title{color:var(--text-muted,#999)}
.cs-desc{font-size:.65rem;color:var(--text-muted,#999)}
.cs-time{font-size:.62rem;color:#10b981;font-weight:600;margin-top:2px}
.cs-item.cancelled .cs-title,.cs-item.cancelled .cs-desc{color:#ef4444}

body.dark .booking-card{background:var(--card-bg);border-color:var(--border)}
body.dark .booking-footer{background:rgba(255,255,255,.03)}
body.dark .legal-stat-card{background:var(--card-bg);border-color:var(--border)}
body.dark .client-step-bar{background:rgba(255,255,255,.03);border-color:var(--border)}
</style>

<!-- Hero Section -->
<div class="legal-hero">
  <div class="container">
    <nav aria-label="breadcrumb" class="mb-3">
      <ol class="breadcrumb mb-0">
        <li class="breadcrumb-item"><a href="<?= SITE_URL ?>" class="text-white-50">Home</a></li>
        <li class="breadcrumb-item"><a href="dashboard.php" class="text-white-50">Dashboard</a></li>
        <li class="breadcrumb-item active text-white">Legal Tracking</li>
      </ol>
    </nav>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
      <div>
        <h3 class="fw-bold mb-1"><i class="fas fa-gavel me-2"></i>Legal Service Tracking</h3>
        <p class="mb-0" style="opacity:.8;font-size:.9rem">Track all your legal service requests — 3-step approval process</p>
      </div>
      <a href="../legal.php" class="btn btn-light fw-bold px-4 rounded-pill">
        <i class="fas fa-plus me-1"></i>Request New Service
      </a>
    </div>
  </div>
</div>

<div class="container py-5">

  <!-- Approval Flow Explainer -->
  <div class="p-3 mb-4 rounded-3 text-center" style="background:var(--card-bg,#fff);border:1px dashed var(--border-color,#ddd);box-shadow:0 2px 10px rgba(0,0,0,.04)">
    <small class="text-muted fw-bold d-block mb-2" style="letter-spacing:1px;font-size:.7rem">APPROVAL PROCESS</small>
    <div class="d-flex align-items-center gap-3 flex-wrap justify-content-center">
      <?php
      $explSteps = [
        ['Step 1','Submitted & Under Review','fa-search','#f59e0b'],
        ['Step 2','Document Verification','fa-clipboard-check','#8b5cf6'],
        ['Step 3','Approved & Completed','fa-check-double','#10b981'],
      ];
      foreach($explSteps as $ei => $es): ?>
      <div class="d-flex align-items-center gap-2">
        <div style="width:28px;height:28px;border-radius:50%;background:<?=$es[3]?>15;color:<?=$es[3]?>;display:flex;align-items:center;justify-content:center;font-size:.7rem;border:2px solid <?=$es[3]?>">
          <i class="fas <?=$es[2]?>"></i>
        </div>
        <div style="text-align:left">
          <div class="fw-bold" style="font-size:.68rem;color:<?=$es[3]?>"><?=$es[0]?></div>
          <div style="font-size:.65rem;color:var(--text-muted)"><?=$es[1]?></div>
        </div>
      </div>
      <?php if($ei < 2): ?>
      <i class="fas fa-chevron-right" style="color:var(--text-muted);opacity:.3;font-size:.65rem"></i>
      <?php endif; ?>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Stats Row -->
  <div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
      <div class="legal-stat-card">
        <div class="stat-num" style="color:#856404"><?= $pendingCount ?></div>
        <div class="stat-label"><i class="fas fa-clock me-1"></i>Pending</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="legal-stat-card">
        <div class="stat-num" style="color:#004085"><?= $processingTotal ?></div>
        <div class="stat-label"><i class="fas fa-spinner me-1"></i>In Progress</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="legal-stat-card">
        <div class="stat-num" style="color:#155724"><?= $completedCount ?></div>
        <div class="stat-label"><i class="fas fa-check-circle me-1"></i>Completed</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="legal-stat-card">
        <div class="stat-num" style="color:#721c24"><?= $cancelledCount ?></div>
        <div class="stat-label"><i class="fas fa-times-circle me-1"></i>Cancelled</div>
      </div>
    </div>
  </div>

  <?php if($totalBookings == 0): ?>
  <!-- Empty State -->
  <div class="text-center py-5">
    <div style="font-size:5rem;margin-bottom:16px">⚖️</div>
    <h4 class="fw-bold">No Legal Requests Yet</h4>
    <p class="text-muted" style="max-width:400px;margin:0 auto">You haven't requested any legal services. Start by choosing a service below.</p>
    <a href="../legal.php" class="btn btn-accent rounded-pill px-5 mt-3 fw-bold">
      <i class="fas fa-gavel me-2"></i>Browse Legal Services
    </a>
  </div>

  <?php else: ?>
  <!-- Filter Tabs -->
  <ul class="nav nav-pills mb-4 gap-2 flex-wrap" id="legalFilterTabs">
    <li class="nav-item">
      <button class="nav-link active rounded-pill px-4 fw-bold" data-filter="all" onclick="filterBookings('all',this)">
        All <span class="badge bg-white text-dark ms-1"><?= $totalBookings ?></span>
      </button>
    </li>
    <?php if($pendingCount): ?>
    <li class="nav-item">
      <button class="nav-link rounded-pill px-4" data-filter="pending" onclick="filterBookings('pending',this)" style="background:#fff3cd;color:#856404">
        ⏳ Pending <span class="badge bg-white text-dark ms-1"><?= $pendingCount ?></span>
      </button>
    </li>
    <?php endif; ?>
    <?php if($processingTotal): ?>
    <li class="nav-item">
      <button class="nav-link rounded-pill px-4" data-filter="processing" onclick="filterBookings('processing',this)" style="background:#cce5ff;color:#004085">
        🔄 In Progress <span class="badge bg-white text-dark ms-1"><?= $processingTotal ?></span>
      </button>
    </li>
    <?php endif; ?>
    <?php if($completedCount): ?>
    <li class="nav-item">
      <button class="nav-link rounded-pill px-4" data-filter="completed" onclick="filterBookings('completed',this)" style="background:#d4edda;color:#155724">
        ✅ Completed <span class="badge bg-white text-dark ms-1"><?= $completedCount ?></span>
      </button>
    </li>
    <?php endif; ?>
  </ul>

  <!-- Bookings List -->
  <div id="bookingsList">
    <?php
    $stepFlow = ['pending','under_review','verified','completed'];
    while($b = $bookings->fetch_assoc()):
      $statusClass = 'status-' . $b['status'];
      $statusIcon = ['pending'=>'⏳','under_review'=>'🔍','verified'=>'✅','completed'=>'🎉','cancelled'=>'❌'][$b['status']] ?? '📋';
      $statusLabel = ['pending'=>'Pending','under_review'=>'Under Review','verified'=>'Verified','completed'=>'Completed','cancelled'=>'Cancelled'][$b['status']] ?? ucfirst($b['status']);
      $serviceIcons = ['Rental Agreement'=>'fa-file-contract','Tenant Verification'=>'fa-user-check','Sale Agreement'=>'fa-handshake','Property Legal Check'=>'fa-gavel'];
      $serviceIcon = $serviceIcons[$b['service_name']] ?? 'fa-file-contract';
      $serviceColors = ['Rental Agreement'=>'#FF6B35','Tenant Verification'=>'#1a3c5e','Sale Agreement'=>'#2d6a4f','Property Legal Check'=>'#6f42c1'];
      $sColor = $serviceColors[$b['service_name']] ?? '#6f42c1';
      $bIdx = array_search($b['status'], $stepFlow);
      $isCancelled = ($b['status'] === 'cancelled');
      $filterGroup = in_array($b['status'], ['under_review','verified']) ? 'processing' : $b['status'];
    ?>
    <div class="booking-card" data-status="<?= $filterGroup ?>">
      <div class="booking-header">
        <div class="d-flex align-items-center gap-3">
          <div style="width:44px;height:44px;background:<?= $sColor ?>18;color:<?= $sColor ?>;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.1rem">
            <i class="fas <?= $serviceIcon ?>"></i>
          </div>
          <div>
            <h6 class="fw-bold mb-0"><?= htmlspecialchars($b['service_name'] ?? 'Legal Service') ?></h6>
            <span class="booking-id">ID: #LGL<?= str_pad($b['id'], 4, '0', STR_PAD_LEFT) ?></span>
          </div>
        </div>
        <span class="status-badge <?= $statusClass ?>">
          <?= $statusIcon ?> <?= $statusLabel ?>
        </span>
      </div>

      <div class="booking-body">
        <div class="row g-3">
          <!-- Info -->
          <div class="col-md-5">
            <div class="mb-2">
              <small class="text-muted d-block" style="font-size:.72rem">Applicant</small>
              <span class="fw-bold" style="font-size:.88rem"><i class="fas fa-user me-1" style="color:<?= $sColor ?>"></i><?= htmlspecialchars($b['name']) ?></span>
            </div>
            <div class="mb-2">
              <small class="text-muted d-block" style="font-size:.72rem">Contact</small>
              <span style="font-size:.85rem"><i class="fas fa-phone me-1 text-muted"></i><?= htmlspecialchars($b['phone']) ?> &nbsp; <i class="fas fa-envelope me-1 text-muted"></i><?= htmlspecialchars($b['email']) ?></span>
            </div>
            <?php if(!empty($b['notes'])): ?>
            <div class="mb-2">
              <small class="text-muted d-block" style="font-size:.72rem">Notes</small>
              <span style="font-size:.83rem"><?= htmlspecialchars(substr($b['notes'], 0, 120)) ?><?= strlen($b['notes']) > 120 ? '...' : '' ?></span>
            </div>
            <?php endif; ?>
            <?php if(!empty($b['admin_remarks'])): ?>
            <div>
              <small class="text-muted d-block" style="font-size:.72rem">Admin Remarks</small>
              <span style="font-size:.83rem;color:#6f42c1;font-weight:600"><?= htmlspecialchars($b['admin_remarks']) ?></span>
            </div>
            <?php endif; ?>
          </div>

          <!-- 3-Step Progress -->
          <div class="col-md-7">
            <small class="text-muted fw-bold d-block mb-2" style="font-size:.72rem;letter-spacing:1px">3-STEP APPROVAL PROGRESS</small>
            <?php if($isCancelled): ?>
            <div class="d-flex align-items-center gap-2 p-3 rounded-3" style="background:#f8d7da">
              <span style="font-size:1.5rem">❌</span>
              <div>
                <div class="fw-bold" style="color:#721c24;font-size:.88rem">Request Cancelled</div>
                <small class="text-muted">This request has been cancelled by admin</small>
              </div>
            </div>
            <?php else: ?>
            <div class="client-step-bar">
              <?php
              $clientSteps = [
                ['Submitted',     'Request received',    'fa-paper-plane',    '#f59e0b', 0],
                ['Under Review',  'Admin reviewing',     'fa-search',         '#3b82f6', 1],
                ['Verified',      'Documents verified',  'fa-clipboard-check','#8b5cf6', 2],
                ['Completed',     'Approved & ready',    'fa-check-double',   '#10b981', 3],
              ];
              foreach($clientSteps as $ci => $cs):
                $cStepColor = $cs[3];
                if ($bIdx !== false && $ci < $bIdx) $cState = 'done';
                elseif ($bIdx !== false && $ci == $bIdx) $cState = ($b['status'] === 'completed') ? 'done' : 'active';
                else $cState = 'waiting';
                $cTime = '';
                if ($ci == 0 && !empty($b['created_at'])) $cTime = date('d M, H:i', strtotime($b['created_at']));
                if ($ci == 1 && !empty($b['reviewed_at'])) $cTime = date('d M, H:i', strtotime($b['reviewed_at']));
                if ($ci == 2 && !empty($b['verified_at'])) $cTime = date('d M, H:i', strtotime($b['verified_at']));
                if ($ci == 3 && !empty($b['completed_at'])) $cTime = date('d M, H:i', strtotime($b['completed_at']));
              ?>
              <div class="cs-item <?=$cState?>" style="--sc:<?=$cStepColor?>">
                <div class="cs-dot" style="--sc:<?=$cStepColor?>">
                  <?php if($cState === 'done'): ?>
                    <i class="fas fa-check"></i>
                  <?php elseif($cState === 'active'): ?>
                    <i class="fas <?=$cs[2]?>"></i>
                  <?php else: ?>
                    <span><?=$ci+1?></span>
                  <?php endif; ?>
                </div>
                <?php if($ci < 3): ?>
                <div class="cs-line <?=$cState === 'done' ? 'done' : ''?>"></div>
                <?php endif; ?>
                <div class="cs-label">
                  <div class="cs-title"><?=$cs[0]?></div>
                  <div class="cs-desc"><?=$cs[1]?></div>
                  <?php if($cTime): ?>
                  <div class="cs-time"><i class="far fa-clock"></i> <?=$cTime?></div>
                  <?php endif; ?>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="booking-footer">
        <div class="d-flex align-items-center gap-2">
          <i class="fas fa-calendar-alt text-muted" style="font-size:.8rem"></i>
          <small class="text-muted"><?= date('d M Y, h:i A', strtotime($b['created_at'])) ?></small>
        </div>
        <div class="d-flex align-items-center gap-2">
          <?php if(!empty($b['service_price'])): ?>
          <span class="fw-bold" style="color:<?= $sColor ?>;font-size:.95rem">₹<?= number_format((float)$b['service_price']) ?></span>
          <?php endif; ?>
          <?php if($b['status'] === 'completed'): ?>
          <span class="badge bg-success rounded-pill px-3"><i class="fas fa-download me-1"></i>Ready</span>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endwhile; ?>
  </div>
  <?php endif; ?>

</div>

<script>
function filterBookings(status, btn) {
  document.querySelectorAll('#legalFilterTabs .nav-link').forEach(function(t) { t.classList.remove('active'); });
  btn.classList.add('active');
  document.querySelectorAll('.booking-card').forEach(function(card) {
    if (status === 'all' || card.dataset.status === status) {
      card.style.display = 'block';
      card.style.animation = 'fadeIn .3s ease';
    } else {
      card.style.display = 'none';
    }
  });
}
</script>

<?php require_once '../includes/footer.php'; ?>
