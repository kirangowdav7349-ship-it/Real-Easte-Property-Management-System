<?php
/**
 * Rent Gate — blocks client access to all pages until first rent is paid.
 * Include this file AFTER session/auth check on every client page EXCEPT:
 *   - rent-payment.php (so they can actually pay)
 *   - login.php / logout.php / register.php (auth pages)
 */
if(!empty($_SESSION['client_id'])) {
  $__cid = (int)$_SESSION['client_id'];
  $__rentCheck = $conn->query("SELECT rp.id, rp.amount, rp.payment_month, rp.receipt_number, p.title as ptitle
    FROM rent_payments rp 
    JOIN properties p ON rp.property_id = p.id
    WHERE rp.client_id = $__cid AND rp.status = 'pending' 
    AND rp.id = (SELECT MIN(r2.id) FROM rent_payments r2 WHERE r2.client_id = $__cid AND r2.property_id = rp.property_id)
    LIMIT 1");
  if($__rentCheck && $__rentCheck->num_rows > 0) {
    $__rent = $__rentCheck->fetch_assoc();
    // Redirect to rent-payment page with a blocker flag
    header("Location: " . SITE_URL . "/client/rent-payment.php?pay_first=1");
    exit();
  }
}
?>
