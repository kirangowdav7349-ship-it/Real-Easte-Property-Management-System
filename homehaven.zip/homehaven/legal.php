<?php
$pageTitle = 'Legal Services';
require_once 'includes/header.php';
$legal = $conn->query("SELECT * FROM legal_services WHERE status='active'");
$legalArr = [];
while($l = $legal->fetch_assoc()) $legalArr[] = $l;

// Handle legal service request
$legalMsg = '';
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['legal_service_id'])) {
    $sid   = (int)$_POST['legal_service_id'];
    $lname = sanitize($_POST['full_name']);
    $lph   = sanitize($_POST['phone']);
    $lem   = sanitize($_POST['email']);
    $ladr  = sanitize($_POST['address'] ?? '');
    $lmsg  = sanitize($_POST['message'] ?? '');
    $cid   = (!empty($_SESSION['client_id'])) ? (int)$_SESSION['client_id'] : 'NULL';
    $conn->query("INSERT INTO legal_bookings (client_id,service_id,name,phone,email,notes,status) VALUES($cid,$sid,'$lname','$lph','$lem','Address: $ladr | Notes: $lmsg','pending')");
    $legalMsg = '<div class="alert alert-success alert-dismissible fade show">
        ✅ <strong>Request submitted!</strong> Our legal expert will contact you within 2 business hours.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
}

// Decoration arrays — cycle safely with modulo for any number of services
$limgs = [
  'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=700',
  'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=700',
  'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=700',
  'https://images.unsplash.com/photo-1593115057322-e94b77572f20?w=700',
];
$licons  = ['fa-file-contract','fa-user-check','fa-handshake','fa-gavel'];
$lcolors = ['#FF6B35','#1a3c5e','#2d6a4f','#6f42c1'];
$lbadges = ['MOST POPULAR','QUICK','ESSENTIAL','COMPLETE'];
$ltime   = ['24 hrs','48 hrs','3-5 days','5-7 days'];
$lrating = ['4.9','4.8','4.9','4.7'];
$lcnt    = count($lcolors); // for safe modulo cycling
?>

<div class="page-banner">
  <div class="container text-center">
    <h2 class="fw-bold mb-2">⚖️ Legal Services</h2>
    <p class="opacity-75 mb-0">100% legally valid documents · Expert lawyers · Doorstep service</p>
  </div>
</div>

<section class="py-5">
  <div class="container">
    <?= $legalMsg ?>

    <!-- Legal Service Cards -->
    <div class="row g-4 mb-5">
      <?php foreach($legalArr as $li => $l):
        $ci = $li % $lcnt; // cycle index — prevents undefined key errors
        $useImg   = !empty($l['image_url']) ? $l['image_url'] : $limgs[$ci];
        $useTurn  = !empty($l['turnaround']) ? $l['turnaround'] : $ltime[$ci];
      ?>
      <div class="col-lg-6">
        <div class="bg-white rounded-4 shadow-sm overflow-hidden h-100" style="border:2px solid transparent;transition:0.3s"
             onmouseover="this.style.borderColor='<?= $lcolors[$ci] ?>'" onmouseout="this.style.borderColor='transparent'">
          <div class="row g-0 h-100">
            <div class="col-4" style="position:relative;min-height:200px">
              <img src="<?= $useImg ?>" style="width:100%;height:100%;object-fit:cover" alt="<?= htmlspecialchars($l['name']) ?>"
                   onerror="this.src='<?= $limgs[$ci] ?>'">
              <div style="position:absolute;top:12px;left:12px;background:<?= $lcolors[$ci] ?>;color:white;padding:3px 10px;border-radius:12px;font-size:0.7rem;font-weight:700">
                <?= $lbadges[$ci] ?>
              </div>
            </div>
            <div class="col-8 p-4 d-flex flex-column justify-content-between">
              <div>
                <div class="d-flex align-items-center mb-2">
                  <div style="width:40px;height:40px;background:<?= $lcolors[$ci] ?>20;color:<?= $lcolors[$ci] ?>;border-radius:10px;display:flex;align-items:center;justify-content:center;margin-right:12px">
                    <i class="fas <?= $licons[$ci] ?>"></i>
                  </div>
                  <h5 class="fw-bold mb-0"><?= htmlspecialchars($l['name']) ?></h5>
                </div>
                <p class="text-muted small mb-3"><?= htmlspecialchars($l['description']) ?></p>
                <div class="d-flex gap-3 mb-3 flex-wrap">
                  <span class="badge" style="background:<?= $lcolors[$ci] ?>20;color:<?= $lcolors[$ci] ?>;padding:6px 12px;border-radius:20px">
                    <i class="fas fa-clock me-1"></i><?= htmlspecialchars($useTurn) ?> delivery
                  </span>
                  <span class="badge bg-warning text-dark" style="padding:6px 12px;border-radius:20px">
                    ⭐ <?= $lrating[$ci] ?> rating
                  </span>
                </div>
              </div>
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <div class="fw-bold fs-5" style="color:<?= $lcolors[$ci] ?>">₹<?= number_format($l['price']) ?></div>
                  <small class="text-muted">All inclusive</small>
                </div>
                <button class="btn fw-bold px-3" style="background:<?= $lcolors[$ci] ?>;color:white;border-radius:25px"
                  data-bs-toggle="modal" data-bs-target="#legalModal<?= $l['id'] ?>">
                  Get Started <i class="fas fa-arrow-right ms-1"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Service Modal -->
      <div class="modal fade" id="legalModal<?= $l['id'] ?>" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0" style="background:<?= $lcolors[$ci] ?>;color:white;border-radius:16px 16px 0 0">
              <h5 class="modal-title fw-bold">
                <i class="fas <?= $licons[$ci] ?> me-2"></i><?= htmlspecialchars($l['name']) ?>
              </h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
              <div class="modal-body p-4">
                <div class="alert" style="background:<?= $lcolors[$ci] ?>15;border:1px solid <?= $lcolors[$ci] ?>40;border-radius:12px">
                  <strong><?= htmlspecialchars($l['name']) ?></strong> — ₹<?= number_format($l['price']) ?> · <?= htmlspecialchars($useTurn) ?> delivery
                </div>
                <input type="hidden" name="legal_service_id" value="<?= $l['id'] ?>">
                <div class="row g-3">
                  <div class="col-12">
                    <label class="fw-bold small">Full Name</label>
                    <input type="text" name="full_name" class="form-control" placeholder="Your full name" required value="<?= $_SESSION['client_name'] ?? '' ?>">
                  </div>
                  <div class="col-6">
                    <label class="fw-bold small">Phone</label>
                    <input type="text" name="phone" class="form-control" placeholder="+91 XXXXX XXXXX" required>
                  </div>
                  <div class="col-6">
                    <label class="fw-bold small">Email</label>
                    <input type="email" name="email" class="form-control" placeholder="your@email.com" required value="<?= $_SESSION['client_email'] ?? '' ?>">
                  </div>
                  <div class="col-12">
                    <label class="fw-bold small">Property Address</label>
                    <input type="text" name="address" class="form-control" placeholder="Full property address">
                  </div>
                  <div class="col-12">
                    <label class="fw-bold small">Additional Details</label>
                    <textarea name="message" class="form-control" rows="3" placeholder="Any specific requirements or details..."></textarea>
                  </div>
                </div>
              </div>
              <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn fw-bold px-5" style="background:<?= $lcolors[$ci] ?>;color:white;border-radius:25px">
                  Submit Request
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- How It Works -->
    <div class="text-center mb-4">
      <h4 class="section-title">How It Works</h4>
      <p class="text-muted">Simple 4-step process to get your legal documents</p>
    </div>
    <div class="row g-4 text-center mb-5">
      <?php
      $steps = [
        ['1','Choose Service','Pick the legal service you need','fa-mouse-pointer','#FF6B35'],
        ['2','Fill Details','Submit your info via our secure form','fa-edit','#1a3c5e'],
        ['3','Expert Review','Our lawyers verify and draft documents','fa-user-tie','#2d6a4f'],
        ['4','Get Documents','Receive stamped legal docs online','fa-file-download','#6f42c1'],
      ];
      foreach($steps as $s): ?>
      <div class="col-md-3 col-6">
        <div class="bg-white p-4 rounded-4 shadow-sm h-100 position-relative">
          <div style="width:55px;height:55px;background:<?= $s[4] ?>;color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.4rem;font-weight:800;margin:0 auto 15px">
            <?= $s[0] ?>
          </div>
          <i class="fas <?= $s[3] ?> fa-2x mb-3" style="color:<?= $s[4] ?>"></i>
          <h6 class="fw-bold"><?= $s[1] ?></h6>
          <p class="text-muted small mb-0"><?= $s[2] ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Trust Badges -->
    <div class="row g-3 text-center">
      <?php $badges = [
        ['fa-shield-alt','100% Legal','All documents are court-admissible','#FF6B35'],
        ['fa-lock','Secure & Private','Your data is fully encrypted','#1a3c5e'],
        ['fa-certificate','Govt Registered','Documents registered with authorities','#2d6a4f'],
        ['fa-star','4.9/5 Rating','Trusted by 10,000+ customers','#6f42c1'],
      ];
      foreach($badges as $b): ?>
      <div class="col-md-3 col-6">
        <div class="bg-white p-3 rounded-4 shadow-sm">
          <i class="fas <?= $b[0] ?> fa-2x mb-2" style="color:<?= $b[3] ?>"></i>
          <div class="fw-bold small"><?= $b[1] ?></div>
          <div class="text-muted" style="font-size:0.78rem"><?= $b[2] ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
