-- PropNexus Database
-- Import instructions (phpMyAdmin):
--   1. Go to http://localhost/phpmyadmin
--   2. Click "New" in left sidebar -> Type database name: homehaven_db -> Click "Create"
--   3. Select "homehaven_db" from left sidebar
--   4. Click "Import" tab -> Choose this file -> Click "Go"

SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS admins (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100) NOT NULL DEFAULT 'Admin',
    email      VARCHAR(100) UNIQUE NOT NULL,
    password   VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 2. CLIENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS clients (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(100) UNIQUE NOT NULL,
    phone       VARCHAR(15),
    password    VARCHAR(255) NOT NULL,
    profile_pic VARCHAR(255) DEFAULT 'default.png',
    status      ENUM('active','inactive') DEFAULT 'active',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 3. PROPERTIES
-- ============================================================
CREATE TABLE IF NOT EXISTS properties (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    title        VARCHAR(200) NOT NULL,
    description  TEXT,
    type         VARCHAR(50) DEFAULT 'apartment',
    listing_type VARCHAR(50) DEFAULT 'rent',
    price        DECIMAL(15,2) NOT NULL DEFAULT 0,
    area         VARCHAR(50),
    bedrooms     INT DEFAULT 0,
    bathrooms    INT DEFAULT 0,
    location     VARCHAR(200),
    city         VARCHAR(100),
    state        VARCHAR(100),
    pincode      VARCHAR(10),
    amenities    TEXT,
    featured     TINYINT(1) DEFAULT 0,
    views        INT DEFAULT 0,
    status       ENUM('available','sold','rented') DEFAULT 'available',
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 4. PROPERTY IMAGES
-- ============================================================
CREATE TABLE IF NOT EXISTS property_images (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    property_id INT NOT NULL,
    image_url   VARCHAR(600) NOT NULL,
    image_type  VARCHAR(50) DEFAULT 'exterior',
    is_primary  TINYINT(1) DEFAULT 0,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
);

-- ============================================================
-- 5. SERVICES
-- ============================================================
CREATE TABLE IF NOT EXISTS services (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    category    VARCHAR(100),
    description TEXT,
    price_range VARCHAR(50),
    image_url   VARCHAR(600),
    status      ENUM('active','inactive') DEFAULT 'active'
);

-- ============================================================
-- 6. LEGAL SERVICES
-- ============================================================
CREATE TABLE IF NOT EXISTS legal_services (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    price       DECIMAL(10,2),
    image_url   VARCHAR(600),
    status      ENUM('active','inactive') DEFAULT 'active'
);

-- ============================================================
-- 6b. LEGAL BOOKINGS
-- ============================================================
CREATE TABLE IF NOT EXISTS legal_bookings (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    client_id   INT DEFAULT NULL,
    service_id  INT DEFAULT NULL,
    name        VARCHAR(100),
    phone       VARCHAR(15),
    email       VARCHAR(100),
    notes       TEXT,
    status      ENUM('pending','processing','completed','cancelled') DEFAULT 'pending',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 7. LOAN SERVICES
-- ============================================================
CREATE TABLE IF NOT EXISTS loan_services (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    bank_name     VARCHAR(100) NOT NULL,
    loan_type     VARCHAR(100),
    interest_rate DECIMAL(5,2),
    max_amount    DECIMAL(15,2),
    tenure_years  INT,
    description   TEXT,
    logo_url      VARCHAR(600)
);

-- ============================================================
-- 8. PLANS
-- ============================================================
CREATE TABLE IF NOT EXISTS plans (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    name             VARCHAR(100) NOT NULL,
    plan_type        ENUM('residential','commercial') DEFAULT 'residential',
    price            DECIMAL(10,2) NOT NULL,
    duration_days    INT DEFAULT 30,
    listings_allowed INT DEFAULT 1,
    features         TEXT,
    is_popular       TINYINT(1) DEFAULT 0
);

-- ============================================================
-- 9. PROPERTY ALERTS
-- ============================================================
CREATE TABLE IF NOT EXISTS property_alerts (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    client_id     INT DEFAULT NULL,
    name          VARCHAR(100),
    email         VARCHAR(100),
    phone         VARCHAR(15),
    property_type VARCHAR(50),
    listing_type  VARCHAR(50),
    city          VARCHAR(100),
    min_budget    DECIMAL(15,2),
    max_budget    DECIMAL(15,2),
    min_bedrooms  INT DEFAULT 0,
    status        ENUM('active','inactive') DEFAULT 'active',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL
);

-- ============================================================
-- 10. RENT PAYMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS rent_payments (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    client_id      INT DEFAULT NULL,
    property_id    INT DEFAULT NULL,
    receipt_number VARCHAR(50),
    amount         DECIMAL(10,2),
    payment_month  VARCHAR(20),
    payment_date   DATE,
    payment_mode   VARCHAR(50),
    transaction_id VARCHAR(100),
    notes          TEXT,
    status         ENUM('paid','pending','failed') DEFAULT 'paid',
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id)   REFERENCES clients(id)    ON DELETE SET NULL,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE SET NULL
);

-- ============================================================
-- 11. SERVICE BOOKINGS
-- ============================================================
CREATE TABLE IF NOT EXISTS service_bookings (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    client_id    INT DEFAULT NULL,
    service_id   INT DEFAULT NULL,
    name         VARCHAR(100),
    phone        VARCHAR(15),
    email        VARCHAR(100),
    address      TEXT,
    booking_date DATE,
    time_slot    VARCHAR(50),
    status       ENUM('pending','confirmed','completed','cancelled') DEFAULT 'pending',
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id)  REFERENCES clients(id)   ON DELETE SET NULL,
    FOREIGN KEY (service_id) REFERENCES services(id)  ON DELETE SET NULL
);

-- ============================================================
-- 12. ENQUIRIES
-- ============================================================
CREATE TABLE IF NOT EXISTS enquiries (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100),
    email       VARCHAR(100),
    phone       VARCHAR(15),
    property_id INT DEFAULT NULL,
    message     TEXT,
    status      ENUM('new','read','replied') DEFAULT 'new',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- 13. LOAN APPLICATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS loan_applications (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    client_id       INT DEFAULT NULL,
    full_name       VARCHAR(100) NOT NULL,
    phone           VARCHAR(15),
    email           VARCHAR(100),
    bank_name       VARCHAR(100),
    loan_amount     DECIMAL(15,2),
    monthly_income  DECIMAL(15,2),
    property_type   VARCHAR(50),
    property_id     INT DEFAULT NULL,
    employment      VARCHAR(50),
    current_step    TINYINT DEFAULT 1,
    status          ENUM('pending','documents_required','under_review','verified','approved','rejected') DEFAULT 'pending',
    admin_remarks   TEXT,
    verified_at     DATETIME DEFAULT NULL,
    approved_at     DATETIME DEFAULT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE SET NULL
);

-- ============================================================
-- 13b. LOAN DOCUMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS loan_documents (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    application_id  INT NOT NULL,
    doc_type        ENUM('pan_card','aadhar_card','salary_slip','bank_statement','property_doc','other') NOT NULL,
    file_name       VARCHAR(255) NOT NULL,
    file_path       VARCHAR(500) NOT NULL,
    status          ENUM('pending','approved','rejected') DEFAULT 'pending',
    remarks         VARCHAR(255) DEFAULT NULL,
    uploaded_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (application_id) REFERENCES loan_applications(id) ON DELETE CASCADE
);

-- ============================================================
-- 14. MAINTENANCE REQUESTS
-- ============================================================
CREATE TABLE IF NOT EXISTS maintenance_requests (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    client_id       INT DEFAULT NULL,
    property_id     INT DEFAULT NULL,
    title           VARCHAR(200) NOT NULL,
    category        ENUM('plumbing','electrical','carpentry','painting','cleaning','pest_control','appliance','other') DEFAULT 'other',
    description     TEXT,
    priority        ENUM('low','medium','high','urgent') DEFAULT 'medium',
    status          ENUM('pending','in_progress','completed','cancelled') DEFAULT 'pending',
    assigned_to     VARCHAR(100),
    notes           TEXT,
    completed_at    DATETIME DEFAULT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE SET NULL
);

-- ============================================================
-- SAMPLE DATA
-- ============================================================

-- Admin (plain text - auto-upgrades to bcrypt on first login)
-- Admin login: admin@PropNexus.com  |  Password: Admin@123
INSERT INTO admins (name, email, password) VALUES
('Super Admin', 'admin@PropNexus.com', 'Admin@123');

-- Sample Client (needed for rent_payments, maintenance_requests, etc.)
-- Client login: john@example.com  |  Password: Client@123
INSERT INTO clients (name, email, phone, password, status) VALUES
('John Doe', 'john@example.com', '9876543210', '$2y$12$9ZAf7YlKa/qr20ND3oYqOO7ZVoLeNpEf3mYd8OTmTUirkBFx20nOq', 'active');

-- Services
INSERT INTO services (name, category, description, price_range, image_url) VALUES
('Home Cleaning',        'home_services', 'Professional home cleaning with trained staff & eco-friendly products', '₹500 - ₹2000',     'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600'),
('Home Painting',        'home_services', 'Interior & exterior wall painting by skilled painters',                '₹8000 - ₹50000',   'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=600'),
('Packers & Movers',     'home_services', 'Safe & reliable packing, loading and moving services',                '₹3000 - ₹20000',   'https://images.unsplash.com/photo-1600518464441-9154a4dea21b?w=600'),
('Commercial Interiors', 'commercial',    'Modern office & shop interior design and execution',                  '₹50000 - ₹500000', 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=600'),
('Plumbing',             'home_services', 'Expert plumbing repair, installation & maintenance',                  '₹200 - ₹5000',     'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=600'),
('Carpentry',            'home_services', 'Custom woodwork, furniture making & carpentry repair',                '₹500 - ₹30000',    'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=600');

-- Legal Services
INSERT INTO legal_services (name, description, price, image_url) VALUES
('Rental Agreement',       'Draft & register legally valid rental agreements for landlords & tenants',  1499, 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600'),
('Tenant Verification',    'Complete police background verification for tenant safety',                  999,  'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=600'),
('Sale Agreement',         'Legal sale deed preparation, stamp duty & property registration',           2999, 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=600'),
('Property Legal Service', 'Complete property documentation, title search & legal due diligence',      4999, 'https://images.unsplash.com/photo-1593115057322-e94b77572f20?w=600');

-- Loan Services
INSERT INTO loan_services (bank_name, loan_type, interest_rate, max_amount, tenure_years, description, logo_url) VALUES
('SBI Home Loan',         'Home Loan',        8.40, 10000000, 30, 'Lowest interest rates with easy EMI options. Special rates for women borrowers.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/SBI-logo.svg/200px-SBI-logo.svg.png'),
('HDFC Home Loan',        'Home Loan',        8.50, 15000000, 30, 'Quick approval & minimal documentation required. Balance transfer facility.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/HDFC_Bank_Logo.svg/200px-HDFC_Bank_Logo.svg.png'),
('ICICI Home Loan',       'Home Loan',        8.75, 20000000, 30, 'Flexible repayment with doorstep service. Top-up loan available.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/ICICI_Bank_Logo.svg/200px-ICICI_Bank_Logo.svg.png'),
('Axis Bank Home Loan',   'Home Loan',        8.75, 15000000, 30, 'Fast track approval in 48 hours. No hidden charges. Attractive floating rates.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Axis_Bank_logo.svg/200px-Axis_Bank_logo.svg.png'),
('Kotak Mahindra Bank',   'Home Loan',        8.65, 20000000, 20, 'Competitive rates with zero prepayment charges. Digital process end-to-end.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/Kotak_Mahindra_Bank_logo.svg/200px-Kotak_Mahindra_Bank_logo.svg.png'),
('Bank of Baroda',        'Home Loan',        8.40, 10000000, 30, 'Government bank with trusted service. Extra benefit for Central Govt employees.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Bank_of_Baroda_logo.svg/200px-Bank_of_Baroda_logo.svg.png'),
('PNB Housing Finance',   'Home Loan',        8.50, 15000000, 30, 'Flexible tenure options up to 30 years. Balance transfer at 8.50% p.a.', 'https://upload.wikimedia.org/wikipedia/en/thumb/2/2b/Punjab_National_Bank_logo.svg/200px-Punjab_National_Bank_logo.svg.png'),
('LIC Housing Finance',   'Home Loan',        8.35, 10000000, 30, 'Most trusted housing finance company. Special schemes for LIC policyholders.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/LIC_Logo.svg/200px-LIC_Logo.svg.png'),
('Bajaj Housing Finance', 'Home Loan',        8.55, 30000000, 30, 'Highest loan amount up to ₹3 Cr. Quick 24-hour disbursal for salaried.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/Bajaj_Finserv_Logo.svg/200px-Bajaj_Finserv_Logo.svg.png'),
('IDFC First Bank',       'Home Loan',        8.85, 10000000, 30, 'Zero foreclosure charges. Paperless application. Part-payment anytime free.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d8/IDFC_FIRST_Bank_Logo.svg/200px-IDFC_FIRST_Bank_Logo.svg.png'),
('Tata Capital',          'Commercial Loan',  9.25, 50000000, 15, 'Best commercial property loans. Flexible EMI structures for businesses.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Tata_logo.svg/200px-Tata_logo.svg.png'),
('Indiabulls Housing',    'Commercial Loan',  9.50, 50000000, 15, 'Fast commercial loan approval. Dedicated relationship manager for enterprises.', 'https://upload.wikimedia.org/wikipedia/en/b/b8/Indiabulls_logo.png');

-- Plans
INSERT INTO plans (name, plan_type, price, duration_days, listings_allowed, features, is_popular) VALUES
('Basic',   'residential', 999,  30,  1, 'Post 1 Listing,Basic Support,30 Day Validity,Email Alerts', 0),
('Premium', 'residential', 2499, 90,  5, 'Post 5 Listings,Priority Support,Featured Badge,90 Day Validity,SMS Alerts,Home Page Feature', 1),
('Pro',     'residential', 4999, 180, 15,'Post 15 Listings,Dedicated Manager,Premium Badge,180 Day Validity,All Alerts,Home Page Priority,Professional Photos', 0),
('Basic',   'commercial',  1999, 30,  1, 'Post 1 Commercial Listing,Basic Support,30 Day Validity', 0),
('Premium', 'commercial',  4999, 90,  5, 'Post 5 Commercial Listings,Priority Support,Featured,90 Day Validity,Dedicated Manager', 1);

-- Properties
INSERT INTO properties (title, description, type, listing_type, price, area, bedrooms, bathrooms, location, city, state, pincode, amenities, featured) VALUES
('Luxury 3BHK Villa Koramangala',    'Spacious villa with modern amenities, private garden & covered parking', 'villa',      'buy',        8500000,  '2400 sqft', 3, 3, 'Koramangala',    'Bangalore', 'Karnataka',    '560034', 'Garden,Pool,Parking,Security,Gym', 1),
('Premium 2BHK Apartment Whitefield','Ready to move apartment near metro. Fully maintained society',           'apartment',  'rent',       25000,    '1200 sqft', 2, 2, 'Whitefield',     'Bangalore', 'Karnataka',    '560066', 'Gym,Security,Power Backup,Lift', 0),
('Modern 4BHK Home JP Nagar',        'Independent house with terrace garden and modular kitchen',              'home',       'buy',        12000000, '3200 sqft', 4, 3, 'JP Nagar',       'Bangalore', 'Karnataka',    '560078', 'Terrace,Garden,Parking,Security', 1),
('Commercial Office MG Road',        'Prime location office space ideal for IT and startups',                  'commercial', 'rent', 75000,    '2000 sqft', 0, 2, 'MG Road',        'Bangalore', 'Karnataka',    '560001', 'AC,Elevator,Parking,Security,Cafeteria', 0),
('Budget 1BHK Electronic City',      'Affordable well-maintained apartment for IT professionals',              'apartment',  'rent',       12000,    '600 sqft',  1, 1, 'Electronic City','Bangalore', 'Karnataka',    '560100', 'Security,Power Backup,Water 24/7', 0),
('2BHK Sea View Bandra West',        'Luxury sea-facing apartment with stunning Arabian Sea views',            'apartment',  'buy',        35000000, '1100 sqft', 2, 2, 'Bandra West',    'Mumbai',    'Maharashtra',  '400050', 'Sea View,Gym,Pool,Security,Valet', 1),
('4BHK Builder Floor Vasant Vihar',  'Spacious builder floor with modular kitchen and 2 parking',              'home',       'buy',        18000000, '2800 sqft', 4, 4, 'Vasant Vihar',   'Delhi',     'Delhi',        '110057', 'Parking,Security,Garden,Modular Kitchen', 0),
('Gated Villa Gachibowli',           'Premium gated community villa with world class clubhouse',               'villa',      'buy',        16000000, '3600 sqft', 4, 4, 'Gachibowli',     'Hyderabad', 'Telangana',    '500032', 'Clubhouse,Pool,Gym,24x7 Security,Tennis', 1),
('PG for Boys Koramangala',          'Clean and spacious PG with food, WiFi and housekeeping',                 'apartment',  'pg',         8000,     '200 sqft',  1, 1, 'Koramangala',    'Bangalore', 'Karnataka',    '560034', 'Food,WiFi,Housekeeping,CCTV,Geyser', 0),
('3BHK Smart Home Baner',            'Fully automated smart home with solar panels and EV charging',           'home',       'buy',        11000000, '1800 sqft', 3, 3, 'Baner',          'Pune',      'Maharashtra',  '411045', 'Smart Home,Solar,EV Charging,Security', 1);

-- Property Images
INSERT INTO property_images (property_id, image_url, image_type, is_primary) VALUES
(1,'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800','exterior',1),
(1,'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800','hall',0),
(1,'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800','bedroom',0),
(2,'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800','exterior',1),
(2,'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800','hall',0),
(3,'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800','exterior',1),
(3,'https://images.unsplash.com/photo-1600210492493-0946911123ea?w=800','hall',0),
(4,'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=800','exterior',1),
(5,'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800','exterior',1),
(6,'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800','exterior',1),
(6,'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800','hall',0),
(7,'https://images.unsplash.com/photo-1583608205776-bfd35f0d9f83?w=800','exterior',1),
(7,'https://images.unsplash.com/photo-1600210492493-0946911123ea?w=800','hall',0),
(8,'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=800','exterior',1),
(8,'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800','hall',0),
(9,'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800','exterior',1),
(10,'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800','exterior',1),
(10,'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800','bedroom',0);

-- Add avatar, bio, country, city columns to clients table
ALTER TABLE clients 
  ADD COLUMN IF NOT EXISTS avatar VARCHAR(500) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS bio TEXT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS country VARCHAR(100) DEFAULT 'India',
  ADD COLUMN IF NOT EXISTS city_name VARCHAR(100) DEFAULT NULL;

-- News & Guides Table
CREATE TABLE IF NOT EXISTS news_guides (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    title      VARCHAR(200) NOT NULL,
    slug       VARCHAR(200) NOT NULL,
    category   ENUM('news','guide','tips','market') DEFAULT 'news',
    content    TEXT,
    excerpt    TEXT,
    image_url  VARCHAR(500),
    author     VARCHAR(100) DEFAULT 'PropNexus Team',
    views      INT DEFAULT 0,
    status     ENUM('published','draft') DEFAULT 'published',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO news_guides (title, slug, category, excerpt, image_url, author, views) VALUES
('Top 10 Areas to Buy Property in Bangalore 2025', 'top-areas-bangalore-2025', 'guide', 'Discover the best localities offering great ROI, connectivity and lifestyle in Bangalore this year.', 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=600', 'PropNexus Team', 1240),
('Complete Guide to Home Loans in India', 'home-loan-guide-india', 'guide', 'Everything you need to know about home loan eligibility, documentation, interest rates and top banks.', 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=600', 'PropNexus Team', 980),
('Mumbai Real Estate Market Report 2025', 'mumbai-market-report-2025', 'market', 'Property prices in Mumbai see 12% YoY growth. Powai and Thane emerging as hotspots for buyers.', 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600', 'PropNexus Team', 2100),
('How to Find the Perfect PG in Bangalore', 'find-pg-bangalore', 'tips', 'Step-by-step guide to finding verified, safe and affordable PG accommodation in Bangalore.', 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=600', 'PropNexus Team', 756),
('Rental Agreement Checklist: What to Check Before Signing', 'rental-agreement-checklist', 'guide', 'A complete checklist of 20 things to verify in your rental agreement to avoid legal issues later.', 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600', 'PropNexus Team', 1890),
('Hyderabad IT Corridor: Best Properties Near Hitech City', 'hyderabad-it-corridor-properties', 'market', 'Properties within 5km of Hitech City are seeing record demand from IT professionals. Here are the top picks.', 'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=600', 'PropNexus Team', 643),
('RERA: Your Rights as a Property Buyer Explained', 'rera-buyer-rights', 'guide', 'RERA protects home buyers. Learn your rights, how to file complaints, and what developers must disclose.', 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=600', 'PropNexus Team', 1450),
('5 Red Flags to Watch Out for When Renting a Home', 'renting-red-flags', 'tips', 'From hidden maintenance fees to no-pets clauses, here are the warning signs every tenant must know.', 'https://images.unsplash.com/photo-1583608205776-bfd35f0d9f83?w=600', 'PropNexus Team', 2340);

-- ============================================================
-- SAMPLE ENQUIRIES
-- ============================================================
INSERT INTO enquiries (name, email, phone, property_id, message, status, created_at) VALUES
('Rahul Sharma',    'rahul.s@gmail.com',   '9876543210', 1, 'I am interested in this villa. Can I schedule a visit?', 'new',     DATE_SUB(NOW(), INTERVAL 1 DAY)),
('Priya Patel',     'priya.p@yahoo.com',   '9876543211', 2, 'Is this apartment available for immediate move-in?', 'read',      DATE_SUB(NOW(), INTERVAL 3 DAY)),
('Amit Kumar',      'amit.k@hotmail.com',  '9876543212', 3, 'What are the maintenance charges for this property?', 'replied',   DATE_SUB(NOW(), INTERVAL 5 DAY)),
('Sneha Reddy',     'sneha.r@gmail.com',   '9876543213', 5, 'Can you share more details about the amenities?', 'new',          DATE_SUB(NOW(), INTERVAL 7 DAY)),
('Vikram Singh',    'vikram.s@outlook.com','9876543214', 6, 'I want to know the negotiable price for this property.', 'new',     DATE_SUB(NOW(), INTERVAL 10 DAY)),
('Meera Nair',      'meera.n@gmail.com',   '9876543215', 7, 'Is there any similar property in JP Nagar area?', 'read',          DATE_SUB(NOW(), INTERVAL 14 DAY)),
('Karthik Iyer',    'karthik.i@gmail.com', '9876543216', 8, 'Looking for a 3BHK in Hyderabad under 1.5 Cr', 'replied',         DATE_SUB(NOW(), INTERVAL 20 DAY)),
('Ananya Gupta',    'ananya.g@yahoo.com',  '9876543217', 10, 'Is this property available for a site visit this weekend?', 'new', DATE_SUB(NOW(), INTERVAL 25 DAY)),
('Rohan Mehta',     'rohan.m@gmail.com',   '9876543218', 4, 'Need office space for a startup, 15 people.', 'read',              DATE_SUB(NOW(), INTERVAL 30 DAY)),
('Deepa Joshi',     'deepa.j@gmail.com',   '9876543219', 9, 'Is the PG pet-friendly?', 'new',                                   DATE_SUB(NOW(), INTERVAL 35 DAY)),
('Suresh Babu',     'suresh.b@hotmail.com','9876543220', 6, 'Looking to invest, any upcoming projects?', 'replied',              DATE_SUB(NOW(), INTERVAL 45 DAY)),
('Lakshmi Menon',   'lakshmi.m@gmail.com', '9876543221', 4, 'What is the lease period for the office?', 'new',                   DATE_SUB(NOW(), INTERVAL 60 DAY));



-- ============================================================
-- SAMPLE RENT PAYMENTS
-- ============================================================
INSERT INTO rent_payments (client_id, property_id, receipt_number, amount, payment_month, payment_date, payment_mode, transaction_id, status, created_at) VALUES
(1, 2,  'REC-2026-001', 25000,  'March 2026',    CURDATE(),                            'UPI',          'TXN20260315001', 'paid',    NOW()),
(1, 2,  'REC-2026-002', 25000,  'February 2026', DATE_SUB(CURDATE(), INTERVAL 30 DAY),  'UPI',          'TXN20260215002', 'paid',    DATE_SUB(NOW(), INTERVAL 30 DAY)),
(1, 2,  'REC-2026-003', 25000,  'January 2026',  DATE_SUB(CURDATE(), INTERVAL 60 DAY),  'Bank Transfer','TXN20260115003', 'paid',    DATE_SUB(NOW(), INTERVAL 60 DAY)),
(1, 2,  'REC-2025-004', 25000,  'December 2025', DATE_SUB(CURDATE(), INTERVAL 90 DAY),  'UPI',          'TXN20251215004', 'paid',    DATE_SUB(NOW(), INTERVAL 90 DAY)),
(1, 2,  'REC-2025-005', 25000,  'November 2025', DATE_SUB(CURDATE(), INTERVAL 120 DAY), 'Bank Transfer','TXN20251115005', 'paid',    DATE_SUB(NOW(), INTERVAL 120 DAY)),
(1, 2,  'REC-2025-006', 25000,  'October 2025',  DATE_SUB(CURDATE(), INTERVAL 150 DAY), 'UPI',          'TXN20251015006', 'paid',    DATE_SUB(NOW(), INTERVAL 150 DAY)),
(1, 5,  'REC-2026-007', 12000,  'March 2026',    CURDATE(),                            'Cash',          'TXN20260315007', 'paid',    NOW()),
(1, 5,  'REC-2026-008', 12000,  'February 2026', DATE_SUB(CURDATE(), INTERVAL 30 DAY),  'Cash',          'TXN20260215008', 'paid',    DATE_SUB(NOW(), INTERVAL 30 DAY)),
(1, 5,  'REC-2026-009', 12000,  'January 2026',  DATE_SUB(CURDATE(), INTERVAL 60 DAY),  'Cash',          'TXN20260115009', 'paid',    DATE_SUB(NOW(), INTERVAL 60 DAY)),
(1, 8,  'REC-2026-010', 15000,  'March 2026',    CURDATE(),                            'UPI',          'TXN20260315010', 'paid',    NOW()),
(1, 8,  'REC-2026-011', 15000,  'February 2026', DATE_SUB(CURDATE(), INTERVAL 30 DAY),  'UPI',          'TXN20260215011', 'paid',    DATE_SUB(NOW(), INTERVAL 30 DAY)),
(1, 3,  'REC-2026-012', 32000,  'March 2026',    CURDATE(),                            'Bank Transfer', 'TXN20260315012', 'paid',    NOW()),
(1, 3,  'REC-2026-013', 32000,  'February 2026', DATE_SUB(CURDATE(), INTERVAL 30 DAY),  'Bank Transfer', 'TXN20260215013', 'paid',    DATE_SUB(NOW(), INTERVAL 30 DAY)),
(1, 6,  'REC-2026-014', 22000,  'March 2026',    CURDATE(),                            'UPI',          'TXN20260315014', 'paid',    NOW()),
(1, 7,  'REC-2026-015', 18000,  'March 2026',    CURDATE(),                            'UPI',          'TXN20260315015', 'paid',    NOW()),
(1, 4,  'REC-2026-016', 75000,  'March 2026',    NULL,                                 'Pending',       NULL,             'pending', NOW()),
(1, 9,  'REC-2026-017', 45000,  'March 2026',    NULL,                                 'Pending',       NULL,             'pending', DATE_SUB(NOW(), INTERVAL 5 DAY)),
(1, 10, 'REC-2026-018', 200000, 'March 2026',    NULL,                                 'Pending',       NULL,             'pending', DATE_SUB(NOW(), INTERVAL 2 DAY));

-- ============================================================
-- SAMPLE MAINTENANCE REQUESTS
-- ============================================================
INSERT INTO maintenance_requests (client_id, property_id, title, category, description, priority, status, assigned_to, notes, created_at) VALUES
(1, 2,  'Leaking tap in kitchen',       'plumbing',    'The kitchen tap has been leaking for 2 days. Water is dripping constantly.', 'high',   'in_progress', 'Raj Plumbing Services', 'Plumber scheduled for tomorrow', DATE_SUB(NOW(), INTERVAL 1 DAY)),
(1, 5,  'Power outage in bedroom',      'electrical',  'The bedroom switch board is not working since yesterday evening.',          'urgent', 'pending',     NULL,                   NULL,                            NOW()),
(1, 8,  'AC not cooling properly',       'appliance',   'Split AC in living room not cooling. Making clicking sounds.',              'medium', 'completed',   'Cool Care Services',   'Replaced gas and filter',       DATE_SUB(NOW(), INTERVAL 10 DAY)),
(1, 2,  'Wall paint peeling in bathroom','painting',    'Paint is peeling off in the bathroom wall near the shower.',                'low',    'pending',     NULL,                   NULL,                            DATE_SUB(NOW(), INTERVAL 3 DAY)),
(1, 3,  'Pest control needed',           'pest_control','Cockroaches found in kitchen and bathroom areas.',                         'medium', 'in_progress', 'PestFree Solutions',   'Scheduled for next week',       DATE_SUB(NOW(), INTERVAL 5 DAY));



-- ============================================================
-- FIX: Ensure properties table has all required columns
-- ============================================================
ALTER TABLE properties
  ADD COLUMN IF NOT EXISTS featured TINYINT(1) DEFAULT 0 AFTER amenities,
  ADD COLUMN IF NOT EXISTS views INT DEFAULT 0 AFTER featured;

-- ============================================================
-- FIX: Ensure loan_applications has all required columns
-- (handles cases where table was created from an older schema)
-- ============================================================
ALTER TABLE loan_applications
  ADD COLUMN IF NOT EXISTS property_type VARCHAR(50) AFTER monthly_income,
  ADD COLUMN IF NOT EXISTS property_id INT DEFAULT NULL AFTER property_type,
  ADD COLUMN IF NOT EXISTS employment VARCHAR(50) AFTER property_id,
  ADD COLUMN IF NOT EXISTS current_step TINYINT DEFAULT 1 AFTER employment,
  ADD COLUMN IF NOT EXISTS admin_remarks TEXT AFTER status,
  ADD COLUMN IF NOT EXISTS verified_at DATETIME DEFAULT NULL AFTER admin_remarks,
  ADD COLUMN IF NOT EXISTS approved_at DATETIME DEFAULT NULL AFTER verified_at;

-- Ensure loan_documents table exists
CREATE TABLE IF NOT EXISTS loan_documents (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    application_id  INT NOT NULL,
    doc_type        ENUM('pan_card','aadhar_card','salary_slip','bank_statement','property_doc','other') NOT NULL,
    file_name       VARCHAR(255) NOT NULL,
    file_path       VARCHAR(500) NOT NULL,
    status          ENUM('pending','approved','rejected') DEFAULT 'pending',
    remarks         VARCHAR(255) DEFAULT NULL,
    uploaded_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (application_id) REFERENCES loan_applications(id) ON DELETE CASCADE
);

-- ============================================================
-- ADD LATITUDE/LONGITUDE FOR MAP SEARCH
-- ============================================================
ALTER TABLE properties
  ADD COLUMN IF NOT EXISTS latitude DECIMAL(10,7) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS longitude DECIMAL(10,7) DEFAULT NULL;

-- Update property coordinates (real locations in India)
UPDATE properties SET latitude = 12.9352, longitude = 77.6245 WHERE id = 1;  -- Koramangala, Bangalore
UPDATE properties SET latitude = 12.9698, longitude = 77.7500 WHERE id = 2;  -- Whitefield, Bangalore
UPDATE properties SET latitude = 12.9077, longitude = 77.5856 WHERE id = 3;  -- JP Nagar, Bangalore
UPDATE properties SET latitude = 12.9756, longitude = 77.6064 WHERE id = 4;  -- MG Road, Bangalore
UPDATE properties SET latitude = 12.8458, longitude = 77.6692 WHERE id = 5;  -- Electronic City, Bangalore
UPDATE properties SET latitude = 19.0544, longitude = 72.8402 WHERE id = 6;  -- Bandra West, Mumbai
UPDATE properties SET latitude = 28.5605, longitude = 77.1600 WHERE id = 7;  -- Vasant Vihar, Delhi
UPDATE properties SET latitude = 17.4400, longitude = 78.3489 WHERE id = 8;  -- Gachibowli, Hyderabad
UPDATE properties SET latitude = 12.9352, longitude = 77.6245 WHERE id = 9;  -- Koramangala, Bangalore (PG)
UPDATE properties SET latitude = 18.5590, longitude = 73.7868 WHERE id = 10; -- Baner, Pune
UPDATE properties SET latitude = 19.0896, longitude = 72.8267 WHERE id = 11; -- Juhu, Mumbai
UPDATE properties SET latitude = 19.0176, longitude = 72.8562 WHERE id = 12; -- Dadar West, Mumbai
UPDATE properties SET latitude = 19.1197, longitude = 72.8464 WHERE id = 13; -- Andheri, Mumbai
UPDATE properties SET latitude = 28.5605, longitude = 77.1600 WHERE id = 14; -- Vasant Vihar, Delhi
UPDATE properties SET latitude = 28.5921, longitude = 77.0460 WHERE id = 15; -- Dwarka, Delhi
UPDATE properties SET latitude = 28.6315, longitude = 77.2167 WHERE id = 16; -- Connaught Place, Delhi
UPDATE properties SET latitude = 28.5244, longitude = 77.2066 WHERE id = 17; -- Saket, Delhi
UPDATE properties SET latitude = 17.4400, longitude = 78.3489 WHERE id = 18; -- Gachibowli, Hyderabad
UPDATE properties SET latitude = 17.4486, longitude = 78.3908 WHERE id = 19; -- Hitech City, Hyderabad
UPDATE properties SET latitude = 17.4312, longitude = 78.4071 WHERE id = 20; -- Jubilee Hills, Hyderabad
UPDATE properties SET latitude = 12.8306, longitude = 80.2063 WHERE id = 21; -- ECR, Chennai
UPDATE properties SET latitude = 13.0853, longitude = 80.2091 WHERE id = 22; -- Anna Nagar, Chennai
UPDATE properties SET latitude = 18.5590, longitude = 73.7868 WHERE id = 23; -- Baner, Pune
UPDATE properties SET latitude = 18.5912, longitude = 73.7380 WHERE id = 24; -- Hinjewadi, Pune
UPDATE properties SET latitude = 18.5873, longitude = 73.7399 WHERE id = 25; -- Hinjewadi, Pune
UPDATE properties SET latitude = 22.5809, longitude = 88.4082 WHERE id = 26; -- Salt Lake, Kolkata
UPDATE properties SET latitude = 28.6273, longitude = 77.3654 WHERE id = 27; -- Sector 62, Noida
UPDATE properties SET latitude = 28.4595, longitude = 77.0266 WHERE id = 28; -- Gurgaon
UPDATE properties SET latitude = 26.9124, longitude = 75.7873 WHERE id = 29; -- Jaipur

SET FOREIGN_KEY_CHECKS = 1;
