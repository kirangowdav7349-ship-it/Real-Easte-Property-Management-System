<?php
$pageTitle = 'Property Alerts';
require_once 'includes/header.php';
$msg = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
  $email = sanitize($_POST['email']);
  $ptype = sanitize($_POST['property_type']);
  $ltype = sanitize($_POST['listing_type']);
  $city = sanitize($_POST['city']);
  $min = (float)$_POST['min_price'];
  $max = (float)$_POST['max_price'];
  $beds = (int)$_POST['bedrooms'];
  $cid = $_SESSION['client_id'] ?? 0;
  $conn->query("INSERT INTO property_alerts (client_id,email,property_type,listing_type,city,min_budget,max_budget,min_bedrooms) VALUES($cid,'$email','$ptype','$ltype','$city',$min,$max,$beds)");
  $msg = '<div class="alert alert-success">🔔 Alert set successfully! You will receive notifications for matching properties.</div>';
}
?>
<div class="page-banner">
  <div class="container text-center">
    <h2 class="fw-bold">🔔 Property Alerts</h2>
    <p class="opacity-75">Get notified when new properties match your requirements</p>
  </div>
</div>

<section class="py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-7">
        <?= $msg ?>
        <div class="admin-card">
          <h4 class="fw-bold mb-4 text-center">Set Your Property Alert</h4>
          <form method="POST">
            <div class="row g-3">
              <div class="col-12">
                <label class="fw-bold">Email Address</label>
                <input type="email" name="email" class="form-control" required placeholder="your@email.com" value="<?= $_SESSION['client_email'] ?? '' ?>">
              </div>
              <div class="col-md-6">
                <label class="fw-bold">Property Type</label>
                <select name="property_type" class="form-select">
                  <option value="">Any</option>
                  <option>Home</option><option>Apartment</option>
                  <option>Villa</option><option>Site</option><option>Commercial</option>
                </select>
              </div>
              <div class="col-md-6">
                <label class="fw-bold">Looking For</label>
                <select name="listing_type" class="form-select">
                  <option value="">Any</option>
                  <option value="buy">Buy</option>
                  <option value="rent">Rent</option>
                  <option value="commercial">Commercial</option>
                </select>
              </div>
              <div class="col-12">
                <label class="fw-bold">City</label>
                <input type="text" name="city" class="form-control" placeholder="e.g. Bangalore, Mumbai">
              </div>
              <div class="col-md-6">
                <label class="fw-bold">Min Price (₹)</label>
                <input type="number" name="min_price" class="form-control" placeholder="Min Budget" value="0">
              </div>
              <div class="col-md-6">
                <label class="fw-bold">Max Price (₹)</label>
                <input type="number" name="max_price" class="form-control" placeholder="Max Budget" value="0">
              </div>
              <div class="col-12">
                <label class="fw-bold">Minimum Bedrooms</label>
                <select name="bedrooms" class="form-select">
                  <option value="0">Any</option>
                  <option>1</option><option>2</option><option>3</option><option>4</option>
                </select>
              </div>
              <div class="col-12">
                <button type="submit" class="btn btn-accent w-100 py-3 fw-bold fs-5">🔔 Set Alert Now</button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="admin-card h-100">
          <h5 class="fw-bold mb-4">Why Set Property Alerts?</h5>
          <?php $points = [['fa-bolt','Instant Notifications','Get notified the moment a matching property is listed'],['fa-bell','Never Miss Out','Be the first to know about new listings'],['fa-filter','Customized Filters','Set precise filters for your requirements'],['fa-mobile-alt','Email Alerts','Receive alerts directly in your inbox']]; foreach($points as $pt): ?>
          <div class="d-flex mb-3">
            <div class="flex-shrink-0 me-3" style="width:50px;height:50px;background:linear-gradient(135deg,#FF6B35,#e85d28);border-radius:12px;display:flex;align-items:center;justify-content:center">
              <i class="fas <?= $pt[0] ?> text-white"></i>
            </div>
            <div>
              <strong><?= $pt[1] ?></strong>
              <p class="text-muted small mb-0"><?= $pt[2] ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
