<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host   = 'localhost';
$user   = 'root';
$pass   = '';
$dbname = 'homehaven_db';

$log     = [];
$success = false;

if (isset($_POST['install'])) {

    // Step 1 — connect WITHOUT selecting a DB
    $conn = @new mysqli($host, $user, $pass);
    if ($conn->connect_error) {
        $log[] = ['fail', 'Cannot connect to MySQL: ' . $conn->connect_error];
        $log[] = ['fail', 'Make sure XAMPP MySQL module is running (green).'];
    } else {
        $log[] = ['ok', 'Connected to MySQL server successfully'];

        // Step 2 — create + select database
        $conn->query("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $conn->select_db($dbname);
        $log[] = ['ok', "Database '$dbname' created and selected"];

        $conn->query("SET FOREIGN_KEY_CHECKS=0");

        // Step 3 — drop existing tables so schema is always fresh
        $dropOrder = ['property_transactions','property_images','property_alerts','rent_payments','service_bookings',
                      'legal_bookings','loan_applications','enquiries','news_guides','maintenance_requests',
                      'services','legal_services','loan_services','plans',
                      'properties','clients','admins'];
        foreach ($dropOrder as $tbl) {
            $conn->query("DROP TABLE IF EXISTS `$tbl`");
        }

        // Step 4 — create tables
        $tables = [];

        $tables['admins'] = "CREATE TABLE IF NOT EXISTS `admins` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(100) NOT NULL DEFAULT 'Admin',
            `email` VARCHAR(100) UNIQUE NOT NULL,
            `password` VARCHAR(255) NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";

        $tables['clients'] = "CREATE TABLE IF NOT EXISTS `clients` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(100) NOT NULL,
            `email` VARCHAR(100) UNIQUE NOT NULL,
            `phone` VARCHAR(15),
            `password` VARCHAR(255) NOT NULL,
            `profile_pic` VARCHAR(255) DEFAULT 'default.png',
            `avatar` VARCHAR(500) DEFAULT NULL,
            `bio` TEXT DEFAULT NULL,
            `city_name` VARCHAR(100) DEFAULT NULL,
            `country` VARCHAR(100) DEFAULT 'India',
            `status` ENUM('active','inactive') DEFAULT 'active',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";

        $tables['properties'] = "CREATE TABLE IF NOT EXISTS `properties` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `title` VARCHAR(200) NOT NULL,
            `description` TEXT,
            `type` VARCHAR(50) DEFAULT 'apartment',
            `listing_type` VARCHAR(50) DEFAULT 'rent',
            `price` DECIMAL(15,2) NOT NULL DEFAULT 0,
            `area` VARCHAR(50),
            `bedrooms` INT DEFAULT 0,
            `bathrooms` INT DEFAULT 0,
            `location` VARCHAR(200),
            `city` VARCHAR(100),
            `state` VARCHAR(100),
            `pincode` VARCHAR(10),
            `latitude` DECIMAL(10,7) DEFAULT NULL,
            `longitude` DECIMAL(10,7) DEFAULT NULL,
            `amenities` TEXT,
            `status` ENUM('available','sold','rented') DEFAULT 'available',
            `featured` TINYINT(1) DEFAULT 0,
            `views` INT DEFAULT 0,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";

        $tables['property_images'] = "CREATE TABLE IF NOT EXISTS `property_images` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `property_id` INT NOT NULL,
            `image_url` VARCHAR(600) NOT NULL,
            `image_type` VARCHAR(50) DEFAULT 'exterior',
            `is_primary` TINYINT(1) DEFAULT 0,
            FOREIGN KEY (`property_id`) REFERENCES `properties`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB";

        $tables['services'] = "CREATE TABLE IF NOT EXISTS `services` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(100) NOT NULL,
            `category` VARCHAR(100),
            `description` TEXT,
            `price_range` VARCHAR(50),
            `image_url` VARCHAR(600),
            `status` ENUM('active','inactive') DEFAULT 'active'
        ) ENGINE=InnoDB";

        $tables['legal_services'] = "CREATE TABLE IF NOT EXISTS `legal_services` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(100) NOT NULL,
            `description` TEXT,
            `price` DECIMAL(10,2),
            `image_url` VARCHAR(600),
            `turnaround` VARCHAR(50),
            `status` ENUM('active','inactive') DEFAULT 'active'
        ) ENGINE=InnoDB";

        $tables['loan_services'] = "CREATE TABLE IF NOT EXISTS `loan_services` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `bank_name` VARCHAR(100) NOT NULL,
            `loan_type` VARCHAR(100),
            `interest_rate` DECIMAL(5,2),
            `max_amount` DECIMAL(15,2),
            `tenure_years` INT DEFAULT 20,
            `description` TEXT,
            `logo_url` VARCHAR(600)
        ) ENGINE=InnoDB";

        $tables['plans'] = "CREATE TABLE IF NOT EXISTS `plans` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(100),
            `plan_type` VARCHAR(50),
            `price` DECIMAL(10,2),
            `duration_days` INT,
            `listings_allowed` INT,
            `features` TEXT,
            `is_popular` TINYINT(1) DEFAULT 0
        ) ENGINE=InnoDB";

        $tables['property_alerts'] = "CREATE TABLE IF NOT EXISTS `property_alerts` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `client_id` INT DEFAULT NULL,
            `email` VARCHAR(100),
            `property_type` VARCHAR(50),
            `listing_type` VARCHAR(50),
            `city` VARCHAR(100),
            `min_budget` DECIMAL(15,2),
            `max_budget` DECIMAL(15,2),
            `min_bedrooms` INT DEFAULT 0,
            `status` ENUM('active','inactive') DEFAULT 'active',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";

        $tables['rent_payments'] = "CREATE TABLE IF NOT EXISTS `rent_payments` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `client_id` INT DEFAULT NULL,
            `property_id` INT DEFAULT NULL,
            `amount` DECIMAL(10,2) NOT NULL,
            `payment_month` VARCHAR(20),
            `payment_date` DATE,
            `payment_mode` VARCHAR(50) DEFAULT 'online',
            `transaction_id` VARCHAR(100),
            `receipt_number` VARCHAR(50),
            `status` ENUM('pending','paid','failed') DEFAULT 'pending',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";

        $tables['service_bookings'] = "CREATE TABLE IF NOT EXISTS `service_bookings` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `client_id` INT DEFAULT NULL,
            `service_id` INT DEFAULT NULL,
            `name` VARCHAR(100),
            `phone` VARCHAR(15),
            `email` VARCHAR(100),
            `address` TEXT,
            `booking_date` DATE,
            `time_slot` VARCHAR(50),
            `status` ENUM('pending','confirmed','completed','cancelled') DEFAULT 'pending',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";

        $tables['legal_bookings'] = "CREATE TABLE IF NOT EXISTS `legal_bookings` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `client_id` INT DEFAULT NULL,
            `service_id` INT DEFAULT NULL,
            `name` VARCHAR(100),
            `phone` VARCHAR(15),
            `email` VARCHAR(100),
            `notes` TEXT,
            `admin_remarks` TEXT DEFAULT NULL,
            `status` ENUM('pending','under_review','verified','completed','cancelled') DEFAULT 'pending',
            `reviewed_at` DATETIME DEFAULT NULL,
            `verified_at` DATETIME DEFAULT NULL,
            `completed_at` DATETIME DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";

        $tables['loan_applications'] = "CREATE TABLE IF NOT EXISTS `loan_applications` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `client_id` INT DEFAULT NULL,
            `full_name` VARCHAR(100),
            `phone` VARCHAR(15),
            `email` VARCHAR(100),
            `bank_name` VARCHAR(100),
            `loan_amount` DECIMAL(15,2),
            `monthly_income` DECIMAL(10,2),
            `property_type` VARCHAR(50) DEFAULT NULL,
            `property_id` INT DEFAULT NULL,
            `employment` VARCHAR(50) DEFAULT 'Salaried',
            `current_step` INT DEFAULT 1,
            `admin_remarks` TEXT DEFAULT NULL,
            `verified_at` DATETIME DEFAULT NULL,
            `approved_at` DATETIME DEFAULT NULL,
            `status` ENUM('pending','documents_required','under_review','verified','approved','rejected') DEFAULT 'pending',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";

        $tables['loan_documents'] = "CREATE TABLE IF NOT EXISTS `loan_documents` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `application_id` INT NOT NULL,
            `doc_type` VARCHAR(50) NOT NULL,
            `file_name` VARCHAR(255),
            `file_path` VARCHAR(500),
            `status` ENUM('pending','approved','rejected') DEFAULT 'pending',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (`application_id`) REFERENCES `loan_applications`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB";

        $tables['enquiries'] = "CREATE TABLE IF NOT EXISTS `enquiries` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `property_id` INT DEFAULT NULL,
            `name` VARCHAR(100),
            `email` VARCHAR(100),
            `phone` VARCHAR(15),
            `message` TEXT,
            `status` ENUM('new','read','replied') DEFAULT 'new',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";

        $tables['maintenance_requests'] = "CREATE TABLE IF NOT EXISTS `maintenance_requests` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `client_id` INT DEFAULT NULL,
            `property_id` INT DEFAULT NULL,
            `title` VARCHAR(200) NOT NULL,
            `category` ENUM('plumbing','electrical','carpentry','painting','cleaning','pest_control','appliance','other') DEFAULT 'other',
            `description` TEXT,
            `priority` ENUM('low','medium','high','urgent') DEFAULT 'medium',
            `status` ENUM('pending','in_progress','completed','cancelled') DEFAULT 'pending',
            `assigned_to` VARCHAR(100),
            `notes` TEXT,
            `completed_at` DATETIME DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";

        $tables['news_guides'] = "CREATE TABLE IF NOT EXISTS `news_guides` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `title` VARCHAR(200),
            `slug` VARCHAR(200),
            `category` ENUM('news','guide','tips','market') DEFAULT 'news',
            `excerpt` TEXT,
            `content` TEXT,
            `image_url` VARCHAR(600),
            `author` VARCHAR(100) DEFAULT 'PropNexus Team',
            `views` INT DEFAULT 0,
            `status` ENUM('published','draft') DEFAULT 'published',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";

        $tables['property_transactions'] = "CREATE TABLE IF NOT EXISTS `property_transactions` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `client_id` INT DEFAULT NULL,
            `property_id` INT NOT NULL,
            `transaction_type` ENUM('buy','rent') NOT NULL,
            `full_name` VARCHAR(100) NOT NULL,
            `email` VARCHAR(100) NOT NULL,
            `phone` VARCHAR(15) NOT NULL,
            `address` TEXT,
            `message` TEXT,
            `amount` DECIMAL(15,2) NOT NULL DEFAULT 0,
            `status` ENUM('pending','approved','rejected','completed') DEFAULT 'pending',
            `admin_read` TINYINT(1) DEFAULT 0,
            `admin_remarks` TEXT DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB";

        // Drop existing tables in reverse dependency order before re-creating
        $dropOrder = [
            'property_transactions','loan_documents','loan_applications','property_images','property_views',
            'enquiries','service_bookings','legal_bookings','news_guides','service_requests',
            'properties','loan_services','legal_services','services','subscription_plans',
            'clients','admins'
        ];
        foreach ($dropOrder as $dt) {
            $conn->query("DROP TABLE IF EXISTS `$dt`");
        }

        $tc = 0;
        foreach ($tables as $name => $sql) {
            if ($conn->query($sql)) { $tc++; }
            else { $log[] = ['fail', "Table $name: " . $conn->error]; }
        }
        $log[] = ['ok', "$tc / " . count($tables) . " tables created"];

        // ---- SEED DATA ----

        // Admin account
        $conn->query("DELETE FROM `admins`");
        $h = password_hash('Admin@123', PASSWORD_BCRYPT);
        $conn->query("INSERT INTO `admins` (name,email,password) VALUES ('Super Admin','admin@PropNexus.com','$h')");
        $log[] = ['ok', 'Admin: admin@PropNexus.com / Admin@123'];

        // Demo client
        $conn->query("DELETE FROM `clients`");
        $ch = password_hash('Demo@123', PASSWORD_BCRYPT);
        $conn->query("INSERT INTO `clients` (name,email,phone,password,city_name) VALUES ('Demo User','demo@PropNexus.com','9876543210','$ch','Bangalore')");
        $log[] = ['ok', 'Client: demo@PropNexus.com / Demo@123'];

        // Services
        $conn->query("DELETE FROM `services`");
        $svcs = [
            ['Home Cleaning',       'Cleaning',   'Professional deep cleaning for homes and apartments.',          '₹499 - ₹2,999',  'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600'],
            ['Home Painting',       'Painting',   'Interior and exterior painting with premium quality paints.',   '₹8,000 - ₹50,000','https://images.unsplash.com/photo-1562259929-b4e1fd3aef09?w=600'],
            ['Packers & Movers',    'Moving',     'Safe and reliable packing and moving across cities.',           '₹3,000 - ₹25,000','https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=600'],
            ['Commercial Interiors','Interiors',  'Complete interior design for offices and commercial spaces.',   '₹50,000+',        'https://images.unsplash.com/photo-1497366216548-37526070297c?w=600'],
            ['Plumbing Services',   'Plumbing',   'Expert plumbing repairs, installations and maintenance.',       '₹299 - ₹5,000',  'https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?w=600'],
            ['Carpentry Work',      'Carpentry',  'Custom furniture, repairs and woodwork by skilled carpenters.', '₹500 - ₹15,000', 'https://images.unsplash.com/photo-1588854337236-6889d631faa8?w=600'],
            ['Electrical Work',     'Electrical', 'All electrical installations, repairs and safety checks.',      '₹299 - ₹8,000',  'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600'],
            ['Pest Control',        'Cleaning',   'Safe pest control treatments for home and office.',             '₹799 - ₹3,500',  'https://images.unsplash.com/photo-1632932800816-a90a4f4a8c95?w=600'],
        ];
        foreach ($svcs as $s) {
            $n=$conn->real_escape_string($s[0]); $c=$conn->real_escape_string($s[1]);
            $d=$conn->real_escape_string($s[2]); $p=$conn->real_escape_string($s[3]); $i=$conn->real_escape_string($s[4]);
            $conn->query("INSERT INTO `services` (name,category,description,price_range,image_url) VALUES ('$n','$c','$d','$p','$i')");
        }
        $log[] = ['ok', count($svcs) . ' services added'];

        // Legal services
        $conn->query("DELETE FROM `legal_services`");
        $legs = [
            ['Rental Agreement',     'Legally binding rental agreement drafted by certified experts.',      2999, '2-3 days'],
            ['Tenant Verification',  'Complete background & identity verification of tenants.',             1499, '1-2 days'],
            ['Sale Agreement',       'Comprehensive property sale agreement with full legal protection.',   4999, '3-5 days'],
            ['Property Legal Check', 'Full title deed and encumbrance certificate verification.',           3499, '5-7 days'],
        ];
        foreach ($legs as $l) {
            $n=$conn->real_escape_string($l[0]); $d=$conn->real_escape_string($l[1]); $t=$conn->real_escape_string($l[3]);
            $conn->query("INSERT INTO `legal_services` (name,description,price,turnaround) VALUES ('$n','$d',$l[2],'$t')");
        }
        $log[] = ['ok', count($legs) . ' legal services added'];

        // Banks
        $conn->query("DELETE FROM `loan_services`");
        $banks = [
            ['LIC Housing Finance',   'Home Loan',       8.35, 10000000, 30, 'Most trusted housing finance. Special schemes for LIC policyholders.'],
            ['SBI Home Loan',         'Home Loan',       8.40, 10000000, 30, 'Lowest interest rates with easy EMI. Special rates for women borrowers.'],
            ['Bank of Baroda',        'Home Loan',       8.40, 10000000, 30, 'Government bank with trusted service. Extra benefit for Govt employees.'],
            ['HDFC Home Loan',        'Home Loan',       8.50, 15000000, 30, 'Quick approval & minimal documentation. Balance transfer facility.'],
            ['PNB Housing Finance',   'Home Loan',       8.50, 15000000, 30, 'Flexible tenure up to 30 years. Balance transfer at 8.50% p.a.'],
            ['Bajaj Housing Finance', 'Home Loan',       8.55, 30000000, 30, 'Highest loan amount up to 3 Cr. Quick 24-hour disbursal for salaried.'],
            ['Kotak Mahindra Bank',   'Home Loan',       8.65, 20000000, 20, 'Zero prepayment charges. Fully digital end-to-end process.'],
            ['ICICI Home Loan',       'Home Loan',       8.75, 20000000, 30, 'Flexible repayment with doorstep service. Top-up loan available.'],
            ['Axis Bank Home Loan',   'Home Loan',       8.75, 15000000, 30, 'Fast track approval in 48 hours. No hidden charges.'],
            ['IDFC First Bank',       'Home Loan',       8.85, 10000000, 30, 'Zero foreclosure charges. Paperless application.'],
            ['Tata Capital',          'Commercial Loan', 9.25, 50000000, 15, 'Best commercial property loans. Flexible EMI for businesses.'],
            ['Indiabulls Housing',    'Commercial Loan', 9.50, 50000000, 15, 'Fast commercial loan approval. Dedicated relationship manager.'],
        ];
        foreach ($banks as $b) {
            $n=$conn->real_escape_string($b[0]); $t=$conn->real_escape_string($b[1]); $d=$conn->real_escape_string($b[5]);
            $conn->query("INSERT INTO `loan_services` (bank_name,loan_type,interest_rate,max_amount,tenure_years,description) VALUES ('$n','$t',$b[2],$b[3],$b[4],'$d')");
        }
        $log[] = ['ok', count($banks) . ' banks added (10 home + 2 commercial)'];

        // Plans
        $conn->query("DELETE FROM `plans`");
        $plans = [
            ['Basic',    'residential', 999,  30,  1,  'Post 1 Listing,Basic Support,30 Day Validity,Email Alerts', 0],
            ['Premium',  'residential', 2499, 90,  5,  'Post 5 Listings,Priority Support,Featured Badge,90 Day Validity,SMS Alerts', 1],
            ['Pro',      'residential', 4999, 180, 15, 'Post 15 Listings,Dedicated Manager,Premium Badge,180 Day Validity,All Alerts', 0],
            ['Basic',    'commercial',  1999, 30,  1,  'Post 1 Commercial Listing,Basic Support,30 Day Validity', 0],
            ['Business', 'commercial',  5999, 90,  5,  'Post 5 Commercial Listings,Priority Support,Featured,90 Day Validity', 1],
        ];
        foreach ($plans as $p) {
            $n=$conn->real_escape_string($p[0]); $t=$conn->real_escape_string($p[1]); $f=$conn->real_escape_string($p[5]);
            $conn->query("INSERT INTO `plans` (name,plan_type,price,duration_days,listings_allowed,features,is_popular) VALUES ('$n','$t',$p[2],$p[3],$p[4],'$f',$p[6])");
        }
        $log[] = ['ok', count($plans) . ' plans added'];

        // Properties + images
        $conn->query("DELETE FROM `property_images`");
        $conn->query("DELETE FROM `properties`");
        // [title, type, listing_type, price, bedrooms, bathrooms, area, city, location, description, amenities, featured, state, pincode, lat, lng]
        $props = [
            // ---- BANGALORE (8) ----
            ['Luxury 3BHK Apartment in Koramangala','apartment','buy',      8500000, 3,2,'1450 sqft','Bangalore','Koramangala','Stunning 3BHK with modular kitchen, balcony and top-class amenities.','Gym,Pool,Parking,Security,Lift',1,'Karnataka','560034', 12.9352, 77.6245],
            ['Spacious 2BHK for Rent - Indiranagar', 'apartment','rent',     35000,  2,2,'1100 sqft','Bangalore','Indiranagar','Well-maintained 2BHK near Indiranagar metro station.',         'Parking,Security,Power Backup',  1,'Karnataka','560038', 12.9784, 77.6408],
            ['4BHK Villa in Whitefield',             'villa',    'buy',    18000000, 4,4,'3200 sqft','Bangalore','Whitefield', 'Premium villa with private garden and infinity pool.',       'Pool,Garden,Gym,Security',       1,'Karnataka','560066', 12.9698, 77.7500],
            ['Commercial Office Space - MG Road',    'commercial','rent',120000,0,2,'2200 sqft','Bangalore','MG Road',   'Prime location commercial space ideal for IT startups.',      'Lift,Parking,24x7 Security,AC',     0,'Karnataka','560001', 12.9758, 77.6045],
            ['Independent House - Jayanagar',        'home',     'buy',    12000000, 3,3,'2400 sqft','Bangalore','Jayanagar', 'Independent house on 30x40 site with car parking.',     'Parking,Garden,Security',        1,'Karnataka','560041', 12.9250, 77.5938],
            ['1BHK Studio - HSR Layout',             'apartment','rent',     18000,  1,1,'650 sqft', 'Bangalore','HSR Layout','Fully furnished studio near tech parks for professionals.',  'Lift,Security,Power Backup,WiFi',     0,'Karnataka','560102', 12.9116, 77.6389],
            ['PG for Boys - Koramangala',            'apartment','pg',        8500,  1,1,'200 sqft', 'Bangalore','Koramangala','Clean PG with food, WiFi and housekeeping included.',  'Food,WiFi,Housekeeping,CCTV,Geyser',     1,'Karnataka','560034', 12.9340, 77.6260],
            ['Girls PG with Food - HSR Layout',      'apartment','pg',        9500,  1,1,'190 sqft', 'Bangalore','HSR Layout','Safe and hygienic girls PG with home-cooked meals.',  'Food,WiFi,Security,CCTV,Laundry',     1,'Karnataka','560102', 12.9130, 77.6370],

            // ---- MUMBAI (5) ----
            ['2BHK Sea View Bandra West',   'apartment','buy',  35000000, 2,2,'1100 sqft','Mumbai','Bandra West','Luxury sea-facing apartment with stunning Arabian Sea views.','Sea View,Gym,Pool,Security,Valet',    1,'Maharashtra','400050', 19.0596, 72.8295],
            ['1BHK Andheri West',           'apartment','rent', 32000,    1,1,'550 sqft', 'Mumbai','Andheri West','Well-maintained apartment near railway and metro station.','Security,Power Backup,Lift',          0,'Maharashtra','400058', 19.1364, 72.8296],
            ['4BHK Duplex Penthouse - Juhu','villa',    'buy',  85000000, 4,5,'5500 sqft','Mumbai','Juhu','Luxurious duplex penthouse with panoramic city and sea views.','Pool,Gym,Terrace,Valet,Security,Jacuzzi', 1,'Maharashtra','400049', 19.1075, 72.8263],
            ['Retail Shop Dadar West',      'commercial','rent',95000,0,1,'600 sqft','Mumbai','Dadar West','High footfall retail space near Dadar station.','Main Road,CCTV,Display Window',0,'Maharashtra','400028', 19.0178, 72.8478],
            ['Premium Girls PG - Andheri',  'apartment','pg',   12000,    1,1,'180 sqft', 'Mumbai','Andheri East','Safe girls PG with food, attached bathroom and CCTV security.','Food,CCTV,Attached Bath,WiFi,AC',     1,'Maharashtra','400069', 19.1197, 72.8464],

            // ---- DELHI (4) ----
            ['4BHK Builder Floor Vasant Vihar','home', 'buy', 18000000, 4,4,'2800 sqft','Delhi','Vasant Vihar','Spacious builder floor with modular kitchen and 2 car parking.','Parking,Security,Garden,Modular Kitchen', 1,'Delhi','110057', 28.5603, 77.1621],
            ['3BHK DDA Flat Dwarka',           'apartment','buy', 12500000, 3,2,'1400 sqft','Delhi','Dwarka Sector 6','Well-located DDA flat near metro with park facing view.','Park View,Security,Parking,Lift',    0,'Delhi','110075', 28.5733, 77.0713],
            ['Premium Office Connaught Place',  'commercial','rent',200000,0,4,'3000 sqft','Delhi','Connaught Place','Grade A office space in Delhi heart with executive amenities.','AC,Elevator,Cafeteria,Parking,24x7',    1,'Delhi','110001', 28.6315, 77.2167],
            ['2BHK Rent Saket',                 'apartment','rent',28000,  2,2,'950 sqft', 'Delhi','Saket','Modern 2BHK near Saket metro and Select Citywalk Mall.','Security,Lift,Power Backup,Parking',0,'Delhi','110017', 28.5245, 77.2066],

            // ---- HYDERABAD (3) ----
            ['Gated Villa Gachibowli',      'villa',    'buy',  16000000, 4,4,'3600 sqft','Hyderabad','Gachibowli','Premium gated community villa with world-class clubhouse.','Clubhouse,Pool,Gym,24x7 Security,Tennis',  1,'Telangana','500032', 17.4401, 78.3489],
            ['2BHK Near Hitech City',       'apartment','rent', 22000,    2,2,'950 sqft', 'Hyderabad','Madhapur','Ready-to-move 2BHK walking distance to Hitech City office parks.','Gym,Security,Power Backup,Parking',     1,'Telangana','500081', 17.4486, 78.3908],
            ['3BHK Jubilee Hills Apartment','apartment','buy',  18000000, 3,3,'2000 sqft','Hyderabad','Jubilee Hills','Premium apartment in most sought-after Hyderabad address.','Pool,Gym,Club,24x7 Security,Valet',      1,'Telangana','500033', 17.4326, 78.4071],

            // ---- CHENNAI (2) ----
            ['Beach Villa ECR Chennai',    'villa',    'buy',  22000000, 5,4,'4500 sqft','Chennai','ECR','Luxurious beach-facing 5BHK villa with private pool and garden.','Beach View,Pool,Garden,Security,Gym',   1,'Tamil Nadu','600119', 12.8352, 80.2039],
            ['2BHK Anna Nagar Rent',       'apartment','rent', 18000,    2,2,'900 sqft', 'Chennai','Anna Nagar','Comfortable 2BHK in most sought-after Chennai neighbourhood.','Security,Parking,Lift,Power Backup',  0,'Tamil Nadu','600040', 13.0850, 80.2101],

            // ---- PUNE (3) ----
            ['3BHK Smart Home Baner',      'home',    'buy',  11000000, 3,3,'1800 sqft','Pune','Baner','Fully automated smart home with solar panels and EV charging.','Smart Home,Solar,EV Charging,Security',1,'Maharashtra','411045', 18.5590, 73.7868],
            ['Plot Hinjewadi Pune',        'site',    'buy',  2500000,  0,0,'2400 sqft','Pune','Hinjewadi','DTCP approved residential plot near IT park entrance.','Water Source,Road Access,Fencing',     0,'Maharashtra','411057', 18.5912, 73.7380],
            ['1BHK Rent Hinjewadi',        'apartment','rent', 14000,   1,1,'650 sqft', 'Pune','Hinjewadi','Affordable rental near Wipro and Infosys campus.','Security,WiFi,Water 24x7',               0,'Maharashtra','411057', 18.5895, 73.7390],

            // ---- KOLKATA (1) ----
            ['2BHK Flat Salt Lake Kolkata', 'apartment','buy',  7500000, 2,2,'1100 sqft','Kolkata','Salt Lake','Well-maintained flat in premium Salt Lake sector with lake views.','Security,Lift,Parking,Garden',       0,'West Bengal','700091', 22.5804, 88.4138],

            // ---- NOIDA (1) ----
            ['3BHK Flat Sector 62 Noida',  'apartment','buy',  8500000, 3,2,'1600 sqft','Noida','Sector 62','Spacious flat in prime Noida sector with excellent connectivity.','Club,Pool,Gym,Security,Parking',    0,'Uttar Pradesh','201309', 28.6270, 77.3650],

            // ---- GURGAON (1) ----
            ['Independent Villa Gurgaon',  'villa',    'buy', 38000000, 5,5,'4200 sqft','Gurgaon','Golf Course Road','Luxury independent villa with smart home and private pool.','Pool,Gym,Garden,Security,Smart Home', 1,'Haryana','122001', 28.4440, 77.0760],

            // ---- JAIPUR (1) ----
            ['Farm House Jaipur Outskirts','villa',    'buy', 12000000, 6,5,'8000 sqft','Jaipur','Mansarovar','Sprawling 2-acre farmhouse with swimming pool and lawns.','Pool,Garden,Parking,Security,Farmland',   0,'Rajasthan','302020', 26.8668, 75.7600],

            // ---- PG / CO-LIVING (5 more) ----
            ['Co-Living Space - Hinjewadi Pune',     'apartment','pg', 7500,  1,1,'180 sqft','Pune','Hinjewadi','Modern co-living with fully furnished rooms near IT park. Common kitchen and chill zone.','WiFi,Food,Laundry,Housekeeping,CCTV,AC',  1,'Maharashtra','411057', 18.5905, 73.7385],
            ['Boys PG - Hauz Khas Delhi',            'apartment','pg', 11000, 1,1,'200 sqft','Delhi','Hauz Khas','Premium boys PG near metro with home-style meals and study room.','Food,WiFi,CCTV,Power Backup,Laundry,Geyser',   1,'Delhi','110016', 28.5494, 77.2001],
            ['Girls Co-Living - Madhapur Hyderabad',  'apartment','pg', 9000,  1,1,'190 sqft','Hyderabad','Madhapur','Safe co-living space for women near Hitech City with biometric entry.','Food,WiFi,Security,CCTV,Gym,Laundry',    1,'Telangana','500081', 17.4482, 78.3915],
            ['Premium PG - OMR Chennai',             'apartment','pg', 8000,  1,1,'170 sqft','Chennai','OMR','Well-furnished PG on IT corridor with AC rooms and daily meals.','Food,AC,WiFi,CCTV,Power Backup,Housekeeping', 0,'Tamil Nadu','600097', 12.9060, 80.2277],
            ['Co-Living Hub - Sector 62 Noida',      'apartment','pg', 8500,  1,1,'210 sqft','Noida','Sector 62','Tech-enabled co-living with app-based entry, events and community area.','WiFi,Food,Gym,CCTV,Laundry,Common Area',  1,'Uttar Pradesh','201309', 28.6265, 77.3645],
        ];
        // Unique images per property — enough sets so no two properties share the same primary image
        $imgSets = [
            'apartment' => [
                [['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800','exterior',1],['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800','hall',0],['https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800','bedroom',0],['https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800','bathroom',0]],
                [['https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800','exterior',1],['https://images.unsplash.com/photo-1600210492493-0946911123ea?w=800','hall',0],['https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800','bedroom',0],['https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800','bathroom',0]],
                [['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800','exterior',1],['https://images.unsplash.com/photo-1560185007-cde436f6a4d0?w=800','hall',0],['https://images.unsplash.com/photo-1540518614846-7eded433c457?w=800','bedroom',0],['https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800','bathroom',0]],
                [['https://images.unsplash.com/photo-1574362848149-11496d93a7c7?w=800','exterior',1],['https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=800','hall',0],['https://images.unsplash.com/photo-1616594039964-ae9021a400a0?w=800','bedroom',0],['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800','kitchen',0]],
                [['https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800','exterior',1],['https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800','hall',0],['https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?w=800','bedroom',0],['https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800','bathroom',0]],
                [['https://images.unsplash.com/photo-1560448075-bb485b067938?w=800','exterior',1],['https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800','hall',0],['https://images.unsplash.com/photo-1615874959474-d609969a20ed?w=800','bedroom',0],['https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800','kitchen',0]],
                [['https://images.unsplash.com/photo-1515263487990-61b07816b324?w=800','exterior',1],['https://images.unsplash.com/photo-1567016432779-094069958ea5?w=800','hall',0],['https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=800','bedroom',0],['https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800','bathroom',0]],
                [['https://images.unsplash.com/photo-1560185127-6ed189bf02f4?w=800','exterior',1],['https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800','hall',0],['https://images.unsplash.com/photo-1616047006789-b7af5afb8c20?w=800','bedroom',0],['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800','kitchen',0]],
                [['https://images.unsplash.com/photo-1560184897-ae75f418493e?w=800','exterior',1],['https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800','hall',0],['https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?w=800','bedroom',0],['https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800','bathroom',0]],
                [['https://images.unsplash.com/photo-1554995207-c18c203602cb?w=800','exterior',1],['https://images.unsplash.com/photo-1600121848594-d8644e57abab?w=800','hall',0],['https://images.unsplash.com/photo-1615874959474-d609969a20ed?w=800','bedroom',0],['https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800','bathroom',0]],
                [['https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?w=800','exterior',1],['https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=800','hall',0],['https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=800','bedroom',0],['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800','kitchen',0]],
                [['https://images.unsplash.com/photo-1558036117-15d82a90b9b1?w=800','exterior',1],['https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800','hall',0],['https://images.unsplash.com/photo-1616047006789-b7af5afb8c20?w=800','bedroom',0],['https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800','bathroom',0]],
                [['https://images.unsplash.com/photo-1560185007-5f0bb1866cab?w=800','exterior',1],['https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800','hall',0],['https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800','bedroom',0],['https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800','bathroom',0]],
                [['https://images.unsplash.com/photo-1560449752-3fd4bdbe7df0?w=800','exterior',1],['https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800','hall',0],['https://images.unsplash.com/photo-1540518614846-7eded433c457?w=800','bedroom',0],['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800','kitchen',0]],
            ],
            'villa' => [
                [['https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800','exterior',1],['https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800','hall',0],['https://images.unsplash.com/photo-1616594039964-ae9021a400a0?w=800','bedroom',0],['https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800','bathroom',0],['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800','kitchen',0]],
                [['https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800','exterior',1],['https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800','hall',0],['https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800','bedroom',0],['https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800','bathroom',0]],
                [['https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800','exterior',1],['https://images.unsplash.com/photo-1600210492493-0946911123ea?w=800','hall',0],['https://images.unsplash.com/photo-1540518614846-7eded433c457?w=800','bedroom',0],['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800','kitchen',0]],
                [['https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800','exterior',1],['https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=800','hall',0],['https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?w=800','bedroom',0],['https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800','bathroom',0],['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800','kitchen',0]],
                [['https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800','exterior',1],['https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800','hall',0],['https://images.unsplash.com/photo-1615874959474-d609969a20ed?w=800','bedroom',0],['https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800','bathroom',0]],
                [['https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=800','exterior',1],['https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800','hall',0],['https://images.unsplash.com/photo-1616047006789-b7af5afb8c20?w=800','bedroom',0],['https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800','bathroom',0]],
            ],
            'home' => [
                [['https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800','exterior',1],['https://images.unsplash.com/photo-1567016432779-094069958ea5?w=800','hall',0],['https://images.unsplash.com/photo-1540518614846-7eded433c457?w=800','bedroom',0],['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800','kitchen',0]],
                [['https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=800','exterior',1],['https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800','hall',0],['https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800','bedroom',0],['https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800','bathroom',0]],
                [['https://images.unsplash.com/photo-1583608205776-bfd35f0d9f83?w=800','exterior',1],['https://images.unsplash.com/photo-1600210492493-0946911123ea?w=800','hall',0],['https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?w=800','bedroom',0],['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800','kitchen',0]],
            ],
            'commercial' => [
                [['https://images.unsplash.com/photo-1497366216548-37526070297c?w=800','exterior',1],['https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=800','hall',0]],
                [['https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800','exterior',1],['https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=800','hall',0]],
                [['https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800','exterior',1],['https://images.unsplash.com/photo-1604328698692-f76ea9498e76?w=800','hall',0]],
            ],
            'site' => [
                [['https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800','exterior',1]],
                [['https://images.unsplash.com/photo-1628624747186-a941c476b7ef?w=800','exterior',1]],
            ],
        ];
        $pc = 0;
        foreach ($props as $p) {
            $t=$conn->real_escape_string($p[0]); $d=$conn->real_escape_string($p[9]); $a=$conn->real_escape_string($p[10]);
            $loc=$conn->real_escape_string($p[8]); $ar=$conn->real_escape_string($p[6]);
            $st=$conn->real_escape_string($p[12]); $pin=$conn->real_escape_string($p[13]);
            $conn->query("INSERT INTO `properties` (title,description,type,listing_type,price,area,bedrooms,bathrooms,location,city,state,pincode,latitude,longitude,amenities,status,featured) VALUES ('$t','$d','{$p[1]}','{$p[2]}',{$p[3]},'$ar',{$p[4]},{$p[5]},'$loc','{$p[7]}','$st','$pin',{$p[14]},{$p[15]},'$a','available',{$p[11]})");
            $pid = $conn->insert_id;
            // Pick an image set with rotation to avoid repetition
            $sets = $imgSets[$p[1]] ?? $imgSets['apartment'];
            $chosenImgs = $sets[$pc % count($sets)];
            foreach ($chosenImgs as $img) {
                $u=$conn->real_escape_string($img[0]);
                $conn->query("INSERT INTO `property_images` (property_id,image_url,image_type,is_primary) VALUES ($pid,'$u','{$img[1]}',{$img[2]})");
            }
            $pc++;
        }
        $log[] = ['ok', "$pc properties + images added"];

        // News
        $conn->query("DELETE FROM `news_guides`");
        $news = [
            ['Bangalore Real Estate 2025: Market Outlook','news-2025','news','Bangalore property market sees 18% growth.'],
            ['Top 5 Tips for First Time Home Buyers','first-home-tips','tips','Avoid common mistakes with these expert tips.'],
            ['How to Verify Property Documents','verify-documents','guide','Checklist for title deed and encumbrance certificate.'],
            ['Rental Yield Calculator Guide','rental-yield','market','How to calculate rental yield and find best areas.'],
        ];
        foreach ($news as $n) {
            $t=$conn->real_escape_string($n[0]); $s=$conn->real_escape_string($n[1]); $e=$conn->real_escape_string($n[3]);
            $conn->query("INSERT INTO `news_guides` (title,slug,category,excerpt,image_url) VALUES ('$t','$s','{$n[2]}','$e','https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600')");
        }
        $log[] = ['ok', count($news) . ' news articles added'];

        $conn->query("SET FOREIGN_KEY_CHECKS=1");
        $conn->close();
        $log[] = ['ok', 'All done! PropNexus is ready.'];
        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280">
<title>PropNexus Installer</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;background:linear-gradient(135deg,#1a3c5e,#2d6a4f);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.card{background:#fff;border-radius:18px;padding:36px;width:100%;max-width:560px;box-shadow:0 20px 60px rgba(0,0,0,.35)}
h2{font-size:1.6rem;color:#1a3c5e}
.log{background:#0f172a;border-radius:10px;padding:16px;max-height:300px;overflow-y:auto;margin:16px 0;font-family:monospace;font-size:.8rem;line-height:1.7}
.ok{color:#4ade80}.fail{color:#f87171}.info{color:#60a5fa}
.btn{display:block;width:100%;padding:14px;background:linear-gradient(135deg,#1a3c5e,#2d6a4f);color:#fff;border:none;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer;transition:.2s}
.btn:hover{opacity:.9}
.links{display:flex;gap:10px;margin-top:12px}
.links a{flex:1;text-align:center;padding:12px;border-radius:10px;font-weight:700;font-size:.9rem;text-decoration:none;color:#fff}
.la{background:#1a3c5e}.lb{background:#FF6B35}
.req{background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:16px;margin-bottom:20px;font-size:.83rem;line-height:1.8}
.creds{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:14px;margin-top:14px;font-size:.85rem;line-height:1.9}
</style>
</head>
<body>
<div class="card">
  <div style="text-align:center;margin-bottom:18px">
    <div style="font-size:3rem">🏠</div>
    <h2>PropNexus Installer</h2>
    <p style="color:#64748b;font-size:.85rem;margin-top:4px">Creates database + loads all data automatically</p>
  </div>

  <?php if ($success): ?>
    <div style="background:#f0fdf4;border:2px solid #10b981;border-radius:12px;padding:20px;text-align:center">
      <div style="font-size:2rem">🎉</div>
      <h3 style="color:#10b981;margin:8px 0">Installation Complete!</h3>
      <p style="color:#475569;font-size:.88rem">Database <strong>homehaven_db</strong> is ready to use.</p>
    </div>
    <div class="log"><?php foreach($log as $m): ?><div class="<?=$m[0]?>"><?=htmlspecialchars($m[1])?></div><?php endforeach; ?></div>
    <div class="links">
      <a href="index.php" class="la">🌐 Visit Website</a>
      <a href="admin/login.php" class="lb">🔐 Admin Panel</a>
    </div>
    <div class="creds">
      <strong>Admin:</strong> admin@PropNexus.com &nbsp;|&nbsp; Admin@123<br>
      <strong>Client:</strong> demo@PropNexus.com &nbsp;|&nbsp; Demo@123
    </div>

  <?php elseif (!empty($log)): ?>
    <div class="log"><?php foreach($log as $m): ?><div class="<?=$m[0]?>"><?=htmlspecialchars($m[1])?></div><?php endforeach; ?></div>
    <form method="POST"><button name="install" class="btn">🔄 Retry Installation</button></form>

  <?php else: ?>
    <div class="req">
      <strong>Before clicking Install, make sure:</strong><br>
      ✅ XAMPP is open and <strong>Apache</strong> is green (running)<br>
      ✅ XAMPP <strong>MySQL</strong> is green (running)<br>
      ✅ Files are in <code>C:\xampp\htdocs\PropNexus\</code>
    </div>
    <form method="POST">
      <button name="install" class="btn">🚀 Install PropNexus Now</button>
    </form>
    <p style="text-align:center;font-size:.75rem;color:#94a3b8;margin-top:12px">
      Creates <strong>homehaven_db</strong> and loads properties, banks, services &amp; sample data
    </p>
  <?php endif; ?>
</div>
</body>
</html>
