<?php
$pageTitle = 'Properties';
require_once 'includes/header.php';

$type = sanitize($_GET['type'] ?? '');
$property_type = sanitize($_GET['property_type'] ?? '');
$search = sanitize($_GET['search'] ?? '');
$min = sanitize($_GET['min_price'] ?? '');
$max = sanitize($_GET['max_price'] ?? '');
$beds = sanitize($_GET['bedrooms'] ?? '');
$city = sanitize($_GET['city'] ?? '');

$where = "WHERE p.status='available'";
if($type) $where .= " AND p.listing_type='$type'";
if($property_type) $where .= " AND p.type='$property_type'";
if($search) $where .= " AND (p.title LIKE '%$search%' OR p.city LIKE '%$search%' OR p.location LIKE '%$search%')";
if($min) $where .= " AND p.price >= '$min'";
if($max) $where .= " AND p.price <= '$max'";
if($beds) $where .= " AND p.bedrooms >= '$beds'";
if($city) $where .= " AND p.city LIKE '%$city%'";

$props = $conn->query("SELECT p.*, pi.image_url FROM properties p 
  LEFT JOIN property_images pi ON p.id = pi.property_id AND pi.is_primary = 1 $where ORDER BY p.featured DESC, p.created_at DESC");
?>

<div class="page-banner">
  <div class="container">
    <h2 class="fw-bold">🏘️ Properties for <?= $type ? ucfirst($type) : 'Buy / Rent / PG' ?></h2>
    <p class="mb-0 opacity-75">Find the perfect property that matches your needs</p>
  </div>
</div>

<section class="py-4">
  <div class="container">
    <!-- Filter Bar -->
    <div class="filter-bar">
      <form method="GET" class="row g-2 align-items-end">
        <div class="col-md-2">
          <label class="form-label small fw-bold">Type</label>
          <select name="type" class="form-select">
            <option value="">All</option>
            <option value="buy" <?= $type=='buy'?'selected':'' ?>>Buy</option>
            <option value="rent" <?= $type=='rent'?'selected':'' ?>>Rent</option>
            <option value="pg" <?= $type=='pg'?'selected':'' ?>>PG / Co-Living</option>
          </select>
        </div>
        <div class="col-md-2">
          <label class="form-label small fw-bold">Property</label>
          <select name="property_type" class="form-select">
            <option value="">All Types</option>
            <option value="home" <?= $property_type=='home'?'selected':'' ?>>Home</option>
            <option value="apartment" <?= $property_type=='apartment'?'selected':'' ?>>Apartment</option>
            <option value="villa" <?= $property_type=='villa'?'selected':'' ?>>Villa</option>
            <option value="site" <?= $property_type=='site'?'selected':'' ?>>Site/Plot</option>
            <option value="commercial" <?= $property_type=='commercial'?'selected':'' ?>>Commercial</option>
          </select>
        </div>
        <div class="col-md-2">
          <label class="form-label small fw-bold">City</label>
          <input type="text" name="city" class="form-control" placeholder="Enter City" value="<?= $city ?>">
        </div>
        <div class="col-md-2">
          <label class="form-label small fw-bold">Bedrooms</label>
          <select name="bedrooms" class="form-select">
            <option value="">Any</option>
            <option value="1">1+</option><option value="2">2+</option>
            <option value="3">3+</option><option value="4">4+</option>
          </select>
        </div>
        <div class="col-md-2">
          <label class="form-label small fw-bold">Budget (Max ₹)</label>
          <input type="number" name="max_price" class="form-control" placeholder="Max Price" value="<?= $max ?>">
        </div>
        <div class="col-md-2">
          <button type="submit" class="btn btn-primary-custom w-100">🔍 Filter</button>
        </div>
      </form>
    </div>

    <!-- Results -->
    <div class="row g-4">
      <?php 
      $count = $props->num_rows;
      if($count == 0): ?>
      <div class="col-12 text-center py-5">
        <i class="fas fa-home fa-4x text-muted mb-3"></i>
        <h4 class="text-muted">No properties found. Try different filters.</h4>
        <a href="properties.php" class="btn btn-accent mt-3">Clear Filters</a>
      </div>
      <?php else: while($p = $props->fetch_assoc()): ?>
      <div class="col-lg-4 col-md-6">
        <a href="property-detail.php?id=<?= $p['id'] ?>" class="text-decoration-none" style="display:block;color:inherit">
        <div class="property-card" style="cursor:pointer">
          <div class="property-img-wrap">
            <img src="<?= $p['image_url'] ?? 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800' ?>" alt="<?= $p['title'] ?>">
            <span class="badge-type badge-<?= $p['listing_type'] ?>"><?= strtoupper($p['listing_type']) ?></span>
            <?php if($p['featured']): ?><span class="badge-featured">⭐ Featured</span><?php endif; ?>
            <?php if($p['status'] === 'sold'): ?>
            <div style="position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(220,53,69,.7);display:flex;align-items:center;justify-content:center;z-index:3">
              <span style="color:white;font-weight:800;font-size:1.6rem;text-shadow:0 2px 8px rgba(0,0,0,.3);letter-spacing:2px">🏷️ SOLD</span>
            </div>
            <?php elseif($p['status'] === 'rented'): ?>
            <div style="position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(245,158,11,.6);display:flex;align-items:center;justify-content:center;z-index:3">
              <span style="color:white;font-weight:800;font-size:1.4rem;text-shadow:0 2px 8px rgba(0,0,0,.3);letter-spacing:2px">🔑 RENTED</span>
            </div>
            <?php endif; ?>
          </div>
          <div class="card-body">
            <div class="property-price"><?= formatPrice($p['price']) ?><?= in_array($p['listing_type'], ['rent','pg']) ? '/mo' : '' ?></div>
            <h6 class="property-title"><?= $p['title'] ?></h6>
            <?php
              $verifyLevels = [
                ['Basic Verified','fa-check-circle','#4CAF50'],
                ['RERA Verified','fa-shield-alt','#2196F3'],
                ['Legal Verified','fa-gavel','#FF9800'],
                ['Premium','fa-award','#9C27B0'],
                ['Certified','fa-certificate','#FF6B35'],
              ];
              $vl = $verifyLevels[$p['id'] % 5];
            ?>
            <span class="prop-verify-badge" style="background:<?=$vl[2]?>"><?=$vl[0]?></span>
            <p class="property-location"><i class="fas fa-map-marker-alt me-1 text-danger"></i><?= $p['location'] ?>, <?= $p['city'] ?></p>
            <div class="property-features d-flex gap-3 flex-wrap">
              <?php if($p['bedrooms'] > 0): ?>
              <span><i class="fas fa-bed me-1"></i><?= $p['bedrooms'] ?> Bed</span>
              <?php endif; ?>
              <?php if($p['bathrooms'] > 0): ?>
              <span><i class="fas fa-bath me-1"></i><?= $p['bathrooms'] ?> Bath</span>
              <?php endif; ?>
              <span><i class="fas fa-ruler-combined me-1"></i><?= $p['area'] ?></span>
              <span class="badge bg-light text-dark"><?= ucfirst($p['type']) ?></span>
            </div>
            <div class="d-flex gap-2">
              <span class="btn btn-accent flex-fill mt-3">View Details</span>
              <?php if($p['status'] === 'sold'): ?>
                <span class="btn btn-danger mt-3 disabled" style="pointer-events:none"><i class="fas fa-tag me-1"></i>Sold</span>
              <?php elseif($p['status'] === 'rented'): ?>
                <span class="btn btn-warning mt-3 disabled text-dark" style="pointer-events:none"><i class="fas fa-key me-1"></i>Rented</span>
              <?php endif; ?>
            </div>
          </div>
        </div>
        </a>
      </div>
      <?php endwhile; endif; ?>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
